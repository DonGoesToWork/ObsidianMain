export type ActionName =
  // UI Actions
  | 'TOGGLE_CHARACTER_PANEL'
  | 'TOGGLE_QUEST_LOG'
  | 'TOGGLE_PERKS_PANEL'
  | 'TOGGLE_REPUTATION_PANEL'
  | 'TOGGLE_SETTINGS_PANEL'
  | 'TOGGLE_PARTY_PANEL'
  | 'TOGGLE_DEBUG_PANEL'
  // Out-of-Combat World Actions
  | 'WORLD_EXPLORE'
  | 'WORLD_WAIT'
  | 'WORLD_CRAFT'
  // Combat Actions
  | 'COMBAT_ATTACK'
  | 'COMBAT_INSPECT'
  | 'COMBAT_RANDOM_LIMB'
  | 'COMBAT_REPEAT_ACTION'
  | 'COMBAT_GUARD'
  | 'COMBAT_FLEE'
  | 'FAVORITE_ABILITY_1'
  | 'FAVORITE_ABILITY_2'
  | 'FAVORITE_ABILITY_3'
  | 'FAVORITE_ABILITY_4'
  | 'FAVORITE_ABILITY_5'
  | 'FAVORITE_ABILITY_6'
  | 'FAVORITE_ABILITY_7'
  | 'FAVORITE_ABILITY_8'
  | 'FAVORITE_ABILITY_9';

export const ACTION_CATEGORIES: Record<string, { name: string; actions: ActionName[] }> = {
  combat: {
    name: 'Combat',
    actions: [
      'COMBAT_ATTACK',
      'COMBAT_INSPECT',
      'COMBAT_RANDOM_LIMB',
      'COMBAT_REPEAT_ACTION',
      'COMBAT_GUARD',
      'COMBAT_FLEE',
      'FAVORITE_ABILITY_1',
      'FAVORITE_ABILITY_2',
      'FAVORITE_ABILITY_3',
      'FAVORITE_ABILITY_4',
      'FAVORITE_ABILITY_5',
      'FAVORITE_ABILITY_6',
      'FAVORITE_ABILITY_7',
      'FAVORITE_ABILITY_8',
      'FAVORITE_ABILITY_9',
    ],
  },
  world: {
    name: 'World',
    actions: ['WORLD_EXPLORE', 'WORLD_WAIT', 'WORLD_CRAFT'],
  },
  ui: {
    name: 'User Interface',
    actions: [
      'TOGGLE_CHARACTER_PANEL',
      'TOGGLE_QUEST_LOG',
      'TOGGLE_PERKS_PANEL',
      'TOGGLE_REPUTATION_PANEL',
      'TOGGLE_PARTY_PANEL',
      'TOGGLE_SETTINGS_PANEL',
      'TOGGLE_DEBUG_PANEL',
    ],
  },
};

export const ACTION_DISPLAY_NAMES: Record<ActionName, string> = {
  TOGGLE_CHARACTER_PANEL: 'Character Panel',
  TOGGLE_QUEST_LOG: 'Quest Log',
  TOGGLE_PERKS_PANEL: 'Skills & Perks',
  TOGGLE_REPUTATION_PANEL: 'Reputation Panel',
  TOGGLE_PARTY_PANEL: 'Party Panel',
  TOGGLE_SETTINGS_PANEL: 'Options Panel',
  TOGGLE_DEBUG_PANEL: 'Debug Menu',
  WORLD_EXPLORE: 'Explore / Return',
  WORLD_WAIT: 'Wait',
  WORLD_CRAFT: 'Craft',
  COMBAT_ATTACK: 'Attack',
  COMBAT_INSPECT: 'Inspect',
  COMBAT_RANDOM_LIMB: 'Random Limb',
  COMBAT_REPEAT_ACTION: 'Repeat Action',
  COMBAT_GUARD: 'Guard',
  COMBAT_FLEE: 'Flee',
  FAVORITE_ABILITY_1: 'Favorite Ability 1',
  FAVORITE_ABILITY_2: 'Favorite Ability 2',
  FAVORITE_ABILITY_3: 'Favorite Ability 3',
  FAVORITE_ABILITY_4: 'Favorite Ability 4',
  FAVORITE_ABILITY_5: 'Favorite Ability 5',
  FAVORITE_ABILITY_6: 'Favorite Ability 6',
  FAVORITE_ABILITY_7: 'Favorite Ability 7',
  FAVORITE_ABILITY_8: 'Favorite Ability 8',
  FAVORITE_ABILITY_9: 'Favorite Ability 9',
};

export type HotkeyConfig = {
  primary: string | null;
  secondary: string | null;
};

// using KeyboardEvent.code
export const DEFAULT_HOTKEYS: Record<ActionName, HotkeyConfig> = {
  TOGGLE_CHARACTER_PANEL: { primary: 'KeyC', secondary: null },
  TOGGLE_QUEST_LOG: { primary: 'KeyQ', secondary: null },
  TOGGLE_PERKS_PANEL: { primary: 'KeyN', secondary: null },
  TOGGLE_REPUTATION_PANEL: { primary: 'KeyU', secondary: null },
  TOGGLE_PARTY_PANEL: { primary: 'KeyK', secondary: null },
  TOGGLE_SETTINGS_PANEL: { primary: 'KeyO', secondary: null },
  TOGGLE_DEBUG_PANEL: { primary: 'KeyD', secondary: null },
  WORLD_EXPLORE: { primary: 'KeyE', secondary: null },
  WORLD_WAIT: { primary: 'KeyW', secondary: 'KeyR' },
  WORLD_CRAFT: { primary: 'KeyT', secondary: null },
  COMBAT_ATTACK: { primary: 'Digit1', secondary: null },
  COMBAT_INSPECT: { primary: 'KeyI', secondary: null },
  COMBAT_RANDOM_LIMB: { primary: 'Digit2', secondary: null },
  COMBAT_REPEAT_ACTION: { primary: 'Digit3', secondary: null },
  COMBAT_GUARD: { primary: 'KeyG', secondary: null },
  COMBAT_FLEE: { primary: 'KeyF', secondary: null },
  FAVORITE_ABILITY_1: { primary: 'Digit4', secondary: null },
  FAVORITE_ABILITY_2: { primary: 'Digit5', secondary: null },
  FAVORITE_ABILITY_3: { primary: 'Digit6', secondary: null },
  FAVORITE_ABILITY_4: { primary: 'Digit7', secondary: null },
  FAVORITE_ABILITY_5: { primary: 'Digit8', secondary: null },
  FAVORITE_ABILITY_6: { primary: 'Digit9', secondary: null },
  FAVORITE_ABILITY_7: { primary: 'Digit0', secondary: null },
  FAVORITE_ABILITY_8: { primary: 'Minus', secondary: null },
  FAVORITE_ABILITY_9: { primary: 'Equal', secondary: null },
};

export const formatKeyCode = (code: string | null): string => {
  if (!code) return '';
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  if (code === 'Minus') return '-';
  if (code === 'Equal') return '=';
  return code;
};

export const getHotkeyDisplay = (hotkeyConfig: HotkeyConfig | undefined): string => {
  if (!hotkeyConfig) return '';

  const primaryDisplay = formatKeyCode(hotkeyConfig.primary);
  const secondaryDisplay = formatKeyCode(hotkeyConfig.secondary);

  const keys = [primaryDisplay, secondaryDisplay].filter(Boolean);

  if (keys.length === 0) return '';
  return ` (${keys.join(',')})`;
};