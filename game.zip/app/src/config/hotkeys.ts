export type ActionName =
  // UI Actions
  | "TOGGLE_CHARACTER_PANEL"
  | "TOGGLE_QUEST_LOG"
  | "TOGGLE_PERKS_PANEL"
  | "TOGGLE_REPUTATION_PANEL"
  | "TOGGLE_SETTINGS_PANEL"
  | "TOGGLE_PARTY_PANEL"
  | "TOGGLE_DEBUG_PANEL"
  // Out-of-Combat World Actions
  | "WORLD_EXPLORE"
  | "WORLD_REST"
  | "WORLD_CRAFT"
  // Combat Actions
  | "COMBAT_ATTACK"
  | "COMBAT_INSPECT"
  | "COMBAT_RANDOM_LIMB"
  | "COMBAT_REPEAT_ACTION"
  | "COMBAT_GUARD"
  | "COMBAT_FLEE"
  | "FAVORITE_ABILITY_1"
  | "FAVORITE_ABILITY_2"
  | "FAVORITE_ABILITY_3"
  | "FAVORITE_ABILITY_4"
  | "FAVORITE_ABILITY_5"
  | "FAVORITE_ABILITY_6"
  | "FAVORITE_ABILITY_7"
  | "FAVORITE_ABILITY_8"
  | "FAVORITE_ABILITY_9";

export const ACTION_CATEGORIES: Record<
  string,
  { name: string; actions: ActionName[] }
> = {
  combat: {
    name: "Combat",
    actions: [
      "COMBAT_ATTACK",
      "COMBAT_INSPECT",
      "COMBAT_RANDOM_LIMB",
      "COMBAT_REPEAT_ACTION",
      "COMBAT_GUARD",
      "COMBAT_FLEE",
      "FAVORITE_ABILITY_1",
      "FAVORITE_ABILITY_2",
      "FAVORITE_ABILITY_3",
      "FAVORITE_ABILITY_4",
      "FAVORITE_ABILITY_5",
      "FAVORITE_ABILITY_6",
      "FAVORITE_ABILITY_7",
      "FAVORITE_ABILITY_8",
      "FAVORITE_ABILITY_9",
    ],
  },
  world: {
    name: "World",
    actions: ["WORLD_EXPLORE", "WORLD_REST", "WORLD_CRAFT"],
  },
  ui: {
    name: "User Interface",
    actions: [
      "TOGGLE_CHARACTER_PANEL",
      "TOGGLE_QUEST_LOG",
      "TOGGLE_PERKS_PANEL",
      "TOGGLE_REPUTATION_PANEL",
      "TOGGLE_PARTY_PANEL",
      "TOGGLE_SETTINGS_PANEL",
      "TOGGLE_DEBUG_PANEL",
    ],
  },
};

export const ACTION_DISPLAY_NAMES: Record<ActionName, string> = {
  TOGGLE_CHARACTER_PANEL: "Character Panel",
  TOGGLE_QUEST_LOG: "Quest Log",
  TOGGLE_PERKS_PANEL: "Perks Panel",
  TOGGLE_REPUTATION_PANEL: "Reputation Panel",
  TOGGLE_PARTY_PANEL: "Party Panel",
  TOGGLE_SETTINGS_PANEL: "Options Panel",
  TOGGLE_DEBUG_PANEL: "Debug Menu",
  WORLD_EXPLORE: "Explore / Return",
  WORLD_REST: "Rest",
  WORLD_CRAFT: "Craft",
  COMBAT_ATTACK: "Attack",
  COMBAT_INSPECT: "Inspect",
  COMBAT_RANDOM_LIMB: "Random Limb",
  COMBAT_REPEAT_ACTION: "Repeat Action",
  COMBAT_GUARD: "Guard",
  COMBAT_FLEE: "Flee",
  FAVORITE_ABILITY_1: "Favorite Ability 1",
  FAVORITE_ABILITY_2: "Favorite Ability 2",
  FAVORITE_ABILITY_3: "Favorite Ability 3",
  FAVORITE_ABILITY_4: "Favorite Ability 4",
  FAVORITE_ABILITY_5: "Favorite Ability 5",
  FAVORITE_ABILITY_6: "Favorite Ability 6",
  FAVORITE_ABILITY_7: "Favorite Ability 7",
  FAVORITE_ABILITY_8: "Favorite Ability 8",
  FAVORITE_ABILITY_9: "Favorite Ability 9",
};

// using KeyboardEvent.code
export const DEFAULT_HOTKEYS: Record<ActionName, string> = {
  TOGGLE_CHARACTER_PANEL: "KeyC",
  TOGGLE_QUEST_LOG: "KeyQ",
  TOGGLE_PERKS_PANEL: "KeyN",
  TOGGLE_REPUTATION_PANEL: "KeyU",
  TOGGLE_PARTY_PANEL: "KeyK",
  TOGGLE_SETTINGS_PANEL: "KeyO",
  TOGGLE_DEBUG_PANEL: "KeyD",
  WORLD_EXPLORE: "KeyE",
  WORLD_REST: "KeyR",
  WORLD_CRAFT: "KeyT",
  COMBAT_ATTACK: "Digit1",
  COMBAT_INSPECT: "KeyI",
  COMBAT_RANDOM_LIMB: "Digit2",
  COMBAT_REPEAT_ACTION: "Digit3",
  COMBAT_GUARD: "KeyG",
  COMBAT_FLEE: "KeyF",
  FAVORITE_ABILITY_1: "Digit4",
  FAVORITE_ABILITY_2: "Digit5",
  FAVORITE_ABILITY_3: "Digit6",
  FAVORITE_ABILITY_4: "Digit7",
  FAVORITE_ABILITY_5: "Digit8",
  FAVORITE_ABILITY_6: "Digit9",
  FAVORITE_ABILITY_7: "Digit0",
  FAVORITE_ABILITY_8: "Minus",
  FAVORITE_ABILITY_9: "Equal",
};

export const getHotkeyDisplay = (code: string | undefined): string => {
  if (!code) return "";
  if (code.startsWith("Key")) return code.slice(3);
  if (code.startsWith("Digit")) return code.slice(5);
  if (code === "Minus") return "-";
  if (code === "Equal") return "=";
  return code;
};
