import { ActionName } from "./hotkeys";
import { CombatContextType } from "types";

export type MainPanelTabConfig = {
  modal: string;
  label: string;
  action: ActionName;
  props?: Record<string, any>;
};

export const MAIN_PANEL_TABS: readonly MainPanelTabConfig[] = [
  { modal: "character", label: "Character", action: "TOGGLE_CHARACTER_PANEL" },
  { modal: "party-modal", label: "Party", action: "TOGGLE_PARTY_PANEL" },
  { modal: "quest-log", label: "Quest Log", action: "TOGGLE_QUEST_LOG" },
  { modal: "perks-modal", label: "Perks", action: "TOGGLE_PERKS_PANEL" },
  {
    modal: "not-implemented",
    label: "Reputations",
    action: "TOGGLE_REPUTATION_PANEL",
    props: { title: "Reputations" },
  },
  {
    modal: "settings-modal",
    label: "Options",
    action: "TOGGLE_SETTINGS_PANEL",
  },
  { modal: "debug-modal", label: "Debug", action: "TOGGLE_DEBUG_PANEL" },
];

export type CombatActionConfig = {
  id: string;
  label: string;
  actionName: ActionName;
  onClick?: (context: CombatContextType) => void;
  action?: { type: "attack" | "inspect"; skillId: null };
  disabled?: (context: CombatContextType) => boolean;
};

export const COMBAT_ACTIONS: readonly CombatActionConfig[] = [
  {
    id: "attack",
    label: "Attack",
    actionName: "COMBAT_ATTACK",
    action: { type: "attack", skillId: null },
  },
  {
    id: "randomLimb",
    label: "Random Limb",
    actionName: "COMBAT_RANDOM_LIMB",
    onClick: (ctx) => {
      if (
        ctx.selectedAction &&
        ctx.selectedAction.type !== "inspect" &&
        ctx.selectedTargetId
      ) {
        ctx.playerTargetRandomLimb(
          ctx.selectedTargetId,
          ctx.selectedAction.type,
          ctx.selectedAction.skillId,
        );
        ctx.setSelectedAction(null);
      }
    },
    disabled: (ctx) =>
      !ctx.selectedAction ||
      ctx.selectedAction.type === "inspect" ||
      !ctx.selectedTargetId,
  },
  {
    id: "repeat",
    label: "Repeat",
    actionName: "COMBAT_REPEAT_ACTION",
    onClick: (ctx) => ctx.playerRepeatLastAction(),
  },
  {
    id: "guard",
    label: "Guard",
    actionName: "COMBAT_GUARD",
    onClick: (ctx) => ctx.playerUseSkill("s_guard", "player", null, false),
    disabled: (ctx) =>
      !!ctx.currentCombat && ctx.currentCombat.combatants.player.sp < 10,
  },
  {
    id: "inspect",
    label: "Inspect",
    actionName: "COMBAT_INSPECT",
    action: { type: "inspect", skillId: null },
  },
  {
    id: "flee",
    label: "Flee",
    actionName: "COMBAT_FLEE",
    onClick: (ctx) => ctx.playerFlee(),
  },
];

export const FAVORITE_ABILITY_HOTKEYS: Record<number, ActionName> = {
  0: "FAVORITE_ABILITY_1",
  1: "FAVORITE_ABILITY_2",
  2: "FAVORITE_ABILITY_3",
  3: "FAVORITE_ABILITY_4",
  4: "FAVORITE_ABILITY_5",
  5: "FAVORITE_ABILITY_6",
  7: "FAVORITE_ABILITY_7",
  8: "FAVORITE_ABILITY_8",
  9: "FAVORITE_ABILITY_9",
};