import { ColumnDef } from 'components/shared/UnifiedInventoryDisplay';
import { GameData } from 'types';
import { calculateItemValue, getItemName, getItemWeight } from 'utils/itemUtils';

export const getStandardInventoryColumns = (GAME_DATA: GameData): ColumnDef[] => [
  {
    key: 'name',
    label: 'Name',
    render: (item, group) => `${getItemName(item, GAME_DATA)}${group.count > 1 ? ` (${group.count})` : ''}`,
    className: 'inventory-row-name',
    isSortable: true,
  },
  {
    key: 'type',
    label: 'Type',
    render: (item) => GAME_DATA.ITEMS[item.id].type.join(', '),
    className: 'inventory-row-type',
    isSortable: true,
  },
  {
    key: 'value',
    label: 'Value',
    render: (item) => `${calculateItemValue(item, GAME_DATA)}g`,
    className: 'inventory-row-value',
    isSortable: true,
  },
  {
    key: 'weight',
    label: 'Weight',
    render: (item) => getItemWeight(item, GAME_DATA).toFixed(1),
    className: 'inventory-row-weight',
    isSortable: true,
  },
];