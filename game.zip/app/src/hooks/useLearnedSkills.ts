import { GameDataContext } from 'context/GameDataContext';
import { useContext, useMemo } from 'react';
import { AbilityId, Combatant, Mercenary, Player } from 'types';

export const useLearnedSkills = (character: Player | Mercenary | Combatant | null, type: 'active' | 'Skill' | 'Spell' | 'Perk') => {
  const GAME_DATA = useContext(GameDataContext)!;
  const abilityIds = useMemo(() => {
    if (!character?.skills) return [];
    return (Object.keys(character.skills) as AbilityId[])
      .filter((id) => {
        const ability = GAME_DATA.SKILLS[id];
        if (!ability) return false;
        if (type === 'active') {
          return ability.abilityType === 'Skill' || ability.abilityType === 'Spell';
        }
        return ability.abilityType === type;
      })
      .sort((a, b) => {
        const skillA = GAME_DATA.SKILLS[a];
        const skillB = GAME_DATA.SKILLS[b];
        return (skillA.levelReq || 0) - (skillB.levelReq || 0) || skillA.name.localeCompare(skillB.name);
      });
  }, [character, type, GAME_DATA.SKILLS]);

  return abilityIds;
};
