import { calculateItemValue } from 'utils/itemUtils';
import { formatDuration } from 'utils/formatUtils';
import { ItemId, ItemInstance } from 'types';
import { WorldContext } from 'context/WorldContext';
import { useContext, useMemo, useState } from 'react';
import { GameDataContext } from 'context/GameDataContext';
import { ShopContext } from 'context/ShopContext';
import { usePlayer } from './usePlayer';

export const useShop = () => {
  const player = usePlayer();
  const GAME_DATA = useContext(GameDataContext)!;
  const { getShopStock, executeTrade, refreshShopInventory } = useContext(ShopContext)!;
  const { gameTime, currentLocation } = useContext(WorldContext)!;

  const [playerOfferItems, setPlayerOfferItems] = useState<ItemInstance[]>([]);
  const [merchantOfferItems, setMerchantOfferItems] = useState<ItemInstance[]>([]);

  const shopData = useMemo(() => {
    if (!player || !currentLocation) return { stock: {}, uniqueStock: [], lastRefreshed: 0 };
    return getShopStock(currentLocation.id);
  }, [currentLocation, getShopStock, player]);

  const allMerchantItems = useMemo(() => {
    const items: ItemInstance[] = [];
    if (!shopData) return items;

    items.push(...shopData.uniqueStock);

    Object.entries(shopData.stock).forEach(([itemId, quantity]) => {
      const itemData = GAME_DATA.ITEMS[itemId as ItemId];
      if (!itemData.stackable) {
        for (let i = 0; i < quantity; i++) {
          items.push({ id: itemId as ItemId, unique_id: `shop_base_${itemId}_${i}`, enchantments: {}, plus_value: 0 });
        }
      } else {
        items.push({ id: itemId as ItemId, unique_id: `shop_base_${itemId}_0`, enchantments: {}, plus_value: 0 });
      }
    });

    return items;
  }, [shopData, GAME_DATA.ITEMS]);

  const playerItemsForDisplay = useMemo(() => {
    if (!player) return [];
    const offeredIds = new Set(playerOfferItems.map((i) => i.unique_id));
    return player.inventory.filter((i) => !offeredIds.has(i.unique_id));
  }, [player, playerOfferItems]);

  const merchantItemsForDisplay = useMemo(() => {
    const offeredIds = new Set(merchantOfferItems.map((i) => i.unique_id));
    return allMerchantItems.filter((i) => !offeredIds.has(i.unique_id));
  }, [allMerchantItems, merchantOfferItems]);

  const handlePlayerTransfer = (item: ItemInstance, quantity: number) => {
    const itemsToMove: ItemInstance[] = [];
    const itemData = GAME_DATA.ITEMS[item.id];
    if (itemData.stackable) {
      itemsToMove.push(item);
    } else {
      for (let i = 0; i < quantity; i++) {
        itemsToMove.push(playerItemsForDisplay.find((pItem) => pItem.unique_id === item.unique_id)!);
      }
    }
    setPlayerOfferItems((prev) => [...prev, ...itemsToMove]);
  };

  const handleMerchantTransfer = (item: ItemInstance, quantity: number) => {
    const itemsToMove: ItemInstance[] = [];
    const itemData = GAME_DATA.ITEMS[item.id];
    if (itemData.stackable) {
      itemsToMove.push(item);
    } else {
      for (let i = 0; i < quantity; i++) {
        const foundItem = merchantItemsForDisplay.find((mItem) => mItem.id === item.id);
        if (foundItem) itemsToMove.push(foundItem);
      }
    }
    setMerchantOfferItems((prev) => [...prev, ...itemsToMove]);
  };

  const handleReturnFromPlayerOffer = (item: ItemInstance, quantity: number) => {
    setPlayerOfferItems((prev) => {
      const newOffer = [...prev];
      let removed = 0;
      return newOffer.filter((offerItem) => {
        if (offerItem.unique_id === item.unique_id && removed < quantity) {
          removed++;
          return false;
        }
        return true;
      });
    });
  };

  const handleReturnFromMerchantOffer = (item: ItemInstance, quantity: number) => {
    setMerchantOfferItems((prev) => {
      const newOffer = [...prev];
      let removed = 0;
      return newOffer.filter((offerItem) => {
        if (offerItem.unique_id === item.unique_id && removed < quantity) {
          removed++;
          return false;
        }
        return true;
      });
    });
  };

  const handleReset = () => {
    setPlayerOfferItems([]);
    setMerchantOfferItems([]);
  };

  const handleAccept = () => {
    if (!currentLocation) return;
    executeTrade(currentLocation.id, playerOfferItems, merchantOfferItems);
    handleReset();
  };

  const playerItemsValue = useMemo(
    () => playerOfferItems.reduce((acc, item) => acc + (Math.floor(calculateItemValue(item, GAME_DATA) / 4) || 1), 0),
    [playerOfferItems, GAME_DATA],
  );

  const merchantItemsValue = useMemo(() => merchantOfferItems.reduce((sum, item) => sum + calculateItemValue(item, GAME_DATA), 0), [merchantOfferItems, GAME_DATA]);

  const playerGoldChange = playerItemsValue - merchantItemsValue;
  const canAccept = player!.gold + playerGoldChange >= 0;

  const shopInfo = useMemo(() => {
    if (!player || !currentLocation) return { lastRefreshed: 0, timeToRestock: 'N/A' };
    const shopData = player.shopInventories[currentLocation.id];
    if (!shopData) return { lastRefreshed: 0, timeToRestock: 'N/A' };
    const lastRefreshed = shopData.lastRefreshed || 0;
    const now = gameTime.getTime();
    const oneDay = 24 * 60 * 60 * 1000;
    const timeToRefresh = Math.max(0, oneDay - (now - lastRefreshed));
    const minutesToRefresh = timeToRefresh / 60000;
    return {
      lastRefreshed,
      timeToRestock: formatDuration(minutesToRefresh),
    };
  }, [player, currentLocation, gameTime]);

  return {
    player,
    currentLocation,
    playerItemsForDisplay,
    merchantItemsForDisplay,
    playerOfferItems,
    merchantOfferItems,
    playerItemsValue,
    merchantItemsValue,
    playerGoldChange,
    canAccept,
    shopInfo,
    handlePlayerTransfer,
    handleMerchantTransfer,
    handleReturnFromPlayerOffer,
    handleReturnFromMerchantOffer,
    handleReset,
    handleAccept,
    refreshShopInventory,
  };
};