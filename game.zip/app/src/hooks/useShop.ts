import { GameDataContext } from 'context/GameDataContext';
import { ShopContext } from 'context/ShopContext';
import { WorldContext } from 'context/WorldContext';
import { useContext, useMemo, useState } from 'react';
import { ItemId, ItemInstance } from 'types';
import { formatDuration } from 'utils/formatUtils';
import { calculateItemValue } from 'utils/itemUtils';
import { usePlayer } from './usePlayer';

export const useShop = () => {
  const player = usePlayer();
  const GAME_DATA = useContext(GameDataContext)!;
  const { getShopStock, executeTrade, refreshShopInventory } = useContext(ShopContext)!;
  const { gameTime, currentLocation, worldLocationsState } = useContext(WorldContext)!;

  const [playerOfferItems, setPlayerOfferItems] = useState<ItemInstance[]>([]);
  const [merchantOfferItems, setMerchantOfferItems] = useState<ItemInstance[]>([]);

  const shopData = useMemo(() => {
    if (!player || !currentLocation) return { stock: {}, uniqueStock: [], lastRefreshed: 0 };
    return getShopStock(currentLocation.id);
  }, [currentLocation, getShopStock, player, worldLocationsState]);

  const allMerchantItems = useMemo(() => {
    const items: ItemInstance[] = [];
    if (!shopData) return items;

    items.push(...shopData.uniqueStock);

    Object.entries(shopData.stock).forEach(([itemId, quantity]) => {
      const itemData = GAME_DATA.ITEMS[itemId as ItemId];
      if (!itemData.stackable) {
        for (let i = 0; i < quantity; i++) {
          items.push({ id: itemId as ItemId, unique_id: `shop_base_${itemId}_${i}`, quantity: 1, enchantments: {}, plus_value: 0 });
        }
      } else {
        items.push({ id: itemId as ItemId, unique_id: `shop_base_${itemId}_0`, quantity: quantity, enchantments: {}, plus_value: 0 });
      }
    });

    return items;
  }, [shopData, GAME_DATA.ITEMS]);

  const playerItemsForDisplay = useMemo(() => {
    if (!player) return [];

    const unstackableOfferedIds = new Set(playerOfferItems.filter((item) => !GAME_DATA.ITEMS[item.id].stackable).map((item) => item.unique_id));

    const stackableOfferedQuantities = playerOfferItems
      .filter((item) => GAME_DATA.ITEMS[item.id].stackable)
      .reduce((acc, item) => {
        acc[item.id] = (acc[item.id] || 0) + item.quantity;
        return acc;
      }, {} as Record<string, number>);

    const displayItems: ItemInstance[] = [];
    player.inventory.forEach((invItem) => {
      if (GAME_DATA.ITEMS[invItem.id].stackable) {
        const offeredQty = stackableOfferedQuantities[invItem.id] || 0;
        if (invItem.quantity > offeredQty) {
          displayItems.push({ ...invItem, quantity: invItem.quantity - offeredQty });
        }
      } else {
        if (!unstackableOfferedIds.has(invItem.unique_id)) {
          displayItems.push(invItem);
        }
      }
    });
    return displayItems;
  }, [player, playerOfferItems, GAME_DATA.ITEMS]);

  const merchantItemsForDisplay = useMemo(() => {
    const unstackableOfferedIds = new Set(merchantOfferItems.filter((item) => !GAME_DATA.ITEMS[item.id].stackable).map((item) => item.unique_id));
    const stackableOfferedQuantities = merchantOfferItems
      .filter((item) => GAME_DATA.ITEMS[item.id].stackable)
      .reduce((acc, item) => {
        acc[item.id] = (acc[item.id] || 0) + item.quantity;
        return acc;
      }, {} as Record<string, number>);

    const displayItems: ItemInstance[] = [];
    allMerchantItems.forEach((shopItem) => {
      if (GAME_DATA.ITEMS[shopItem.id].stackable) {
        const offeredQty = stackableOfferedQuantities[shopItem.id] || 0;
        if (shopItem.quantity > offeredQty) {
          displayItems.push({ ...shopItem, quantity: shopItem.quantity - offeredQty });
        }
      } else {
        if (!unstackableOfferedIds.has(shopItem.unique_id)) {
          displayItems.push(shopItem);
        }
      }
    });
    return displayItems;
  }, [allMerchantItems, merchantOfferItems, GAME_DATA.ITEMS]);

  const handlePlayerTransfer = (item: ItemInstance, quantity: number, _indices: number[]) => {
    const isStackable = GAME_DATA.ITEMS[item.id].stackable;

    setPlayerOfferItems((prev) => {
      const newOffers = [...prev];
      if (isStackable) {
        const existingIndex = newOffers.findIndex((i) => i.id === item.id);
        if (existingIndex > -1) {
          newOffers[existingIndex].quantity += quantity;
        } else {
          newOffers.push({ ...item, quantity });
        }
      } else {
        newOffers.push({ ...item, quantity: 1 });
      }
      return newOffers;
    });
  };

  const handleMerchantTransfer = (item: ItemInstance, quantity: number, _indices: number[]) => {
    const isStackable = GAME_DATA.ITEMS[item.id].stackable;

    setMerchantOfferItems((prev) => {
      const newOffers = [...prev];
      if (isStackable) {
        const existingIndex = newOffers.findIndex((i) => i.id === item.id);
        if (existingIndex > -1) {
          newOffers[existingIndex].quantity += quantity;
        } else {
          newOffers.push({ ...item, quantity });
        }
      } else {
        newOffers.push({ ...item, quantity: 1 });
      }
      return newOffers;
    });
  };

  const handleReturnFromPlayerOffer = (item: ItemInstance, quantity: number, _indices: number[]) => {
    setPlayerOfferItems((prev) => {
      const isStackable = GAME_DATA.ITEMS[item.id].stackable;
      if (isStackable) {
        const newOffers = [...prev];
        const existingIndex = newOffers.findIndex((i) => i.id === item.id);
        if (existingIndex > -1) {
          newOffers[existingIndex].quantity -= quantity;
          if (newOffers[existingIndex].quantity <= 0) {
            newOffers.splice(existingIndex, 1);
          }
        }
        return newOffers;
      } else {
        const indexToRemove = prev.findIndex((i) => i.unique_id === item.unique_id);
        if (indexToRemove > -1) {
          const newOffers = [...prev];
          newOffers.splice(indexToRemove, 1);
          return newOffers;
        }
      }
      return prev;
    });
  };

  const handleReturnFromMerchantOffer = (item: ItemInstance, quantity: number, _indices: number[]) => {
    setMerchantOfferItems((prev) => {
      const isStackable = GAME_DATA.ITEMS[item.id].stackable;
      if (isStackable) {
        const newOffers = [...prev];
        const existingIndex = newOffers.findIndex((i) => i.id === item.id);
        if (existingIndex > -1) {
          newOffers[existingIndex].quantity -= quantity;
          if (newOffers[existingIndex].quantity <= 0) {
            newOffers.splice(existingIndex, 1);
          }
        }
        return newOffers;
      } else {
        const indexToRemove = prev.findIndex((i) => i.unique_id === item.unique_id);
        if (indexToRemove > -1) {
          const newOffers = [...prev];
          newOffers.splice(indexToRemove, 1);
          return newOffers;
        }
      }
      return prev;
    });
  };

  const handleReset = () => {
    setPlayerOfferItems([]);
    setMerchantOfferItems([]);
  };

  const handleAccept = () => {
    if (!currentLocation) return;
    executeTrade(currentLocation.id, playerOfferItems, merchantOfferItems);
    handleReset();
  };

  const playerItemsValue = useMemo(() => playerOfferItems.reduce((acc, item) => acc + (Math.floor(calculateItemValue(item, GAME_DATA) / 4) || 1) * item.quantity, 0), [
    playerOfferItems,
    GAME_DATA,
  ]);

  const merchantItemsValue = useMemo(() => merchantOfferItems.reduce((sum, item) => sum + calculateItemValue(item, GAME_DATA) * item.quantity, 0), [
    merchantOfferItems,
    GAME_DATA,
  ]);

  const playerGoldChange = playerItemsValue - merchantItemsValue;
  const canAccept = player!.gold + playerGoldChange >= 0;

  const shopInfo = useMemo(() => {
    if (!player || !currentLocation) return { lastRefreshed: 0, timeToRestock: 'N/A' };
    const shopData = getShopStock(currentLocation.id);
    if (!shopData) return { lastRefreshed: 0, timeToRestock: 'N/A' };

    const lastRefreshDate = new Date(shopData.lastRefreshed || 0);
    const nextRefreshTime = new Date(lastRefreshDate);
    nextRefreshTime.setDate(nextRefreshTime.getDate() + 1);
    nextRefreshTime.setHours(6, 0, 0, 0);

    const timeToRefreshMs = Math.max(0, nextRefreshTime.getTime() - gameTime.getTime());
    const minutesToRefresh = timeToRefreshMs / 60000;

    return {
      lastRefreshed: shopData.lastRefreshed,
      timeToRestock: formatDuration(minutesToRefresh),
    };
  }, [player, currentLocation, gameTime, getShopStock, worldLocationsState]);

  return {
    player,
    currentLocation,
    playerItemsForDisplay,
    merchantItemsForDisplay,
    playerOfferItems,
    merchantOfferItems,
    playerItemsValue,
    merchantItemsValue,
    playerGoldChange,
    canAccept,
    shopInfo,
    handlePlayerTransfer,
    handleMerchantTransfer,
    handleReturnFromPlayerOffer,
    handleReturnFromMerchantOffer,
    handleReset,
    handleAccept,
    refreshShopInventory,
  };
};