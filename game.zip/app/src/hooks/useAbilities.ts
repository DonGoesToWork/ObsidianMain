import { useContext } from 'react';
import { useLearnedSkills } from 'hooks/useLearnedSkills';
import { CharacterContext } from 'context/CharacterContext';
import { usePlayer } from './usePlayer';

export const useAbilities = () => {
  const player = usePlayer();
  const characterContext = useContext(CharacterContext);

  if (!characterContext) {
    throw new Error('useAbilities must be used within the required providers');
  }

  const { learnAbility, learnPerk, toggleFavoriteAbility } = characterContext;

  const learnedSkills = useLearnedSkills(player, 'Skill');
  const learnedSpells = useLearnedSkills(player, 'Spell');
  const learnedPerks = useLearnedSkills(player, 'Perk');

  return {
    skills: player?.skills,
    favoriteAbilities: player?.favoriteAbilities,
    perkPoints: player?.perkPoints,
    learnedSkills,
    learnedSpells,
    learnedPerks,
    learnAbility,
    learnPerk,
    toggleFavoriteAbility,
  };
};