import { UIContext } from 'context/UIContext';
import { useCallback, useContext } from 'react';
import { ViewMode } from 'types';

type ModalSetting = 'viewMode' | 'transferAmount';

export const useModalState = (modalId: string, uiKey: string | undefined) => {
  const { modalUiSettings, setModalUiSettings } = useContext(UIContext)!;

  const getSetting = useCallback(
    <T>(setting: ModalSetting, defaultValue: T): T => {
      if (!uiKey) return defaultValue;
      return (modalUiSettings[modalId]?.[uiKey]?.[setting] as T) ?? defaultValue;
    },
    [modalUiSettings, modalId, uiKey]
  );

  const updateSetting = useCallback(
    (setting: ModalSetting, value: any) => {
      if (!uiKey) return;
      setModalUiSettings((prev) => ({
        ...prev,
        [modalId]: {
          ...prev[modalId],
          [uiKey]: {
            ...(prev[modalId]?.[uiKey] ?? {}),
            [setting]: value,
          },
        },
      }));
    },
    [setModalUiSettings, modalId, uiKey]
  );

  const viewMode = getSetting<ViewMode>('viewMode', 'simple');
  const transferAmount = getSetting<number>('transferAmount', 1);

  const setViewMode = useCallback((mode: ViewMode) => updateSetting('viewMode', mode), [updateSetting]);
  const setTransferAmount = useCallback((amount: number) => updateSetting('transferAmount', amount), [updateSetting]);

  return {
    viewMode,
    transferAmount,
    setViewMode,
    setTransferAmount,
  };
};
