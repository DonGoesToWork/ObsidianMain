import { UIContext } from 'context/UIContext';
import { useCallback, useContext } from 'react';
import { SortDirection, SortKey, ViewMode } from 'types';

type ModalSetting = 'viewMode' | 'transferAmount' | 'sortConfig';

export const useModalState = (modalId: string, uiKey: string | undefined) => {
  const { modalUiSettings, setModalUiSettings } = useContext(UIContext)!;

  const getSetting = useCallback(
    <T,>(setting: ModalSetting): T | undefined => {
      if (!uiKey) return undefined;
      return modalUiSettings[modalId]?.[uiKey]?.[setting] as T;
    },
    [modalUiSettings, modalId, uiKey]
  );

  const updateSetting = useCallback(
    (setting: ModalSetting, value: any) => {
      if (!uiKey) return;
      setModalUiSettings((prev) => ({
        ...prev,
        [modalId]: {
          ...prev[modalId],
          [uiKey]: {
            ...(prev[modalId]?.[uiKey] ?? {}),
            [setting]: value,
          },
        },
      }));
    },
    [setModalUiSettings, modalId, uiKey]
  );

  const viewMode = getSetting<ViewMode>('viewMode') ?? 'simple';
  const transferAmount = getSetting<number>('transferAmount') ?? 1;
  const sortConfig = getSetting<{ key: SortKey; direction: SortDirection } | null>('sortConfig');

  const setViewMode = useCallback((mode: ViewMode) => updateSetting('viewMode', mode), [updateSetting]);
  const setTransferAmount = useCallback((amount: number) => updateSetting('transferAmount', amount), [updateSetting]);
  const setSortConfig = useCallback((config: { key: SortKey; direction: SortDirection } | null) => updateSetting('sortConfig', config), [updateSetting]);

  return {
    viewMode,
    transferAmount,
    sortConfig,
    setViewMode,
    setTransferAmount,
    setSortConfig,
  };
};