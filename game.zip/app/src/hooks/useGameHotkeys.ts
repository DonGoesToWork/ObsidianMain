import { CombatContext } from 'context/CombatContext';
import { GameDataContext } from 'context/GameDataContext';
import { LogContext } from 'context/LogContext';
import { UIContext } from 'context/UIContext';
import { WorldContext } from 'context/WorldContext';
import { useContext, useEffect } from 'react';
import { ActionName } from '../config/hotkeys';
import { HotkeyContext } from '../context/HotkeyContext';
import { useAbilities } from './useAbilities';
import { usePlayer } from './usePlayer';

export const useGameHotkeys = () => {
  const player = usePlayer();
  const { favoriteAbilities } = useAbilities();
  const uiContext = useContext(UIContext);
  const worldContext = useContext(WorldContext);
  const combatContext = useContext(CombatContext);
  const logContext = useContext(LogContext);
  const hotkeyContext = useContext(HotkeyContext);
  const GAME_DATA = useContext(GameDataContext);

  useEffect(() => {
    if (!uiContext || !worldContext || !combatContext || !hotkeyContext || !logContext || !GAME_DATA) return;

    const { modalStack, setActiveModal } = uiContext;
    const { logMessage } = logContext;
    const { gameState, changeGameState, currentLocation, travelTo, castAbilityOutOfCombat } = worldContext;
    const { currentCombat, setSelectedAction, playerTargetRandomLimb, selectedTargetId, selectedAction, playerRepeatLastAction, playerUseSkill, playerFlee } = combatContext;
    const { hotkeys } = hotkeyContext;

    const handleKeyDown = (e: KeyboardEvent) => {
      const isTyping =
        document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA' || document.activeElement?.classList.contains('hotkey-input-btn');

      if (e.key === 'Escape' && modalStack.length > 0) {
        setActiveModal(null);
        return;
      }

      if (isTyping) return;

      const action = (Object.keys(hotkeys) as ActionName[]).find((key) => {
        const config = hotkeys[key];
        return config.primary === e.code || config.secondary === e.code;
      });

      if (!action) return;

      e.preventDefault();

      const toggleModal = (modalId: string) => {
        const currentTopModal = modalStack.length > 0 ? modalStack[modalStack.length - 1] : null;

        if (currentTopModal && currentTopModal.id === modalId) {
          setActiveModal(null); // Close it
        } else {
          setActiveModal(modalId); // Open it (replace)
        }
      };

      // Handle universal modal toggles first.
      switch (action) {
        case 'TOGGLE_CHARACTER_PANEL':
          toggleModal('character');
          return;
        case 'TOGGLE_QUEST_LOG':
          toggleModal('quest-log');
          return;
        case 'TOGGLE_PERKS_PANEL':
          toggleModal('skills-modal');
          return;
        case 'TOGGLE_PARTY_PANEL':
          toggleModal('party-modal');
          return;
        case 'TOGGLE_REPUTATION_PANEL':
          toggleModal('not-implemented');
          return;
        case 'TOGGLE_SETTINGS_PANEL':
          toggleModal('settings-modal');
          return;
        case 'TOGGLE_DEBUG_PANEL':
          toggleModal('debug-modal');
          return;
        default:
          // Not a universal modal toggle, proceed to state-dependent actions.
          break;
      }

      if (currentCombat?.isActive) {
        if (!currentCombat.isPlayerTurn) return;
        switch (action) {
          case 'COMBAT_ATTACK':
            setSelectedAction({ type: 'attack', skillId: null });
            break;
          case 'COMBAT_INSPECT':
            setSelectedAction({ type: 'inspect', skillId: null });
            break;
          case 'COMBAT_RANDOM_LIMB':
            if (selectedAction && selectedAction.type !== 'inspect' && selectedTargetId) {
              playerTargetRandomLimb(selectedTargetId, selectedAction.type, selectedAction.skillId);
              setSelectedAction(null);
            }
            break;
          case 'COMBAT_REPEAT_ACTION':
            playerRepeatLastAction();
            break;
          case 'COMBAT_GUARD':
            playerUseSkill('s_guard', 'player', null, false);
            break;
          case 'COMBAT_FLEE':
            playerFlee();
            break;
          default:
            if (action.startsWith('FAVORITE_ABILITY_')) {
              const index = parseInt(action.split('_')[2], 10) - 1;
              if (favoriteAbilities && favoriteAbilities[index]) {
                const abilityId = favoriteAbilities[index];
                const abilityData = GAME_DATA.SKILLS[abilityId];
                if (abilityData.targetRule === 'Self' || abilityData.targetRule === 'Field' || abilityData.targetRule === 'AllEnemies') {
                  playerUseSkill(abilityId, 'player', null, false);
                } else {
                  setSelectedAction({ type: 'skill', skillId: abilityId });
                }
              }
            }
            break;
        }
      } else {
        // Out of Combat
        switch (action) {
          case 'WORLD_EXPLORE':
            if (player && player.currentWeight >= player.maxCarryWeight) {
              logMessage(
                {
                  floatingText: 'Encumbered!',
                  detailedText: 'You are too encumbered to travel.',
                },
                'error'
              );
              return;
            }
            if (gameState === 'world-map' && currentLocation) {
              travelTo(currentLocation.id);
            } else {
              changeGameState('world-map');
            }
            break;
          case 'WORLD_WAIT':
            toggleModal('wait-modal');
            break;
          case 'WORLD_CRAFT':
            toggleModal('crafting-modal');
            break;
          default:
            if (action.startsWith('FAVORITE_ABILITY_') && castAbilityOutOfCombat) {
              const index = parseInt(action.split('_')[2], 10) - 1;
              if (favoriteAbilities && favoriteAbilities[index]) {
                const abilityId = favoriteAbilities[index];
                // Synthesize a mouse event at the center of the screen
                const fakeEvent = new MouseEvent('click', {
                  bubbles: true,
                  cancelable: true,
                  clientX: window.innerWidth / 2,
                  clientY: window.innerHeight / 2,
                });
                castAbilityOutOfCombat(abilityId, fakeEvent as any);
              }
            }
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [player, favoriteAbilities, uiContext, worldContext, combatContext, hotkeyContext, logContext, GAME_DATA]);
};