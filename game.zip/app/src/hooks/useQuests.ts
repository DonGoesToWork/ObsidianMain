import { useContext } from "react";
import { PlayerContext } from "context/PlayerContext";
import { CharacterContext } from "context/CharacterContext";

export const useQuests = () => {
  const playerContext = useContext(PlayerContext);
  const characterContext = useContext(CharacterContext);

  if (!playerContext || !characterContext) {
    throw new Error("useQuests must be used within the required providers");
  }

  const { player } = playerContext;
  const { acceptQuest, completeQuest, updateQuestProgress } = characterContext;

  return {
    quests: player?.quests,
    acceptQuest,
    completeQuest,
    updateQuestProgress,
  };
};