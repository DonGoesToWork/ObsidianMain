import { useContext } from 'react';
import { CharacterContext } from 'context/CharacterContext';
import { usePlayer } from './usePlayer';

export const useQuests = () => {
  const player = usePlayer();
  const characterContext = useContext(CharacterContext);

  if (!characterContext) {
    throw new Error('useQuests must be used within the required providers');
  }

  const { acceptQuest, completeQuest, updateQuestProgress } = characterContext;

  return {
    quests: player?.quests,
    acceptQuest,
    completeQuest,
    updateQuestProgress,
  };
};