import React, { useContext, useMemo, useState } from 'react';
import { PlayerContext } from 'context/PlayerContext';
import { ProfessionsContext } from 'context/ProfessionsContext';
import { WorldContext } from 'context/WorldContext';
import { LogContext } from 'context/LogContext';
import { ItemInstance, ProfessionId, Recipe } from 'types';
import { GameDataContext } from 'context/GameDataContext';
import { getCraftingChecks } from 'utils/craftingUtils';
import { groupItems } from 'utils/itemUtils';

const MAX_TOOLS = 4;
const MAX_INGREDIENTS = 10;

export const useCrafting = () => {
  const { player } = useContext(PlayerContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { craftItem } = useContext(ProfessionsContext)!;
  const { currentLocation } = useContext(WorldContext)!;
  const { logMessage } = useContext(LogContext)!;

  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [tools, setTools] = useState<ItemInstance[]>([]);
  const [ingredients, setIngredients] = useState<ItemInstance[]>([]);
  const [recipeProfession, setRecipeProfession] = useState<ProfessionId>('smithing');

  const { playerInventoryForDisplay, playerInventoryMap } = useMemo(() => {
    if (!player) return { playerInventoryForDisplay: [], playerInventoryMap: [] };
    const itemsInCrafting = new Set([...tools, ...ingredients]);
    const displayItems: ItemInstance[] = [];
    const displayMap: number[] = [];
    player.inventory.forEach((item: ItemInstance, index: number) => {
      const isItemInCrafting = itemsInCrafting.has(item);
      if (!isItemInCrafting && !item.isUnidentified) {
        displayItems.push(item);
        displayMap.push(index);
      }
    });
    return {
      playerInventoryForDisplay: displayItems,
      playerInventoryMap: displayMap,
    };
  }, [player, tools, ingredients]);

  const groupedIngredients = useMemo(() => groupItems(ingredients, GAME_DATA), [ingredients, GAME_DATA]);

  const inventoryCounts = useMemo(() => {
    if (!player) return {};
    return player.inventory.reduce((acc: Record<string, number>, item: ItemInstance) => {
      if (!item.isUnidentified) {
        acc[item.id] = (acc[item.id] || 0) + 1;
      }
      return acc;
    }, {} as Record<string, number>);
  }, [player?.inventory]);

  const knownRecipes = useMemo(() => {
    if (!player) return [];
    return Object.values(GAME_DATA.ALL_RECIPES).filter((r) => r.profession === recipeProfession && player.knownRecipes[r.id]);
  }, [player?.knownRecipes, recipeProfession, GAME_DATA.ALL_RECIPES]);

  const { craftableRecipes, uncraftableRecipes } = useMemo(() => {
    const craftable: Recipe[] = [];
    const uncraftable: Recipe[] = [];

    if (!player) return { craftableRecipes: [], uncraftableRecipes: knownRecipes };

    const hasForge = currentLocation?.type === 'town' || !!player.inventory.find((i: ItemInstance) => i.id === 'item_forge');

    knownRecipes.forEach((recipe) => {
      const hasMaterials = Object.entries(recipe.materials).every(([matId, requiredCount]) => {
        return (inventoryCounts[matId as string] || 0) >= requiredCount;
      });
      const hasTools = (recipe.tools || []).every((toolId) => (inventoryCounts[toolId as string] || 0) >= 1);
      const forgeOk = !recipe.requiresForge || hasForge;

      if (hasMaterials && hasTools && forgeOk) {
        craftable.push(recipe);
      } else {
        uncraftable.push(recipe);
      }
    });

    const sorter = (a: Recipe, b: Recipe) => a.levelReq - b.levelReq;
    craftable.sort(sorter);
    uncraftable.sort(sorter);

    return { craftableRecipes: craftable, uncraftableRecipes: uncraftable };
  }, [knownRecipes, inventoryCounts, player, currentLocation]);

  const { discoveredRecipe, requirementChecks } = useMemo(() => {
    if (!player) return { discoveredRecipe: undefined, requirementChecks: {} };

    const allRecipes = Object.values(GAME_DATA.ALL_RECIPES);
    const ingredientCounts: Record<string, number> = {};
    for (const ing of ingredients) {
      ingredientCounts[ing.id] = (ingredientCounts[ing.id] || 0) + 1;
    }

    const recipe = allRecipes.find((r) => {
      const recipeMatKeys = Object.keys(r.materials);
      const providedIngKeys = Object.keys(ingredientCounts);
      if (recipeMatKeys.length !== providedIngKeys.length) return false;
      for (const key of recipeMatKeys) {
        if (ingredientCounts[key] !== r.materials[key as string]) return false;
      }
      return true;
    });

    const checks = getCraftingChecks(player, selectedRecipe || recipe || null, tools, currentLocation, false, GAME_DATA);

    return { discoveredRecipe: recipe, requirementChecks: checks };
  }, [tools, ingredients, player, currentLocation, selectedRecipe, GAME_DATA]);

  const canCraftSingle = useMemo(() => {
    if (!discoveredRecipe && !selectedRecipe) return false;
    return Object.values(requirementChecks).every((c) => c.ok);
  }, [discoveredRecipe, selectedRecipe, requirementChecks]);

  const canCraftMultiple = (quantity: number) => {
    if (!selectedRecipe || !player) return false;
    if (!Object.values(requirementChecks).every((c) => c.ok)) return false;

    const invCounts = groupItems(player.inventory, GAME_DATA);
    for (const [matId, count] of Object.entries(selectedRecipe.materials)) {
      const matKey = Object.keys(invCounts).find((k) => invCounts[k].item.id === matId);
      if (!matKey || invCounts[matKey].count < count * quantity) return false;
    }
    return true;
  };

  const handleAddItemToCraft = (itemsToAdd: ItemInstance[]) => {
    if (itemsToAdd.length === 0) return;

    const itemData = GAME_DATA.ITEMS[itemsToAdd[0].id];
    const isTool = itemData.type.includes('tool') || (itemData.type.includes('equipment') && itemData.skillBonuses);

    if (isTool) {
      if (tools.length + itemsToAdd.length <= MAX_TOOLS) {
        setTools((prev) => [...prev, ...itemsToAdd]);
      } else {
        logMessage('Tool slots are full.', 'error');
      }
    } else {
      if (ingredients.length + itemsToAdd.length <= MAX_INGREDIENTS) {
        setIngredients((prev) => [...prev, ...itemsToAdd]);
      } else {
        logMessage('Ingredient slots are full.', 'error');
      }
    }
  };

  const handleSelectRecipe = (recipe: Recipe) => {
    if (!player) return;

    let availableInventory = [...player.inventory];

    const neededIngredients: ItemInstance[] = [];
    let canFulfillIngredients = true;
    for (const [matId, requiredCount] of Object.entries(recipe.materials)) {
      let foundCount = 0;
      for (let i = availableInventory.length - 1; i >= 0; i--) {
        if (foundCount === requiredCount) break;
        if (availableInventory[i].id === matId) {
          neededIngredients.push(availableInventory.splice(i, 1)[0]);
          foundCount++;
        }
      }
      if (foundCount < requiredCount) {
        canFulfillIngredients = false;
        break;
      }
    }

    if (!canFulfillIngredients) {
      logMessage(`You don't have enough materials for ${recipe.name}.`, 'error');
      setIngredients([]);
      setTools([]);
      setSelectedRecipe(null);
      return;
    }

    const neededTools: ItemInstance[] = [];
    let canFulfillTools = true;
    if (recipe.tools) {
      for (const toolId of recipe.tools) {
        const toolIndex = availableInventory.findIndex((item) => item.id === toolId);
        if (toolIndex !== -1) {
          neededTools.push(availableInventory.splice(toolIndex, 1)[0]);
        } else {
          canFulfillTools = false;
          break;
        }
      }
    }

    if (!canFulfillTools) {
      logMessage(`You are missing a required tool for ${recipe.name}.`, 'error');
      setIngredients([]);
      setTools([]);
      setSelectedRecipe(null);
      return;
    }

    setIngredients(neededIngredients);
    setTools(neededTools);
    setSelectedRecipe(recipe);
    logMessage(`Added materials for ${recipe.name}.`, 'info');
  };

  const handleCraft = (quantity: number) => {
    if (!player) return;

    const recipeToCraft = selectedRecipe || discoveredRecipe;
    if (!recipeToCraft) {
      logMessage('No valid recipe selected or discovered.', 'error');
      return;
    }

    if (quantity > 1 && !selectedRecipe) {
      logMessage('Multi-craft only available for known recipes selected from the list.', 'error');
      return;
    }

    if (quantity > 1 && !canCraftMultiple(quantity)) {
      logMessage(`You lack the requirements to craft ${quantity}x of ${recipeToCraft.name}.`, 'error');
      return;
    }
    if (quantity === 1 && !canCraftSingle) {
      logMessage(`You lack the requirements to craft ${recipeToCraft.name}.`, 'error');
      return;
    }

    let ingredientsToConsume: ItemInstance[] = [];
    if (quantity === 1 && !selectedRecipe) {
      ingredientsToConsume = [...ingredients];
    } else {
      let tempInventory = [...player.inventory];
      for (const [matId, count] of Object.entries(recipeToCraft.materials)) {
        const totalToConsume = count * quantity;
        let consumed = 0;
        for (let i = tempInventory.length - 1; i >= 0; i--) {
          if (consumed === totalToConsume) break;
          if (tempInventory[i].id === matId) {
            ingredientsToConsume.push(tempInventory.splice(i, 1)[0]);
            consumed++;
          }
        }
      }
    }

    craftItem(recipeToCraft, quantity, tools, ingredientsToConsume);
    setIngredients([]);
    setTools([]);
    setSelectedRecipe(null);
  };

  const handleRemoveItem = (item: ItemInstance, setFn: React.Dispatch<React.SetStateAction<ItemInstance[]>>, transferAmount: number) => {
    setFn((prev) => {
      let countToRemove = transferAmount;
      const newItems = [...prev];
      for (let i = newItems.length - 1; i >= 0; i--) {
        if (countToRemove === 0) break;
        // Compare by instance for tools, by ID for stackable ingredients
        const isTool = GAME_DATA.ITEMS[item.id].type.includes('tool');
        const match = isTool ? newItems[i] === item : newItems[i].id === item.id;
        if (match) {
          newItems.splice(i, 1);
          countToRemove--;
        }
      }
      return newItems;
    });
  };

  return {
    player,
    tools,
    setTools,
    ingredients,
    setIngredients,
    selectedRecipe,
    recipeProfession,
    setRecipeProfession,
    playerInventoryForDisplay,
    playerInventoryMap,
    groupedIngredients,
    knownRecipes,
    craftableRecipes,
    uncraftableRecipes,
    discoveredRecipe,
    requirementChecks,
    canCraftSingle,
    canCraftMultiple,
    handleAddItemToCraft,
    handleSelectRecipe,
    handleCraft,
    handleRemoveItem,
  };
};
