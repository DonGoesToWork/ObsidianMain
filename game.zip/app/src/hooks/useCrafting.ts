import React, { useContext, useEffect, useMemo, useState } from 'react';
import { ItemInstance, ProfessionId, Recipe, UseCraftingReturn } from 'types';
import { calculateCraftSuccessChance, findDiscoveredRecipe, getCraftingChecks, getRequirementStatus } from 'utils/craftingUtils';
import { areEffectivelyEqual, groupItems, mergeIntoInventory } from 'utils/itemUtils';

import { GameDataContext } from 'context/GameDataContext';
import { LogContext } from 'context/LogContext';
import { PlayerContext } from 'context/PlayerContext';
import { ProfessionsContext } from 'context/ProfessionsContext';
import { WorldContext } from 'context/WorldContext';
import { PLAYER_INVENTORY_MAX_STACK_SIZE } from 'config/GLOBAL_QUICK_DEV_CONFIGURATION';

const MAX_TOOLS = 4;
const MAX_INGREDIENTS = 10;

export const useCrafting = (): UseCraftingReturn => {
  const { player } = useContext(PlayerContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { craftItem } = useContext(ProfessionsContext)!;
  const { currentLocation } = useContext(WorldContext)!;
  const { logMessage } = useContext(LogContext)!;

  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [tools, setTools] = useState<ItemInstance[]>([]);
  const [ingredients, setIngredients] = useState<ItemInstance[]>([]);
  const [recipeProfession, setRecipeProfession] = useState<ProfessionId>('smithing');

  const { playerInventoryForDisplay, playerInventoryMap } = useMemo(() => {
    if (!player) return { playerInventoryForDisplay: [], playerInventoryMap: [] };

    const itemsInCrafting = [...tools, ...ingredients];
    const stackableQuantities: Record<string, number> = {};
    const unstackableIds = new Set<string>();

    for (const item of itemsInCrafting) {
      if (GAME_DATA.ITEMS[item!.id].stackable) {
        stackableQuantities[item!.id] = (stackableQuantities[item!.id] || 0) + item!.quantity;
      } else {
        unstackableIds.add(item!.unique_id);
      }
    }

    const displayItems: ItemInstance[] = [];
    const displayMap: number[] = [];
    player.inventory.forEach((item, index) => {
      if (item.isUnidentified) return;

      if (GAME_DATA.ITEMS[item.id].stackable) {
        const quantityInCrafting = stackableQuantities[item.id] || 0;
        if (item.quantity > quantityInCrafting) {
          displayItems.push({ ...item, quantity: item.quantity - quantityInCrafting });
          displayMap.push(index);
        }
      } else {
        if (!unstackableIds.has(item.unique_id)) {
          displayItems.push(item);
          displayMap.push(index);
        }
      }
    });

    return {
      playerInventoryForDisplay: displayItems,
      playerInventoryMap: displayMap,
    };
  }, [player, tools, ingredients, GAME_DATA]);

  const groupedIngredients = useMemo(() => groupItems(ingredients, GAME_DATA), [ingredients, GAME_DATA]);

  const knownRecipes = useMemo(() => {
    if (!player) return [];
    return Object.values(GAME_DATA.ALL_RECIPES).filter((r) => r.profession === recipeProfession && player.knownRecipes[r.id]);
  }, [player?.knownRecipes, recipeProfession, GAME_DATA.ALL_RECIPES]);

  const discoveredRecipe = useMemo(() => {
    return findDiscoveredRecipe(ingredients, tools, currentLocation, GAME_DATA.ALL_RECIPES);
  }, [ingredients, tools, currentLocation, GAME_DATA.ALL_RECIPES]);

  useEffect(() => {
    if (discoveredRecipe && player?.knownRecipes[discoveredRecipe.id]) {
      setSelectedRecipe(discoveredRecipe);
    } else {
      setSelectedRecipe(null);
    }
  }, [discoveredRecipe, player?.knownRecipes]);

  const requirementChecks = useMemo(() => {
    if (!player) return {};
    const recipe = selectedRecipe || discoveredRecipe || null;
    const checks = getCraftingChecks(player, recipe, tools, currentLocation, !!selectedRecipe, GAME_DATA, { materialSource: ingredients });

    if (recipe?.profession) {
      const playerSkill = player.professions[recipe.profession].level;
      checks.dr = { ok: true, text: `DR: ${recipe.levelReq} (vs ${playerSkill})` };
      checks.success = { ok: true, text: `Success: ${calculateCraftSuccessChance(playerSkill, recipe.levelReq).toFixed(1)}%` };
      checks.failure = { ok: true, text: `Failure consumes materials.` };
    }

    return checks;
  }, [player, selectedRecipe, discoveredRecipe, tools, ingredients, currentLocation, GAME_DATA]);

  const canCraftSingle = useMemo(() => {
    const recipe = selectedRecipe || discoveredRecipe;
    if (!recipe) {
      return ingredients.length > 0;
    }
    return getRequirementStatus(requirementChecks) === 'full';
  }, [selectedRecipe, discoveredRecipe, ingredients.length, requirementChecks]);

  const canCraftMultiple = (quantity: number) => {
    if (!selectedRecipe || !player) return false;
    if (getRequirementStatus(requirementChecks) !== 'full') return false;

    const invCounts = groupItems(player.inventory, GAME_DATA);
    for (const [matId, count] of Object.entries(selectedRecipe.materials)) {
      const matKey = Object.keys(invCounts).find((k) => invCounts[k].item.id === matId);
      if (!matKey || invCounts[matKey].count < count * quantity) return false;
    }
    return true;
  };

  const handleAddItemToCraft = (itemsToAdd: ItemInstance[]) => {
    const ingredientsToAdd = itemsToAdd.filter((item) => !GAME_DATA.ITEMS[item.id].type.includes('tool') && item.id !== 'item_forge');
    const toolsToAdd = itemsToAdd.filter((item) => GAME_DATA.ITEMS[item.id].type.includes('tool') || item.id === 'item_forge');

    if (toolsToAdd.length > 0) {
      setTools((prevTools) => {
        const newTools = [...prevTools];
        for (const tool of toolsToAdd) {
          if (!newTools.find((t) => t.unique_id === tool.unique_id) && newTools.length < MAX_TOOLS) {
            newTools.push(tool);
          } else if (newTools.length >= MAX_TOOLS) {
            logMessage('Tool slots are full.', 'error');
            break;
          }
        }
        return newTools;
      });
    }

    if (ingredientsToAdd.length > 0) {
      setIngredients((prevIngredients) => {
        const merged = mergeIntoInventory(prevIngredients, ingredientsToAdd, GAME_DATA, {
          maxUniqueItems: MAX_INGREDIENTS,
          maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
        });
        if (merged.overflow.length > 0) {
          logMessage('Ingredient slots are full.', 'error');
        }
        return merged.newInventory;
      });
    }
  };

  const handleSelectRecipe = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    if (!player) return;

    const availableInventory = JSON.parse(JSON.stringify(player.inventory));
    let itemsToMove: ItemInstance[] = [];

    for (const [matId, requiredCount] of Object.entries(recipe.materials)) {
      let count = 0;
      for (let i = availableInventory.length - 1; i >= 0; i--) {
        if (count >= requiredCount) break;
        const item = availableInventory[i];
        if (item.id === matId) {
          const takeAmount = Math.min(item.quantity, requiredCount - count);
          itemsToMove.push({ ...item, quantity: takeAmount });
          item.quantity -= takeAmount;
          count += takeAmount;
          if (item.quantity <= 0) {
            availableInventory.splice(i, 1);
          }
        }
      }
    }

    const { newInventory: neededIngredients, overflow } = mergeIntoInventory([], itemsToMove, GAME_DATA, {
      maxUniqueItems: MAX_INGREDIENTS,
      maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
    });
    if (overflow.length > 0) {
      logMessage('Not all materials could fit in the crafting slots.', 'info');
    }
    setIngredients(neededIngredients);

    const neededTools: ItemInstance[] = [];
    if (recipe.tools) {
      for (const toolId of recipe.tools) {
        const toolIndex = availableInventory.findIndex((item: ItemInstance) => item.id === toolId);
        if (toolIndex !== -1) {
          neededTools.push(availableInventory.splice(toolIndex, 1)[0]);
        }
      }
    }
    if (recipe.requiresForge) {
      const forgeIndex = availableInventory.findIndex((item: ItemInstance) => item.id === 'item_forge');
      if (forgeIndex !== -1) {
        neededTools.push(availableInventory.splice(forgeIndex, 1)[0]);
      }
    }

    setTools(neededTools);
  };

  const handleCraft = (quantity: number) => {
    if (!player) return;

    const recipeToCraft = selectedRecipe || discoveredRecipe;

    if (!recipeToCraft) {
      if (quantity > 1) {
        logMessage('Cannot multi-craft an unknown experimental recipe.', 'error');
        return;
      }
      if (ingredients.length === 0) {
        logMessage("You haven't added any ingredients to experiment with.", 'error');
        return;
      }
      craftItem(null, 1, tools, ingredients);
      setIngredients([]);
      setTools([]);
      setSelectedRecipe(null);
      return;
    }

    if (quantity > 1 && !selectedRecipe) {
      logMessage('Multi-craft only available for known recipes selected from the list.', 'error');
      return;
    }

    if (quantity > 1 && !canCraftMultiple(quantity)) {
      logMessage(`You lack the requirements to craft ${quantity}x of ${recipeToCraft.name}.`, 'error');
      return;
    }
    if (quantity === 1 && !canCraftSingle) {
      logMessage(`You lack the requirements to craft ${recipeToCraft.name}.`, 'error');
      return;
    }

    let ingredientsToConsume: ItemInstance[] = [];
    if (quantity === 1 && discoveredRecipe) {
      ingredientsToConsume = [...ingredients];
    } else {
      let tempInventory = [...player.inventory];
      for (const [matId, count] of Object.entries(recipeToCraft.materials)) {
        const totalToConsume = count * quantity;
        let consumed = 0;
        for (let i = tempInventory.length - 1; i >= 0; i--) {
          if (consumed >= totalToConsume) break;
          const item = tempInventory[i];
          if (item.id === matId) {
            const takeAmount = Math.min(item.quantity, totalToConsume - consumed);
            const existing = ingredientsToConsume.find((it) => it.id === matId);
            if (existing) {
              existing.quantity += takeAmount;
            } else {
              ingredientsToConsume.push({ ...item, quantity: takeAmount });
            }
            item.quantity -= takeAmount;
            consumed += takeAmount;
            if (item.quantity <= 0) {
              tempInventory.splice(i, 1);
            }
          }
        }
      }
    }

    craftItem(recipeToCraft, quantity, tools, ingredientsToConsume);
    setIngredients([]);
    setTools([]);
    setSelectedRecipe(null);
  };

  const handleRemoveItem = (item: ItemInstance, setFn: React.Dispatch<React.SetStateAction<ItemInstance[]>>, transferAmount: number) => {
    setFn((prev) => {
      const newItems = [...prev];
      const isStackable = GAME_DATA.ITEMS[item.id].stackable;

      if (isStackable) {
        const itemIndex = newItems.findIndex((i) => areEffectivelyEqual(i, item));
        if (itemIndex > -1) {
          const stack = newItems[itemIndex];
          const amountToRemove = Math.min(transferAmount, stack.quantity);
          stack.quantity -= amountToRemove;
          if (stack.quantity <= 0) {
            newItems.splice(itemIndex, 1);
          }
        }
      } else {
        // Unstackable items are removed one by one
        let removedCount = 0;
        for (let i = newItems.length - 1; i >= 0; i--) {
          if (removedCount >= transferAmount) break;
          if (newItems[i].unique_id === item.unique_id) {
            newItems.splice(i, 1);
            removedCount++;
          }
        }
      }
      return newItems;
    });
  };

  return {
    player,
    tools,
    setTools,
    ingredients,
    setIngredients,
    selectedRecipe,
    recipeProfession,
    setRecipeProfession,
    playerInventoryForDisplay,
    playerInventoryMap,
    groupedIngredients,
    knownRecipes,
    discoveredRecipe,
    requirementChecks,
    canCraftSingle,
    canCraftMultiple,
    handleAddItemToCraft,
    handleSelectRecipe,
    handleCraft,
    handleRemoveItem,
  };
};