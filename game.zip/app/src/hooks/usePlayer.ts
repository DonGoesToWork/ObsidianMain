import { useContext, useMemo } from 'react';
import { PlayerContext } from 'context/PlayerContext';
import { Player, Mercenary } from 'types';
import { CombatContext } from 'context/CombatContext';
import { deepCloneWithInfinity } from 'utils/mathUtils';

/**
 * A hook to get the player object. It provides a "live" version during combat.
 * When combat is active, it returns a memoized, composite Player object that reflects
 * real-time changes to health, resources, and status effects for the player and their party.
 * When combat is not active, it returns the standard persistent player state.
 * This ensures that any UI component using this hook will always display the most current data.
 */
export const usePlayer = (): Player | null => {
  const playerContext = useContext(PlayerContext);
  const combatContext = useContext(CombatContext);

  const livePlayer = useMemo(() => {
    if (!playerContext?.player) {
      return null;
    }

    if (combatContext?.currentCombat?.isActive) {
      const livePlayerObject = deepCloneWithInfinity(playerContext.player);
      const playerCombatant = combatContext.currentCombat.combatants['player'];

      if (playerCombatant) {
        livePlayerObject.body = playerCombatant.body;
        livePlayerObject.mp = playerCombatant.mp;
        livePlayerObject.sp = playerCombatant.sp;
        livePlayerObject.statusEffects = playerCombatant.statusEffects;
        livePlayerObject.totalStats = playerCombatant.totalStats;
      }

      livePlayerObject.party = livePlayerObject.party.map((merc) => {
        const mercCombatant = combatContext.currentCombat!.combatants[merc.id];
        if (mercCombatant) {
          const liveMerc: Mercenary = {
            ...merc,
            body: mercCombatant.body,
            mp: mercCombatant.mp,
            sp: mercCombatant.sp,
            statusEffects: mercCombatant.statusEffects,
            totalStats: mercCombatant.totalStats,
          };
          return liveMerc;
        }
        return merc;
      });

      return livePlayerObject;
    }

    return playerContext.player;
  }, [playerContext?.player, combatContext?.currentCombat]);

  return livePlayer;
};