import { useContext } from "react";
import { PlayerContext } from "context/PlayerContext";
import { Player } from "types";

/**
 * A hook to get the raw player object.
 * Use more specific hooks like useInventory or useAttributes where possible
 * to improve component isolation and readability.
 * This hook is appropriate for components that need to display a wide range of
 * player data (like CharacterVitalsPanel) or pass the player object to complex
 * utility functions.
 */
export const usePlayer = (): Player | null => {
  const context = useContext(PlayerContext);
  if (!context) {
    throw new Error("usePlayer must be used within a PlayerProvider");
  }
  return context.player;
};