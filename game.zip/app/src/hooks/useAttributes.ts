import { CharacterContext } from 'context/CharacterContext';
import { useContext } from 'react';
import { usePlayer } from './usePlayer';

export const useAttributes = () => {
  const player = usePlayer();
  const characterContext = useContext(CharacterContext);

  if (!characterContext) {
    throw new Error('useAttributes must be used within a PlayerProvider');
  }
  const { spendAttributePoint } = characterContext;
  return {
    level: player?.level,
    baseStats: player?.baseStats,
    totalStats: player?.totalStats,
    attributePoints: player?.attributePoints,
    spendAttributePoint,
  };
};
