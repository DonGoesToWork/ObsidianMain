import { useContext } from "react";
import { PlayerContext } from "context/PlayerContext";
import { CharacterContext } from "context/CharacterContext";

export const useAttributes = () => {
  const playerContext = useContext(PlayerContext);
  const characterContext = useContext(CharacterContext);

  if (!playerContext || !characterContext) {
    throw new Error("useAttributes must be used within a PlayerProvider");
  }
  const { player } = playerContext;
  const { spendAttributePoint } = characterContext;
  return {
    level: player?.level,
    baseStats: player?.baseStats,
    totalStats: player?.totalStats,
    attributePoints: player?.attributePoints,
    spendAttributePoint,
  };
};