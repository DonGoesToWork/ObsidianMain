import { useContext } from "react";
import { PlayerContext } from "context/PlayerContext";
import { PartyContext } from "context/PartyContext";

export const useParty = () => {
  const playerContext = useContext(PlayerContext);
  const partyContext = useContext(PartyContext);

  if (!playerContext || !partyContext) {
    throw new Error("useParty must be used within the required providers");
  }

  const { player } = playerContext;
  const {
    hireMercenary,
    fireMercenary,
    gainMercenaryXp,
    reviveDownedAlly,
    reviveFallenAlly,
    refreshMercenaryGuild,
    healBrokenLimb,
  } = partyContext;

  return {
    party: player?.party,
    mercenaryGuildData: player?.mercenaryGuildData,
    hireMercenary,
    fireMercenary,
    gainMercenaryXp,
    reviveDownedAlly,
    reviveFallenAlly,
    refreshMercenaryGuild,
    healBrokenLimb,
  };
};