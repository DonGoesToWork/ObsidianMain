import { PartyContext } from 'context/PartyContext';
import { WorldContext } from 'context/WorldContext';
import { useContext } from 'react';
import { usePlayer } from './usePlayer';

export const useParty = () => {
  const player = usePlayer();
  const partyContext = useContext(PartyContext);
  const worldContext = useContext(WorldContext);

  if (!partyContext || !worldContext) {
    throw new Error('useParty must be used within the required providers');
  }

  const { hireMercenary, fireMercenary, gainMercenaryXp, reviveDownedAlly, reviveFallenAlly, refreshMercenaryGuild, healBrokenLimb } = partyContext;
  const mercenaryGuildData = worldContext.worldLocationsState?.[worldContext.currentLocation?.id || '']?.mercenaryGuild;

  return {
    party: player?.party,
    mercenaryGuildData,
    hireMercenary,
    fireMercenary,
    gainMercenaryXp,
    reviveDownedAlly,
    reviveFallenAlly,
    refreshMercenaryGuild,
    healBrokenLimb,
  };
};