import { PartyContext } from 'context/PartyContext';
import { useContext } from 'react';
import { usePlayer } from './usePlayer';

export const useParty = () => {
  const player = usePlayer();
  const partyContext = useContext(PartyContext);

  if (!partyContext) {
    throw new Error('useParty must be used within the required providers');
  }

  const { hireMercenary, fireMercenary, gainMercenaryXp, reviveDownedAlly, reviveFallenAlly, refreshMercenaryGuild, healBrokenLimb } = partyContext;

  return {
    party: player?.party,
    mercenaryGuildData: player?.mercenaryGuildData,
    hireMercenary,
    fireMercenary,
    gainMercenaryXp,
    reviveDownedAlly,
    reviveFallenAlly,
    refreshMercenaryGuild,
    healBrokenLimb,
  };
};
