import { GameDataContext } from 'context/GameDataContext';
import { WorldContext } from 'context/WorldContext';
import { useContext, useMemo } from 'react';
import { RequirementStatus } from 'types';
import { calculateCraftingTabStatuses } from '../services/craftingService';
import { usePlayer } from './usePlayer';

export const useCraftingTabs = (): Record<string, RequirementStatus> => {
  const player = usePlayer();
  const { currentLocation } = useContext(WorldContext)!;
  const GAME_DATA = useContext(GameDataContext)!;

  const tabStatuses = useMemo<Record<string, RequirementStatus>>(() => {
    if (!player) {
      return {
        Create: 'none',
        Repair: 'none',
        Upgrade: 'none',
        Enchanting: 'none',
      };
    }
    return calculateCraftingTabStatuses(player, currentLocation, GAME_DATA);
  }, [player, currentLocation, GAME_DATA]);

  return tabStatuses;
};