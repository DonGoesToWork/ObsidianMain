import { GameDataContext } from 'context/GameDataContext';
import { PlayerContext } from 'context/PlayerContext';
import { ProfessionsContext } from 'context/ProfessionsContext';
import React, { useContext, useEffect, useMemo, useState } from 'react';
import { ItemInstance } from 'types';
import { UseEnchantingReturn } from 'types/hooks';
import { calculateEnchantmentDetails } from 'utils/craftingUtils';
import { calculateItemLevel, calculateItemTier } from 'utils/itemUtils';

export const useEnchanting = (): UseEnchantingReturn => {
  const { player } = useContext(PlayerContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { enchantItem } = useContext(ProfessionsContext)!;

  const [selectedItem, setSelectedItem] = useState<ItemInstance | null>(null);
  const [selectedEnchantment, setSelectedEnchantment] = useState<{ enchantId: string; tier: number } | null>(null);
  const [isEnchanting, setIsEnchanting] = useState(false);

  useEffect(() => {
    if (isEnchanting) {
      return;
    }
    if (selectedItem && player) {
      // Find the original stack in the player's inventory
      const originalStack = player.inventory.find((item) => item.unique_id === selectedItem.unique_id);
      if (originalStack) {
        // Create a new selectedItem with the original stack's properties but quantity 1
        const updatedSelectedItem = { ...originalStack, quantity: 1 };
        if (JSON.stringify(updatedSelectedItem) !== JSON.stringify(selectedItem)) {
          setSelectedItem(updatedSelectedItem);
        }
      } else {
        // The item no longer exists (e.g., was dropped, sold, or destroyed)
        setSelectedItem(null);
        setSelectedEnchantment(null);
      }
    }
  }, [player, selectedItem, isEnchanting]);

  const inventoryItems = useMemo(() => {
    if (!player) return [];
    const baseList =
      player?.inventory.filter((item: ItemInstance) => {
        const itemData = GAME_DATA.ITEMS[item.id];
        return !item.isUnidentified && !itemData.isUnarmed && itemData.type.includes('equipment');
      }) || [];

    if (!selectedItem) return baseList;

    const newInventory = baseList
      .map((invItem) => {
        if (invItem.unique_id === selectedItem.unique_id) {
          // Return a new item with decremented quantity
          return { ...invItem, quantity: invItem.quantity - 1 };
        }
        return invItem;
      })
      .filter((invItem) => invItem.quantity > 0); // Remove the item if its quantity becomes 0

    return newInventory;
  }, [player, selectedItem, GAME_DATA.ITEMS]);

  const itemTier = useMemo(() => {
    if (!selectedItem) return Infinity;
    const calculatedLevel = calculateItemLevel(selectedItem, GAME_DATA);
    return calculateItemTier(calculatedLevel);
  }, [selectedItem, GAME_DATA]);

  const numEnchantments = selectedItem ? Object.keys(selectedItem.enchantments).length : 0;
  const hasMaxEnchants = useMemo(() => {
    if (!selectedItem) return false;
    return numEnchantments >= Object.keys(GAME_DATA.ITEM_RARITY_TIERS).length - 1;
  }, [selectedItem, numEnchantments, GAME_DATA.ITEM_RARITY_TIERS]);

  const availableEnchants = useMemo(() => {
    if (!selectedItem || !player) return [];
    const itemData = GAME_DATA.ITEMS[selectedItem.id];

    return GAME_DATA.ENCHANTS.filter((enchant) => {
      const isKnown = enchant.scaling.some((_, index) => {
        const tier = index + 1;
        const recipeId = `${enchant.id}_t${tier}`;
        return !!player.knownEnchantments[recipeId];
      });

      if (!isKnown) {
        return false;
      }

      if (enchant.type === 'global') {
        return true;
      }
      if (enchant.type === 'local') {
        if (!enchant.appliesTo) {
          return true; // Universal local enchant
        }
        const { hasStat, hasItemType } = enchant.appliesTo;

        // If appliesTo is specified, but no conditions inside, it should match anything
        if ((!hasStat || hasStat.length === 0) && (!hasItemType || hasItemType.length === 0)) return true;

        const itemStats = itemData.stats || {};
        const itemTypes = itemData.type || [];

        const statMatch = hasStat && hasStat.some((s) => itemStats[s] !== undefined);
        const typeMatch = hasItemType && hasItemType.some((t) => itemTypes.includes(t));

        return !!(statMatch || typeMatch);
      }
      return false;
    });
  }, [selectedItem, GAME_DATA, player]);

  const enchantmentDetails = useMemo(() => {
    if (!player || !selectedItem || !selectedEnchantment) return null;
    return calculateEnchantmentDetails(player, selectedItem, selectedEnchantment, itemTier, GAME_DATA);
  }, [player, selectedItem, selectedEnchantment, GAME_DATA, itemTier]);

  const handleEnchant = () => {
    if (!enchantmentDetails?.canEnchant || !selectedItem || !selectedEnchantment) return;
    const { enchantDef } = enchantmentDetails;
    const rank = selectedEnchantment.tier - 1;

    setIsEnchanting(true);
    enchantItem(selectedItem.unique_id, enchantDef, rank, (newItem) => {
      // The useEffect will handle updating the selectedItem based on the new player state
      setIsEnchanting(false);
    });
    setSelectedEnchantment(null);
  };

  const handleSelectItem = (_e: React.MouseEvent, item: ItemInstance) => {
    setSelectedItem({ ...item, quantity: 1 });
    setSelectedEnchantment(null);
  };

  const handleSelectTier = (enchantId: string, tier: number) => {
    if (selectedEnchantment?.enchantId === enchantId && selectedEnchantment?.tier === tier) {
      setSelectedEnchantment(null);
    } else {
      setSelectedEnchantment({ enchantId, tier });
    }
  };

  return {
    player,
    selectedItem,
    setSelectedItem,
    selectedEnchantment,
    setSelectedEnchantment,
    inventoryItems,
    itemTier,
    numEnchantments,
    hasMaxEnchants,
    availableEnchants,
    enchantmentDetails,
    handleEnchant,
    handleSelectItem,
    handleSelectTier,
  };
};