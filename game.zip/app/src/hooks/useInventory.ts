import { useContext } from "react";
import { PlayerContext } from "context/PlayerContext";
import { InventoryContext } from "context/InventoryContext";

export const useInventory = () => {
  const playerContext = useContext(PlayerContext);
  const inventoryContext = useContext(InventoryContext);

  if (!playerContext || !inventoryContext) {
    throw new Error("useInventory must be used within the required providers");
  }

  const { player } = playerContext;
  const {
    addItem,
    removeItem,
    removeItemByInstance,
    equipItem,
    unequipItem,
    dropItem,
    dropItems,
    consumeItem,
    moveItemToBank,
    moveItemsToBank,
    moveItemFromBank,
    moveItemsFromBank,
    moveItemToContainer,
    moveItemFromContainer,
    giftItemToMercenary,
  } = inventoryContext;

  return {
    inventory: player?.inventory,
    equipment: player?.equipment,
    bank: player?.bank,
    gold: player?.gold,
    currentWeight: player?.currentWeight,
    maxWeight: player?.maxWeight,
    addItem,
    removeItem,
    removeItemByInstance,
    equipItem,
    unequipItem,
    dropItem,
    dropItems,
    consumeItem,
    moveItemToBank,
    moveItemsToBank,
    moveItemFromBank,
    moveItemsFromBank,
    moveItemToContainer,
    moveItemFromContainer,
    giftItemToMercenary,
  };
};