import { useContext } from 'react';
import { InventoryContext } from 'context/InventoryContext';
import { usePlayer } from './usePlayer';

export const useInventory = () => {
  const player = usePlayer();
  const inventoryContext = useContext(InventoryContext);

  if (!inventoryContext) {
    throw new Error('useInventory must be used within the required providers');
  }

  const {
    addItem,
    removeItem,
    removeItemByInstance,
    equipItem,
    unequipItem,
    dropItem,
    dropItems,
    consumeItem,
    moveItemToBank,
    moveItemsToBank,
    moveItemFromBank,
    moveItemsFromBank,
    moveItemToContainer,
    moveItemFromContainer,
    giftItemToMercenary,
  } = inventoryContext;

  return {
    inventory: player?.inventory,
    equipment: player?.equipment,
    bank: player?.bank,
    gold: player?.gold,
    currentWeight: player?.currentWeight,
    maxWeight: player?.maxCarryWeight,
    addItem,
    removeItem,
    removeItemByInstance,
    equipItem,
    unequipItem,
    dropItem,
    dropItems,
    consumeItem,
    moveItemToBank,
    moveItemsToBank,
    moveItemFromBank,
    moveItemsFromBank,
    moveItemToContainer,
    moveItemFromContainer,
    giftItemToMercenary,
  };
};