import { GameData } from "types";

export const ITEM_SETS: GameData["ITEM_SETS"] = {
  valiant: {
    name: "Plate of the Valiant",
    bonuses: {
      2: { stats: { armor: 10 }, desc: "2 Piece: +10 Armor" },
      3: {
        stats: { strength: 5, constitution: 5 },
        desc: "3 Piece: +5 Strength, +5 Constitution",
      },
    },
  },
  serpent_scale: {
    name: "Serpent Scale Armor",
    bonuses: {
      2: {
        special: "serpent_reflexes",
        desc: "2 Piece: Your attacks have a 15% chance to inflict a Stage 2 Cut.",
      },
    },
  },
};
