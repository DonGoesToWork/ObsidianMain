import { GameData } from "types";

export const GUILD_DATA: GameData["GUILD_DATA"] = {
  levels: [
    {
      xpToNext: 10000,
      bonus: { desc: "+5% Max HP", effect: { maxHp_mod: 1.05 } },
    },
    {
      xpToNext: 50000,
      bonus: {
        desc: "+5% Max HP, +2% All Primary Stats",
        effect: { maxHp_mod: 1.05, primary_stats_mod: 1.02 },
      },
    },
  ],
  donationTiers: {
    gold: { value: 1000, xp: 100 },
    material_common: { value: 10, xp: 10 },
    material_uncommon: { value: 5, xp: 25 },
  },
};