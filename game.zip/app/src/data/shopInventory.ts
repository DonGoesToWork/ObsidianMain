import { ItemId } from 'types';

// This is a curated list of items that can appear in a general store.
// The actual stock is determined by location level and random chance at restock time.
export const SHOP_INVENTORY: ItemId[] = [
  // --- Potions ---
  'p001', // Minor Health
  'p002', // Minor Mana
  'p007', // Minor Stamina
  'p004', // Antidote

  // --- Bandages ---
  'item_bandage_1',
  'item_bandage_2',
  'item_bandage_3',
  'item_bandage_4',
  'item_bandage_5',
  'item_phoenix_feather',

  // --- Survival ---
  'i_ration',
  'i_waterskin',
  'i_coffee',
  'i_tent',
  'i_trap',

  // --- Tools ---
  'tool_pickaxe01',
  'tool_lens01',
  'tool_hammer01',
  'tool_axe_wood01',
  // Molds
  'tool_ingot_mold',
  'tool_dagger_mold',
  'tool_shortsword_mold',
  'tool_longsword_mold',
  'tool_greatsword_mold',
  'tool_war-axe_mold',
  'tool_mace_mold',
  'tool_shield_mold',
  'tool_helmet_mold',
  'tool_chestplate_mold',
  'tool_greaves_mold',
  'tool_chest_mold',
  'tool_armlet_mold',
  'tool_legging_mold',
  'tool_boot_mold',
  'tool_glove_mold',
  'tool_groinguard_mold',

  // --- Materials ---
  'mat_equip_wood',
  'mat_equip_stone',
  'mat_ore_iron',
  'mat_ore_coal',

  // --- Magic Crystals (T1-T5 for general stores) ---
  'mat_crystal_t1',
  'mat_crystal_t2',
  'mat_crystal_t3',
  'mat_crystal_t4',
  'mat_crystal_t5',

  // --- Reforging Embers (T1-T5 for general stores) ---
  'mat_reforge_ember_t1',
  'mat_reforge_ember_t2',
  'mat_reforge_ember_t3',
  'mat_reforge_ember_t4',
  'mat_reforge_ember_t5',

  // --- Recipes ---
  'recipe_minor_health_potion',
  'recipe_ingot_copper',
  'recipe_ingot_tin',
  'recipe_ingot_bronze',
  'recipe_ingot_iron',
  'recipe_ingot_steel',
];