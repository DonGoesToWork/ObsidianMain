import { GameData, Quest } from "types";

export const QUESTS: GameData["QUESTS"] = {
  q001_main: {
    name: "A Rat Problem",
    giver: "Guard Captain",
    type: "main",
    startDesc:
      "The forest path is infested with oversized rats. We need someone to clear them out. Kill 5 Giant Rats for me, and I'll make it worth your while.",
    objective: { type: "kill", target: "m001", count: 5 },
    reward: {
      xp: 100,
      gold: 50,
      reputation: { faction: "haven_guard", points: 50 },
    },
  },
  q002_main: {
    name: "The Cursed Mines",
    giver: "Guard Captain",
    type: "main",
    prereq: "q001_main",
    startDesc:
      "Excellent work. Now, a more serious threat. The old mine is stirring with undead. We believe a powerful Foreman is leading them. Defeat him so we can reclaim the mine.",
    objective: { type: "kill", target: "m005_boss", count: 1 },
    reward: {
      xp: 500,
      gold: 250,
      items: ["mat_crystal_t1"],
      reputation: { faction: "haven_guard", points: 150 },
    },
  },
  q003_main: {
    name: "Into the Fen",
    giver: "Guard Captain",
    type: "main",
    prereq: "q002_main",
    levelReq: 12,
    startDesc:
      "We're getting reports of serpentine creatures in the Shadowfen to the south. It's too dangerous for our regular patrols. Scout the area and kill 5 Fen Serpents so we know what we're dealing with.",
    objective: { type: "kill", target: "m009", count: 5 },
    reward: {
      xp: 1000,
      gold: 800,
      reputation: { faction: "haven_guard", points: 250 },
    },
  },
  q004_main: {
    name: "The Serpent God",
    giver: "Guard Captain",
    type: "main",
    prereq: "q003_main",
    levelReq: 15,
    startDesc:
      "Serpents are one thing, but our scouts whisper of an ancient temple where they worship a monstrous god, Yig. This must be the source. Venture into the Sunken Temple and destroy it.",
    objective: { type: "kill", target: "m012_boss", count: 1 },
    reward: {
      xp: 3000,
      gold: 2500,
      items: ["mat_crystal_t2"],
      reputation: { faction: "haven_guard", points: 500 },
    },
  },
  q101_side: {
    name: "Gems for the Jeweler",
    giver: "Guard Captain",
    type: "side",
    prereq: "q001_main",
    startDesc:
      "The local jeweler needs some raw materials. Could you bring me 10 Stone Chunks? You can often find them in the Cursed Mines. I'll pass them along.",
    objective: { type: "gather", target: "mat_equip_stone", count: 10 },
    reward: { xp: 150, gold: 100, professions: { jewelcrafting: 25 } },
  },
  q_daily_haven_guard: {
    name: "[Daily] Goblin Patrol",
    giver: "Guard Captain",
    type: "daily",
    levelReq: 2,
    startDesc:
      "Those pesky goblins are always a nuisance. Thin their numbers for us. Kill 10 Forest Goblins and I'll have a reward for you. Come back tomorrow for more work.",
    objective: { type: "kill", target: "m002", count: 10 },
    reward: {
      xp: 200,
      gold: 100,
      reputation: { faction: "haven_guard", points: 75 },
    },
  },
};