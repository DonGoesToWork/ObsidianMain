import { GameData } from 'types';

export const PETS: GameData['PETS'] = { wolf: { name: 'Wolf', baseStats: { attack: 8, hp: 50, armor: 5 }, statGainPerLevel: { attack: 2, hp: 10, armor: 1 } } };
