import { Ability, AbilityId, EnchantDef, EquipmentSlot, GameItem, ItemId, ItemType, ProfessionId, Recipe, RecipeId, StatBlock } from 'types';
import { toRoman } from 'utils/formatUtils';

interface EquipmentMaterial {
  id: ItemId;
  profession: ProfessionId;
  namePart: string;
}

interface EquipmentTemplate {
  professions: ProfessionId[];
  baseName: string;
  nameOverrides?: Partial<Record<ProfessionId, string>>;
  icon: string;
  materialCost: number;
  secondaryMaterials?: Record<ItemId, number>;
  baseWeight: number;
  valueMultiplier: number;
  itemLevelModifier: number;
  baseDurability: number;
  isTwoHanded?: boolean;
  requiredTool?: ItemId;
  moldFor?: string;
  requiresForge?: boolean;
  defaultAttack?: { name: string; tags: string[] };
  slot?: EquipmentSlot;
  itemTypes?: ItemType[];
  stat?: keyof StatBlock;
  capacity?: number;
}

const EQUIPMENT_MATERIALS: EquipmentMaterial[] = [
  // --- Smithing Materials
  // Wood, Bone & Stone
  { id: 'mat_equip_wood', profession: 'smithing', namePart: 'Oak' },
  { id: 'mat_equip_stone', profession: 'smithing', namePart: 'Stone' },
  { id: 'mat_equip_yew', profession: 'smithing', namePart: 'Yew' },
  { id: 'mat_equip_ironwood', profession: 'smithing', namePart: 'Ironwood' },
  { id: 'mat_equip_obsidian', profession: 'smithing', namePart: 'Obsidian' },
  { id: 'mat_equip_petrified_wood', profession: 'smithing', namePart: 'Petrified' },
  { id: 'mat_equip_demon_bone', profession: 'smithing', namePart: 'Demonbone' },
  { id: 'mat_equip_ancient_wood', profession: 'smithing', namePart: 'Ancient' },
  { id: 'mat_equip_astral_stone', profession: 'smithing', namePart: 'Astral' },
  { id: 'mat_equip_dragonbone', profession: 'smithing', namePart: 'Dragonbone' },
  { id: 'mat_equip_divine_wood', profession: 'smithing', namePart: 'Divine' },
  // Ingots
  { id: 'mat_ingot_bronze', profession: 'smithing', namePart: 'Bronze' },
  { id: 'mat_ingot_iron', profession: 'smithing', namePart: 'Iron' },
  { id: 'mat_ingot_silver', profession: 'smithing', namePart: 'Silver' },
  { id: 'mat_ingot_steel', profession: 'smithing', namePart: 'Steel' },
  { id: 'mat_ingot_mithril', profession: 'smithing', namePart: 'Mithril' },
  { id: 'mat_ingot_cobalt', profession: 'smithing', namePart: 'Cobalt' },
  { id: 'mat_ingot_adamantite', profession: 'smithing', namePart: 'Adamantite' },
  { id: 'mat_ingot_orichalcum', profession: 'smithing', namePart: 'Orichalcum' },
  { id: 'mat_ingot_thorium', profession: 'smithing', namePart: 'Thorium' },
  { id: 'mat_ingot_divinite', profession: 'smithing', namePart: 'Divinite' },

  // --- Leatherworking Materials
  { id: 'mat_leather_scraps', profession: 'leatherworking', namePart: 'Scrap-Leather' },
  { id: 'mat_leather_basic', profession: 'leatherworking', namePart: 'Leather' },
  { id: 'mat_leather_hardened', profession: 'leatherworking', namePart: 'Hardened Leather' },
  { id: 'mat_leather_thick', profession: 'leatherworking', namePart: 'Thick Leather' },
  { id: 'mat_leather_bristly', profession: 'leatherworking', namePart: 'Bristly Leather' },
  { id: 'mat_leather_scaled', profession: 'leatherworking', namePart: 'Scaled Leather' },
  { id: 'mat_leather_drake', profession: 'leatherworking', namePart: 'Drake Leather' },
  { id: 'mat_leather_wyrm', profession: 'leatherworking', namePart: 'Wyrmhide' },
  { id: 'mat_leather_demonic', profession: 'leatherworking', namePart: 'Demonic Leather' },
  { id: 'mat_leather_shadow', profession: 'leatherworking', namePart: 'Shadow-Hide' },
  { id: 'mat_leather_divine', profession: 'leatherworking', namePart: 'Divine Leather' },

  // --- Tailoring Materials
  { id: 'mat_cloth_scraps', profession: 'tailoring', namePart: 'Scrap-Cloth' },
  { id: 'mat_cloth_linen', profession: 'tailoring', namePart: 'Linen' },
  { id: 'mat_cloth_wool', profession: 'tailoring', namePart: 'Wool' },
  { id: 'mat_cloth_silk', profession: 'tailoring', namePart: 'Silk' },
  { id: 'mat_cloth_mageweave', profession: 'tailoring', namePart: 'Mageweave' },
  { id: 'mat_cloth_runic', profession: 'tailoring', namePart: 'Runic' },
  { id: 'mat_cloth_ghostly', profession: 'tailoring', namePart: 'Ghostly' },
  { id: 'mat_cloth_phase', profession: 'tailoring', namePart: 'Phase-Thread' },
  { id: 'mat_cloth_ebon', profession: 'tailoring', namePart: 'Ebon' },
  { id: 'mat_cloth_celestial', profession: 'tailoring', namePart: 'Celestial' },
  { id: 'mat_cloth_godweave', profession: 'tailoring', namePart: 'God-Weave' },
];

const WEAPON_TEMPLATES: Record<string, EquipmentTemplate> = {
  dagger: {
    slot: 'weapon',
    professions: ['smithing'],
    baseName: 'Dagger',
    icon: '🗡️',
    materialCost: 1,
    baseWeight: 1,
    stat: 'attackPower',
    valueMultiplier: 2.5,
    itemLevelModifier: 0,
    moldFor: 'dagger',
    requiresForge: true,
    baseDurability: 100,
    defaultAttack: { name: 'Stab', tags: ['Pierce'] },
  },
  shortsword: {
    slot: 'weapon',
    professions: ['smithing'],
    baseName: 'Shortsword',
    icon: '⚔️',
    materialCost: 3,
    baseWeight: 3,
    stat: 'attackPower',
    valueMultiplier: 4,
    itemLevelModifier: 1,
    moldFor: 'shortsword',
    requiresForge: true,
    baseDurability: 150,
    defaultAttack: { name: 'Slash', tags: ['Slashing'] },
  },
  longsword: {
    slot: 'weapon',
    professions: ['smithing'],
    baseName: 'Longsword',
    icon: '⚔️',
    materialCost: 5,
    baseWeight: 5,
    stat: 'attackPower',
    valueMultiplier: 6,
    itemLevelModifier: 2,
    moldFor: 'longsword',
    requiresForge: true,
    baseDurability: 200,
    defaultAttack: { name: 'Slash', tags: ['Slashing'] },
  },
  greatsword: {
    slot: 'weapon',
    professions: ['smithing'],
    baseName: 'Greatsword',
    icon: '⚔️',
    isTwoHanded: true,
    materialCost: 8,
    baseWeight: 8,
    stat: 'attackPower',
    valueMultiplier: 8,
    itemLevelModifier: 4,
    moldFor: 'greatsword',
    requiresForge: true,
    baseDurability: 250,
    defaultAttack: { name: 'Cleave', tags: ['Slashing'] },
  },
  'war-axe': {
    slot: 'weapon',
    professions: ['smithing'],
    baseName: 'War-Axe',
    icon: '🪓',
    materialCost: 4,
    baseWeight: 6,
    stat: 'attackPower',
    valueMultiplier: 5,
    itemLevelModifier: 3,
    moldFor: 'war-axe',
    requiresForge: true,
    baseDurability: 180,
    defaultAttack: { name: 'Chop', tags: ['Slashing'] },
  },
  mace: {
    slot: 'weapon',
    professions: ['smithing'],
    baseName: 'Mace',
    icon: '🔨',
    materialCost: 4,
    baseWeight: 7,
    stat: 'attackPower',
    valueMultiplier: 4.5,
    itemLevelModifier: 2,
    moldFor: 'mace',
    requiresForge: true,
    baseDurability: 220,
    defaultAttack: { name: 'Bash', tags: ['Blunt'] },
  },
  staff: {
    slot: 'weapon',
    professions: ['smithing'],
    baseName: 'Staff',
    icon: '🥍',
    isTwoHanded: true,
    materialCost: 5,
    baseWeight: 4,
    stat: 'spellPower',
    valueMultiplier: 4,
    itemLevelModifier: 0,
    baseDurability: 120,
    defaultAttack: { name: 'Whack', tags: ['Blunt'] },
  },
  'hunting-bow': {
    slot: 'weapon',
    professions: ['smithing'],
    baseName: 'Hunting Bow',
    icon: '🏹',
    isTwoHanded: true,
    materialCost: 4,
    baseWeight: 3,
    stat: 'attackPower',
    valueMultiplier: 3.5,
    itemLevelModifier: 1,
    baseDurability: 100,
    defaultAttack: { name: 'Shoot', tags: ['Pierce'] },
  },
  longbow: {
    slot: 'weapon',
    professions: ['smithing'],
    baseName: 'Longbow',
    icon: '🏹',
    isTwoHanded: true,
    materialCost: 6,
    baseWeight: 5,
    stat: 'attackPower',
    valueMultiplier: 5.5,
    itemLevelModifier: 3,
    baseDurability: 150,
    defaultAttack: { name: 'Shoot', tags: ['Pierce'] },
  },
};

const ARMOR_TEMPLATES: Record<string, EquipmentTemplate> = {
  shield: {
    slot: 'shield',
    professions: ['smithing'],
    baseName: 'Shield',
    icon: '🛡️',
    materialCost: 4,
    baseWeight: 6,
    stat: 'armor',
    valueMultiplier: 4,
    itemLevelModifier: 1,
    moldFor: 'shield',
    requiresForge: true,
    baseDurability: 300,
  },
  helmet: {
    slot: 'head',
    professions: ['smithing', 'leatherworking'],
    baseName: 'Helmet',
    icon: '👑',
    materialCost: 4,
    baseWeight: 2,
    stat: 'armor',
    valueMultiplier: 3,
    itemLevelModifier: 2,
    moldFor: 'helmet',
    requiresForge: true,
    baseDurability: 250,
  },
  chestplate: {
    slot: 'chest',
    professions: ['smithing'],
    baseName: 'Chestplate',
    icon: '👕',
    materialCost: 12,
    baseWeight: 15,
    stat: 'armor',
    valueMultiplier: 8,
    itemLevelModifier: 9,
    moldFor: 'chestplate',
    requiresForge: true,
    baseDurability: 500,
  },
  chainbody: {
    slot: 'chest',
    professions: ['smithing'],
    baseName: 'Chainbody',
    icon: '👕',
    materialCost: 8,
    secondaryMaterials: { mat_leather_basic: 6 },
    baseWeight: 12,
    stat: 'armor',
    valueMultiplier: 7,
    itemLevelModifier: 3,
    moldFor: 'chestplate',
    requiresForge: true,
    baseDurability: 400,
  },
  'leather-jerkin': {
    slot: 'chest',
    professions: ['leatherworking'],
    baseName: 'Jerkin',
    icon: '👕',
    materialCost: 7,
    baseWeight: 4,
    stat: 'armor',
    valueMultiplier: 5,
    itemLevelModifier: 2,
    baseDurability: 200,
  },
  'cloth-robe': {
    slot: 'chest',
    professions: ['tailoring'],
    baseName: 'Robe',
    icon: '👕',
    materialCost: 6,
    baseWeight: 3,
    stat: 'armor',
    valueMultiplier: 5,
    itemLevelModifier: 2,
    baseDurability: 80,
  },
  'leather-cap': {
    slot: 'head',
    professions: ['leatherworking'],
    baseName: 'Cap',
    icon: '👑',
    materialCost: 2,
    baseWeight: 1,
    stat: 'armor',
    valueMultiplier: 2.5,
    itemLevelModifier: 0,
    baseDurability: 100,
  },
  'cloth-cowl': {
    slot: 'head',
    professions: ['tailoring'],
    baseName: 'Cowl',
    icon: '👑',
    materialCost: 3,
    baseWeight: 1,
    stat: 'armor',
    valueMultiplier: 3,
    itemLevelModifier: 1,
    baseDurability: 60,
  },
  left_armlet: {
    slot: 'left_armlet',
    professions: ['leatherworking', 'smithing'],
    baseName: 'Left Armlet',
    icon: '🛡️',
    materialCost: 2,
    baseWeight: 1,
    stat: 'armor',
    valueMultiplier: 2,
    itemLevelModifier: 0,
    baseDurability: 80,
    moldFor: 'left_armlet',
    requiresForge: true,
  },
  right_armlet: {
    slot: 'right_armlet',
    professions: ['leatherworking', 'smithing'],
    baseName: 'Right Armlet',
    icon: '🛡️',
    materialCost: 2,
    baseWeight: 1,
    stat: 'armor',
    valueMultiplier: 2,
    itemLevelModifier: 0,
    baseDurability: 80,
    moldFor: 'right_armlet',
    requiresForge: true,
  },
  left_legging: {
    slot: 'left_legging',
    professions: ['leatherworking', 'smithing', 'tailoring'],
    baseName: 'Left Legging',
    icon: '👖',
    materialCost: 5,
    baseWeight: 3,
    stat: 'armor',
    valueMultiplier: 4,
    itemLevelModifier: 1,
    baseDurability: 150,
    moldFor: 'left_legging',
    requiresForge: true,
  },
  right_legging: {
    slot: 'right_legging',
    professions: ['leatherworking', 'smithing', 'tailoring'],
    baseName: 'Right Legging',
    icon: '👖',
    materialCost: 5,
    baseWeight: 3,
    stat: 'armor',
    valueMultiplier: 4,
    itemLevelModifier: 1,
    baseDurability: 150,
    moldFor: 'right_legging',
    requiresForge: true,
  },
  left_boot: {
    slot: 'left_foot',
    professions: ['leatherworking', 'smithing', 'tailoring'],
    baseName: 'Left Boot',
    icon: '👢',
    materialCost: 3,
    baseWeight: 2,
    stat: 'armor',
    valueMultiplier: 3,
    itemLevelModifier: 0,
    baseDurability: 120,
    moldFor: 'left_boot',
    requiresForge: true,
  },
  right_boot: {
    slot: 'right_foot',
    professions: ['leatherworking', 'smithing', 'tailoring'],
    baseName: 'Right Boot',
    icon: '👢',
    materialCost: 3,
    baseWeight: 2,
    stat: 'armor',
    valueMultiplier: 3,
    itemLevelModifier: 0,
    baseDurability: 120,
    moldFor: 'right_boot',
    requiresForge: true,
  },
  left_glove: {
    slot: 'left_glove',
    professions: ['leatherworking', 'smithing', 'tailoring'],
    baseName: 'Left Glove',
    nameOverrides: {
      smithing: 'Left Gauntlet',
      leatherworking: 'Left Grip',
      tailoring: 'Left Glove',
    },
    icon: '🧤',
    materialCost: 2,
    baseWeight: 1,
    stat: 'armor',
    valueMultiplier: 2.5,
    itemLevelModifier: 0,
    baseDurability: 100,
    moldFor: 'left_glove',
    requiresForge: true,
  },
  right_glove: {
    slot: 'right_glove',
    professions: ['leatherworking', 'smithing', 'tailoring'],
    baseName: 'Right Glove',
    nameOverrides: {
      smithing: 'Right Gauntlet',
      leatherworking: 'Right Grip',
      tailoring: 'Right Glove',
    },
    icon: '🧤',
    materialCost: 2,
    baseWeight: 1,
    stat: 'armor',
    valueMultiplier: 2.5,
    itemLevelModifier: 0,
    baseDurability: 100,
    moldFor: 'right_glove',
    requiresForge: true,
  },
  groinguard: {
    slot: 'groin',
    professions: ['leatherworking', 'smithing', 'tailoring'],
    baseName: 'Groinguard',
    icon: '🛡️',
    materialCost: 3,
    baseWeight: 2,
    stat: 'armor',
    valueMultiplier: 3.5,
    itemLevelModifier: 1,
    baseDurability: 130,
    moldFor: 'groinguard',
    requiresForge: true,
  },
};

const CONTAINER_TEMPLATES: Record<string, EquipmentTemplate> = {
  chest: {
    professions: ['smithing'],
    itemTypes: ['container'],
    baseName: 'Chest',
    icon: '🧰',
    materialCost: 20,
    baseWeight: 15,
    capacity: 100,
    valueMultiplier: 10,
    itemLevelModifier: 5,
    moldFor: 'chest',
    requiresForge: true,
    baseDurability: 300,
  },
};

const ALL_TEMPLATES = { ...WEAPON_TEMPLATES, ...ARMOR_TEMPLATES, ...CONTAINER_TEMPLATES };

export function generateAll(materialsData: Record<ItemId, GameItem>) {
  const generatedItems: Record<ItemId, GameItem> = {};
  const generatedRecipes: Record<RecipeId, Recipe> = {};
  const generatedRecipeItems: Record<ItemId, GameItem> = {};

  for (const material of EQUIPMENT_MATERIALS) {
    const materialData = materialsData[material.id];
    if (!materialData) continue;

    for (const [templateKey, template] of Object.entries(ALL_TEMPLATES)) {
      if (!template.professions.includes(material.profession)) continue;

      const itemId = `gen_${material.profession}_${material.id}_${templateKey}` as ItemId;
      const recipeId = `rec_${itemId}` as RecipeId;

      const isContainer = template.itemTypes?.includes('container') ?? false;
      const templateBaseName = template.nameOverrides?.[material.profession] || template.baseName;
      const itemName = `${material.namePart} ${templateBaseName}`;
      const itemLevel = materialData.itemLevel + template.itemLevelModifier;
      const materialDurabilityMod = (materialData as GameItem).durabilityMod || 1.0;

      const newItem: GameItem = {
        name: itemName,
        icon: template.icon,
        type: template.itemTypes || ['equipment'],
        itemLevel: itemLevel,
        weight: template.baseWeight + materialData.weight * template.materialCost,
        value: Math.ceil(materialData.value * template.valueMultiplier),
        material: material.id,
        recipeId: recipeId,
        baseDurability: Math.round(template.baseDurability * materialDurabilityMod),
        stackable: true,
      };

      if (isContainer) {
        newItem.capacity = Math.round((template.capacity || 50) * materialDurabilityMod);
      } else {
        newItem.slot = template.slot;
        const newItemStats: Partial<StatBlock> = {};
        if (template.stat) {
          const materialHardness = materialData.hardness || Math.max(1, Math.round(materialData.itemLevel / 5));
          const baseStatValue = materialHardness * template.materialCost * 0.5;

          newItemStats[template.stat] = Math.ceil(baseStatValue);

          if (template.slot === 'weapon') {
            newItemStats.accuracy = Math.ceil(baseStatValue / 10);
          }

          const attackSpeedPenaltyValue = materialHardness * template.materialCost * 0.5;
          newItemStats.attackSpeed = -(attackSpeedPenaltyValue / 1000);
        }

        newItem.stats = newItemStats;
        newItem.twoHanded = template.isTwoHanded;
        newItem.defaultAttack = template.defaultAttack;
      }

      const materials: Record<string, number> = { [material.id]: template.materialCost };
      if (template.secondaryMaterials) {
        for (const [matId, cost] of Object.entries(template.secondaryMaterials)) {
          materials[matId] = cost;
        }
      }

      const newRecipe: Recipe = {
        id: recipeId,
        name: itemName,
        profession: material.profession,
        levelReq: itemLevel,
        xp: itemLevel * 5,
        creates: itemId,
        quantity: 1,
        materials: materials,
        requiresForge: template.requiresForge,
      };

      const toolList: ItemId[] = [];
      if (template.professions.includes('smithing')) {
        toolList.push('tool_hammer01');
      }
      if (isContainer) {
        toolList.push('tool_chest_mold');
      } else if (template.moldFor) {
        const moldId = `tool_${template.moldFor}_mold` as ItemId;
        toolList.push(moldId);
      }
      if (toolList.length > 0) {
        newRecipe.tools = toolList;
      }

      generatedItems[itemId] = newItem;
      generatedRecipes[recipeId] = newRecipe;

      const recipeNoteId = `note_${recipeId}` as ItemId;
      const recipeNoteItem: GameItem = {
        name: `Recipe: ${itemName}`,
        type: ['knowledge'],
        itemLevel: newRecipe.levelReq,
        weight: 0.1,
        value: newRecipe.levelReq * 10 + 50,
        sellValue: Math.floor((newRecipe.levelReq * 10 + 50) / 4) || 1,
        teachesRecipe: recipeId,
        stackable: true,
        icon: '📜',
      };
      generatedRecipeItems[recipeNoteId] = recipeNoteItem;
    }
  }

  return { generatedItems, generatedRecipes, generatedRecipeItems };
}

export function generateSkillBooks(skillsData: Record<AbilityId, Ability>): { generatedItems: Record<ItemId, GameItem> } {
  const generatedItems: Record<ItemId, GameItem> = {};
  for (const [abilityId, ability] of Object.entries(skillsData)) {
    if (ability.abilityType !== 'Skill' && ability.abilityType !== 'Spell') {
      continue;
    }

    const isSkill = ability.abilityType === 'Skill';
    const itemType = isSkill ? 'scroll' : 'tome';
    const itemNamePrefix = isSkill ? 'Skill Scroll' : 'Spell Tome';
    const icon = isSkill ? '📜' : '📕';

    const itemId = `note_${itemType}_${abilityId}` as ItemId;

    const itemLevel = ability.levelReq || 1;
    const value = itemLevel * 20 + 100;

    const newItem: GameItem = {
      name: `${itemNamePrefix}: ${ability.name}`,
      type: ['knowledge'],
      itemLevel: itemLevel,
      weight: 0.1,
      value: value,
      sellValue: Math.floor(value / 4) || 1,
      teachesAbility: abilityId,
      stackable: true,
      desc: `A magical ${itemType} that teaches the reader the ${ability.abilityType.toLowerCase()} "${ability.name}".`,
      icon: icon,
    };

    generatedItems[itemId] = newItem;
  }

  return { generatedItems };
}

export function generateMemoryGlobes(enchantsData: EnchantDef[]): { generatedItems: Record<ItemId, GameItem> } {
  const generatedItems: Record<ItemId, GameItem> = {};
  for (const enchant of enchantsData) {
    enchant.scaling.forEach((_, index) => {
      const tier = index + 1;
      const enchantId = enchant.id;
      const recipeId = `${enchantId}_t${tier}`;
      const itemId = `note_enchantment_recipe_${recipeId}` as ItemId;
      const enchantName = `${enchant.name} ${toRoman(tier)}`;
      const fullDesc = `Unlocks the ${enchantName} Enchantment.\n\n${enchant.desc}`;

      const newItem: GameItem = {
        name: `Memory Globe: ${enchantName}`,
        icon: '🔮',
        type: ['knowledge'],
        itemLevel: tier * 10,
        weight: 0.1,
        value: enchant.gold[index] / 10,
        sellValue: Math.floor(enchant.gold[index] / 10 / 4) || 1,
        teachesEnchantmentRecipe: recipeId,
        desc: fullDesc,
        stackable: true,
      };
      generatedItems[itemId] = newItem;
    });
  }
  return { generatedItems };
}

export function generatePlusStones(): { generatedItems: Record<ItemId, GameItem> } {
  const generatedItems: Record<ItemId, GameItem> = {};
  for (let tier = 1; tier <= 11; tier++) {
    const itemId = `mat_plus_stone_t${tier}` as ItemId;
    const itemLevel = tier * 10 - 5;
    const value = tier * tier * 50;
    const newItem: GameItem = {
      name: `T${tier} Plus Stone`,
      icon: '➕',
      type: ['misc'],
      itemLevel: Math.max(1, itemLevel),
      weight: 0.5,
      value: value,
      sellValue: Math.floor(value / 4),
      stackable: true,
      desc: `A magical stone that can enhance equipment. Can upgrade an item with a plus value lower than ${tier}.`,
      plusStoneTier: tier,
      primaryAction: 'pick_up',
    };
    generatedItems[itemId] = newItem;
  }
  return { generatedItems };
}

export function generateEnchantingOrbs(enchantsData: EnchantDef[]): { generatedItems: Record<ItemId, GameItem> } {
  const generatedItems: Record<ItemId, GameItem> = {};
  for (const enchant of enchantsData) {
    enchant.scaling.forEach((_, index) => {
      const tier = index + 1;
      const enchantId = enchant.id;
      const itemId = `gen_enchanting_orb_${enchantId}_t${tier}` as ItemId;
      const enchantName = `${enchant.name} ${toRoman(tier)}`;
      const fullDesc = `An orb containing the essence of the '${enchantName}' enchantment. Use this on a piece of equipment to apply the enchantment with 100% success.`;
      const value = (enchant.gold[index] || 0) * 2;

      const newItem: GameItem = {
        name: `Enchanting Orb: ${enchantName}`,
        icon: '🔮',
        type: ['misc', 'consumable'],
        itemLevel: tier * 10 - 5,
        weight: 0.1,
        value: value,
        sellValue: Math.floor(value / 4),
        desc: fullDesc,
        stackable: true,
        primaryAction: 'pick_up',
        bestowsEnchantment: {
          id: enchantId,
          tier: tier,
        },
      };
      generatedItems[itemId] = newItem;
    });
  }
  return { generatedItems };
}