import { GameData } from 'types';

export const RACES: GameData['RACES'] = {
  human: {
    name: 'Human',
    desc: 'Versatile and ambitious, humans gain an extra perk point to begin their journey.',
    unarmedWeapon: 'unarmed_fist',
    bonus: { perkPoints: 1, attributePoints: 2 },
    baseWeight: 150,
  },
  elf: {
    name: 'Elf',
    desc: 'Graceful and attuned to magic, elves start with higher intelligence and dexterity.',
    unarmedWeapon: 'unarmed_fist',
    bonus: { stats: { intelligence: 1, dexterity: 1 } },
    baseWeight: 120,
  },
  dwarf: {
    name: 'Dwarf',
    desc: 'Sturdy and resilient, dwarves have a natural knack for smithing and higher constitution.',
    unarmedWeapon: 'unarmed_fist',
    bonus: { stats: { strength: 1, constitution: 1 }, professions: { smithing: 5 } },
    baseWeight: 180,
  },
  orc: {
    name: 'Orc',
    desc: 'Fierce and strong, Orcs are natural warriors, excelling in raw power.',
    unarmedWeapon: 'unarmed_fist',
    bonus: { stats: { strength: 2, constitution: 1, intelligence: -1 } },
    baseWeight: 200,
  },
  // Monster Races
  rat: { name: 'Rat', desc: 'A rodent, often grown to monstrous sizes in cursed lands.', unarmedWeapon: 'unarmed_bite', bonus: {}, baseWeight: 5 },
  goblin: { name: 'Goblin', desc: 'A small, cruel and craven creature, dangerous in numbers.', unarmedWeapon: 'unarmed_fist', bonus: {}, baseWeight: 40 },
  wolf: { name: 'Wolf', desc: 'A natural predator of the wilds.', unarmedWeapon: 'unarmed_claws', bonus: {}, baseWeight: 70 },
  crawler: { name: 'Crawler', desc: 'An insectoid or subterranean creature.', unarmedWeapon: 'unarmed_pincers', bonus: {}, baseWeight: 100 },
  undead: { name: 'Undead', desc: 'A corpse reanimated by foul magic.', unarmedWeapon: 'unarmed_fist', bonus: {}, baseWeight: 150 },
  elemental: { name: 'Elemental', desc: 'A being of pure elemental force.', unarmedWeapon: 'unarmed_fist', bonus: {}, baseWeight: 250 },
  yeti: { name: 'Yeti', desc: 'A large, ape-like creature of the frozen peaks.', unarmedWeapon: 'unarmed_fist', bonus: {}, baseWeight: 400 },
  serpent: { name: 'Serpent', desc: 'A scaled, serpentine creature.', unarmedWeapon: 'unarmed_bite', bonus: {}, baseWeight: 100 },
  naga: { name: 'Naga', desc: 'A humanoid creature with a serpentine lower body.', unarmedWeapon: 'unarmed_fist', bonus: {}, baseWeight: 170 },
  beast: { name: 'Beast', desc: 'A catch-all term for monstrous animals.', unarmedWeapon: 'unarmed_claws', bonus: {}, baseWeight: 150 },
};
