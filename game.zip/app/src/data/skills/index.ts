import { GameData } from 'types';
import { CLERIC_SKILLS } from './cleric';
import { LIGHTNING_SKILLS } from './lightning';
import { MAGE_SKILLS } from './mage';
import { PASSIVE_SKILLS } from './passives';
import { RANGER_SKILLS } from './ranger';
import { ROGUE_SKILLS } from './rogue';
import { UTILITY_SKILLS } from './utility';
import { WARRIOR_SKILLS } from './warrior';

export const SKILLS: GameData['SKILLS'] = {
  ...WARRIOR_SKILLS,
  ...MAGE_SKILLS,
  ...ROGUE_SKILLS,
  ...CLERIC_SKILLS,
  ...RANGER_SKILLS,
  ...LIGHTNING_SKILLS,
  ...UTILITY_SKILLS,
  ...PASSIVE_SKILLS,
};
