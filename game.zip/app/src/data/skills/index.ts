import { GameData } from "types";
import { WARRIOR_SKILLS } from "./warrior";
import { MAGE_SKILLS } from "./mage";
import { ROGUE_SKILLS } from "./rogue";
import { CLERIC_SKILLS } from "./cleric";
import { RANGER_SKILLS } from "./ranger";
import { LIGHTNING_SKILLS } from "./lightning";
import { UTILITY_SKILLS } from "./utility";
import { PASSIVE_SKILLS } from "./passives";

export const SKILLS: GameData["SKILLS"] = {
  ...WARRIOR_SKILLS,
  ...MAGE_SKILLS,
  ...ROGUE_SKILLS,
  ...CLERIC_SKILLS,
  ...RANGER_SKILLS,
  ...LIGHTNING_SKILLS,
  ...UTILITY_SKILLS,
  ...PASSIVE_SKILLS,
};