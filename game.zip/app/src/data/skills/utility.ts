import { GameData } from 'types';

export const UTILITY_SKILLS: GameData['SKILLS'] = {
  s_guard: {
    name: 'Guard',
    desc: 'Take a defensive stance, reducing incoming damage by 50% and increasing evasion rating by 50% for 1 turn.',
    abilityType: 'Skill',
    resourceType: 'SP',
    resourceCost: 10,
    damageTypeTags: [],
    targetRule: 'Self',
    range: 'N/A',
    aiTags: ['Buff'],
    category: 'Utility',
    effect: { type: 'buff', target: 'self', applyStatusEffect: { id: 'guarding', turns: 2 } }, // 2 turns so it lasts until the start of your next turn
    validTargets: ['self'],
  },
};
