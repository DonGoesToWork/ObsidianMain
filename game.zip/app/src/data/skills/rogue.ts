import { GameData } from "types";

export const ROGUE_SKILLS: GameData["SKILLS"] = {
  s004: {
    name: "Poison Shiv",
    desc: "A quick stab with a poisoned blade, dealing 100% [+10% per rank] weapon damage and applying a deadly poison for 3 turns [+1 turn per rank].",
    abilityType: "Skill",
    resourceType: "SP",
    resourceCost: 12,
    damageTypeTags: ["Physical", "Poison", "Pierce"],
    targetRule: "SingleLimb",
    range: "Close",
    aiTags: ["Debuff", "Single Target Consistent Damage"],
    category: "Weapon",
    effect: {
      type: "damage",
      target: "any",
      multiplier: 1.0,
      scalesWith: "attackPower",
      applyStatusEffect: { id: "poisoned", chance: 1.0, turns: 3 },
      scaling: { multiplier: 0.1, turns: 1 },
    },
    validTargets: ["enemy", "self", "ally"],
  },
};