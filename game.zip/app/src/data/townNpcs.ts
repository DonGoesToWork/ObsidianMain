import { GameData } from 'types';

export const TOWN_NPCS: GameData['TOWN_NPCS'] = {
  innkeeper: { name: 'Innkeeper', services: [{ type: 'modal', id: 'inn-modal' }] },
  clinic: { name: 'Clinic', services: [{ type: 'modal', id: 'clinic-modal' }] },
  shopkeeper: { name: 'General Store', services: [{ type: 'modal', id: 'shop-modal' }] },
  appraiser: { name: 'Appraiser', services: [{ type: 'modal', id: 'appraiser-modal' }] },
  banker: { name: 'Bank', services: [{ type: 'modal', id: 'bank-modal' }] },
  guildmaster: { name: 'Guild Hall', services: [{ type: 'modal', id: 'not-implemented', props: { title: 'Guild Hall' } }] },
  mercenary_guild: { name: 'Mercenary Guild', services: [{ type: 'modal', id: 'mercenary-guild-modal' }] },
  captain: { name: 'Guard Captain', services: [{ type: 'modal', id: 'quest-modal', quests: ['q001_main', 'q002_main', 'q003_main', 'q004_main', 'q_daily_haven_guard'] }] },
};
