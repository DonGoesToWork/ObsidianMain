import { GameItem, ItemId } from 'types';
import { CLOTHS } from './cloths';
import { HERBS } from './herbs';
import { INGOTS } from './ingots';
import { LEATHERS } from './leathers';
import { ORES } from './ores';
import { REAGENTS } from './reagents';
import { WOODS_AND_STONES } from './woodsAndStones';

export const MATERIALS: Record<ItemId, GameItem> = {
  ...ORES,
  ...INGOTS,
  ...WOODS_AND_STONES,
  ...LEATHERS,
  ...CLOTHS,
  ...HERBS,
  ...REAGENTS,
};
