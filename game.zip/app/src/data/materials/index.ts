import { GameItem, ItemId } from 'types';
import { ORES } from './ores';
import { INGOTS } from './ingots';
import { WOODS_AND_STONES } from './woodsAndStones';
import { LEATHERS } from './leathers';
import { CLOTHS } from './cloths';
import { HERBS } from './herbs';
import { REAGENTS } from './reagents';

export const MATERIALS: Record<ItemId, GameItem> = {
  ...ORES,
  ...INGOTS,
  ...WOODS_AND_STONES,
  ...LEATHERS,
  ...CLOTHS,
  ...HERBS,
  ...REAGENTS,
};
