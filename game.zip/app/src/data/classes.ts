import { GameData } from 'types';

export const CLASSES: GameData['CLASSES'] = {
  warrior: {
    name: 'Warrior',
    desc: 'A master of melee combat, focusing on strength and survivability.',
    baseStats: { strength: 3, constitution: 2, intelligence: 0, dexterity: 0 },
    startEquip: ['gen_smithing_mat_equip_wood_shortsword', 'gen_leatherworking_mat_leather_basic_leather-jerkin'],
    startSkills: ['s001', 's005'],
  },
  mage: {
    name: 'Mage',
    desc: 'A wielder of powerful arcane energies, using intelligence to fuel devastating spells.',
    baseStats: { strength: 0, constitution: 0, intelligence: 3, dexterity: 2 },
    startEquip: ['gen_smithing_mat_equip_wood_staff', 'gen_tailoring_mat_cloth_linen_cloth-robe'],
    startSkills: ['s002', 'sp_lightning_t1'],
  },
  rogue: {
    name: 'Rogue',
    desc: 'A swift and deadly fighter who uses dexterity to strike from the shadows and inflict ailments.',
    baseStats: { strength: 0, constitution: 0, intelligence: 2, dexterity: 3 },
    startEquip: ['gen_smithing_mat_equip_stone_dagger', 'gen_leatherworking_mat_leather_basic_leather-jerkin'],
    startSkills: ['s004'],
  },
  cleric: {
    name: 'Cleric',
    desc: 'A devout follower of the light, able to heal allies and smite foes with divine power.',
    baseStats: { strength: 1, constitution: 1, intelligence: 3, dexterity: 0 },
    startEquip: ['gen_smithing_mat_equip_wood_mace', 'gen_tailoring_mat_cloth_linen_cloth-robe'],
    startSkills: ['s007', 's008'],
  },
  ranger: {
    name: 'Ranger',
    desc: 'A master of the wilds, fighting with a bow and the aid of a loyal animal companion.',
    baseStats: { strength: 1, dexterity: 3, intelligence: 1, constitution: 0 },
    startEquip: ['gen_smithing_mat_equip_wood_hunting-bow', 'gen_leatherworking_mat_leather_basic_leather-jerkin'],
    startSkills: ['s_rng01', 's_rng02'],
  },
  none: { name: 'None', desc: 'No class', baseStats: { strength: 0, constitution: 0, intelligence: 0, dexterity: 0 }, startEquip: [], startSkills: [] },
};
