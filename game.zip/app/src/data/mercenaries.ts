import { GameData } from 'types';

export const MERCENARIES: GameData['MERCENARIES'] = {
  westhaven_warrior: {
    name: 'Westhaven Sellsword',
    class: 'warrior',
    race: 'human',
    baseCost: 100,
    baseDailyCost: 10,
    fleeThreshold: 0.2,
    statGrowth: { strength: 2, constitution: 1, intelligence: 0, dexterity: 1 },
    skillPool: ['s001', 's005'],
    equipmentPool: {
      weapon: ['gen_smithing_mat_ingot_iron_shortsword'],
      chest: ['gen_smithing_mat_ingot_iron_chainbody'],
      legs: ['gen_smithing_mat_ingot_iron_greaves'],
      head: ['gen_smithing_mat_ingot_iron_helmet'],
    },
  },
  westhaven_mage: {
    name: 'Westhaven Hedge-Mage',
    class: 'mage',
    race: 'elf',
    baseCost: 150,
    baseDailyCost: 15,
    fleeThreshold: 0.15,
    statGrowth: { strength: 0, constitution: 0, intelligence: 2, dexterity: 1 },
    skillPool: ['s002', 'sp_lightning_t1'],
    equipmentPool: { weapon: ['gen_smithing_mat_equip_yew_staff'], chest: ['gen_tailoring_mat_cloth_wool_cloth-robe'] },
  },
  westhaven_cleric: {
    name: 'Westhaven Acolyte',
    class: 'cleric',
    race: 'dwarf',
    baseCost: 125,
    baseDailyCost: 12,
    fleeThreshold: 0.25,
    statGrowth: { strength: 1, constitution: 1, intelligence: 2, dexterity: 0 },
    skillPool: ['s007', 's008'],
    equipmentPool: { weapon: ['gen_smithing_mat_ingot_bronze_mace'], shield: ['gen_smithing_mat_equip_wood_shield'], chest: ['gen_smithing_mat_ingot_bronze_chainbody'] },
  },
};
