import { GameData, ItemQuality, ProfessionId, Recipe, RecipeId, ItemId, AbilityId, Ability } from 'types';
import { CLASSES } from './classes';
import { RACES } from './races';
import { ITEMS as BASE_ITEMS } from './items';
import { MATERIALS } from './materials/index';
import { ITEM_SETS } from './itemSets';
import { SKILLS } from './skills/index';
import { STATUS_EFFECTS } from './statusEffects';
import { MONSTERS } from './monsters';
import { ZONES } from './zones';
import { TOWN_NPCS } from './townNpcs';
import { SHOP_INVENTORY } from './shopInventory';
import { RECIPES as BASE_RECIPES } from './recipes';
import { ENCHANTS } from './enchants';
import { QUESTS } from './quests';
import { FACTIONS } from './factions';
import { PETS } from './pets';
import { GUILD_DATA } from './guild';
import { BODY_PLANS } from './bodyPlans';
import { MERCENARIES } from './mercenaries';
import { generateAll, generateSkillBooks } from './itemGenerators';

export function initializeData(): GameData {
  const ITEM_QUALITIES: Record<ItemQuality, { color: string; multiplier: number }> = {
    Poor: { color: 'grey', multiplier: 0.9 },
    Average: { color: 'white', multiplier: 1.0 },
    Good: { color: 'lime', multiplier: 1.05 },
    Great: { color: '#0070dd', multiplier: 1.1 },
    Exceptional: { color: '#ff8000', multiplier: 1.15 },
    Masterwork: { color: '#a335ee', multiplier: 1.25 },
    'One-of-a-kind': { color: '#ff4500', multiplier: 1.4 },
  };

  const ITEMS = { ...BASE_ITEMS, ...MATERIALS };

  const RECIPES: Record<ProfessionId, Recipe[]> = { ...BASE_RECIPES };
  const ALL_RECIPES: Record<RecipeId, Recipe> = {};
  const finalShopInventory = [...SHOP_INVENTORY];

  const { generatedItems, generatedRecipes, generatedRecipeItems } = generateAll(MATERIALS);
  const { generatedItems: generatedSkillBookItems } = generateSkillBooks(SKILLS);

  Object.assign(ITEMS, generatedItems);
  finalShopInventory.push(...(Object.keys(generatedItems) as ItemId[]));

  Object.assign(ITEMS, generatedRecipeItems);
  finalShopInventory.push(...(Object.keys(generatedRecipeItems) as ItemId[]));

  Object.assign(ITEMS, generatedSkillBookItems);
  finalShopInventory.push(...(Object.keys(generatedSkillBookItems) as ItemId[]));

  for (const recipe of Object.values(generatedRecipes)) {
    if (!RECIPES[recipe.profession]) {
      RECIPES[recipe.profession] = [];
    }
    RECIPES[recipe.profession].push(recipe);
  }

  Object.values(RECIPES)
    .flat()
    .forEach((recipe) => {
      ALL_RECIPES[recipe.id] = recipe;
    });

  return {
    CLASSES,
    RACES,
    ITEMS,
    ITEM_SETS,
    SKILLS,
    STATUS_EFFECTS,
    MONSTERS,
    ZONES,
    TOWN_NPCS,
    SHOP_INVENTORY: finalShopInventory,
    RECIPES,
    ALL_RECIPES,
    ENCHANTS,
    QUESTS,
    FACTIONS,
    PETS,
    GUILD_DATA,
    ITEM_QUALITIES,
    BODY_PLANS,
    MERCENARIES,
  };
}
