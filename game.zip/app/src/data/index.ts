import { GameData, ItemId, ProfessionId, Recipe, RecipeId } from 'types';
import { generateAll, generateEnchantingOrbs, generateMemoryGlobes, generatePlusStones, generateSkillBooks } from './itemGenerators';

import { BODY_PLANS } from './bodyPlans';
import { ITEM_RARITY_TIERS } from 'utils/itemUtils';
import { CLASSES } from './classes';
import { ENCHANTS } from './enchants';
import { FACTIONS } from './factions';
import { GUILD_DATA } from './guild';
import { ITEMS as BASE_ITEMS } from './items';
import { ITEM_SETS } from './itemSets';
import { MATERIALS } from './materials/index';
import { MERCENARIES } from './mercenaries';
import { MONSTERS } from './monsters';
import { PETS } from './pets';
import { QUESTS } from './quests';
import { RACES } from './races';
import { RECIPES as BASE_RECIPES } from './recipes';
import { SHOP_INVENTORY as BASE_SHOP_INVENTORY } from './shopInventory';
import { SKILLS } from './skills/index';
import { STATUS_EFFECTS } from './statusEffects';
import { TOWN_NPCS } from './townNpcs';
import { ZONES } from './zones';

// --- Data Assembly
// 1. Generate dynamic data based on static sources
const { generatedItems, generatedRecipes, generatedRecipeItems } = generateAll(MATERIALS);
const { generatedItems: generatedSkillBookItems } = generateSkillBooks(SKILLS);
const { generatedItems: generatedMemoryGlobeItems } = generateMemoryGlobes(ENCHANTS);
const { generatedItems: plusStones } = generatePlusStones();
const { generatedItems: enchantingOrbs } = generateEnchantingOrbs(ENCHANTS);

// 2. Combine static and generated data into final collections
const ITEMS = {
  ...BASE_ITEMS,
  ...MATERIALS,
  ...generatedItems,
  ...generatedRecipeItems,
  ...generatedSkillBookItems,
  ...generatedMemoryGlobeItems,
  ...plusStones,
  ...enchantingOrbs,
};

const RECIPES: Record<ProfessionId, Recipe[]> = { ...BASE_RECIPES };
for (const recipe of Object.values(generatedRecipes)) {
  if (!RECIPES[recipe.profession]) {
    RECIPES[recipe.profession] = [];
  }
  RECIPES[recipe.profession].push(recipe);
}

const ALL_RECIPES: Record<RecipeId, Recipe> = {};
Object.values(RECIPES)
  .flat()
  .forEach((recipe) => {
    ALL_RECIPES[recipe.id] = recipe;
  });

const SHOP_INVENTORY = [
  ...BASE_SHOP_INVENTORY,
  ...(Object.keys(generatedItems) as ItemId[]),
  ...(Object.keys(generatedRecipeItems) as ItemId[]),
  ...(Object.keys(generatedSkillBookItems) as ItemId[]),
  ...(Object.keys(generatedMemoryGlobeItems) as ItemId[]),
  ...(Object.keys(plusStones) as ItemId[]),
  ...(Object.keys(enchantingOrbs) as ItemId[]),
];

// --- Final Export
// This constant is built once when the module is imported, serving as a singleton.
export const GAME_DATA: GameData = {
  CLASSES,
  RACES,
  ITEMS,
  ITEM_SETS,
  SKILLS,
  STATUS_EFFECTS,
  MONSTERS,
  ZONES,
  TOWN_NPCS,
  SHOP_INVENTORY,
  RECIPES,
  ALL_RECIPES,
  ENCHANTS,
  QUESTS,
  FACTIONS,
  PETS,
  GUILD_DATA,
  BODY_PLANS,
  MERCENARIES,
  ITEM_RARITY_TIERS,
};