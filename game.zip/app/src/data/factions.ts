import { GameData } from 'types';

export const FACTIONS: GameData['FACTIONS'] = {
  haven_guard: {
    name: 'Haven Guard',
    ranks: [
      { name: 'Neutral', points: 0 },
      { name: 'Friendly', points: 500 },
      { name: 'Honored', points: 1500 },
      { name: 'Revered', points: 3000 },
      { name: 'Exalted', points: 6000 },
    ],
    vendor: ['w_axe01'], // Items unlocked at certain ranks
  },
};
