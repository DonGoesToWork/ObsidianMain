import { GameData } from 'types';

export const ENCHANTS: GameData['ENCHANTS'] = {
  weapon: [
    {
      stat: 'strength',
      scaling: [1, 2, 4, 7, 11, 16],
      gold: [50, 200, 1000, 3000, 8000, 20000],
      cost: [{ mat_crystal_t1: 1 }, { mat_crystal_t1: 3 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 2 }, { mat_crystal_t4: 2 }, { mat_crystal_t5: 2 }],
    },
    {
      stat: 'intelligence',
      scaling: [1, 2, 4, 7, 11, 16],
      gold: [50, 200, 1000, 3000, 8000, 20000],
      cost: [{ mat_crystal_t1: 1 }, { mat_crystal_t1: 3 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 2 }, { mat_crystal_t4: 2 }, { mat_crystal_t5: 2 }],
    },
    {
      stat: 'dexterity',
      scaling: [1, 2, 4, 7, 11, 16],
      gold: [50, 200, 1000, 3000, 8000, 20000],
      cost: [{ mat_crystal_t1: 1 }, { mat_crystal_t1: 3 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 2 }, { mat_crystal_t4: 2 }, { mat_crystal_t5: 2 }],
    },
    {
      stat: 'attackPower',
      scaling: [3, 6, 12, 20, 30, 45],
      gold: [60, 250, 1100, 3300, 8800, 22000],
      cost: [{ mat_crystal_t1: 1 }, { mat_crystal_t1: 3 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 2 }, { mat_crystal_t4: 2 }, { mat_crystal_t5: 2 }],
    },
    {
      stat: 'spellPower',
      scaling: [3, 6, 12, 20, 30, 45],
      gold: [60, 250, 1100, 3300, 8800, 22000],
      cost: [{ mat_crystal_t1: 1 }, { mat_crystal_t1: 3 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 2 }, { mat_crystal_t4: 2 }, { mat_crystal_t5: 2 }],
    },
    {
      stat: 'critChance',
      scaling: [1, 2, 3, 4, 5, 6],
      gold: [100, 400, 1500, 4000, 10000, 25000],
      cost: [{ mat_crystal_t1: 2 }, { mat_crystal_t2: 1 }, { mat_crystal_t3: 1 }, { mat_crystal_t4: 1 }, { mat_crystal_t5: 1 }, { mat_crystal_t6: 1 }],
    },
  ],
  shield: [
    {
      stat: 'armor',
      scaling: [5, 10, 20, 35, 55, 80],
      gold: [75, 300, 1200, 3600, 9000, 24000],
      cost: [{ mat_crystal_t1: 2 }, { mat_crystal_t1: 5 }, { mat_crystal_t2: 3 }, { mat_crystal_t3: 3 }, { mat_crystal_t4: 3 }, { mat_crystal_t5: 3 }],
    },
    {
      stat: 'constitution',
      scaling: [1, 2, 4, 7, 11, 16],
      gold: [80, 350, 1400, 4200, 10000, 28000],
      cost: [{ mat_crystal_t1: 2 }, { mat_crystal_t2: 1 }, { mat_crystal_t3: 1 }, { mat_crystal_t4: 1 }, { mat_crystal_t5: 1 }, { mat_crystal_t6: 1 }],
    },
  ],
  head: [
    {
      stat: 'constitution',
      scaling: [1, 2, 3, 5, 8, 12],
      gold: [50, 200, 800, 2400, 6400, 16000],
      cost: [{ mat_crystal_t1: 1 }, { mat_crystal_t1: 3 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 2 }, { mat_crystal_t4: 2 }, { mat_crystal_t5: 2 }],
    },
    {
      stat: 'intelligence',
      scaling: [1, 2, 3, 5, 8, 12],
      gold: [50, 200, 800, 2400, 6400, 16000],
      cost: [{ mat_crystal_t1: 1 }, { mat_crystal_t1: 3 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 2 }, { mat_crystal_t4: 2 }, { mat_crystal_t5: 2 }],
    },
  ],
  chest: [
    {
      stat: 'constitution',
      scaling: [2, 4, 8, 13, 20, 30],
      gold: [100, 400, 1500, 4500, 12000, 30000],
      cost: [{ mat_crystal_t1: 1 }, { mat_crystal_t1: 3 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 2 }, { mat_crystal_t4: 2 }, { mat_crystal_t5: 2 }],
    },
    {
      stat: 'armor',
      scaling: [5, 10, 20, 35, 55, 80],
      gold: [75, 300, 1200, 3600, 9600, 24000],
      cost: [{ mat_crystal_t1: 2 }, { mat_crystal_t1: 5 }, { mat_crystal_t2: 3 }, { mat_crystal_t3: 3 }, { mat_crystal_t4: 3 }, { mat_crystal_t5: 3 }],
    },
    {
      stat: 'worldHpRegen',
      scaling: [0.1, 0.2, 0.4, 0.7, 1.1, 1.6],
      gold: [150, 500, 1800, 5400, 14000, 36000],
      cost: [{ mat_crystal_t1: 3 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 1 }, { mat_crystal_t4: 1 }, { mat_crystal_t5: 1 }, { mat_crystal_t6: 1 }],
    },
  ],
  legs: [
    {
      stat: 'armor',
      scaling: [3, 7, 15, 25, 40, 60],
      gold: [60, 250, 1000, 3000, 8000, 20000],
      cost: [{ mat_crystal_t1: 1 }, { mat_crystal_t1: 4 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 2 }, { mat_crystal_t4: 2 }, { mat_crystal_t5: 2 }],
    },
    {
      stat: 'strength',
      scaling: [1, 2, 3, 5, 8, 12],
      gold: [50, 200, 800, 2400, 6400, 16000],
      cost: [{ mat_crystal_t1: 1 }, { mat_crystal_t1: 3 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 2 }, { mat_crystal_t4: 2 }, { mat_crystal_t5: 2 }],
    },
    {
      stat: 'dexterity',
      scaling: [1, 2, 3, 5, 8, 12],
      gold: [50, 200, 800, 2400, 6400, 16000],
      cost: [{ mat_crystal_t1: 1 }, { mat_crystal_t1: 3 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 2 }, { mat_crystal_t4: 2 }, { mat_crystal_t5: 2 }],
    },
  ],
  amulet: [
    {
      stat: 'worldMpRegen',
      scaling: [0.1, 0.2, 0.4, 0.7, 1.1, 1.6],
      gold: [200, 600, 2000, 6000, 16000, 40000],
      cost: [{ mat_crystal_t1: 3 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 1 }, { mat_crystal_t4: 1 }, { mat_crystal_t5: 1 }, { mat_crystal_t6: 1 }],
    },
    {
      stat: 'luck',
      scaling: [1, 2, 4, 7, 11, 16],
      gold: [200, 600, 2000, 6000, 16000, 40000],
      cost: [{ mat_crystal_t1: 3 }, { mat_crystal_t2: 2 }, { mat_crystal_t3: 1 }, { mat_crystal_t4: 1 }, { mat_crystal_t5: 1 }, { mat_crystal_t6: 1 }],
    },
  ],
  ring: [
    {
      stat: 'goldFind',
      scaling: [1, 2, 3, 4, 5, 6],
      gold: [250, 700, 2200, 6600, 18000, 45000],
      cost: [{ mat_crystal_t2: 1 }, { mat_crystal_t2: 3 }, { mat_crystal_t3: 2 }, { mat_crystal_t4: 2 }, { mat_crystal_t5: 2 }, { mat_crystal_t6: 2 }],
    },
    {
      stat: 'xpGain',
      scaling: [1, 2, 3, 4, 5, 6],
      gold: [250, 700, 2200, 6600, 18000, 45000],
      cost: [{ mat_crystal_t2: 1 }, { mat_crystal_t2: 3 }, { mat_crystal_t3: 2 }, { mat_crystal_t4: 2 }, { mat_crystal_t5: 2 }, { mat_crystal_t6: 2 }],
    },
  ],
};
