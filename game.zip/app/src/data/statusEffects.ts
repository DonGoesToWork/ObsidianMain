import { GameData } from 'types';

export const STATUS_EFFECTS: GameData['STATUS_EFFECTS'] = {
  // New Bleed/Cut System
  cut: {
    name: 'Cut',
    desc: 'An open wound. May bleed or become infected.',
    icon: '🩹',
    isBeneficial: false,
    maxStages: 5,
    stages: [
      { name: 'Scratch', desc: 'A minor scratch. Barely an inconvenience.' },
      { name: 'Cut', desc: 'A noticeable cut that is bleeding slightly.' },
      { name: 'Slash', desc: 'A deep slash that is bleeding moderately.' },
      { name: 'Gash', desc: 'A gaping gash that is bleeding profusely.' },
      { name: 'Severed', desc: 'The limb has been severed and is bleeding catastrophically.' },
    ],
  },
  external_bleed: {
    name: 'External Bleed',
    desc: 'Losing health from an open wound.',
    icon: '🩸',
    isBeneficial: false,
    maxStages: 5,
    stages: [
      { name: 'Small Bleed', desc: 'Losing a small amount of health.', effects: { onTurn: { type: 'damage_percent_max_hp', percent: 0.1 / 6 } } },
      { name: 'Bleeding', desc: 'Losing a noticeable amount of health.', effects: { onTurn: { type: 'damage_percent_max_hp', percent: 2 / 6 } } },
      { name: 'Major Bleed', desc: 'Losing a large amount of health.', effects: { onTurn: { type: 'damage_percent_max_hp', percent: 5 / 6 } } },
      { name: 'Gushing Bleed', desc: 'Losing a dangerous amount of health.', effects: { onTurn: { type: 'damage_percent_max_hp', percent: 10 / 6 } } },
      { name: 'Draining Blood', desc: 'Losing a dangerous amount of health.', effects: { onTurn: { type: 'damage_percent_max_hp', percent: 25 / 6 } } },
    ],
  },
  infection: { name: 'Infection', desc: 'Feeling unwell, strength is reduced by 10%.', icon: '🤢', isBeneficial: false, effects: { statMods: { strength: 0.9 } } },

  // Standard Effects
  burning: {
    name: 'Burning',
    desc: 'Taking fire damage over time.',
    icon: '🔥',
    isBeneficial: false,
    effects: { onTurn: { type: 'damage', base: 5, scalesWith: 'spellPower', multiplier: 0.1 } },
  },
  poisoned: {
    name: 'Poisoned',
    desc: 'Taking poison damage over time.',
    icon: '☠️',
    isBeneficial: false,
    effects: { onTurn: { type: 'damage', base: 3, scalesWith: 'attackPower', multiplier: 0.1 } },
  },
  stunned: { name: 'Stunned', desc: 'Cannot act.', icon: '💫', isBeneficial: false, effects: { onApply: { type: 'skipTurn' } } },
  fortified: { name: 'Fortified', desc: 'Armor is increased by 50%.', icon: '🛡️', isBeneficial: true, effects: { statMods: { armor: 1.5 } } },
  guarding: {
    name: 'Guarding',
    desc: 'Damage taken is reduced by 50% and evasion rating is increased by 50%.',
    icon: '✋',
    isBeneficial: true,
    effects: { statMods: { evasion: 1.5 } },
  },
  frozen: { name: 'Frozen', desc: 'Cannot act.', icon: '❄️', isBeneficial: false, effects: { onApply: { type: 'skipTurn' } } },
  regeneration: {
    name: 'Regeneration',
    desc: 'Regenerating health over time.',
    icon: '✨',
    isBeneficial: true,
    effects: { onTurn: { type: 'heal', base: 5, scalesWith: 'spellPower', multiplier: 0.2 } },
  },
  sundered: { name: 'Sundered', desc: 'Armor is reduced by 25%.', icon: '💔', isBeneficial: false, effects: { statMods: { armor: 0.75 } } },
  pet_empower: {
    name: 'Empowered',
    desc: 'Next attack will be a critical strike.',
    icon: '🐾',
    isBeneficial: true,
    effects: {
      statMods: { critChance: 100 }, // This is a simplified way to represent it
    },
  },
  hasted: { name: 'Hasted', desc: 'Dexterity is increased by 25%.', icon: '💨', isBeneficial: true, effects: { statMods: { dexterity: 1.25 } } },
  enraged: {
    name: 'Enraged',
    desc: 'Strength is increased by 30%, but armor is reduced by 50%.',
    icon: '😡',
    isBeneficial: false, // Mixed, but overall detrimental for most
    effects: { statMods: { strength: 1.3, armor: 0.5 } },
  },
  chilled: { name: 'Chilled', desc: 'Dexterity is reduced by 25%.', icon: '🥶', isBeneficial: false, effects: { statMods: { dexterity: 0.75 } } },
  weakened: { name: 'Weakened', desc: 'All damage dealt is reduced by 25%.', icon: '😩', isBeneficial: false, effects: { statMods: { attackPower: 0.75, spellPower: 0.75 } } },
  arcane_brilliance: { name: 'Arcane Brilliance', desc: 'Intelligence is increased by 15%.', icon: '🧠', isBeneficial: true, effects: { statMods: { intelligence: 1.15 } } },
  earthen_ward: { name: 'Earthen Ward', desc: 'Constitution is increased by 15%.', icon: '🪨', isBeneficial: true, effects: { statMods: { constitution: 1.15 } } },
  shadow_veil: { name: 'Shadow Veil', desc: 'Critical Strike chance is increased by 10%.', icon: '👻', isBeneficial: true, effects: { stats: { critChance: 10 } } },
  cursed: {
    name: 'Cursed',
    desc: 'All primary stats are reduced by 10%.',
    icon: '⛓️',
    isBeneficial: false,
    effects: { statMods: { strength: 0.9, dexterity: 0.9, intelligence: 0.9, constitution: 0.9 } },
  },
  blessed: {
    name: 'Blessed',
    desc: 'All primary stats are increased by 10%.',
    icon: '😇',
    isBeneficial: true,
    effects: { statMods: { strength: 1.1, dexterity: 1.1, intelligence: 1.1, constitution: 1.1 } },
  },
  focused: {
    name: 'Focused',
    desc: 'Critical Strike chance is increased by 20%, but armor is reduced by 10%.',
    icon: '🎯',
    isBeneficial: true,
    effects: { stats: { critChance: 20 }, statMods: { armor: 0.9 } },
  },
  // Head Crippled Effects
  blinded: { name: 'Blinded', desc: 'Accuracy is severely reduced by 90%.', icon: '😵', isBeneficial: false, effects: { statMods: { accuracy: 0.1 } } },
  silenced: { name: 'Silenced', desc: 'Cannot use abilities that cost Mana.', icon: '🤫', isBeneficial: false, effects: {} },
  confused: { name: 'Confused', desc: '50% chance to act randomly each turn.', icon: '❓', isBeneficial: false, effects: {} },
  immobilized: { name: 'Immobilized', desc: 'Cannot evade attacks.', icon: '🕸️', isBeneficial: false, effects: { statMods: { evasion: 0 } } },
  lightning_dot: {
    name: 'Electric Current',
    desc: 'Taking lightning damage over time.',
    icon: '⚡',
    isBeneficial: false,
    effects: { onTurn: { type: 'damage', base: 10, scalesWith: 'spellPower', multiplier: 0.2 } },
  },
  // Potion Effects
  hp_regen_potion_minor: { name: 'Minor Regeneration', desc: 'Regenerates 2 HP per hour.', icon: '❤️‍🩹', isBeneficial: true, effects: { stats: { worldHpRegen: 2 / 60 } } },
  mp_regen_potion_minor: { name: 'Minor Mana Recovery', desc: 'Regenerates 2 MP per hour.', icon: '💧', isBeneficial: true, effects: { stats: { worldMpRegen: 2 / 60 } } },
  sp_regen_potion_minor: { name: 'Minor Vigor', desc: 'Regenerates 2 SP per hour.', icon: '💪', isBeneficial: true, effects: { stats: { worldSpRegen: 2 / 60 } } },
  hp_regen_potion: { name: 'Regeneration', desc: 'Regenerates 5 HP per hour.', icon: '❤️‍🩹', isBeneficial: true, effects: { stats: { worldHpRegen: 5 / 60 } } },
  mp_regen_potion: { name: 'Mana Recovery', desc: 'Regenerates 5 MP per hour.', icon: '💧', isBeneficial: true, effects: { stats: { worldMpRegen: 5 / 60 } } },
  // System Effects
  encumbered: {
    name: 'Encumbered',
    desc: 'Carrying too much weight. Greatly reduces evasion. Unable to travel between zones.',
    icon: '⚖️',
    isBeneficial: false,
    effects: { statMods: { evasion: 0.5 } },
  },
};
