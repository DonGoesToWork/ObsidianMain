import { BodyPlan, Limb, MonsterData, StatusEffectInstance } from 'types';

const PLAYER_BODY_PLAN_TEMPLATE: BodyPlan<Limb> = {
  head: { id: 'head', displayName: 'Head', accuracyModifier: 0.25, maxHp: 0, currentHp: 0, armorValue: 0, equipmentSlots: ['head'], state: 'Healthy', statusEffects: [] },
  torso: {
    id: 'torso',
    displayName: 'Torso',
    accuracyModifier: 1.0,
    maxHp: 0,
    currentHp: 0,
    armorValue: 0,
    equipmentSlots: ['chest', 'amulet'],
    state: 'Healthy',
    statusEffects: [],
  },
  left_arm: {
    id: 'left_arm',
    displayName: 'Left Arm',
    accuracyModifier: 0.5,
    maxHp: 0,
    currentHp: 0,
    armorValue: 0,
    equipmentSlots: ['weapon', 'ring1'],
    state: 'Healthy',
    statusEffects: [],
  },
  right_arm: {
    id: 'right_arm',
    displayName: 'Right Arm',
    accuracyModifier: 0.5,
    maxHp: 0,
    currentHp: 0,
    armorValue: 0,
    equipmentSlots: ['shield', 'ring2'],
    state: 'Healthy',
    statusEffects: [],
  },
  left_leg: {
    id: 'left_leg',
    displayName: 'Left Leg',
    accuracyModifier: 0.75,
    maxHp: 0,
    currentHp: 0,
    armorValue: 0,
    equipmentSlots: ['legs'],
    state: 'Healthy',
    statusEffects: [],
  },
  right_leg: {
    id: 'right_leg',
    displayName: 'Right Leg',
    accuracyModifier: 0.75,
    maxHp: 0,
    currentHp: 0,
    armorValue: 0,
    equipmentSlots: ['legs'],
    state: 'Healthy',
    statusEffects: [],
  },
};

const WOLF_BODY_PLAN_TEMPLATE: BodyPlan<Limb> = {
  head: { id: 'head', displayName: 'Head', accuracyModifier: 0.25, maxHp: 0, currentHp: 0, armorValue: 0, equipmentSlots: ['head'], state: 'Healthy', statusEffects: [] },
  body: { id: 'body', displayName: 'Body', accuracyModifier: 1.0, maxHp: 0, currentHp: 0, armorValue: 0, equipmentSlots: [], state: 'Healthy', statusEffects: [] },
  front_left_leg: {
    id: 'front_left_leg',
    displayName: 'Front-Left Leg',
    accuracyModifier: 0.75,
    maxHp: 0,
    currentHp: 0,
    armorValue: 0,
    equipmentSlots: [],
    state: 'Healthy',
    statusEffects: [],
  },
  front_right_leg: {
    id: 'front_right_leg',
    displayName: 'Front-Right Leg',
    accuracyModifier: 0.75,
    maxHp: 0,
    currentHp: 0,
    armorValue: 0,
    equipmentSlots: [],
    state: 'Healthy',
    statusEffects: [],
  },
  rear_left_leg: {
    id: 'rear_left_leg',
    displayName: 'Rear-Left Leg',
    accuracyModifier: 0.75,
    maxHp: 0,
    currentHp: 0,
    armorValue: 0,
    equipmentSlots: [],
    state: 'Healthy',
    statusEffects: [],
  },
  rear_right_leg: {
    id: 'rear_right_leg',
    displayName: 'Rear-Right Leg',
    accuracyModifier: 0.75,
    maxHp: 0,
    currentHp: 0,
    armorValue: 0,
    equipmentSlots: [],
    state: 'Healthy',
    statusEffects: [],
  },
};

const MONSTER_TEMPLATES: Record<string, BodyPlan<Limb>> = {
  default: PLAYER_BODY_PLAN_TEMPLATE, // For humanoid monsters
  wolf: WOLF_BODY_PLAN_TEMPLATE,
};

export const BODY_PLANS = {
  TEMPLATES: MONSTER_TEMPLATES,
  getPlayerTemplate: (): BodyPlan<Limb> => JSON.parse(JSON.stringify(PLAYER_BODY_PLAN_TEMPLATE)),
  getMonsterTemplate: (monster: MonsterData): BodyPlan<Limb> => {
    const template = MONSTER_TEMPLATES[monster.bodyPlan || 'default'] || MONSTER_TEMPLATES.default;
    return JSON.parse(JSON.stringify(template));
  },
};
