import { useContext } from 'react';
import CharacterCreation from './components/CharacterCreation';
import GameUI from './GameUI';
import { GameProvider } from './context/GameProvider';
import { ContextMenuProvider } from './context/ContextMenuContext';
import { HotkeyProvider } from './context/HotkeyContext';
import './index.css';
import { usePlayer } from 'hooks/usePlayer';
import { UIContext } from './context/UIContext';
import { WorldContext } from './context/WorldContext';
import { GameDataProvider } from 'context/GameDataContext';

function Game() {
  const player = usePlayer();
  const worldContext = useContext(WorldContext);

  if (!worldContext) return null; // Provider not ready

  const { createPlayer } = worldContext;

  if (!player) {
    return <CharacterCreation onFinalize={createPlayer} />;
  }

  return <GameUI />;
}

const AppContent: React.FC = () => {
  const uiContext = useContext(UIContext);
  if (!uiContext) return null; // Provider not ready

  return (
    <div id="app-wrapper">
      <Game />
    </div>
  );
};

function App() {
  return (
    <GameDataProvider>
      <HotkeyProvider>
        <ContextMenuProvider>
          <GameProvider>
            <AppContent />
          </GameProvider>
        </ContextMenuProvider>
      </HotkeyProvider>
    </GameDataProvider>
  );
}

export default App;
