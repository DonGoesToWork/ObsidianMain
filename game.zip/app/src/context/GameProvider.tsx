import { CombatState, DungeonState, GameLocation, GameState, ItemInstance, LogEntry, ModalState, ModalUiSettings, Player, Zone } from "../types";
import React, { ReactNode, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";

import { CharacterContext } from "./CharacterContext";
import { CombatContext } from "./CombatContext";
import { GameDataContext } from "./GameDataContext";
import { InventoryContext } from "./InventoryContext";
import { LogContext } from "./LogContext";
import { PartyContext } from "./PartyContext";
import { PlayerContext } from "./PlayerContext";
import { ProfessionsContext } from "./ProfessionsContext";
import { UIContext } from "./UIContext";
import { WorldContext } from "./WorldContext";
import { createLocationFromZone } from "utils/locationUtils";
import { isCombatantDefeated } from "utils/combatUtils";
import { useCharacterProviderLogic } from "./hooks/useCharacterProviderLogic";
import { useCombatProviderLogic } from "./hooks/useCombatProviderLogic";
import { useContextMenu } from "./ContextMenuContext";
import { useDebugProviderLogic } from "./hooks/useDebugProviderLogic";
import { useInventoryProviderLogic } from "./hooks/useInventoryProviderLogic";
import { useLogProviderLogic } from "./hooks/useLogProviderLogic";
import { usePartyProviderLogic } from "./hooks/usePartyProviderLogic";
import { useProfessionsProviderLogic } from "./hooks/useProfessionsProviderLogic";
import { useUIProviderLogic } from "./hooks/useUIProviderLogic";
import { useWorldProviderLogic } from "./hooks/useWorldProviderLogic";
import { DebugContext } from "./DebugContext";
import { ShopContext } from "./ShopContext";
import { useShopProviderLogic } from "./hooks/useShopProviderLogic";
import { calculateCharacterStats } from "services/statService";

const SAVE_KEY = "aura_rpg_save_v19";
const ZOOM_KEY = "aura_rpg_zoom_v1";

export const GameProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // State Declarations
  const GAME_DATA = useContext(GameDataContext)!;
  const [player, setPlayerState] = useState<Player | null>(null);
  const [gameState, setGameState] = useState<GameState>("character-creation");
  const [currentCombat, setCurrentCombat] = useState<CombatState | null>(null);
  const [currentDungeon, setCurrentDungeon] = useState<DungeonState | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [modalStack, setModalStack] = useState<ModalState[]>([]);
  const [gameTime, setGameTime] = useState(() => new Date());
  const [currentLocation, setCurrentLocation] = useState<GameLocation | null>(null);
  const [generatedZones, setGeneratedZones] = useState<Record<string, Zone>>({});
  const [floatingTexts, setFloatingTexts] = useState<{ id: number; text: string }[]>([]);
  const [zoomLevel, setZoomLevel] = useState<number>(() => {
    try {
      const savedZoom = localStorage.getItem(ZOOM_KEY);
      return savedZoom ? Number(savedZoom) : 100;
    } catch {
      return 100;
    }
  });
  const [modalUiSettings, setModalUiSettings] = useState<Record<string, ModalUiSettings>>({});
  const { showContextMenu } = useContextMenu();
  const endTurnCallbackRef = useRef<(() => void) | null>(null);

  // Raw player state updater that also recalculates stats
  const setPlayer = useCallback(
    (newPlayerData: React.SetStateAction<Player | null>) => {
      setPlayerState((prev) => {
        const p = typeof newPlayerData === "function" ? (prev ? newPlayerData(prev) : null) : newPlayerData;
        if (!p) return null;
        if (!p.party) p.party = [];
        if (!p.shopInventories) p.shopInventories = {};
        const updatedParty = p.party.map((merc) => calculateCharacterStats(merc, GAME_DATA) || merc);
        return calculateCharacterStats({ ...p, party: updatedParty }, GAME_DATA);
      });
    },
    [setPlayerState, GAME_DATA],
  );

  const playerActionTaken = useCallback(() => {
    if (currentCombat?.isPlayerTurn) {
      endTurnCallbackRef.current?.();
    }
  }, [currentCombat]);

  // Logic Hooks
  const logContextValue = useLogProviderLogic({ logs, setLogs, setFloatingTexts });
  const uiContextValue = useUIProviderLogic({ modalStack, setModalStack, zoomLevel, setZoomLevel, modalUiSettings, setModalUiSettings, floatingTexts, setFloatingTexts });

  const characterContextValue = useCharacterProviderLogic({ setPlayer, logMessage: logContextValue.logMessage });
  const partyContextValue = usePartyProviderLogic({ setPlayer, logMessage: logContextValue.logMessage, gameTime });
  const shopContextValue = useShopProviderLogic({ player, setPlayer, logMessage: logContextValue.logMessage, gameTime });
  const professionsContextValue = useProfessionsProviderLogic({ setPlayer: setPlayer, logMessage: logContextValue.logMessage });

  const inventoryContextValue = useInventoryProviderLogic({
    setPlayer: setPlayer,
    logMessage: logContextValue.logMessage,
    setCurrentLocation,
    gameTime,
    playerActionTaken,
    gainProfessionXp: professionsContextValue.gainProfessionXp,
    updateQuestProgress: characterContextValue.updateQuestProgress,
    learnRecipe: professionsContextValue.learnRecipe,
    learnAbility: characterContextValue.learnAbility,
    applyStatusEffect: characterContextValue.applyStatusEffect,
  });

  const debugContextValue = useDebugProviderLogic({
    addGold: characterContextValue.addGold,
    setPlayer,
    logMessage: logContextValue.logMessage,
    gainXp: characterContextValue.gainXp,
    travelTo: (locationId: string) => worldContextValue.travelTo(locationId), // Filled in below
    addItem: inventoryContextValue.addItem,
  });

  const combatLogic = useCombatProviderLogic({
    player: player,
    setPlayer: setPlayer,
    currentCombat,
    setCurrentCombat,
    logMessage: logContextValue.logMessage,
    setActiveModal: uiContextValue.setActiveModal,
    addItemsToGround: (items: ItemInstance[]) => {
      if (items.length === 0) return;
      setCurrentLocation((l) => {
        if (!l) return l;
        const newLoot = [...(l.groundLoot || []), ...items];
        return { ...l, groundLoot: newLoot, groundLootTimestamp: gameTime.getTime() };
      });
      const firstItemName = GAME_DATA.ITEMS[items[0].id]?.name || "Item";
      if (items.length > 1) {
        logContextValue.logMessage(`${firstItemName} and other items fall to the ground.`, "loot");
      } else {
        logContextValue.logMessage(`${firstItemName} falls to the ground.`, "loot");
      }
    },
    gainXp: characterContextValue.gainXp,
    gainMercenaryXp: partyContextValue.gainMercenaryXp,
    addGold: characterContextValue.addGold,
    updateQuestProgress: characterContextValue.updateQuestProgress,
    removeItem: inventoryContextValue.removeItem,
    passTime: (minutes, options) => worldContextValue.passTime(minutes, options), // Filled in below
    damageItemDurability: inventoryContextValue.damageItemDurability,
    applyStatusEffect: characterContextValue.applyStatusEffect,
    endTurnCallbackRef,
  });

  const worldContextValue = useWorldProviderLogic({
    player,
    setPlayer: setPlayer,
    gameState,
    setGameState,
    gameTime,
    setGameTime,
    currentLocation,
    setCurrentLocation,
    generatedZones,
    setGeneratedZones,
    currentDungeon,
    setCurrentDungeon,
    logMessage: logContextValue.logMessage,
    setActiveModal: uiContextValue.setActiveModal,
    startCombat: combatLogic.startCombat,
    addItemsToGround: (items: ItemInstance[]) => {
      if (items.length === 0) return;
      setCurrentLocation((l) => {
        if (!l) return l;
        const newLoot = [...(l.groundLoot || []), ...items];
        return { ...l, groundLoot: newLoot, groundLootTimestamp: gameTime.getTime() };
      });
      const firstItemName = GAME_DATA.ITEMS[items[0].id]?.name || "Item";
      if (items.length > 1) {
        logContextValue.logMessage(`${firstItemName} and other items fall to the ground.`, "loot");
      } else {
        logContextValue.logMessage(`${firstItemName} falls to the ground.`, "loot");
      }
    },
    setLogs,
    gainProfessionXp: professionsContextValue.gainProfessionXp,
    showContextMenu: showContextMenu,
    applyStatusEffect: characterContextValue.applyStatusEffect,
  });

  // Load game on initial mount
  useEffect(() => {
    const savedData = localStorage.getItem(SAVE_KEY);
    if (savedData) {
      try {
        const loaded = JSON.parse(savedData);
        if (loaded.player) setPlayer(loaded.player);
        if (loaded.gameTime) setGameTime(new Date(loaded.gameTime));
        if (loaded.currentLocation) setCurrentLocation(loaded.currentLocation);
        if (loaded.currentDungeon) setCurrentDungeon(loaded.currentDungeon);
        if (loaded.generatedZones) setGeneratedZones(loaded.generatedZones);
        if (loaded.logs) setLogs(loaded.logs);
        if (loaded.modalUiSettings) setModalUiSettings(loaded.modalUiSettings);
        setGameState(loaded.gameState && !loaded.gameState.startsWith("combat") ? loaded.gameState : "town");
        if (loaded.gameState?.startsWith("combat")) {
          const westhavenData = GAME_DATA.ZONES["zone0"];
          setCurrentLocation(createLocationFromZone("zone0", westhavenData));
        }
        logContextValue.logMessage("Game Loaded! Welcome back.", "info");
      } catch (error) {
        console.error("Failed to load or parse saved game:", error);
        localStorage.removeItem(SAVE_KEY);
        setGameState("character-creation");
      }
    } else {
      setGameState("character-creation");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [GAME_DATA]); // Add GAME_DATA to dep array

  // Auto-save game
  const saveGame = useCallback(() => {
    if (player && !currentCombat) {
      try {
        const gameStateToSave = {
          player,
          currentDungeon,
          gameTime: gameTime.toISOString(),
          currentLocation,
          gameState,
          generatedZones,
          logs,
          modalUiSettings,
        };
        localStorage.setItem(SAVE_KEY, JSON.stringify(gameStateToSave));
        console.debug("Game saved automatically.");
      } catch (e) {
        console.error("Failed to save game:", e);
        logContextValue.logMessage("Failed to save game. Storage might be full.", "error");
      }
    }
  }, [player, currentDungeon, gameTime, currentLocation, gameState, currentCombat, logContextValue, generatedZones, logs, modalUiSettings]);

  useEffect(() => {
    const interval = setInterval(saveGame, 30000);
    return () => clearInterval(interval);
  }, [saveGame]);

  // Handle post-combat state transitions
  const prevCombatActive = useRef(currentCombat?.isActive);
  useEffect(() => {
    if (prevCombatActive.current && !currentCombat?.isActive) {
      worldContextValue.changeGameState(
        currentLocation?.type === "dungeon" ? "dungeon" : currentLocation?.type === "town" ? "town" : "wilds",
      );
    }
    prevCombatActive.current = currentCombat?.isActive;
  }, [currentCombat, worldContextValue, currentLocation]);

  // Handle player death modal
  useEffect(() => {
    if (player && !currentCombat && isCombatantDefeated(player) && modalStack.length === 0) {
      uiContextValue.setActiveModal("death-modal");
    }
  }, [player, currentCombat, modalStack, uiContextValue]);

  // Update zoom level in local storage
  useEffect(() => {
    try {
      localStorage.setItem(ZOOM_KEY, String(zoomLevel));
    } catch (e) {
      console.error("Failed to save zoom level", e);
    }
  }, [zoomLevel]);

  const playerContextValue = useMemo(() => ({ player, setPlayer }), [player, setPlayer]);

  return (
    <LogContext.Provider value={logContextValue}>
      <UIContext.Provider value={uiContextValue}>
        <PlayerContext.Provider value={playerContextValue}>
          <DebugContext.Provider value={debugContextValue}>
            <WorldContext.Provider value={worldContextValue}>
              <CharacterContext.Provider value={characterContextValue}>
                <InventoryContext.Provider value={inventoryContextValue}>
                  <PartyContext.Provider value={partyContextValue}>
                    <ShopContext.Provider value={shopContextValue}>
                      <ProfessionsContext.Provider value={{ ...professionsContextValue, player }}>
                        <CombatContext.Provider value={combatLogic.combatContextValue}>
                          {children}
                        </CombatContext.Provider>
                      </ProfessionsContext.Provider>
                    </ShopContext.Provider>
                  </PartyContext.Provider>
                </InventoryContext.Provider>
              </CharacterContext.Provider>
            </WorldContext.Provider>
          </DebugContext.Provider>
        </PlayerContext.Provider>
      </UIContext.Provider>
    </LogContext.Provider>
  );
};