import {
  CombatState,
  DungeonState,
  GameLocation,
  GameSideEffect,
  GameState,
  ItemInstance,
  LogEntry,
  ModalState,
  ModalUiSettings,
  Player,
  WorldContextType,
  Zone,
} from '../types';
import React, { ReactNode, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';

import { CharacterContext } from './CharacterContext';
import { CombatContext } from './CombatContext';
import { DebugContext } from './DebugContext';
import { GameDataContext } from './GameDataContext';
import { InventoryContext } from './InventoryContext';
import { LogContext } from './LogContext';
import { PartyContext } from './PartyContext';
import { PlayerContext } from './PlayerContext';
import { ProfessionsContext } from './ProfessionsContext';
import { ShopContext } from './ShopContext';
import { UIContext } from './UIContext';
import { WorldContext } from './WorldContext';
import { calculateCharacterStats } from '../services/statService';
import { createLocationFromZone } from '../utils/locationUtils';
import { isCombatantDefeated } from '../utils/combatUtils';
import { processGameRules } from 'services/gameRuleService';
import { useCharacterProviderLogic } from './hooks/useCharacterProviderLogic';
import { useCombatProviderLogic } from './hooks/useCombatProviderLogic';
import { useContextMenu } from './ContextMenuContext';
import { useDebugProviderLogic } from './hooks/useDebugProviderLogic';
import { useInventoryProviderLogic } from './hooks/useInventoryProviderLogic';
import { useLogProviderLogic } from './hooks/useLogProviderLogic';
import { usePartyProviderLogic } from './hooks/usePartyProviderLogic';
import { useProfessionsProviderLogic } from './hooks/useProfessionsProviderLogic';
import { useShopContextLogic } from './hooks/useShopProviderLogic';
import { useUIProviderLogic } from './hooks/useUIProviderLogic';
import { useWorldProviderLogic } from './hooks/useWorldProviderLogic';

const SAVE_KEY = 'aura_rpg_save_v19';
const ZOOM_KEY = 'aura_rpg_zoom_v1';

const jsonReplacer = (key: string, value: any) => (value === Infinity ? 'Infinity' : value);
const jsonReviver = (key: string, value: any) => (value === 'Infinity' ? Infinity : value);

export const GameProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // State Declarations
  const GAME_DATA = useContext(GameDataContext)!;
  const [player, setPlayerState] = useState<Player | null>(null);
  const [gameState, setGameState] = useState<GameState>('character-creation');
  const [currentCombat, setCurrentCombat] = useState<CombatState | null>(null);
  const [currentDungeon, setCurrentDungeon] = useState<DungeonState | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [modalStack, setModalStack] = useState<ModalState[]>([]);
  const [gameTime, setGameTime] = useState(() => new Date());
  const [currentLocation, setCurrentLocation] = useState<GameLocation | null>(null);
  const [generatedZones, setGeneratedZones] = useState<Record<string, Zone>>({});
  const [floatingTexts, setFloatingTexts] = useState<{ id: number; text: string }[]>([]);
  const [modalUiSettings, setModalUiSettings] = useState<Record<string, ModalUiSettings>>({});
  const [debugTargets, setDebugTargets] = useState<string[]>([]);
  const [sideEffectQueue, setSideEffectQueue] = useState<GameSideEffect[]>([]);
  const { showContextMenu } = useContextMenu();
  const endTurnCallbackRef = useRef<(() => void) | null>(null);

  const queueSideEffects = useCallback((effects: GameSideEffect[]) => {
    setSideEffectQueue((q) => [...q, ...effects]);
  }, []);

  // Raw player state updater that also recalculates stats
  const setPlayer = useCallback(
    (newPlayerData: React.SetStateAction<Player | null>) => {
      setPlayerState((prev) => {
        const p = typeof newPlayerData === 'function' ? (prev ? newPlayerData(prev) : null) : newPlayerData;
        if (!p) return null;
        if (!p.party) p.party = [];
        if (!p.shopInventories) p.shopInventories = {};
        const updatedParty = p.party.map((merc) => calculateCharacterStats(merc, GAME_DATA) || merc);
        return calculateCharacterStats({ ...p, party: updatedParty }, GAME_DATA);
      });
    },
    [setPlayerState, GAME_DATA]
  );

  const playerActionTaken = useCallback(() => {
    if (currentCombat?.isPlayerTurn) {
      endTurnCallbackRef.current?.();
    }
  }, [currentCombat]);

  // Logic Hooks
  const logContextValue = useLogProviderLogic({ logs, setLogs, setFloatingTexts });
  const uiContextValue = useUIProviderLogic({ modalStack, setModalStack, modalUiSettings, setModalUiSettings, floatingTexts, setFloatingTexts });
  const characterContextValue = useCharacterProviderLogic({ setPlayer, queueSideEffects });
  const partyContextValue = usePartyProviderLogic({ setPlayer, logMessage: logContextValue.logMessage, gameTime });
  const shopContextValue = useShopContextLogic({ player, setPlayer, logMessage: logContextValue.logMessage, gameTime });
  const professionsContextValue = useProfessionsProviderLogic({ player, setPlayer: setPlayer, currentLocation, queueSideEffects });
  let worldContextValue: WorldContextType = null!;

  const inventoryContextValue = useInventoryProviderLogic({
    player,
    setPlayer: setPlayer,
    setCurrentLocation,
    gameTime,
    playerActionTaken,
    queueSideEffects,
  });

  const combatLogic = useCombatProviderLogic({
    player: player,
    setPlayer: setPlayer,
    currentCombat,
    setCurrentCombat,
    logMessage: logContextValue.logMessage,
    setActiveModal: uiContextValue.setActiveModal,
    addItemsToGround: (items: ItemInstance[]) => {
      if (items.length === 0) return;
      setCurrentLocation((l) => {
        if (!l) return l;
        const newLoot = [...(l.groundLoot || []), ...items];
        return { ...l, groundLoot: newLoot, groundLootTimestamp: gameTime.getTime() };
      });
      const firstItemName = GAME_DATA.ITEMS[items[0].id]?.name || 'Item';
      if (items.length > 1) {
        logContextValue.logMessage(`${firstItemName} and other items fall to the ground.`, 'loot');
      } else {
        logContextValue.logMessage(`${firstItemName} falls to the ground.`, 'loot');
      }
    },
    gainXp: characterContextValue.gainXp,
    gainMercenaryXp: partyContextValue.gainMercenaryXp,
    addGold: characterContextValue.addGold,
    updateQuestProgress: characterContextValue.updateQuestProgress,
    removeItem: inventoryContextValue.removeItem,
    passTime: (minutes, options) => worldContextValue.passTime(minutes, options),
    damageItemDurability: inventoryContextValue.damageItemDurability,
    applyStatusEffect: characterContextValue.applyStatusEffect,
    endTurnCallbackRef,
    changeGameState: (gameState, options) => worldContextValue.changeGameState(gameState, options),
    currentLocation: currentLocation,
  });

  worldContextValue = useWorldProviderLogic({
    player,
    setPlayer: setPlayer,
    gameState,
    setGameState,
    gameTime,
    setGameTime,
    currentLocation,
    setCurrentLocation,
    generatedZones,
    setGeneratedZones,
    currentDungeon,
    setCurrentDungeon,
    logMessage: logContextValue.logMessage,
    setActiveModal: uiContextValue.setActiveModal,
    startCombat: combatLogic.startCombat,
    addItemsToGround: (items: ItemInstance[]) => {
      if (items.length === 0) return;
      setCurrentLocation((l) => {
        if (!l) return l;
        const newLoot = [...(l.groundLoot || []), ...items];
        return { ...l, groundLoot: newLoot, groundLootTimestamp: gameTime.getTime() };
      });
      const firstItemName = GAME_DATA.ITEMS[items[0].id]?.name || 'Item';
      if (items.length > 1) {
        logContextValue.logMessage(`${firstItemName} and other items fall to the ground.`, 'loot');
      } else {
        logContextValue.logMessage(`${firstItemName} falls to the ground.`, 'loot');
      }
    },
    setLogs,
    gainProfessionXp: professionsContextValue.gainProfessionXp,
    showContextMenu: showContextMenu,
    applyStatusEffect: characterContextValue.applyStatusEffect,
    updateQuestProgress: characterContextValue.updateQuestProgress,
    currentCombat,
    logs,
    modalUiSettings,
    queueSideEffects,
  });

  const debugContextValue = useDebugProviderLogic({
    addGold: (amount) => characterContextValue.addGold(amount),
    setPlayer,
    logMessage: logContextValue.logMessage,
    gainXp: characterContextValue.gainXp,
    travelTo: (locationId: string) => worldContextValue.travelTo(locationId),
    addItem: inventoryContextValue.addItem,
    debugTargets,
    setDebugTargets,
    currentCombat,
    setCurrentCombat,
    setGameTime,
  });

  // Central Side Effect Observer
  useEffect(() => {
    if (sideEffectQueue.length === 0) return;

    const effectsToProcess = [...sideEffectQueue];
    setSideEffectQueue([]);

    effectsToProcess.forEach((effect) => {
      switch (effect.type) {
        case 'LOG':
          logContextValue.logMessage(effect.message, effect.logType);
          break;
        case 'GENERATE_ZONE':
          worldContextValue.generateNewZone(effect.level);
          break;
        case 'PASS_TIME':
          worldContextValue.passTime(effect.minutes, effect.options);
          break;
        case 'GAIN_PROFESSION_XP':
          professionsContextValue.gainProfessionXp(effect.professionId, effect.amount);
          break;
        case 'UPDATE_QUEST_PROGRESS':
          characterContextValue.updateQuestProgress(effect.questType, effect.target, effect.count);
          break;
        case 'LEARN_RECIPE':
          professionsContextValue.learnRecipe(effect.recipeId);
          break;
        case 'LEARN_ABILITY':
          characterContextValue.learnAbility(effect.abilityId);
          break;
        case 'APPLY_STATUS_EFFECT':
          characterContextValue.applyStatusEffect('player', effect.effectId, effect.options);
          break;
      }
    });
    // It's critical to NOT include context values in the dependency array to avoid re-triggering.
    // The functions within them are memoized and don't change, so this is safe.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sideEffectQueue]);

  // This effect hook acts as the central observer for all critical state changes.
  useEffect(() => {
    if (!player) return;

    const { newPlayer, corpsesToDrop, deadMercs, starvation, thirst } = processGameRules(player, GAME_DATA);

    if (starvation.length > 0) {
      starvation.forEach((name) => logContextValue.logMessage(`${name} has died of starvation.`, 'error'));
    }
    if (thirst.length > 0) {
      thirst.forEach((name) => logContextValue.logMessage(`${name} has died of thirst.`, 'error'));
    }
    if (deadMercs.length > 0) {
      deadMercs.forEach((merc) => {
        if (!starvation.includes(merc.name) && !thirst.includes(merc.name)) {
          logContextValue.logMessage(`${merc.name} has succumbed to their injuries.`, 'error');
        }
      });
    }
    if (corpsesToDrop.length > 0) {
      worldContextValue.addItemsToGround(corpsesToDrop);
      corpsesToDrop.forEach((corpse) => {
        if (corpse.deceasedCharacter) {
          logContextValue.logMessage(`${corpse.deceasedCharacter.name}'s body falls to the ground.`, 'combat');
        }
      });
    }

    if (newPlayer) {
      setPlayer(newPlayer);
    }

    // Now, regardless of modifications, check the final state for UI consequences
    const finalPlayerState = newPlayer || player;
    if (isCombatantDefeated(finalPlayerState) && !currentCombat && !modalStack.some((m) => m.id === 'death-modal')) {
      uiContextValue.setActiveModal('death-modal');
    }
  }, [player, setPlayer, currentCombat, logContextValue, uiContextValue, worldContextValue, modalStack, GAME_DATA]);

  // Load game on initial mount
  useEffect(() => {
    const savedData = localStorage.getItem(SAVE_KEY);
    if (savedData) {
      try {
        const loaded = JSON.parse(savedData, jsonReviver);
        if (loaded.player) {
          const playerToLoad: Player = loaded.player;
          if (!playerToLoad.nextRingSlotToEquip) playerToLoad.nextRingSlotToEquip = 'right';
          if (!playerToLoad.nextAmuletSlotToEquip) playerToLoad.nextAmuletSlotToEquip = '2';
          if (!playerToLoad.nextHandSlotToEquip) playerToLoad.nextHandSlotToEquip = 'weapon';
          if (!playerToLoad.nextArmletSlotToEquip) playerToLoad.nextArmletSlotToEquip = 'right';
          if (!playerToLoad.nextGloveSlotToEquip) playerToLoad.nextGloveSlotToEquip = 'right';
          if (!playerToLoad.nextLeggingSlotToEquip) playerToLoad.nextLeggingSlotToEquip = 'right';
          if (!playerToLoad.nextFootSlotToEquip) playerToLoad.nextFootSlotToEquip = 'right';
          setPlayer(playerToLoad);
        }
        if (loaded.gameTime) setGameTime(new Date(loaded.gameTime));
        if (loaded.currentLocation) setCurrentLocation(loaded.currentLocation);
        if (loaded.currentDungeon) setCurrentDungeon(loaded.currentDungeon);
        if (loaded.generatedZones) setGeneratedZones(loaded.generatedZones);
        if (loaded.logs) setLogs(loaded.logs);
        if (loaded.modalUiSettings) setModalUiSettings(loaded.modalUiSettings);
        setGameState(loaded.gameState && !loaded.gameState.startsWith('combat') ? loaded.gameState : 'town');
        if (loaded.gameState?.startsWith('combat')) {
          const westhavenData = GAME_DATA.ZONES['zone0'];
          setCurrentLocation(createLocationFromZone('zone0', westhavenData));
        }
        logContextValue.logMessage('Game Loaded! Welcome back.', 'info');
      } catch (error) {
        console.error('Failed to load or parse saved game:', error);
        localStorage.removeItem(SAVE_KEY);
        setGameState('character-creation');
      }
    } else {
      setGameState('character-creation');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [GAME_DATA]); // Add GAME_DATA to dep array

  // Handle post-combat state transitions
  const prevCombatActive = useRef(currentCombat?.isActive);
  useEffect(() => {
    if (prevCombatActive.current && !currentCombat?.isActive) {
      worldContextValue.changeGameState(currentLocation?.type === 'dungeon' ? 'dungeon' : currentLocation?.type === 'town' ? 'town' : 'wilds');
    }
    prevCombatActive.current = currentCombat?.isActive;
  }, [currentCombat, worldContextValue, currentLocation]);

  const playerContextValue = useMemo(() => ({ player, setPlayer }), [player, setPlayer]);

  return (
    <LogContext.Provider value={logContextValue}>
      <UIContext.Provider value={uiContextValue}>
        <PlayerContext.Provider value={playerContextValue}>
          <DebugContext.Provider value={debugContextValue}>
            <WorldContext.Provider value={worldContextValue}>
              <CharacterContext.Provider value={characterContextValue}>
                <InventoryContext.Provider value={inventoryContextValue}>
                  <PartyContext.Provider value={partyContextValue}>
                    <ShopContext.Provider value={shopContextValue}>
                      <ProfessionsContext.Provider value={{ ...professionsContextValue, player }}>
                        <CombatContext.Provider value={combatLogic.combatContextValue}>{children}</CombatContext.Provider>
                      </ProfessionsContext.Provider>
                    </ShopContext.Provider>
                  </PartyContext.Provider>
                </InventoryContext.Provider>
              </CharacterContext.Provider>
            </WorldContext.Provider>
          </DebugContext.Provider>
        </PlayerContext.Provider>
      </UIContext.Provider>
    </LogContext.Provider>
  );
};
