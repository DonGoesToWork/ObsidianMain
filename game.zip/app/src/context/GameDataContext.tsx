import React, { createContext, ReactNode } from "react";
import { GameData } from "types";
import { initializeData } from "../data";

export const GameDataContext = createContext<GameData | null>(null);

const gameData = initializeData();

export const GameDataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  return <GameDataContext.Provider value={gameData}>{children}</GameDataContext.Provider>;
};