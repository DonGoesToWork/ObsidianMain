import React, { createContext, ReactNode } from 'react';
import { GameData } from 'types';
import { GAME_DATA } from '../data';

export const GameDataContext = createContext<GameData | null>(null);

// By importing the pre-built GAME_DATA constant, we ensure that all data
// is initialized only once when this module is first imported by the application.
// This is more performant and idiomatic than calling a function.
export const GameDataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  return <GameDataContext.Provider value={GAME_DATA}>{children}</GameDataContext.Provider>;
};
