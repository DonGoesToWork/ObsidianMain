import { createContext } from "react";
import { LogContextType } from "../types";

export const LogContext = createContext<LogContextType | null>(null);