import { createContext } from 'react';
import { CombatContextType } from '../types';

export const CombatContext = createContext<CombatContextType | null>(null);
