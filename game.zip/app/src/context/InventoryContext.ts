import { createContext } from 'react';
import { InventoryContextType, SortDirection, SortKey } from '../types';

export const InventoryContext = createContext<InventoryContextType | null>(null);