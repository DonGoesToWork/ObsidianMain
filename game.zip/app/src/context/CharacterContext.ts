import { createContext } from "react";
import { CharacterContextType } from "../types";

export const CharacterContext = createContext<CharacterContextType | null>(null);