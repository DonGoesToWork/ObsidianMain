import { createContext } from "react";
import { PartyContextType } from "../types";

export const PartyContext = createContext<PartyContextType | null>(null);