import React, { createContext, ReactNode, useCallback, useEffect, useState } from 'react';
import { ActionName, DEFAULT_HOTKEYS, HotkeyConfig } from '../config/hotkeys';

const HOTKEY_SAVE_KEY = 'aura_rpg_hotkeys_v2'; // Version bump for new structure

interface HotkeyContextType {
  hotkeys: Record<ActionName, HotkeyConfig>;
  saveHotkeys: (newHotkeys: Record<ActionName, HotkeyConfig>) => void;
  resetHotkeys: () => void;
  getHotkeyFor: (action: ActionName) => HotkeyConfig;
}

export const HotkeyContext = createContext<HotkeyContextType | null>(null);

export const HotkeyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [hotkeys, setHotkeys] = useState<Record<ActionName, HotkeyConfig>>(DEFAULT_HOTKEYS);

  useEffect(() => {
    try {
      const savedHotkeys = localStorage.getItem(HOTKEY_SAVE_KEY);
      if (savedHotkeys) {
        const parsed = JSON.parse(savedHotkeys);
        const migratedHotkeys: Record<ActionName, HotkeyConfig> = { ...DEFAULT_HOTKEYS };

        for (const action in parsed) {
          if (Object.prototype.hasOwnProperty.call(DEFAULT_HOTKEYS, action)) {
            const actionName = action as ActionName;
            const savedBinding = parsed[actionName];

            if (typeof savedBinding === 'string') {
              migratedHotkeys[actionName] = { primary: savedBinding, secondary: null };
            } else if (typeof savedBinding === 'object' && savedBinding !== null && 'primary' in savedBinding) {
              migratedHotkeys[actionName] = {
                primary: savedBinding.primary || null,
                secondary: savedBinding.secondary || null,
              };
            }
          }
        }
        setHotkeys(migratedHotkeys);
      }
    } catch (error) {
      console.error('Failed to load hotkeys from localStorage', error);
      setHotkeys(DEFAULT_HOTKEYS);
    }
  }, []);

  const saveHotkeys = useCallback((newHotkeys: Record<ActionName, HotkeyConfig>) => {
    setHotkeys(newHotkeys);
    try {
      localStorage.setItem(HOTKEY_SAVE_KEY, JSON.stringify(newHotkeys));
    } catch (error) {
      console.error('Failed to save hotkeys to localStorage', error);
    }
  }, []);

  const resetHotkeys = useCallback(() => {
    saveHotkeys(DEFAULT_HOTKEYS);
  }, [saveHotkeys]);

  const getHotkeyFor = useCallback(
    (action: ActionName): HotkeyConfig => {
      return hotkeys[action] || { primary: null, secondary: null };
    },
    [hotkeys]
  );

  const contextValue: HotkeyContextType = {
    hotkeys,
    saveHotkeys,
    resetHotkeys,
    getHotkeyFor,
  };

  return <HotkeyContext.Provider value={contextValue}>{children}</HotkeyContext.Provider>;
};