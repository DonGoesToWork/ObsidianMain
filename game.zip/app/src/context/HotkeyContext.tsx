import React, { createContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { ActionName, DEFAULT_HOTKEYS } from '../config/hotkeys';

const HOTKEY_SAVE_KEY = 'aura_rpg_hotkeys_v1';

interface HotkeyContextType {
  hotkeys: Record<ActionName, string>;
  saveHotkeys: (newHotkeys: Record<ActionName, string>) => void;
  resetHotkeys: () => void;
  getHotkeyFor: (action: ActionName) => string;
}

export const HotkeyContext = createContext<HotkeyContextType | null>(null);

export const HotkeyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [hotkeys, setHotkeys] = useState<Record<ActionName, string>>(DEFAULT_HOTKEYS);

  useEffect(() => {
    try {
      const savedHotkeys = localStorage.getItem(HOTKEY_SAVE_KEY);
      if (savedHotkeys) {
        const parsed = JSON.parse(savedHotkeys);
        // Merge saved with defaults to prevent missing keys on updates
        setHotkeys({ ...DEFAULT_HOTKEYS, ...parsed });
      }
    } catch (error) {
      console.error('Failed to load hotkeys from localStorage', error);
      setHotkeys(DEFAULT_HOTKEYS);
    }
  }, []);

  const saveHotkeys = useCallback((newHotkeys: Record<ActionName, string>) => {
    setHotkeys(newHotkeys);
    try {
      localStorage.setItem(HOTKEY_SAVE_KEY, JSON.stringify(newHotkeys));
    } catch (error) {
      console.error('Failed to save hotkeys to localStorage', error);
    }
  }, []);

  const resetHotkeys = useCallback(() => {
    saveHotkeys(DEFAULT_HOTKEYS);
  }, [saveHotkeys]);

  const getHotkeyFor = useCallback(
    (action: ActionName): string => {
      return hotkeys[action] || '';
    },
    [hotkeys]
  );

  const contextValue: HotkeyContextType = {
    hotkeys,
    saveHotkeys,
    resetHotkeys,
    getHotkeyFor,
  };

  return <HotkeyContext.Provider value={contextValue}>{children}</HotkeyContext.Provider>;
};
