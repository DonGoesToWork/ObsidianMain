import { createContext } from 'react';
import { ProfessionsContextType } from '../types';

export const ProfessionsContext = createContext<ProfessionsContextType | null>(null);