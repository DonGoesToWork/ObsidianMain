import { createContext } from "react";
import { DebugContextType } from "../types";

export const DebugContext = createContext<DebugContextType | null>(null);