import { useCallback, useContext } from "react";
import {
  Player,
  BaseStatBlock,
  StatusEffectInstance,
  ItemId,
  RecipeId,
  AbilityId,
  ItemInstance,
  Loggable,
  Mercenary,
  Limb,
  GameData,
} from "../../types";
import { LogType } from "types";
import { processLimbDamage } from "utils/combatUtils";
import { applyFullHealLogic } from "utils/playerUtils";
import { GameDataContext } from "context/GameDataContext";

type DebugActionsDeps = {
  addGold: (amount: number) => void;
  setPlayer: (update: React.SetStateAction<Player | null>) => void;
  logMessage: (message: Loggable, type: LogType) => void;
  gainXp: (amount: number) => void;
  travelTo: (locationId: string) => void;
  addItem: (
    itemId: ItemId,
    quantity?: number,
    options?: any,
  ) => ItemInstance[];
};

function modifyCharacterInState(
  playerState: Player,
  targetId: string,
  modificationFn: (char: Player | Mercenary) => Player | Mercenary,
): Player {
  if (targetId === "player") {
    const modifiedPlayer = modificationFn(playerState);
    return modifiedPlayer as Player;
  } else {
    const newParty = playerState.party.map((merc) => {
      if (merc.id === targetId) {
        return modificationFn(merc) as Mercenary;
      }
      return merc;
    });
    return { ...playerState, party: newParty };
  }
}

function applyRestoreResourcesLogic(
  char: Player | Mercenary,
): Player | Mercenary {
  const newBody = JSON.parse(JSON.stringify(char.body));
  Object.values(newBody).forEach((limb: any) => {
    limb.currentHp = limb.maxHp;
  });
  return { ...char, body: newBody, mp: char.maxMp, sp: char.maxSp };
}

function applyClearDebuffsLogic(char: Player | Mercenary, GAME_DATA: GameData): Player | Mercenary {
  const newBody = JSON.parse(JSON.stringify(char.body));
  Object.values(newBody).forEach((limb: any) => {
    limb.statusEffects = limb.statusEffects.filter(
      (e: StatusEffectInstance) =>
        GAME_DATA.STATUS_EFFECTS[e.id]?.isBeneficial,
    );
  });
  const statusEffects = char.statusEffects.filter(
    (e: StatusEffectInstance) =>
      GAME_DATA.STATUS_EFFECTS[e.id]?.isBeneficial,
  );
  return { ...char, body: newBody, statusEffects };
}

export function useDebugProviderLogic(deps: DebugActionsDeps) {
  const { addGold, setPlayer, logMessage, gainXp, travelTo, addItem } = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const debug_addGold = useCallback(
    (amount: number) => {
      addGold(amount);
      logMessage(`DEBUG: Added ${amount} gold.`, "info");
    },
    [addGold, logMessage],
  );

  const debug_fullHeal = useCallback(
    (targetId: string) => {
      setPlayer((p) => {
        if (!p) return p;
        return modifyCharacterInState(p, targetId, (char) => applyFullHealLogic(char, GAME_DATA));
      });
      logMessage(
        `DEBUG: Target fully healed, resources restored, and debuffs cleared.`,
        "heal",
      );
    },
    [setPlayer, logMessage, GAME_DATA],
  );

  const debug_fullHealAll = useCallback(() => {
    setPlayer((p) => {
      if (!p) return p;
      let newPlayer = applyFullHealLogic(p, GAME_DATA) as Player;
      newPlayer.party = newPlayer.party.map(
        (merc) => applyFullHealLogic(merc, GAME_DATA) as Mercenary,
      );
      return newPlayer;
    });
    logMessage(`DEBUG: Player and all party members fully healed.`, "heal");
  }, [setPlayer, logMessage, GAME_DATA]);

  const debug_restoreResources = useCallback(
    (targetId: string) => {
      setPlayer((p) => {
        if (!p) return p;
        return modifyCharacterInState(p, targetId, applyRestoreResourcesLogic);
      });
      logMessage(`DEBUG: Target HP, MP, and SP restored.`, "heal");
    },
    [setPlayer, logMessage],
  );

  const debug_clearDebuffs = useCallback(
    (targetId: string) => {
      setPlayer((p) => {
        if (!p) return p;
        return modifyCharacterInState(p, targetId, (char) => applyClearDebuffsLogic(char, GAME_DATA));
      });
      logMessage(`DEBUG: Cleared all debuffs on target.`, "info");
    },
    [setPlayer, logMessage, GAME_DATA],
  );

  const debug_addPoints = useCallback(
    (type: "perk" | "stat", amount: number) => {
      setPlayer((p) => {
        if (!p) return p;
        if (type === "perk") {
          logMessage(`DEBUG: Added ${amount} perk point(s).`, "info");
          return { ...p, perkPoints: p.perkPoints + amount };
        }
        logMessage(`DEBUG: Added ${amount} stat point(s).`, "info");
        return { ...p, attributePoints: p.attributePoints + amount };
      });
    },
    [setPlayer, logMessage],
  );

  const debug_addXP = useCallback(
    (amount: number) => gainXp(amount),
    [gainXp],
  );

  const debug_addLevel = useCallback(
    (levels: number) => {
      setPlayer((p) => {
        if (!p) return p;
        let newPlayer = { ...p };
        newPlayer.level += levels;
        newPlayer.perkPoints += levels;
        newPlayer.attributePoints += levels * 5;
        newPlayer.xp = 0;
        logMessage(`DEBUG: Added ${levels} level(s).`, "quest");
        return newPlayer;
      });
    },
    [setPlayer, logMessage],
  );

  const debug_addAttributes = useCallback(
    (amount: number) => {
      setPlayer((p) => {
        if (!p) return p;
        const newBaseStats: BaseStatBlock = { ...p.baseStats };
        (Object.keys(newBaseStats) as Array<keyof BaseStatBlock>).forEach(
          (stat) => {
            newBaseStats[stat] += amount;
          },
        );
        logMessage(`DEBUG: Added ${amount} to all attributes.`, "info");
        return { ...p, baseStats: newBaseStats };
      });
    },
    [setPlayer, logMessage],
  );

  const debug_duplicateItems = useCallback(() => {
    setPlayer((p) => {
      if (!p || p.inventory.length === 0) {
        logMessage("DEBUG: No items to duplicate.", "info");
        return p;
      }
      const newItems = p.inventory.map((item) =>
        JSON.parse(JSON.stringify(item)),
      );
      logMessage(`DEBUG: Duplicated ${newItems.length} item(s).`, "info");
      return { ...p, inventory: [...p.inventory, ...newItems] };
    });
  }, [setPlayer, logMessage]);

  const debug_teleportToTown = useCallback(() => {
    travelTo("zone0");
    logMessage("DEBUG: Teleported to Westhaven.", "info");
  }, [travelTo, logMessage]);

  const debug_maxProfessions = useCallback(() => {
    setPlayer((p) => {
      if (!p) return p;
      const newProfessions = { ...p.professions };
      Object.values(newProfessions).forEach((prof) => {
        prof.level = 100;
        prof.xp = 0;
      });
      logMessage("DEBUG: All professions set to 100.", "info");
      return { ...p, professions: newProfessions };
    });
  }, [setPlayer, logMessage]);

  const debug_learnAllRecipes = useCallback(() => {
    setPlayer((p) => {
      if (!p) return p;
      const allRecipeIds = Object.keys(GAME_DATA.ALL_RECIPES) as RecipeId[];
      const newKnownRecipes = { ...p.knownRecipes };
      allRecipeIds.forEach((id) => {
        newKnownRecipes[id] = true;
      });
      logMessage(`DEBUG: Learned all ${allRecipeIds.length} recipes.`, "info");
      return { ...p, knownRecipes: newKnownRecipes };
    });
  }, [setPlayer, logMessage, GAME_DATA]);

  const debug_learnAllSpells = useCallback(() => {
    setPlayer((p) => {
      if (!p) return p;
      const allAbilityIds = Object.keys(GAME_DATA.SKILLS) as AbilityId[];
      const newSkills = { ...p.skills };
      let count = 0;
      allAbilityIds.forEach((id) => {
        if (GAME_DATA.SKILLS[id].abilityType === "Spell" && !newSkills[id]) {
          newSkills[id] = { rank: 1 };
          count++;
        }
      });
      logMessage(`DEBUG: Learned ${count} new spells.`, "info");
      return { ...p, skills: newSkills };
    });
  }, [setPlayer, logMessage, GAME_DATA]);

  const debug_learnAllSkills = useCallback(() => {
    setPlayer((p) => {
      if (!p) return p;
      const allAbilityIds = Object.keys(GAME_DATA.SKILLS) as AbilityId[];
      const newSkills = { ...p.skills };
      let count = 0;
      allAbilityIds.forEach((id) => {
        if (GAME_DATA.SKILLS[id].abilityType === "Skill" && !newSkills[id]) {
          newSkills[id] = { rank: 1 };
          count++;
        }
      });
      logMessage(`DEBUG: Learned ${count} new skills.`, "info");
      return { ...p, skills: newSkills };
    });
  }, [setPlayer, logMessage, GAME_DATA]);

  const debug_unlockAll = useCallback(() => {
    debug_maxProfessions();
    debug_learnAllRecipes();
    debug_learnAllSkills();
    debug_learnAllSpells();
    logMessage("DEBUG: All unlocks applied.", "info");
  }, [
    debug_maxProfessions,
    debug_learnAllRecipes,
    debug_learnAllSkills,
    debug_learnAllSpells,
    logMessage,
  ]);

  const debug_giveRandomItems = useCallback(
    (count: number) => {
      for (let i = 0; i < count; i++) {
        const allItemIds = Object.keys(GAME_DATA.ITEMS) as ItemId[];
        const randomId =
          allItemIds[Math.floor(Math.random() * allItemIds.length)];
        addItem(randomId);
      }
      logMessage(`DEBUG: Added ${count} random items.`, "info");
    },
    [logMessage, addItem, GAME_DATA],
  );

  const debug_giveDamagedItem = useCallback(() => {
    addItem("gen_smithing_mat_ingot_iron_shortsword", 1, {
      isUnidentified: false,
      initialDurabilityPercent: 0.5,
    });
    logMessage(`DEBUG: Gave a damaged Iron Shortsword.`, "info");
  }, [addItem, logMessage]);

  const debug_clearInventory = useCallback(() => {
    setPlayer((p) => {
      if (!p) return p;
      logMessage("DEBUG: Inventory cleared.", "info");
      return { ...p, inventory: [] };
    });
  }, [setPlayer, logMessage]);

  const debug_applyDirectDamage = useCallback(
    (
      targetId: string,
      limbId: string,
      damage: number,
      damageTypes: string[],
    ) => {
      setPlayer((p) => {
        if (!p) return p;

        return modifyCharacterInState(p, targetId, (char) => {
          const limbToDamage = char.body[limbId as keyof typeof char.body];
          if (!limbToDamage || limbToDamage.state === "Destroyed") {
            logMessage(`Limb is already destroyed.`, "info");
            return char;
          }

          const { updatedLimb, logMessages } = processLimbDamage(
            limbToDamage,
            damage,
            damageTypes,
            char.name,
            GAME_DATA,
          );

          logMessages.forEach((msg) => logMessage(msg, "combat"));

          const newBody = {
            ...char.body,
            [limbId]: updatedLimb as Limb,
          };
          return { ...char, body: newBody };
        });
      });
    },
    [setPlayer, logMessage, GAME_DATA],
  );

  const debug_test_all = useCallback(() => {
    logMessage("DEBUG: Applying all test options...", "info");
    debug_addLevel(99);
    debug_addGold(100000);
    debug_addAttributes(1000);
    debug_learnAllSkills();
    debug_learnAllSpells();
    debug_learnAllRecipes();
    debug_fullHeal("player");
    debug_giveRandomItems(50);
    for (let i = 0; i < 10; i++) {
      debug_giveDamagedItem();
    }
  }, [
    logMessage,
    debug_addLevel,
    debug_addGold,
    debug_addAttributes,
    debug_learnAllSkills,
    debug_learnAllSpells,
    debug_learnAllRecipes,
    debug_fullHeal,
    debug_giveRandomItems,
    debug_giveDamagedItem,
  ]);

  return {
    debug_addGold,
    debug_fullHeal,
    debug_fullHealAll,
    debug_addPoints,
    debug_addXP,
    debug_addLevel,
    debug_addAttributes,
    debug_duplicateItems,
    debug_teleportToTown,
    debug_maxProfessions,
    debug_restoreResources,
    debug_clearDebuffs,
    debug_learnAllRecipes,
    debug_learnAllSpells,
    debug_learnAllSkills,
    debug_unlockAll,
    debug_giveRandomItems,
    debug_giveDamagedItem,
    debug_clearInventory,
    debug_test_all,
    debug_applyDirectDamage,
  };
}