import { useCallback, useContext } from 'react';
import {
  Player,
  BaseStatBlock,
  StatusEffectInstance,
  ItemId,
  RecipeId,
  AbilityId,
  ItemInstance,
  Loggable,
  Mercenary,
  Limb,
  GameData,
  LimbState,
  VitalId,
  Combatant,
  CombatState,
  TotalPlayerStats,
} from '../../types';
import { LogType } from 'types';
import { processLimbDamage } from 'utils/combatUtils';
import { applyFullHealLogic, applyRestoreResourcesLogic, applyClearDebuffsLogic } from 'utils/playerUtils';
import { GameDataContext } from 'context/GameDataContext';
import { calculateXpToNextLevel } from 'services/statService';
import { createItemInstances } from 'utils/itemUtils';

type DebugActionsDeps = {
  addGold: (amount: number) => void;
  setPlayer: (update: React.SetStateAction<Player | null>) => void;
  logMessage: (message: Loggable, type: LogType) => void;
  gainXp: (amount: number) => void;
  travelTo: (locationId: string) => void;
  addItem: (itemId: ItemId, quantity?: number, options?: any) => ItemInstance[];
  debugTargets: string[];
  setDebugTargets: React.Dispatch<React.SetStateAction<string[]>>;
  currentCombat: CombatState | null;
  setCurrentCombat: React.Dispatch<React.SetStateAction<CombatState | null>>;
  setGameTime: React.Dispatch<React.SetStateAction<Date>>;
};

function modifyCharacterInState(playerState: Player, targetId: string, modificationFn: (char: Player | Mercenary) => Player | Mercenary): Player {
  if (targetId === 'player') {
    const modifiedPlayer = modificationFn(playerState);
    return modifiedPlayer as Player;
  } else {
    const newParty = playerState.party.map((merc) => {
      if (merc.id === targetId) {
        return modificationFn(merc) as Mercenary;
      }
      return merc;
    });
    return { ...playerState, party: newParty };
  }
}

export function useDebugProviderLogic(deps: DebugActionsDeps) {
  const { addGold, setPlayer, logMessage, gainXp, travelTo, addItem, debugTargets, setDebugTargets, currentCombat, setCurrentCombat, setGameTime } = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const executeOnTargets = useCallback(
    (
      playerModificationFn: (p: Player, id: string) => Player,
      enemyModificationFn: (c: Combatant) => Combatant | null,
      message: string,
    ) => {
      if (debugTargets.length === 0) {
        logMessage('DEBUG: No targets selected.', 'error');
        return;
      }

      setPlayer((p) => {
        if (!p) return p;
        let tempPlayer = { ...p };
        debugTargets.forEach((targetId) => {
          if (targetId === 'player' || tempPlayer.party.some((m) => m.id === targetId)) {
            tempPlayer = playerModificationFn(tempPlayer, targetId);
          }
        });
        return tempPlayer;
      });

      setCurrentCombat((c) => {
        if (!c) return c;
        let tempCombat = { ...c };
        let combatantsModified = false;
        debugTargets.forEach((targetId) => {
          if (tempCombat.combatants[targetId]?.team === 'enemy') {
            const modified = enemyModificationFn(tempCombat.combatants[targetId]);
            if (modified) {
              tempCombat.combatants[targetId] = modified;
              combatantsModified = true;
            }
          }
        });
        return combatantsModified ? tempCombat : c;
      });

      logMessage(`DEBUG: ${message} on ${debugTargets.length} target(s).`, 'info');
    },
    [debugTargets, setPlayer, logMessage, setCurrentCombat],
  );

  const debug_addGold = useCallback(
    (amount: number) => {
      const playerFn = (p: Player, id: string) =>
        modifyCharacterInState(p, id, (char) => {
          if ('gold' in char) {
            return { ...char, gold: (char.gold || 0) + amount };
          }
          return char;
        });
      executeOnTargets(playerFn, () => null, `Added ${amount} gold`);
    },
    [executeOnTargets],
  );

  const debug_fullHeal = useCallback(() => {
    const playerFn = (p: Player, id: string) => modifyCharacterInState(p, id, (char) => applyFullHealLogic(char, GAME_DATA) as Player | Mercenary);
    const enemyFn = (c: Combatant) => applyFullHealLogic(c, GAME_DATA) as Combatant;
    executeOnTargets(playerFn, enemyFn, 'Full heal applied');
  }, [executeOnTargets, GAME_DATA]);

  const debug_fullHealAll = useCallback(() => {
    setPlayer((p) => {
      if (!p) return p;
      let newPlayer = applyFullHealLogic(p, GAME_DATA) as Player;
      newPlayer.party = newPlayer.party.map((merc) => applyFullHealLogic(merc, GAME_DATA) as Mercenary);
      return newPlayer;
    });
    logMessage(`DEBUG: Player and all party members fully healed.`, 'heal');
  }, [setPlayer, logMessage, GAME_DATA]);

  const debug_restoreResources = useCallback(() => {
    const playerFn = (p: Player, id: string) => modifyCharacterInState(p, id, (char) => applyRestoreResourcesLogic(char) as Player | Mercenary);
    const enemyFn = (c: Combatant) => applyRestoreResourcesLogic(c) as Combatant;
    executeOnTargets(playerFn, enemyFn, 'Resources restored');
  }, [executeOnTargets]);

  const debug_clearDebuffs = useCallback(() => {
    const playerFn = (p: Player, id: string) => modifyCharacterInState(p, id, (char) => applyClearDebuffsLogic(char, GAME_DATA) as Player | Mercenary);
    const enemyFn = (c: Combatant) => applyClearDebuffsLogic(c, GAME_DATA) as Combatant;
    executeOnTargets(playerFn, enemyFn, 'Debuffs cleared');
  }, [executeOnTargets, GAME_DATA]);

  const debug_addPoints = useCallback(
    (type: 'perk' | 'stat', amount: number) => {
      setPlayer((p) => {
        if (!p) return p;
        if (type === 'perk') {
          logMessage(`DEBUG: Added ${amount} perk point(s).`, 'info');
          return { ...p, perkPoints: p.perkPoints + amount };
        }
        logMessage(`DEBUG: Added ${amount} stat point(s).`, 'info');
        return { ...p, attributePoints: p.attributePoints + amount };
      });
    },
    [setPlayer, logMessage],
  );

  const debug_addXP = useCallback(
    (amount: number) => {
      const playerFn = (p: Player, id: string) =>
        modifyCharacterInState(p, id, (char) => {
          if ('xp' in char && 'xpToNextLevel' in char) {
            let newChar = { ...char };
            newChar.xp += amount;
            while (newChar.xp >= newChar.xpToNextLevel) {
              newChar.xp -= newChar.xpToNextLevel;
              newChar.level++;
              if ('professions' in newChar) (newChar as Player).perkPoints++;
              newChar.xpToNextLevel = calculateXpToNextLevel(newChar.level);
            }
            return newChar;
          }
          return char;
        });
      executeOnTargets(playerFn, () => null, `Added ${amount} XP`);
    },
    [executeOnTargets],
  );

  const debug_addLevel = useCallback(
    (levels: number) => {
      const applyToPlayer = (char: Player | Mercenary) => {
        const newChar: any = { ...char, level: char.level + levels };
        newChar.xp = 0;
        newChar.xpToNextLevel = calculateXpToNextLevel(newChar.level);

        if ('professions' in newChar) {
          (newChar as Player).perkPoints += levels;
          (newChar as Player).attributePoints += levels * 5;
        }
        return newChar;
      };
      const applyToEnemy = (c: Combatant) => ({ ...c, level: c.level + levels });

      const playerFn = (p: Player, id: string) => modifyCharacterInState(p, id, applyToPlayer);
      const enemyFn = (c: Combatant) => applyToEnemy(c);
      executeOnTargets(playerFn, enemyFn, `Added ${levels} level(s)`);
    },
    [executeOnTargets],
  );

  const debug_addAttributes = useCallback(
    (amount: number) => {
      const applyToPlayer = (char: Player | Mercenary) => {
        const newBaseStats = { ...char.baseStats };
        (Object.keys(newBaseStats) as (keyof BaseStatBlock)[]).forEach((stat) => {
          newBaseStats[stat] += amount;
        });
        return { ...char, baseStats: newBaseStats };
      };
      const applyToEnemy = (c: Combatant) => {
        const newBaseStats = { ...c.baseStats };
        (Object.keys(newBaseStats) as (keyof TotalPlayerStats)[]).forEach((stat) => {
          if (typeof (newBaseStats as any)[stat] === 'number') (newBaseStats as any)[stat] += amount;
        });
        return { ...c, baseStats: newBaseStats };
      };

      const playerFn = (p: Player, id: string) => modifyCharacterInState(p, id, applyToPlayer);
      const enemyFn = (c: Combatant) => applyToEnemy(c);
      executeOnTargets(playerFn, enemyFn, `Added ${amount} to all attributes`);
    },
    [executeOnTargets],
  );

  const debug_modifyVitals = useCallback(
    (vital: VitalId, amount: number) => {
      const action = (p: Player, id: string) =>
        modifyCharacterInState(p, id, (char) => {
          if ('vitals' in char) {
            const newVitals = { ...char.vitals };
            newVitals[vital].current = Math.max(0, Math.min(newVitals[vital].max, newVitals[vital].current + amount));
            return { ...char, vitals: newVitals };
          }
          return char;
        });
      executeOnTargets(action, () => null, `Modified ${vital}`);
    },
    [executeOnTargets],
  );

  const debug_setLimbState = useCallback(
    (limbId: string, state: LimbState) => {
      const applyFn = (char: Player | Mercenary | Combatant) => {
        if (char.body[limbId]) {
          const newBody = { ...char.body };
          const newLimb = { ...newBody[limbId] };
          newLimb.state = state;
          if (state === 'Healthy') newLimb.currentHp = newLimb.maxHp;
          if (state === 'Destroyed') newLimb.currentHp = 0;
          newBody[limbId] = newLimb;
          return { ...char, body: newBody };
        }
        return char;
      };
      const playerFn = (p: Player, id: string) => modifyCharacterInState(p, id, (char) => applyFn(char) as Player | Mercenary);
      const enemyFn = (c: Combatant) => applyFn(c) as Combatant;
      executeOnTargets(playerFn, enemyFn, `Set ${limbId} to ${state}`);
    },
    [executeOnTargets],
  );

  const debug_duplicateItems = useCallback(() => {
    const applyFn = (char: Player | Mercenary | Combatant) => {
      if (char.inventory.length === 0) return char;
      const newItems = char.inventory.map((item) => ({ ...item, unique_id: `item_${Date.now()}_${Math.random()}` }));
      return { ...char, inventory: [...char.inventory, ...newItems] };
    };
    const playerFn = (p: Player, id: string) => modifyCharacterInState(p, id, (char) => applyFn(char) as Player | Mercenary);
    const enemyFn = (c: Combatant) => applyFn(c) as Combatant;
    executeOnTargets(playerFn, enemyFn, `Duplicated items`);
  }, [executeOnTargets]);

  const debug_teleportToTown = useCallback(() => {
    travelTo('zone0');
    logMessage('DEBUG: Teleported to Westhaven.', 'info');
  }, [travelTo, logMessage]);

  const debug_maxProfessions = useCallback(() => {
    setPlayer((p) => {
      if (!p) return p;
      const newProfessions = { ...p.professions };
      Object.values(newProfessions).forEach((prof) => {
        prof.level = 100;
        prof.xp = 0;
      });
      logMessage('DEBUG: All professions set to 100.', 'info');
      return { ...p, professions: newProfessions };
    });
  }, [setPlayer, logMessage]);

  const debug_learnAllRecipes = useCallback(() => {
    setPlayer((p) => {
      if (!p) return p;
      const allRecipeIds = Object.keys(GAME_DATA.ALL_RECIPES) as RecipeId[];
      const newKnownRecipes = { ...p.knownRecipes };
      allRecipeIds.forEach((id) => {
        newKnownRecipes[id] = true;
      });
      logMessage(`DEBUG: Learned all ${allRecipeIds.length} recipes.`, 'info');
      return { ...p, knownRecipes: newKnownRecipes };
    });
  }, [setPlayer, logMessage, GAME_DATA]);

  const debug_learnAllSpells = useCallback(() => {
    const allSpellIds = Object.keys(GAME_DATA.SKILLS).filter((id) => GAME_DATA.SKILLS[id].abilityType === 'Spell');
    const applyFn = (char: Player | Mercenary | Combatant) => {
      const newSkills = { ...char.skills };
      allSpellIds.forEach((id) => {
        newSkills[id as AbilityId] = { rank: 1 };
      });
      return { ...char, skills: newSkills };
    };
    const playerFn = (p: Player, id: string) => modifyCharacterInState(p, id, (char) => applyFn(char) as Player | Mercenary);
    const enemyFn = (c: Combatant) => applyFn(c) as Combatant;
    executeOnTargets(playerFn, enemyFn, `Learned all spells`);
  }, [executeOnTargets, GAME_DATA.SKILLS]);

  const debug_learnAllSkills = useCallback(() => {
    const allSkillIds = Object.keys(GAME_DATA.SKILLS).filter((id) => GAME_DATA.SKILLS[id].abilityType === 'Skill');
    const applyFn = (char: Player | Mercenary | Combatant) => {
      const newSkills = { ...char.skills };
      allSkillIds.forEach((id) => {
        newSkills[id as AbilityId] = { rank: 1 };
      });
      return { ...char, skills: newSkills };
    };
    const playerFn = (p: Player, id: string) => modifyCharacterInState(p, id, (char) => applyFn(char) as Player | Mercenary);
    const enemyFn = (c: Combatant) => applyFn(c) as Combatant;
    executeOnTargets(playerFn, enemyFn, `Learned all skills`);
  }, [executeOnTargets, GAME_DATA.SKILLS]);

  const debug_unlockAll = useCallback(() => {
    debug_maxProfessions();
    debug_learnAllRecipes();
    debug_learnAllSkills();
    debug_learnAllSpells();
    logMessage('DEBUG: All unlocks applied for player.', 'info');
  }, [debug_maxProfessions, debug_learnAllRecipes, debug_learnAllSkills, debug_learnAllSpells, logMessage]);

  const debug_giveRandomItems = useCallback(
    (count: number) => {
      const allItemIds = Object.keys(GAME_DATA.ITEMS) as ItemId[];
      const applyFn = (char: Player | Mercenary | Combatant) => {
        const newItems: ItemInstance[] = [];
        for (let i = 0; i < count; i++) {
          const randomId = allItemIds[Math.floor(Math.random() * allItemIds.length)];
          newItems.push(...createItemInstances(randomId, 1, undefined, GAME_DATA));
        }
        return { ...char, inventory: [...char.inventory, ...newItems] };
      };
      const playerFn = (p: Player, id: string) => modifyCharacterInState(p, id, (char) => applyFn(char) as Player | Mercenary);
      const enemyFn = (c: Combatant) => applyFn(c) as Combatant;
      executeOnTargets(playerFn, enemyFn, `Added ${count} random items`);
    },
    [executeOnTargets, GAME_DATA],
  );

  const debug_giveDamagedItem = useCallback(() => {
    const applyFn = (char: Player | Mercenary | Combatant) => {
      const newItems = createItemInstances('gen_smithing_mat_ingot_iron_shortsword', 1, {
        isUnidentified: false,
        initialDurabilityPercent: 0.5,
      }, GAME_DATA);
      return { ...char, inventory: [...char.inventory, ...newItems] };
    };
    const playerFn = (p: Player, id: string) => modifyCharacterInState(p, id, (char) => applyFn(char) as Player | Mercenary);
    const enemyFn = (c: Combatant) => applyFn(c) as Combatant;
    executeOnTargets(playerFn, enemyFn, `Gave a damaged Iron Shortsword`);
  }, [executeOnTargets, GAME_DATA]);

  const debug_clearInventory = useCallback(() => {
    const applyFn = (char: Player | Mercenary | Combatant) => ({ ...char, inventory: [] });
    const playerFn = (p: Player, id: string) => modifyCharacterInState(p, id, (char) => applyFn(char) as Player | Mercenary);
    const enemyFn = (c: Combatant) => applyFn(c) as Combatant;
    executeOnTargets(playerFn, enemyFn, `Inventory cleared`);
  }, [executeOnTargets]);

  const debug_applyDirectDamage = useCallback(
    (targetId: string, limbId: string, damage: number, damageTypes: string[]) => {
      setPlayer((p) => {
        if (!p) return p;

        return modifyCharacterInState(p, targetId, (char) => {
          const limbToDamage = char.body[limbId as keyof typeof char.body];
          if (!limbToDamage || limbToDamage.state === 'Destroyed') {
            logMessage(`Limb is already destroyed.`, 'info');
            return char;
          }

          const { updatedLimb, logMessages } = processLimbDamage(limbToDamage, damage, damageTypes, char.name, GAME_DATA);

          logMessages.forEach((msg) => logMessage(msg, 'combat'));

          const newBody = {
            ...char.body,
            [limbId]: updatedLimb as Limb,
          };
          return { ...char, body: newBody };
        });
      });
    },
    [setPlayer, logMessage, GAME_DATA],
  );

  const debug_setGameTimeToStartOfDay = useCallback(() => {
    setGameTime((currentTime) => {
      const newTime = new Date(currentTime);
      newTime.setHours(0, 0, 0, 0);
      logMessage(`DEBUG: Game time set to ${newTime.toLocaleTimeString()}.`, 'info');
      return newTime;
    });
  }, [setGameTime, logMessage]);

  const debug_test_all = useCallback(() => {
    logMessage('DEBUG: Applying all test options...', 'info');
    debug_addLevel(99);
    debug_addGold(100000);
    setPlayer((p) => {
      if (!p) return p;
      let tempPlayer = { ...p };
      ['player', ...p.party.map((m) => m.id)].forEach((targetId) => {
        tempPlayer = modifyCharacterInState(tempPlayer, targetId, (char) => {
          const newBaseStats = { ...char.baseStats };
          (Object.keys(newBaseStats) as (keyof BaseStatBlock)[]).forEach((stat) => {
            newBaseStats[stat] += 1000;
          });
          return { ...char, baseStats: newBaseStats };
        });
      });
      return tempPlayer;
    });

    debug_learnAllSkills();
    debug_learnAllSpells();
    debug_learnAllRecipes();
    debug_fullHealAll();
    debug_giveRandomItems(50);
    for (let i = 0; i < 10; i++) {
      debug_giveDamagedItem();
    }
  }, [logMessage, debug_addLevel, debug_addGold, setPlayer, debug_learnAllSkills, debug_learnAllSpells, debug_learnAllRecipes, debug_fullHealAll, debug_giveRandomItems, debug_giveDamagedItem]);

  return {
    debug_addGold,
    debug_fullHeal,
    debug_fullHealAll,
    debug_addPoints,
    debug_addXP,
    debug_addLevel,
    debug_addAttributes,
    debug_duplicateItems,
    debug_teleportToTown,
    debug_maxProfessions,
    debug_restoreResources,
    debug_clearDebuffs,
    debug_learnAllRecipes,
    debug_learnAllSpells,
    debug_learnAllSkills,
    debug_unlockAll,
    debug_giveRandomItems,
    debug_giveDamagedItem,
    debug_test_all,
    debug_clearInventory,
    debug_applyDirectDamage,
    debugTargets,
    setDebugTargets,
    debug_modifyVitals,
    debug_setLimbState,
    debug_setGameTimeToStartOfDay,
  };
}