import { GameDataContext } from 'context/GameDataContext';
import React, { useContext, useMemo } from 'react';
import { CombatState, Loggable, Player } from '../../types';
import {
  debug_addAttributes,
  debug_addGold,
  debug_addLevel,
  debug_addPoints,
  debug_addXP,
  debug_applyDirectDamage,
  debug_clearDebuffs,
  debug_clearInventory,
  debug_craftGod,
  debug_duplicateItems,
  debug_fullHeal,
  debug_giveAllRecipeItems,
  debug_giveAntiGravityChest,
  debug_giveDamagedItem,
  debug_giveRandomItems,
  debug_learnAllEnchantmentRecipes,
  debug_learnAllRecipes,
  debug_learnAllSkills,
  debug_learnAllSpells,
  debug_lockAll,
  debug_maxProfessions,
  debug_modifyVitals,
  debug_restoreResources,
  debug_setAttributes,
  debug_setGameTimeToStartOfDay,
  debug_setGold,
  debug_setLevel,
  debug_setLimbHp,
  debug_setPerkPoints,
  debug_setProfessionLevel,
  debug_setStatPoints,
  debug_setVital,
  debug_setXP,
  debug_teleportToTown,
  debug_test_all,
  debug_unlockAll,
} from '../actions/debug';

import { LogType } from 'types';
import { createExecuteOnTargets } from '../actions/debug/utils';

type DebugActionsDeps = {
  setPlayer: (update: React.SetStateAction<Player | null>) => void;
  logMessage: (message: Loggable, type: LogType) => void;
  travelTo: (locationId: string) => void;
  debugTargets: string[];
  setDebugTargets: React.Dispatch<React.SetStateAction<string[]>>;
  currentCombat: CombatState | null;
  setCurrentCombat: React.Dispatch<React.SetStateAction<CombatState | null>>;
  setGameTime: React.Dispatch<React.SetStateAction<Date>>;
};

export function useDebugProviderLogic(deps: DebugActionsDeps) {
  const { debugTargets, setPlayer, setCurrentCombat, logMessage, travelTo, setGameTime } = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const execute = useMemo(() => createExecuteOnTargets(debugTargets, setPlayer, setCurrentCombat, logMessage), [debugTargets, setPlayer, setCurrentCombat, logMessage]);

  const actionDeps = useMemo(
    () => ({
      GAME_DATA,
      execute,
      logMessage,
      setPlayer,
      travelTo,
      setGameTime,
    }),
    [GAME_DATA, execute, logMessage, setPlayer, travelTo, setGameTime]
  );

  return useMemo(
    () => ({
      debug_addGold: (amount: number) => debug_addGold(actionDeps, amount),
      debug_setGold: (amount: number) => debug_setGold(actionDeps, amount),
      debug_fullHeal: () => debug_fullHeal(actionDeps),
      debug_fullHealAll: () => debug_fullHeal(actionDeps), // Re-using for now as fullHeal targets all with executeOnTargets
      debug_addPoints: (type: 'perk' | 'stat', amount: number) => debug_addPoints(actionDeps, type, amount),
      debug_setStatPoints: (amount: number) => debug_setStatPoints(actionDeps, amount),
      debug_setPerkPoints: (amount: number) => debug_setPerkPoints(actionDeps, amount),
      debug_addXP: (amount: number) => debug_addXP(actionDeps, amount),
      debug_setXP: (xp: number) => debug_setXP(actionDeps, xp),
      debug_addLevel: (levels: number) => debug_addLevel(actionDeps, levels),
      debug_setLevel: (level: number) => debug_setLevel(actionDeps, level),
      debug_addAttributes: (amount: number) => debug_addAttributes(actionDeps, amount),
      debug_setAttributes: (amount: number) => debug_setAttributes(actionDeps, amount),
      debug_duplicateItems: () => debug_duplicateItems(actionDeps),
      debug_teleportToTown: () => debug_teleportToTown(actionDeps as any),
      debug_maxProfessions: () => debug_maxProfessions(actionDeps),
      debug_setProfessionLevel: (level: number) => debug_setProfessionLevel(actionDeps, level),
      debug_restoreResources: () => debug_restoreResources(actionDeps),
      debug_clearDebuffs: () => debug_clearDebuffs(actionDeps),
      debug_learnAllRecipes: () => debug_learnAllRecipes(actionDeps),
      debug_learnAllEnchantmentRecipes: () => debug_learnAllEnchantmentRecipes(actionDeps),
      debug_learnAllSpells: () => debug_learnAllSpells(actionDeps),
      debug_learnAllSkills: () => debug_learnAllSkills(actionDeps),
      debug_unlockAll: () => debug_unlockAll(actionDeps as any),
      debug_lockAll: () => debug_lockAll(actionDeps as any),
      debug_giveRandomItems: (count: number, options?: { unidentifiedWithEnchantments?: boolean }) => debug_giveRandomItems(actionDeps, count, options),
      debug_giveAllRecipeItems: () => debug_giveAllRecipeItems(actionDeps),
      debug_giveDamagedItem: (count: number) => debug_giveDamagedItem(actionDeps, count),
      debug_giveAntiGravityChest: (count: number) => debug_giveAntiGravityChest(actionDeps, count),
      debug_test_all: () => debug_test_all(actionDeps as any),
      debug_clearInventory: () => debug_clearInventory(actionDeps),
      debug_applyDirectDamage: (targetId: string, limbId: string, damage: number, damageTypes: string[]) =>
        debug_applyDirectDamage(actionDeps, targetId, limbId, damage, damageTypes),
      debug_modifyVitals: (vital: 'hunger' | 'thirst' | 'alertness' | 'courage', amount: number) => debug_modifyVitals(actionDeps, vital, amount),
      debug_setVital: (vital: 'hunger' | 'thirst' | 'alertness' | 'courage', amount: number) => debug_setVital(actionDeps, vital, amount),
      debug_setLimbHp: (limbId: string, value: number, isPercent: boolean) => debug_setLimbHp(actionDeps, limbId, value, isPercent),
      debug_setGameTimeToStartOfDay: () => debug_setGameTimeToStartOfDay(actionDeps as any),
      debug_craftGod: () => debug_craftGod(actionDeps as any),
      debugTargets: deps.debugTargets,
      setDebugTargets: deps.setDebugTargets,
    }),
    [actionDeps, deps.debugTargets, deps.setDebugTargets]
  );
}