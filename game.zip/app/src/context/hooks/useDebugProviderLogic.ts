import {
  AbilityId,
  BaseStatBlock,
  CombatState,
  Combatant,
  GameData,
  ItemId,
  ItemInstance,
  Limb,
  Loggable,
  Mercenary,
  Player,
  ProfessionId,
  RecipeId,
  StatBlock,
  TotalPlayerStats,
  VitalId,
} from '../../types';
import { applyClearDebuffsLogic, applyFullHealLogic, applyRestoreResourcesLogic } from 'utils/playerUtils';
import { useCallback, useContext, useRef } from 'react';

import { GameDataContext } from 'context/GameDataContext';
import { LogType } from 'types';
import { calculateXpToNextLevel } from 'services/statService';
import { createItemInstances } from 'utils/itemUtils';
import { deepCloneWithInfinity } from 'utils/mathUtils';
import { processLimbDamage } from 'utils/combatUtils';

type DebugActionsDeps = {
  addGold: (amount: number) => void;
  setPlayer: (update: React.SetStateAction<Player | null>) => void;
  logMessage: (message: Loggable, type: LogType) => void;
  gainXp: (amount: number) => void;
  travelTo: (locationId: string) => void;
  addItem: (itemId: ItemId, quantity?: number, options?: any) => ItemInstance[];
  debugTargets: string[];
  setDebugTargets: React.Dispatch<React.SetStateAction<string[]>>;
  currentCombat: CombatState | null;
  setCurrentCombat: React.Dispatch<React.SetStateAction<CombatState | null>>;
  setGameTime: React.Dispatch<React.SetStateAction<Date>>;
};

export function useDebugProviderLogic(deps: DebugActionsDeps) {
  const depsRef = useRef(deps);
  depsRef.current = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const executeOnTargets = useCallback((modificationFn: (char: Player | Mercenary | Combatant) => Player | Mercenary | Combatant, message: string) => {
    const { debugTargets, logMessage, setPlayer, setCurrentCombat } = depsRef.current;
    if (debugTargets.length === 0) {
      logMessage('DEBUG: No targets selected.', 'error');
      return;
    }

    setPlayer((p) => {
      if (!p) return p;
      let tempPlayer = deepCloneWithInfinity(p);
      let modified = false;

      if (debugTargets.includes('player')) {
        tempPlayer = modificationFn(tempPlayer) as Player;
        modified = true;
      }

      tempPlayer.party = tempPlayer.party.map((merc) => {
        if (debugTargets.includes(merc.id)) {
          modified = true;
          return modificationFn(merc) as Mercenary;
        }
        return merc;
      });
      return modified ? tempPlayer : p;
    });

    setCurrentCombat((c) => {
      if (!c) return c;
      let tempCombat = deepCloneWithInfinity(c);
      let modified = false;
      Object.keys(tempCombat.combatants).forEach((id) => {
        if (debugTargets.includes(id) && tempCombat.combatants[id].team === 'enemy') {
          tempCombat.combatants[id] = modificationFn(tempCombat.combatants[id]) as Combatant;
          modified = true;
        }
      });
      return modified ? tempCombat : c;
    });

    logMessage(`DEBUG: ${message} on target(s).`, 'info');
  }, []);

  const debug_addGold = useCallback(
    (amount: number) => {
      executeOnTargets((char) => ('gold' in char ? { ...char, gold: (char.gold || 0) + amount } : char), `Added ${amount} gold`);
    },
    [executeOnTargets]
  );

  const debug_setGold = useCallback(
    (amount: number) => {
      executeOnTargets((char) => ('gold' in char ? { ...char, gold: amount } : char), `Set gold to ${amount}`);
    },
    [executeOnTargets]
  );

  const debug_fullHeal = useCallback(() => {
    executeOnTargets((char) => applyFullHealLogic(char, GAME_DATA), 'Full heal applied');
  }, [executeOnTargets, GAME_DATA]);

  const debug_fullHealAll = useCallback(() => {
    depsRef.current.setPlayer((p) => {
      if (!p) return p;
      let newPlayer = applyFullHealLogic(p, GAME_DATA) as Player;
      newPlayer.party = newPlayer.party.map((merc) => applyFullHealLogic(merc, GAME_DATA) as Mercenary);
      return newPlayer;
    });
    depsRef.current.logMessage(`DEBUG: Player and all party members fully healed.`, 'heal');
  }, [GAME_DATA]);

  const debug_restoreResources = useCallback(() => {
    executeOnTargets(applyRestoreResourcesLogic, 'Resources restored');
  }, [executeOnTargets]);

  const debug_clearDebuffs = useCallback(() => {
    executeOnTargets((char) => applyClearDebuffsLogic(char, GAME_DATA), 'Debuffs cleared');
  }, [executeOnTargets, GAME_DATA]);

  const debug_addPoints = useCallback(
    (type: 'perk' | 'stat', amount: number) => {
      executeOnTargets((char) => {
        if ('professions' in char) {
          if (type === 'perk') {
            return { ...char, perkPoints: char.perkPoints + amount };
          }
          return { ...char, attributePoints: char.attributePoints + amount };
        }
        return char;
      }, `Added ${amount} ${type} point(s)`);
    },
    [executeOnTargets]
  );

  const debug_setStatPoints = useCallback(
    (amount: number) => {
      executeOnTargets((char) => ('professions' in char ? { ...char, attributePoints: amount } : char), `Set stat points to ${amount}`);
    },
    [executeOnTargets]
  );

  const debug_setPerkPoints = useCallback(
    (amount: number) => {
      executeOnTargets((char) => ('professions' in char ? { ...char, perkPoints: amount } : char), `Set perk points to ${amount}`);
    },
    [executeOnTargets]
  );

  const debug_addXP = useCallback(
    (amount: number) => {
      const modificationFn = (char: Player | Mercenary | Combatant) => {
        if ('xp' in char && 'xpToNextLevel' in char) {
          let newChar = { ...char, xp: char.xp + amount };
          while (newChar.xp >= newChar.xpToNextLevel) {
            newChar.xp -= newChar.xpToNextLevel;
            newChar.level++;
            if ('professions' in newChar) (newChar as Player).perkPoints++;
            newChar.xpToNextLevel = calculateXpToNextLevel(newChar.level);
          }
          return newChar;
        }
        return char;
      };
      executeOnTargets(modificationFn, `Added ${amount} XP`);
    },
    [executeOnTargets]
  );

  const debug_setXP = useCallback(
    (xp: number) => {
      const applyFn = (char: Player | Mercenary | Combatant) => ('xp' in char ? { ...char, xp } : char);
      executeOnTargets(applyFn, `Set XP to ${xp}`);
    },
    [executeOnTargets]
  );

  const debug_addLevel = useCallback(
    (levels: number) => {
      const applyFn = (char: Player | Mercenary | Combatant) => {
        const newChar: any = { ...char, level: char.level + levels };
        newChar.xp = 0;
        newChar.xpToNextLevel = calculateXpToNextLevel(newChar.level);
        if ('professions' in newChar) {
          (newChar as Player).perkPoints += levels;
          (newChar as Player).attributePoints += levels * 5;
        }
        return newChar;
      };
      executeOnTargets(applyFn, `Added ${levels} level(s)`);
    },
    [executeOnTargets]
  );

  const debug_setLevel = useCallback(
    (level: number) => {
      const applyFn = (char: Player | Mercenary | Combatant) => {
        const newChar: any = { ...char, level: level };
        newChar.xp = 0;
        newChar.xpToNextLevel = calculateXpToNextLevel(newChar.level);
        return newChar;
      };
      executeOnTargets(applyFn, `Set level to ${level}`);
    },
    [executeOnTargets]
  );

  const debug_addAttributes = useCallback(
    (amount: number) => {
      const applyFn = (char: Player | Mercenary | Combatant): Player | Mercenary | Combatant => {
        if ('team' in char) {
          // Combatant
          const newBaseStats = { ...char.baseStats };
          const coreStats: (keyof BaseStatBlock)[] = ['strength', 'constitution', 'intelligence', 'dexterity'];
          coreStats.forEach((stat) => {
            newBaseStats[stat] += amount;
          });
          return { ...char, baseStats: newBaseStats };
        } else {
          // Player or Mercenary
          const newBaseStats = { ...char.baseStats };
          const coreStats: (keyof BaseStatBlock)[] = ['strength', 'constitution', 'intelligence', 'dexterity'];
          coreStats.forEach((stat) => {
            newBaseStats[stat] += amount;
          });
          return { ...char, baseStats: newBaseStats };
        }
      };
      executeOnTargets(applyFn, `Added ${amount} to all attributes`);
    },
    [executeOnTargets]
  );

  const debug_setAttributes = useCallback(
    (amount: number) => {
      const applyFn = (char: Player | Mercenary | Combatant): Player | Mercenary | Combatant => {
        if ('team' in char) {
          // Combatant
          const newBaseStats = { ...char.baseStats };
          const coreStats: (keyof BaseStatBlock)[] = ['strength', 'constitution', 'intelligence', 'dexterity'];
          coreStats.forEach((stat) => {
            newBaseStats[stat] = amount;
          });
          return { ...char, baseStats: newBaseStats };
        } else {
          // Player or Mercenary
          const newBaseStats = { ...char.baseStats };
          const coreStats: (keyof BaseStatBlock)[] = ['strength', 'constitution', 'intelligence', 'dexterity'];
          coreStats.forEach((stat) => {
            newBaseStats[stat] = amount;
          });
          return { ...char, baseStats: newBaseStats };
        }
      };
      executeOnTargets(applyFn, `Set all base attributes to ${amount}`);
    },
    [executeOnTargets]
  );

  const debug_modifyVitals = useCallback(
    (vital: VitalId, amount: number) => {
      const applyFn = (char: Player | Mercenary | Combatant) => {
        if ('vitals' in char) {
          const newVitals = { ...char.vitals };
          newVitals[vital].current = Math.max(0, Math.min(newVitals[vital].max, newVitals[vital].current + amount));
          return { ...char, vitals: newVitals };
        }
        return char;
      };
      executeOnTargets(applyFn, `Modified ${vital}`);
    },
    [executeOnTargets]
  );

  const debug_setVital = useCallback(
    (vital: VitalId, amount: number) => {
      const applyFn = (char: Player | Mercenary | Combatant) => {
        if ('vitals' in char) {
          const newVitals = { ...char.vitals };
          newVitals[vital].current = Math.max(0, Math.min(newVitals[vital].max, amount));
          return { ...char, vitals: newVitals };
        }
        return char;
      };
      executeOnTargets(applyFn, `Set ${vital} to ${amount}`);
    },
    [executeOnTargets]
  );

  const debug_setLimbHp = useCallback(
    (limbId: string, value: number, isPercent: boolean) => {
      const applyFn = (char: Player | Mercenary | Combatant) => {
        if (char.body[limbId]) {
          const newBody = { ...char.body };
          const newLimb = { ...newBody[limbId] };
          const hpValue = isPercent ? Math.round(newLimb.maxHp * (value / 100)) : value;
          newLimb.currentHp = Math.max(0, Math.min(newLimb.maxHp, hpValue));
          newLimb.state = newLimb.currentHp <= 0 ? 'Destroyed' : newLimb.currentHp < newLimb.maxHp ? 'Injured' : 'Healthy';
          newBody[limbId] = newLimb;
          return { ...char, body: newBody };
        }
        return char;
      };
      executeOnTargets(applyFn, `Set ${limbId} HP to ${value}${isPercent ? '%' : ''}`);
    },
    [executeOnTargets]
  );

  const debug_duplicateItems = useCallback(() => {
    const applyFn = (char: Player | Mercenary | Combatant) => {
      if (char.inventory.length === 0) return char;
      const newItems = char.inventory.map((item) => ({ ...item, unique_id: `item_${Date.now()}_${Math.random()}` }));
      return { ...char, inventory: [...char.inventory, ...newItems] };
    };
    executeOnTargets(applyFn, `Duplicated items`);
  }, [executeOnTargets]);

  const debug_teleportToTown = useCallback(() => {
    const { travelTo, logMessage } = depsRef.current;
    travelTo('zone0');
    logMessage('DEBUG: Teleported to Westhaven.', 'info');
  }, []);

  const debug_maxProfessions = useCallback(() => {
    const applyFn = (char: Player | Mercenary | Combatant) => {
      if ('professions' in char) {
        const newProfessions = { ...char.professions };
        Object.values(newProfessions).forEach((prof) => {
          prof.level = 100;
          prof.xp = 0;
        });
        return { ...char, professions: newProfessions };
      }
      return char;
    };
    executeOnTargets(applyFn, 'All professions set to 100.');
  }, [executeOnTargets]);

  const debug_setProfessionLevel = useCallback(
    (level: number) => {
      const applyFn = (char: Player | Mercenary | Combatant) => {
        if ('professions' in char) {
          const newProfessions = { ...char.professions };
          Object.keys(newProfessions).forEach((profId) => {
            const prof = newProfessions[profId as ProfessionId];
            prof.level = level;
            prof.xp = 0;
            prof.xpToNextLevel = calculateXpToNextLevel(level);
          });
          return { ...char, professions: newProfessions };
        }
        return char;
      };
      executeOnTargets(applyFn, `All professions set to ${level}.`);
    },
    [executeOnTargets]
  );

  const debug_learnAllRecipes = useCallback(() => {
    const applyFn = (char: Player | Mercenary | Combatant) => {
      if ('professions' in char) {
        const allRecipeIds = Object.keys(GAME_DATA.ALL_RECIPES) as RecipeId[];
        const newKnownRecipes = { ...char.knownRecipes };
        allRecipeIds.forEach((id) => (newKnownRecipes[id] = true));
        return { ...char, knownRecipes: newKnownRecipes };
      }
      return char;
    };
    executeOnTargets(applyFn, `Learned all ${Object.keys(GAME_DATA.ALL_RECIPES).length} recipes.`);
  }, [executeOnTargets, GAME_DATA.ALL_RECIPES]);

  const debug_learnAllSpells = useCallback(() => {
    const allSpellIds = Object.keys(GAME_DATA.SKILLS).filter((id) => GAME_DATA.SKILLS[id].abilityType === 'Spell');
    const applyFn = (char: Player | Mercenary | Combatant) => {
      const newSkills = { ...char.skills };
      allSpellIds.forEach((id) => (newSkills[id as AbilityId] = { rank: 1 }));
      return { ...char, skills: newSkills };
    };
    executeOnTargets(applyFn, `Learned all spells`);
  }, [executeOnTargets, GAME_DATA.SKILLS]);

  const debug_learnAllSkills = useCallback(() => {
    const allSkillIds = Object.keys(GAME_DATA.SKILLS).filter((id) => GAME_DATA.SKILLS[id].abilityType === 'Skill');
    const applyFn = (char: Player | Mercenary | Combatant) => {
      const newSkills = { ...char.skills };
      allSkillIds.forEach((id) => (newSkills[id as AbilityId] = { rank: 1 }));
      return { ...char, skills: newSkills };
    };
    executeOnTargets(applyFn, `Learned all skills`);
  }, [executeOnTargets, GAME_DATA.SKILLS]);

  const debug_unlockAll = useCallback(() => {
    depsRef.current.setPlayer((p) => {
      if (!p) return p;
      let newPlayer = { ...p };
      const allRecipeIds = Object.keys(GAME_DATA.ALL_RECIPES) as RecipeId[];
      allRecipeIds.forEach((id) => (newPlayer.knownRecipes[id] = true));
      const allSkillIds = Object.keys(GAME_DATA.SKILLS).filter((id) => GAME_DATA.SKILLS[id].abilityType === 'Skill' || GAME_DATA.SKILLS[id].abilityType === 'Spell');
      allSkillIds.forEach((id) => (newPlayer.skills[id as AbilityId] = { rank: 1 }));
      Object.values(newPlayer.professions).forEach((prof) => (prof.level = 100));
      depsRef.current.logMessage('DEBUG: All unlocks applied for player.', 'info');
      return newPlayer;
    });
  }, [GAME_DATA.ALL_RECIPES, GAME_DATA.SKILLS]);

  const debug_giveRandomItems = useCallback(
    (count: number, options?: { unidentifiedWithEnchantments?: boolean }) => {
      let allItemIds = Object.keys(GAME_DATA.ITEMS) as ItemId[];
      if (options?.unidentifiedWithEnchantments) {
        allItemIds = allItemIds.filter((id) => GAME_DATA.ITEMS[id].type.includes('equipment') && !GAME_DATA.ITEMS[id].isUnarmed && GAME_DATA.ITEMS[id].slot);
      }
      const applyFn = (char: Player | Mercenary | Combatant) => {
        const newItems: ItemInstance[] = [];
        for (let i = 0; i < count; i++) {
          const randomId = allItemIds[Math.floor(Math.random() * allItemIds.length)];
          const createOpts = options?.unidentifiedWithEnchantments ? { isUnidentified: true, addRandomEnchantments: true } : undefined;
          newItems.push(...createItemInstances(randomId, 1, createOpts, GAME_DATA));
        }
        return { ...char, inventory: [...char.inventory, ...newItems] };
      };
      executeOnTargets(applyFn, `Added ${count} random items` + (options?.unidentifiedWithEnchantments ? ' (unidentified enchanted)' : ''));
    },
    [executeOnTargets, GAME_DATA]
  );

  const debug_giveDamagedItem = useCallback(
    (count: number) => {
      const applyFn = (char: Player | Mercenary | Combatant) => {
        const newItems = createItemInstances('gen_smithing_mat_ingot_iron_shortsword', count, { isUnidentified: false, initialDurabilityPercent: 0.5 }, GAME_DATA);
        return { ...char, inventory: [...char.inventory, ...newItems] };
      };
      executeOnTargets(applyFn, `Gave ${count} damaged Iron Shortsword(s)`);
    },
    [executeOnTargets, GAME_DATA]
  );

  const debug_giveAntiGravityChest = useCallback(
    (count: number) => {
      const applyFn = (char: Player | Mercenary | Combatant) => {
        const chests = createItemInstances('gen_smithing_mat_equip_wood_chest', count, undefined, GAME_DATA);
        chests.forEach((chest) => (chest.enchantments['univ_anti_gravity'] = 1));
        return { ...char, inventory: [...char.inventory, ...chests] };
      };
      executeOnTargets(applyFn, `Gave ${count} Anti-Gravity chest(s)`);
    },
    [executeOnTargets, GAME_DATA]
  );

  const debug_clearInventory = useCallback(() => {
    executeOnTargets((char) => ({ ...char, inventory: [] }), `Inventory cleared`);
  }, [executeOnTargets]);

  const debug_applyDirectDamage = useCallback(
    (targetId: string, limbId: string, damage: number, damageTypes: string[]) => {
      const { setPlayer, logMessage } = depsRef.current;
      setPlayer((p) => {
        if (!p) return p;

        const applyDamage = <T extends Player | Mercenary>(char: T): T => {
          const limbToDamage = char.body[limbId as keyof typeof char.body];
          if (!limbToDamage || limbToDamage.state === 'Destroyed') {
            logMessage(`Limb is already destroyed.`, 'info');
            return char;
          }
          const { updatedLimb, logMessages } = processLimbDamage(limbToDamage, damage, damageTypes, char.name, GAME_DATA);
          logMessages.forEach((msg) => logMessage(msg, 'combat'));
          return { ...char, body: { ...char.body, [limbId]: updatedLimb as Limb } };
        };

        if (targetId === 'player') {
          return applyDamage(p);
        } else {
          return {
            ...p,
            party: p.party.map((m) => (m.id === targetId ? applyDamage(m) : m)),
          };
        }
      });
    },
    [GAME_DATA]
  );

  const debug_setGameTimeToStartOfDay = useCallback(() => {
    const { setGameTime, logMessage } = depsRef.current;
    setGameTime((currentTime) => {
      const newTime = new Date(currentTime);
      newTime.setHours(0, 0, 0, 0);
      logMessage(`DEBUG: Game time set to ${newTime.toLocaleTimeString()}.`, 'info');
      return newTime;
    });
  }, []);

  const debug_test_all = useCallback(() => {
    const { logMessage, setPlayer } = depsRef.current;
    logMessage('DEBUG: Applying all test options...', 'info');
    const modifyChar = (charToModify: Player | Mercenary): Player | Mercenary => {
      let char = deepCloneWithInfinity(charToModify);
      char.level = 100;
      char.xp = 0;
      char.xpToNextLevel = calculateXpToNextLevel(100);
      (Object.keys(char.baseStats) as (keyof BaseStatBlock)[]).forEach((stat) => (char.baseStats[stat] = (char.baseStats[stat] || 0) + 10000));
      const allSkillIds = Object.keys(GAME_DATA.SKILLS);
      allSkillIds.forEach((id) => (char.skills[id as AbilityId] = { rank: 1 }));
      return char;
    };
    setPlayer((p: Player | null) => {
      if (!p) return p;
      let newPlayer = modifyChar(p) as Player;
      newPlayer.party = newPlayer.party.map((merc) => modifyChar(merc) as Mercenary);
      newPlayer.gold = 999999;
      const allRecipeIds = Object.keys(GAME_DATA.ALL_RECIPES) as RecipeId[];
      allRecipeIds.forEach((id) => (newPlayer.knownRecipes[id] = true));
      let healedPlayer = applyFullHealLogic(newPlayer, GAME_DATA) as Player;
      healedPlayer.party = healedPlayer.party.map((merc) => applyFullHealLogic(merc, GAME_DATA) as Mercenary);
      return healedPlayer;
    });
  }, [GAME_DATA]);

  const debug_craftGod = useCallback(() => {
    const { setPlayer, logMessage } = depsRef.current;
    setPlayer((p: Player | null) => {
      if (!p) return p;
      let newPlayer = deepCloneWithInfinity(p);

      const newItems: ItemInstance[] = [];
      Object.keys(GAME_DATA.ITEMS).forEach((itemIdStr) => {
        const itemId = itemIdStr as ItemId;
        const itemData = GAME_DATA.ITEMS[itemId];
        if (!itemData || itemData.isUnarmed) return;
        if (itemId.startsWith('mat_reforge_ember_') || itemId.startsWith('mat_crystal_') || itemData.type.includes('tool') || itemData.type.includes('material')) {
          newItems.push(...createItemInstances(itemId, 100, undefined, GAME_DATA));
        }
      });
      newItems.push(...createItemInstances('gen_smithing_mat_ingot_iron_shortsword', 5, { initialDurabilityPercent: 0.25 }, GAME_DATA));
      newItems.push(...createItemInstances('gen_leatherworking_mat_leather_hardened_leather-jerkin', 5, { initialDurabilityPercent: 0.1 }, GAME_DATA));
      newPlayer.inventory.push(...newItems);

      Object.values(newPlayer.professions).forEach((prof) => {
        prof.level = 100;
        prof.xp = 0;
        prof.xpToNextLevel = calculateXpToNextLevel(100);
      });
      Object.keys(GAME_DATA.ALL_RECIPES).forEach((id) => (newPlayer.knownRecipes[id as RecipeId] = true));
      Object.keys(GAME_DATA.SKILLS).forEach((id) => (newPlayer.skills[id as AbilityId] = { rank: 1 }));

      logMessage('DEBUG: Craft God mode activated. All materials, tools, and recipes granted.', 'info');
      return newPlayer;
    });
  }, [GAME_DATA]);

  return {
    debug_addGold,
    debug_setGold,
    debug_fullHeal,
    debug_fullHealAll,
    debug_addPoints,
    debug_setStatPoints,
    debug_setPerkPoints,
    debug_addXP,
    debug_setXP,
    debug_addLevel,
    debug_setLevel,
    debug_addAttributes,
    debug_setAttributes,
    debug_duplicateItems,
    debug_teleportToTown,
    debug_maxProfessions,
    debug_setProfessionLevel,
    debug_restoreResources,
    debug_clearDebuffs,
    debug_learnAllRecipes,
    debug_learnAllSpells,
    debug_learnAllSkills,
    debug_unlockAll,
    debug_giveRandomItems,
    debug_giveDamagedItem,
    debug_giveAntiGravityChest,
    debug_test_all,
    debug_clearInventory,
    debug_applyDirectDamage,
    debugTargets: deps.debugTargets,
    setDebugTargets: deps.setDebugTargets,
    debug_modifyVitals,
    debug_setVital,
    debug_setLimbHp,
    debug_setGameTimeToStartOfDay,
    debug_craftGod,
  };
}
