import { AbilityId, BaseStatBlock, GameSideEffect, LogType, Loggable, Player, QuestId, StatusEffectId } from 'types';
import React, { useCallback, useMemo, useContext } from 'react';
import {
  acceptQuestImpl,
  addGold as addGoldAction,
  applyStatusEffectImpl,
  completeQuestImpl,
  gainXp as gainXpAction,
  learnAbilityImpl,
  learnPerkImpl,
  spendAttributePointImpl,
  toggleFavoriteAbilityImpl,
  updateQuestProgressImpl,
} from '../actions/characterActions';
import { GameDataContext } from 'context/GameDataContext';

interface CharacterProviderDeps {
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
}

export const useCharacterProviderLogic = (deps: CharacterProviderDeps) => {
  const { setPlayer, logMessage } = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const handleSideEffects = useCallback(
    (effects: GameSideEffect[]) => {
      effects.forEach((effect) => {
        switch (effect.type) {
          case 'LOG':
            logMessage(effect.message, effect.logType);
            break;
          case 'GENERATE_ZONE':
            console.warn('GENERATE_ZONE side effect should be handled by WorldProvider');
            break;
        }
      });
    },
    [logMessage]
  );

  const gainXp = useCallback(
    (amount: number) => {
      setPlayer((p) => {
        if (!p) return p;
        const { player: newPlayer, sideEffects } = gainXpAction(p, amount);
        handleSideEffects(sideEffects);
        return newPlayer;
      });
    },
    [setPlayer, handleSideEffects]
  );

  const addGold = useCallback(
    (amount: number) => {
      setPlayer((p) => {
        if (!p) return p;
        const { player: newPlayer, sideEffects } = addGoldAction(p, amount);
        handleSideEffects(sideEffects);
        return newPlayer;
      });
    },
    [setPlayer, handleSideEffects]
  );

  const updateQuestProgress = useCallback(
    (type: 'kill' | 'gather', target: string, count?: number) => updateQuestProgressImpl(type, target, count, setPlayer, logMessage, GAME_DATA),
    [setPlayer, logMessage, GAME_DATA]
  );

  const applyStatusEffect = useCallback(
    (
      targetId: 'player',
      effectId: StatusEffectId,
      options: {
        turns?: number;
        durationInMinutes?: number;
        limbId?: string;
        stage?: number;
        instanceId?: string;
        linkedToInstanceId?: string;
        isClosed?: boolean;
      }
    ) => applyStatusEffectImpl(targetId, effectId, options, setPlayer, logMessage, GAME_DATA),
    [setPlayer, logMessage, GAME_DATA]
  );

  const spendAttributePoint = useCallback((stat: keyof BaseStatBlock) => spendAttributePointImpl(stat, setPlayer, logMessage), [setPlayer, logMessage]);

  const learnPerk = useCallback((abilityId: AbilityId) => learnPerkImpl(abilityId, setPlayer, logMessage, GAME_DATA), [setPlayer, logMessage, GAME_DATA]);

  const learnAbility = useCallback((abilityId: AbilityId) => learnAbilityImpl(abilityId, setPlayer, logMessage, GAME_DATA), [setPlayer, logMessage, GAME_DATA]);

  const acceptQuest = useCallback((questId: QuestId) => acceptQuestImpl(questId, setPlayer, logMessage, GAME_DATA), [setPlayer, logMessage, GAME_DATA]);

  const completeQuest = useCallback((questId: QuestId) => completeQuestImpl(questId, setPlayer, logMessage, gainXp, GAME_DATA), [setPlayer, logMessage, gainXp, GAME_DATA]);

  const toggleFavoriteAbility = useCallback((abilityId: AbilityId) => toggleFavoriteAbilityImpl(abilityId, setPlayer), [setPlayer]);

  return useMemo(
    () => ({
      gainXp,
      addGold,
      updateQuestProgress,
      applyStatusEffect,
      acceptQuest,
      completeQuest,
      spendAttributePoint,
      learnPerk,
      learnAbility,
      toggleFavoriteAbility,
    }),
    [gainXp, addGold, updateQuestProgress, applyStatusEffect, acceptQuest, completeQuest, spendAttributePoint, learnPerk, learnAbility, toggleFavoriteAbility]
  );
};
