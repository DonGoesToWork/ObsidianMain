import { AbilityId, BaseStatBlock, GameSideEffect, LogType, Loggable, Player, QuestId, StatusEffectId } from 'types';
import React, { useCallback, useMemo, useContext, useRef } from 'react';
import {
  acceptQuest as acceptQuestAction,
  addGold as addGoldAction,
  applyStatusEffect as applyStatusEffectAction,
  completeQuest as completeQuestAction,
  gainXp as gainXpAction,
  learnAbility as learnAbilityAction,
  learnPerk as learnPerkAction,
  spendAttributePoint as spendAttributePointAction,
  toggleFavoriteAbility as toggleFavoriteAbilityAction,
  updateQuestProgress as updateQuestProgressAction,
} from '../actions/characterActions';
import { GameDataContext } from 'context/GameDataContext';

interface CharacterProviderDeps {
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  queueSideEffects: (effects: GameSideEffect[]) => void;
}

export const useCharacterProviderLogic = (deps: CharacterProviderDeps) => {
  const depsRef = useRef(deps);
  depsRef.current = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const gainXp = useCallback(
    (amount: number) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const { player: newPlayer, sideEffects } = gainXpAction(p, amount);
        if (sideEffects.length) depsRef.current.queueSideEffects(sideEffects);
        return newPlayer;
      });
    },
    [],
  );

  const addGold = useCallback(
    (amount: number) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const { player: newPlayer, sideEffects } = addGoldAction(p, amount);
        if (sideEffects.length) depsRef.current.queueSideEffects(sideEffects);
        return newPlayer;
      });
    },
    [],
  );

  const updateQuestProgress = useCallback(
    (type: 'kill' | 'gather', target: string, count: number = 1) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = updateQuestProgressAction(p, type, target, count, GAME_DATA);
        if (!result) return p;
        if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA],
  );

  const applyStatusEffect = useCallback(
    (
      targetId: 'player', // targetId is kept for API consistency, but the pure function only needs the player object
      effectId: StatusEffectId,
      options: {
        turns?: number;
        durationInMinutes?: number;
        limbId?: string;
        stage?: number;
        instanceId?: string;
        linkedToInstanceId?: string;
        isClosed?: boolean;
      },
    ) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = applyStatusEffectAction(p, effectId, options, GAME_DATA);
        if (!result) return p;
        if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA],
  );

  const spendAttributePoint = useCallback(
    (stat: keyof BaseStatBlock) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = spendAttributePointAction(p, stat);
        if (!result) return p;
        if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [],
  );

  const learnPerk = useCallback(
    (abilityId: AbilityId) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = learnPerkAction(p, abilityId, GAME_DATA);
        if (!result) return p;
        if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA],
  );

  const learnAbility = useCallback(
    (abilityId: AbilityId) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = learnAbilityAction(p, abilityId, GAME_DATA);
        if (!result) return p;
        if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA],
  );

  const acceptQuest = useCallback(
    (questId: QuestId) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = acceptQuestAction(p, questId, GAME_DATA);
        if (!result) return p;
        if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA],
  );

  const completeQuest = useCallback(
    (questId: QuestId) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = completeQuestAction(p, questId, GAME_DATA);
        if (!result) return p;
        if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA],
  );

  const toggleFavoriteAbility = useCallback(
    (abilityId: AbilityId) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const { player: newPlayer } = toggleFavoriteAbilityAction(p, abilityId);
        return newPlayer;
      });
    },
    [],
  );

  return useMemo(
    () => ({
      gainXp,
      addGold,
      updateQuestProgress,
      applyStatusEffect,
      acceptQuest,
      completeQuest,
      spendAttributePoint,
      learnPerk,
      learnAbility,
      toggleFavoriteAbility,
    }),
    [gainXp, addGold, updateQuestProgress, applyStatusEffect, acceptQuest, completeQuest, spendAttributePoint, learnPerk, learnAbility, toggleFavoriteAbility],
  );
};