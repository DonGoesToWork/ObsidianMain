import React, { useCallback, useMemo, useContext } from 'react';
import { GameLocation, ItemId, ItemInstance, ItemQuality, LogType, Loggable, Player, PlayerEquipmentSlot, ProfessionId, RecipeId, GameData } from 'types';
import { giftItemToMercenaryImpl } from '../actions/partyActions';
import { equipItemImpl, unequipItemImpl, damageItemDurabilityImpl } from '../actions/inventory/itemEquipActions';
import { addItemImpl, removeItemImpl, removeItemByInstanceImpl } from '../actions/inventory/itemLifecycle';
import {
  dropItemsImpl,
  moveItemToBankImpl,
  moveItemsToBankImpl,
  moveItemFromBankImpl,
  moveItemsFromBankImpl,
  moveItemToContainerImpl,
  moveItemFromContainerImpl,
} from '../actions/inventory/itemMovement';
import { consumeItemImpl } from '../actions/inventory/itemUsage';
import { GameDataContext } from 'context/GameDataContext';

interface InventoryProviderDeps {
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
  setCurrentLocation: React.Dispatch<React.SetStateAction<GameLocation | null>>;
  gameTime: Date;
  playerActionTaken: () => void;
  gainProfessionXp: (id: ProfessionId, amount: number) => void;
  updateQuestProgress: (type: 'kill' | 'gather', target: string, count?: number) => void;
  learnRecipe: (recipeId: RecipeId) => void;
  // from CharacterContext
  learnAbility: (abilityId: any) => void;
  applyStatusEffect: (targetId: 'player', effectId: any, options: any) => void;
}

export const useInventoryProviderLogic = (deps: InventoryProviderDeps) => {
  const { setPlayer, logMessage, setCurrentLocation, gameTime, playerActionTaken, gainProfessionXp, updateQuestProgress, learnRecipe, learnAbility, applyStatusEffect } = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const addItem = useCallback(
    (
      itemId: ItemId,
      quantity = 1,
      options?: {
        isUnidentified?: boolean;
        quality?: ItemQuality;
        initialDurabilityPercent?: number;
      }
    ) => addItemImpl(itemId, quantity, options, setPlayer, logMessage, gainProfessionXp, updateQuestProgress, GAME_DATA),
    [setPlayer, logMessage, gainProfessionXp, updateQuestProgress, GAME_DATA]
  );
  const removeItem = useCallback((itemId: ItemId, quantity = 1) => removeItemImpl(itemId, quantity, setPlayer), [setPlayer]);
  const removeItemByInstance = useCallback((itemToRemove: ItemInstance) => removeItemByInstanceImpl(itemToRemove, setPlayer), [setPlayer]);
  const dropItems = useCallback(
    (itemUniqueIds: string[]) => dropItemsImpl(itemUniqueIds, setPlayer, setCurrentLocation, logMessage, gameTime),
    [setPlayer, setCurrentLocation, logMessage, gameTime]
  );
  const dropItem = useCallback((itemUniqueId: string) => dropItems([itemUniqueId]), [dropItems]);
  const equipItem = useCallback(
    (itemUniqueId: string) => equipItemImpl(itemUniqueId, setPlayer, logMessage, playerActionTaken, GAME_DATA),
    [setPlayer, logMessage, playerActionTaken, GAME_DATA]
  );
  const unequipItem = useCallback((slot: PlayerEquipmentSlot) => unequipItemImpl(slot, setPlayer, playerActionTaken), [setPlayer, playerActionTaken]);
  const consumeItem = useCallback(
    (itemUniqueId: string, targetId?: string) =>
      consumeItemImpl(itemUniqueId, setPlayer, logMessage, applyStatusEffect, playerActionTaken, learnRecipe, learnAbility, targetId, GAME_DATA),
    [setPlayer, logMessage, applyStatusEffect, playerActionTaken, learnRecipe, learnAbility, GAME_DATA]
  );

  const moveItemToBank = useCallback((itemUniqueId: string) => moveItemToBankImpl(itemUniqueId, setPlayer), [setPlayer]);
  const moveItemsToBank = useCallback((itemUniqueIds: string[]) => moveItemsToBankImpl(itemUniqueIds, setPlayer), [setPlayer]);
  const moveItemFromBank = useCallback((itemUniqueId: string) => moveItemFromBankImpl(itemUniqueId, setPlayer), [setPlayer]);
  const moveItemsFromBank = useCallback((itemUniqueIds: string[]) => moveItemsFromBankImpl(itemUniqueIds, setPlayer), [setPlayer]);

  const moveItemToContainer = useCallback(
    (itemUniqueId: string, containerUniqueId: string) => moveItemToContainerImpl(itemUniqueId, containerUniqueId, setPlayer, logMessage, GAME_DATA),
    [setPlayer, logMessage, GAME_DATA]
  );
  const moveItemFromContainer = useCallback(
    (itemUniqueIdInContainer: string, containerUniqueId: string) => moveItemFromContainerImpl(itemUniqueIdInContainer, containerUniqueId, setPlayer, logMessage, GAME_DATA),
    [setPlayer, logMessage, GAME_DATA]
  );
  const damageItemDurability = useCallback(
    (slot: PlayerEquipmentSlot, amount: number) => damageItemDurabilityImpl(slot, amount, setPlayer, logMessage, GAME_DATA),
    [setPlayer, logMessage, GAME_DATA]
  );
  const giftItemToMercenary = useCallback(
    (id: string, item: ItemInstance) => giftItemToMercenaryImpl(id, item, setPlayer, logMessage, GAME_DATA),
    [logMessage, setPlayer, GAME_DATA]
  );

  return useMemo(
    () => ({
      addItem,
      removeItem,
      removeItemByInstance,
      equipItem,
      unequipItem,
      dropItem,
      dropItems,
      consumeItem,
      damageItemDurability,
      moveItemToBank,
      moveItemsToBank,
      moveItemFromBank,
      moveItemsFromBank,
      moveItemToContainer,
      moveItemFromContainer,
      giftItemToMercenary,
    }),
    [
      addItem,
      removeItem,
      removeItemByInstance,
      equipItem,
      unequipItem,
      dropItem,
      dropItems,
      consumeItem,
      damageItemDurability,
      moveItemToBank,
      moveItemsToBank,
      moveItemFromBank,
      moveItemsFromBank,
      moveItemToContainer,
      moveItemFromContainer,
      giftItemToMercenary,
    ]
  );
};