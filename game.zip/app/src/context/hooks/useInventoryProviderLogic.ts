import { GameDataContext } from 'context/GameDataContext';
import React, { useCallback, useContext, useMemo, useRef } from 'react';
import { GameLocation, GameSideEffect, ItemId, ItemInstance, Player, PlayerEquipmentSlot, SortDirection, SortKey } from 'types';
import { calculateItemLevel, calculateItemValue, getItemName, getItemWeight } from 'utils/itemUtils';
import { damageItemDurability as damageItemDurabilityAction, equipItem as equipItemAction, unequipItem as unequipItemAction } from '../actions/inventory/itemEquipActions';
import { addItem as addItemAction, removeItem as removeItemAction, removeItemByInstance as removeItemByInstanceAction } from '../actions/inventory/itemLifecycle';
import {
  dropItemsAction,
  moveItemFromBankAction,
  moveItemFromContainerAction,
  moveItemsFromBankAction,
  moveItemsToBankAction,
  moveItemToBankAction,
  moveItemToContainerAction,
  reorderInventoryAction,
} from '../actions/inventory/itemMovement';
import { consumeItem as consumeItemAction, itemOnItemAction } from '../actions/inventory/itemUsage';
import { giftItemToMercenary as giftItemToMercenaryAction } from '../actions/partyActions';

export interface InventoryProviderDeps {
  player: Player | null;
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  setCurrentLocation: React.Dispatch<React.SetStateAction<GameLocation | null>>;
  gameTime: Date;
  playerActionTaken: () => void;
  queueSideEffects: (effects: GameSideEffect[]) => void;
  withActionLock: <T>(action: () => T, options?: { silent?: boolean }) => T | undefined;
  addItemsToGround: (items: ItemInstance[]) => void;
}

export const useInventoryProviderLogic = (deps: InventoryProviderDeps) => {
  const depsRef = useRef(deps);
  depsRef.current = deps;
  const GAME_DATA = useContext(GameDataContext)!;
  const { withActionLock } = deps;

  const addItem = useCallback(
    (
      itemId: ItemId,
      quantity = 1,
      options?: {
        isUnidentified?: boolean;
        plus_value?: number;
        initialDurabilityPercent?: number;
        addRandomEnchantments?: boolean;
      }
    ): ItemInstance[] => {
      let newItems: ItemInstance[] = [];
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = addItemAction(p, itemId, quantity, options || {}, GAME_DATA);
          if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
          newItems = result.newItems;
          return result.player;
        });
      });
      return newItems;
    },
    [GAME_DATA, withActionLock]
  );
  const removeItem = useCallback(
    (itemId: ItemId, quantity = 1) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = removeItemAction(p, itemId, quantity);
          return result ? result.player : p;
        });
      });
    },
    [withActionLock]
  );
  const removeItemByInstance = useCallback(
    (itemToRemove: ItemInstance) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = removeItemByInstanceAction(p, itemToRemove);
          return result ? result.player : p;
        });
      });
    },
    [withActionLock]
  );
  const dropItems = useCallback(
    (itemsToDrop: { unique_id: string; quantity?: number }[]) => {
      withActionLock(() => {
        const { setPlayer, addItemsToGround, queueSideEffects } = depsRef.current;
        setPlayer((p) => {
          if (!p) return p;
          const result = dropItemsAction(p, itemsToDrop, GAME_DATA);
          const { player: newPlayer, droppedItems, sideEffects } = result;
          if (sideEffects.length) queueSideEffects(sideEffects);
          if (droppedItems.length > 0) {
            addItemsToGround(droppedItems);
          }
          return newPlayer;
        });
      });
    },
    [withActionLock, GAME_DATA]
  );

  const reorderInventory = useCallback(
    (draggedItemUniqueId: string, targetIndex: number) => {
      withActionLock(
        () => {
          depsRef.current.setPlayer((p) => {
            if (!p) return p;
            const result = reorderInventoryAction(p, draggedItemUniqueId, targetIndex);
            if (!result) return p;
            if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
            return result.player;
          });
        },
        { silent: true }
      );
    },
    [withActionLock]
  );

  const sortInventory = useCallback(
    (sortConfig: { key: SortKey; direction: SortDirection } | null) => {
      withActionLock(
        () => {
          depsRef.current.setPlayer((p) => {
            if (!p) return p;
            if (!sortConfig) {
              // If sort is disabled, we don't need to do anything to the data.
              // The visual layer will simply render the array as is.
              console.log('[GameProvider] Sorting disabled. Inventory order preserved.');
              return p;
            }
            console.log(`[GameProvider] Sorting inventory by ${sortConfig.key} ${sortConfig.direction}`);

            const denseInventory = p.inventory.filter((item): item is ItemInstance => !!item);

            denseInventory.sort((a, b) => {
              const dataA = GAME_DATA.ITEMS[a.id];
              const dataB = GAME_DATA.ITEMS[b.id];
              let compareA: string | number;
              let compareB: string | number;

              switch (sortConfig.key) {
                case 'value':
                  compareA = calculateItemValue(a, GAME_DATA);
                  compareB = calculateItemValue(b, GAME_DATA);
                  break;
                case 'type':
                  compareA = dataA?.type[0] || '';
                  compareB = dataB?.type[0] || '';
                  break;
                case 'weight':
                  compareA = getItemWeight(a, GAME_DATA);
                  compareB = getItemWeight(b, GAME_DATA);
                  break;
                case 'itemLevel':
                  compareA = calculateItemLevel(a, GAME_DATA);
                  compareB = calculateItemLevel(b, GAME_DATA);
                  break;
                case 'name':
                default:
                  compareA = getItemName(a, GAME_DATA);
                  compareB = getItemName(b, GAME_DATA);
                  break;
              }

              let result = 0;
              if (typeof compareA === 'string' && typeof compareB === 'string') {
                result = compareA.localeCompare(compareB);
              } else {
                if (compareA < compareB) result = -1;
                if (compareA > compareB) result = 1;
              }

              return sortConfig.direction === 'asc' ? result : -result;
            });

            return { ...p, inventory: denseInventory };
          });
        },
        { silent: true }
      );
    },
    [withActionLock, GAME_DATA]
  );

  const equipItem = useCallback(
    (itemUniqueId: string, slot?: PlayerEquipmentSlot) => {
      withActionLock(() => {
        const { playerActionTaken, queueSideEffects } = depsRef.current;
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = equipItemAction(p, itemUniqueId, GAME_DATA, slot);
          if (!result) return p;
          if (result.sideEffects.length) queueSideEffects(result.sideEffects);
          if (result.player !== p) playerActionTaken();
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const unequipItem = useCallback(
    (slot: PlayerEquipmentSlot) => {
      withActionLock(() => {
        const { playerActionTaken, queueSideEffects } = depsRef.current;
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = unequipItemAction(p, slot, GAME_DATA);
          if (!result) return p;
          if (result.sideEffects.length) queueSideEffects(result.sideEffects);
          if (result.player !== p) playerActionTaken();
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const consumeItem = useCallback(
    (itemUniqueId: string, targetId?: string) => {
      withActionLock(() => {
        const { playerActionTaken, queueSideEffects } = depsRef.current;
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = consumeItemAction(p, itemUniqueId, targetId, GAME_DATA);
          if (!result) return p;
          if (result.sideEffects.length) queueSideEffects(result.sideEffects);
          if (result.player !== p) playerActionTaken();
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const doUseItemOnItem = useCallback(
    (heldItemUniqueId: string, targetItemUniqueId: string) => {
      withActionLock(() => {
        const { queueSideEffects } = depsRef.current;
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = itemOnItemAction(p, heldItemUniqueId, targetItemUniqueId, GAME_DATA);
          if (!result) return p;
          if (result.sideEffects.length) queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );

  const moveItemToBank = useCallback(
    (itemUniqueId: string, quantity?: number) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          return moveItemToBankAction(p, itemUniqueId, quantity, GAME_DATA) || p;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const moveItemsToBank = useCallback(
    (itemsToMove: { unique_id: string; quantity: number }[]) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          return moveItemsToBankAction(p, itemsToMove, GAME_DATA) || p;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const moveItemFromBank = useCallback(
    (itemUniqueId: string, quantity?: number) => {
      withActionLock(() => {
        const { queueSideEffects, setPlayer } = depsRef.current;
        setPlayer((p) => {
          if (!p) return p;
          const result = moveItemFromBankAction(p, itemUniqueId, quantity, GAME_DATA);
          if (!result) return p;
          queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const moveItemsFromBank = useCallback(
    (itemsToMove: { unique_id: string; quantity: number }[]) => {
      withActionLock(() => {
        const { queueSideEffects, setPlayer } = depsRef.current;
        setPlayer((p) => {
          if (!p) return p;
          const result = moveItemsFromBankAction(p, itemsToMove, GAME_DATA);
          if (!result) return p;
          queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );

  const moveItemToContainer = useCallback(
    (itemUniqueId: string, quantity: number, containerUniqueId: string) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = moveItemToContainerAction(p, itemUniqueId, quantity, containerUniqueId, GAME_DATA);
          if (result.newContainerId) {
            depsRef.current.queueSideEffects([
              {
                type: 'UPDATE_MODAL_REFERENCE',
                modalId: 'item-container-modal',
                newUniqueId: result.newContainerId,
              },
            ]);
          }
          if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const moveItemFromContainer = useCallback(
    (itemUniqueIdInContainer: string, quantity: number, containerUniqueId: string) => {
      withActionLock(() => {
        const { queueSideEffects, setPlayer } = depsRef.current;
        setPlayer((p) => {
          if (!p) return p;
          const result = moveItemFromContainerAction(p, itemUniqueIdInContainer, quantity, containerUniqueId, GAME_DATA);
          if (result.sideEffects.length) queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const damageItemDurability = useCallback(
    (slot: PlayerEquipmentSlot, amount: number) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = damageItemDurabilityAction(p, slot, amount, GAME_DATA);
          if (!result) return p;
          if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const giftItemToMercenary = useCallback(
    (id: string, item: ItemInstance) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = giftItemToMercenaryAction(p, id, item, GAME_DATA);
          if (!result) return p;
          if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );

  return useMemo(
    () => ({
      addItem,
      removeItem,
      removeItemByInstance,
      equipItem,
      unequipItem,
      dropItems,
      reorderInventory,
      sortInventory,
      consumeItem,
      damageItemDurability,
      moveItemToBank,
      moveItemsToBank,
      moveItemFromBank,
      moveItemsFromBank,
      moveItemToContainer,
      moveItemFromContainer,
      giftItemToMercenary,
      doUseItemOnItem,
    }),
    [
      addItem,
      removeItem,
      removeItemByInstance,
      equipItem,
      unequipItem,
      dropItems,
      reorderInventory,
      sortInventory,
      consumeItem,
      damageItemDurability,
      moveItemToBank,
      moveItemsToBank,
      moveItemFromBank,
      moveItemsFromBank,
      moveItemToContainer,
      moveItemFromContainer,
      giftItemToMercenary,
      doUseItemOnItem,
    ]
  );
};
