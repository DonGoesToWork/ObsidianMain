import React, { useCallback, useMemo, useContext, useRef } from 'react';
import { GameLocation, ItemId, ItemInstance, LogType, Loggable, Player, PlayerEquipmentSlot, ProfessionId, RecipeId, GameData, GameSideEffect } from 'types';
import { giftItemToMercenary as giftItemToMercenaryAction } from '../actions/partyActions';
import { equipItem as equipItemAction, unequipItem as unequipItemAction, damageItemDurability as damageItemDurabilityAction } from '../actions/inventory/itemEquipActions';
import { addItem as addItemAction, removeItem as removeItemAction, removeItemByInstance as removeItemByInstanceAction } from '../actions/inventory/itemLifecycle';
import {
  dropItemsImpl as dropItemsAction,
  moveItemToBankAction,
  moveItemsToBankAction as moveItemsToBankImpl,
  moveItemFromBankAction,
  moveItemsFromBankAction as moveItemsFromBankImpl,
  moveItemToContainerAction,
  moveItemFromContainerAction,
} from '../actions/inventory/itemMovement';
import { consumeItem as consumeItemAction } from '../actions/inventory/itemUsage';
import { GameDataContext } from 'context/GameDataContext';

export interface InventoryProviderDeps {
  player: Player | null;
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  setCurrentLocation: React.Dispatch<React.SetStateAction<GameLocation | null>>;
  gameTime: Date;
  playerActionTaken: () => void;
  queueSideEffects: (effects: GameSideEffect[]) => void;
}

export const useInventoryProviderLogic = (deps: InventoryProviderDeps) => {
  const depsRef = useRef(deps);
  depsRef.current = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const addItem = useCallback(
    (
      itemId: ItemId,
      quantity = 1,
      options?: {
        isUnidentified?: boolean;
        plus_value?: number;
        initialDurabilityPercent?: number;
      },
    ): ItemInstance[] => {
      let newItems: ItemInstance[] = [];
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = addItemAction(p, itemId, quantity, options, GAME_DATA);
        if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
        newItems = result.newItems;
        return result.player;
      });
      return newItems;
    },
    [GAME_DATA],
  );
  const removeItem = useCallback(
    (itemId: ItemId, quantity = 1) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = removeItemAction(p, itemId, quantity);
        return result ? result.player : p;
      });
    },
    [],
  );
  const removeItemByInstance = useCallback(
    (itemToRemove: ItemInstance) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = removeItemByInstanceAction(p, itemToRemove);
        return result ? result.player : p;
      });
    },
    [],
  );
  const dropItems = useCallback(
    (itemUniqueIds: string[]) => {
      const { setPlayer, setCurrentLocation, gameTime, queueSideEffects } = depsRef.current;
      setPlayer((p) => {
        if (!p) return p;
        const result = dropItemsAction(p, itemUniqueIds);
        const { player: newPlayer, itemsToDrop, sideEffects } = result;
        if (sideEffects.length) queueSideEffects(sideEffects);
        if (itemsToDrop.length > 0) {
          setCurrentLocation((l) => {
            if (!l) return l;
            return { ...l, groundLoot: [...(l.groundLoot || []), ...itemsToDrop], groundLootTimestamp: gameTime.getTime() };
          });
        }
        return newPlayer;
      });
    },
    [],
  );

  const dropItem = useCallback((itemUniqueId: string) => dropItems([itemUniqueId]), [dropItems]);
  const equipItem = useCallback(
    (itemUniqueId: string, slot?: PlayerEquipmentSlot) => {
      const { playerActionTaken, queueSideEffects } = depsRef.current;
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = equipItemAction(p, itemUniqueId, GAME_DATA, slot);
        if (!result) return p;
        if (result.sideEffects.length) queueSideEffects(result.sideEffects);
        if (result.player !== p) playerActionTaken();
        return result.player;
      });
    },
    [GAME_DATA],
  );
  const unequipItem = useCallback(
    (slot: PlayerEquipmentSlot) => {
      const { playerActionTaken } = depsRef.current;
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = unequipItemAction(p, slot);
        if (!result) return p;
        if (result.player !== p) playerActionTaken();
        return result.player;
      });
    },
    [],
  );
  const consumeItem = useCallback(
    (itemUniqueId: string, targetId?: string) => {
      const { playerActionTaken, queueSideEffects } = depsRef.current;
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = consumeItemAction(p, itemUniqueId, targetId, GAME_DATA);
        if (!result) return p;
        if (result.sideEffects.length) queueSideEffects(result.sideEffects);
        if (result.player !== p) playerActionTaken();
        return result.player;
      });
    },
    [GAME_DATA],
  );

  const moveItemToBank = useCallback(
    (itemUniqueId: string) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        return moveItemToBankAction(p, itemUniqueId) || p;
      });
    },
    [],
  );
  const moveItemsToBank = useCallback(
    (itemUniqueIds: string[]) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        return moveItemsToBankImpl(p, itemUniqueIds) || p;
      });
    },
    [],
  );
  const moveItemFromBank = useCallback(
    (itemUniqueId: string) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        return moveItemFromBankAction(p, itemUniqueId) || p;
      });
    },
    [],
  );
  const moveItemsFromBank = useCallback(
    (itemUniqueIds: string[]) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        return moveItemsFromBankImpl(p, itemUniqueIds) || p;
      });
    },
    [],
  );

  const moveItemToContainer = useCallback(
    (itemUniqueId: string, containerUniqueId: string) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = moveItemToContainerAction(p, itemUniqueId, containerUniqueId, GAME_DATA);
        if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA],
  );
  const moveItemFromContainer = useCallback(
    (itemUniqueIdInContainer: string, containerUniqueId: string) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = moveItemFromContainerAction(p, itemUniqueIdInContainer, containerUniqueId, GAME_DATA);
        if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA],
  );
  const damageItemDurability = useCallback(
    (slot: PlayerEquipmentSlot, amount: number) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = damageItemDurabilityAction(p, slot, amount, GAME_DATA);
        if (!result) return p;
        if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA],
  );
  const giftItemToMercenary = useCallback(
    (id: string, item: ItemInstance) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = giftItemToMercenaryAction(p, id, item, GAME_DATA);
        if (!result) return p;
        if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA],
  );

  return useMemo(
    () => ({
      addItem,
      removeItem,
      removeItemByInstance,
      equipItem,
      unequipItem,
      dropItem,
      dropItems,
      consumeItem,
      damageItemDurability,
      moveItemToBank,
      moveItemsToBank,
      moveItemFromBank,
      moveItemsFromBank,
      moveItemToContainer,
      moveItemFromContainer,
      giftItemToMercenary,
    }),
    [
      addItem,
      removeItem,
      removeItemByInstance,
      equipItem,
      unequipItem,
      dropItem,
      dropItems,
      consumeItem,
      damageItemDurability,
      moveItemToBank,
      moveItemsToBank,
      moveItemFromBank,
      moveItemsFromBank,
      moveItemToContainer,
      moveItemFromContainer,
      giftItemToMercenary,
    ],
  );
};