import { GameDataContext } from 'context/GameDataContext';
import React, { useCallback, useContext, useMemo, useRef } from 'react';
import { GameLocation, GameSideEffect, ItemId, ItemInstance, Player, PlayerEquipmentSlot } from 'types';
import { damageItemDurability as damageItemDurabilityAction, equipItem as equipItemAction, unequipItem as unequipItemAction } from '../actions/inventory/itemEquipActions';
import { addItem as addItemAction, removeItem as removeItemAction, removeItemByInstance as removeItemByInstanceAction } from '../actions/inventory/itemLifecycle';
import {
  dropItemsAction,
  moveItemFromBankAction,
  moveItemFromContainerAction,
  moveItemsFromBankAction,
  moveItemsToBankAction,
  moveItemToBankAction,
  moveItemToContainerAction,
} from '../actions/inventory/itemMovement';
import { consumeItem as consumeItemAction } from '../actions/inventory/itemUsage';
import { giftItemToMercenary as giftItemToMercenaryAction } from '../actions/partyActions';

export interface InventoryProviderDeps {
  player: Player | null;
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  setCurrentLocation: React.Dispatch<React.SetStateAction<GameLocation | null>>;
  gameTime: Date;
  playerActionTaken: () => void;
  queueSideEffects: (effects: GameSideEffect[]) => void;
  withActionLock: <T>(action: () => T) => T | undefined;
  addItemsToGround: (items: ItemInstance[]) => void;
}

export const useInventoryProviderLogic = (deps: InventoryProviderDeps) => {
  const depsRef = useRef(deps);
  depsRef.current = deps;
  const GAME_DATA = useContext(GameDataContext)!;
  const { withActionLock } = deps;

  const addItem = useCallback(
    (
      itemId: ItemId,
      quantity = 1,
      options?: {
        isUnidentified?: boolean;
        plus_value?: number;
        initialDurabilityPercent?: number;
        addRandomEnchantments?: boolean;
      }
    ): ItemInstance[] => {
      let newItems: ItemInstance[] = [];
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = addItemAction(p, itemId, quantity, options || {}, GAME_DATA);
          if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
          newItems = result.newItems;
          return result.player;
        });
      });
      return newItems;
    },
    [GAME_DATA, withActionLock]
  );
  const removeItem = useCallback(
    (itemId: ItemId, quantity = 1) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = removeItemAction(p, itemId, quantity);
          return result ? result.player : p;
        });
      });
    },
    [withActionLock]
  );
  const removeItemByInstance = useCallback(
    (itemToRemove: ItemInstance) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = removeItemByInstanceAction(p, itemToRemove);
          return result ? result.player : p;
        });
      });
    },
    [withActionLock]
  );
  const dropItems = useCallback(
    (itemsToDrop: { unique_id: string; quantity?: number }[]) => {
      withActionLock(() => {
        const { setPlayer, addItemsToGround, queueSideEffects } = depsRef.current;
        setPlayer((p) => {
          if (!p) return p;
          const result = dropItemsAction(p, itemsToDrop);
          const { player: newPlayer, droppedItems, sideEffects } = result;
          if (sideEffects.length) queueSideEffects(sideEffects);
          if (droppedItems.length > 0) {
            addItemsToGround(droppedItems);
          }
          return newPlayer;
        });
      });
    },
    [withActionLock]
  );

  const equipItem = useCallback(
    (itemUniqueId: string, slot?: PlayerEquipmentSlot) => {
      withActionLock(() => {
        const { playerActionTaken, queueSideEffects } = depsRef.current;
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = equipItemAction(p, itemUniqueId, GAME_DATA, slot);
          if (!result) return p;
          if (result.sideEffects.length) queueSideEffects(result.sideEffects);
          if (result.player !== p) playerActionTaken();
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const unequipItem = useCallback(
    (slot: PlayerEquipmentSlot) => {
      withActionLock(() => {
        const { playerActionTaken, queueSideEffects } = depsRef.current;
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = unequipItemAction(p, slot, GAME_DATA);
          if (!result) return p;
          if (result.sideEffects.length) queueSideEffects(result.sideEffects);
          if (result.player !== p) playerActionTaken();
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const consumeItem = useCallback(
    (itemUniqueId: string, targetId?: string) => {
      withActionLock(() => {
        const { playerActionTaken, queueSideEffects } = depsRef.current;
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = consumeItemAction(p, itemUniqueId, targetId, GAME_DATA);
          if (!result) return p;
          if (result.sideEffects.length) queueSideEffects(result.sideEffects);
          if (result.player !== p) playerActionTaken();
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );

  const moveItemToBank = useCallback(
    (itemUniqueId: string, quantity?: number) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          return moveItemToBankAction(p, itemUniqueId, quantity, GAME_DATA) || p;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const moveItemsToBank = useCallback(
    (itemsToMove: { unique_id: string; quantity: number }[]) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          return moveItemsToBankAction(p, itemsToMove, GAME_DATA) || p;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const moveItemFromBank = useCallback(
    (itemUniqueId: string, quantity?: number) => {
      withActionLock(() => {
        const { queueSideEffects, setPlayer } = depsRef.current;
        setPlayer((p) => {
          if (!p) return p;
          const result = moveItemFromBankAction(p, itemUniqueId, quantity, GAME_DATA);
          if (!result) return p;
          queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const moveItemsFromBank = useCallback(
    (itemsToMove: { unique_id: string; quantity: number }[]) => {
      withActionLock(() => {
        const { queueSideEffects, setPlayer } = depsRef.current;
        setPlayer((p) => {
          if (!p) return p;
          const result = moveItemsFromBankAction(p, itemsToMove, GAME_DATA);
          if (!result) return p;
          queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );

  const moveItemToContainer = useCallback(
    (itemUniqueId: string, quantity: number, containerUniqueId: string) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = moveItemToContainerAction(p, itemUniqueId, quantity, containerUniqueId, GAME_DATA);
          if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const moveItemFromContainer = useCallback(
    (itemUniqueIdInContainer: string, quantity: number, containerUniqueId: string) => {
      withActionLock(() => {
        const { queueSideEffects, setPlayer } = depsRef.current;
        setPlayer((p) => {
          if (!p) return p;
          const result = moveItemFromContainerAction(p, itemUniqueIdInContainer, quantity, containerUniqueId, GAME_DATA);
          if (result.sideEffects.length) queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const damageItemDurability = useCallback(
    (slot: PlayerEquipmentSlot, amount: number) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = damageItemDurabilityAction(p, slot, amount, GAME_DATA);
          if (!result) return p;
          if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );
  const giftItemToMercenary = useCallback(
    (id: string, item: ItemInstance) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = giftItemToMercenaryAction(p, id, item, GAME_DATA);
          if (!result) return p;
          if (result.sideEffects.length) depsRef.current.queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );

  return useMemo(
    () => ({
      addItem,
      removeItem,
      removeItemByInstance,
      equipItem,
      unequipItem,
      dropItems,
      consumeItem,
      damageItemDurability,
      moveItemToBank,
      moveItemsToBank,
      moveItemFromBank,
      moveItemsFromBank,
      moveItemToContainer,
      moveItemFromContainer,
      giftItemToMercenary,
    }),
    [
      addItem,
      removeItem,
      removeItemByInstance,
      equipItem,
      unequipItem,
      dropItems,
      consumeItem,
      damageItemDurability,
      moveItemToBank,
      moveItemsToBank,
      moveItemFromBank,
      moveItemsFromBank,
      moveItemToContainer,
      moveItemFromContainer,
      giftItemToMercenary,
    ]
  );
};