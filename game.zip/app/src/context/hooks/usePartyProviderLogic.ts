import { GameDataContext } from 'context/GameDataContext';
import React, { useCallback, useContext, useMemo, useRef } from 'react';
import { GameSideEffect, ItemInstance, LogType, Loggable, Mercenary, Player } from 'types';
import { healBrokenLimb as healBrokenLimbAction, reviveDownedAlly as reviveDownedAllyAction, reviveFallenAlly as reviveFallenAllyAction } from '../actions/clinicActions';
import {
  fireMercenary as fireMercenaryAction,
  gainMercenaryXp as gainMercenaryXpAction,
  hireMercenary as hireMercenaryAction,
  refreshMercenaryGuild as refreshMercenaryGuildAction,
} from '../actions/partyActions';

interface PartyProviderDeps {
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
  gameTime: Date;
  withActionLock: <T>(action: () => T) => T | undefined;
}

export const usePartyProviderLogic = (deps: PartyProviderDeps) => {
  const depsRef = useRef(deps);
  depsRef.current = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const handleSideEffects = useCallback((effects: GameSideEffect[]) => {
    effects.forEach((effect) => {
      switch (effect.type) {
        case 'LOG':
          depsRef.current.logMessage(effect.message, effect.logType);
          break;
      }
    });
  }, []);

  const hireMercenary = useCallback(
    (mercenary: Mercenary) => {
      deps.withActionLock(() =>
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = hireMercenaryAction(p, mercenary);
          handleSideEffects(result.sideEffects);
          return result.player;
        })
      );
    },
    [handleSideEffects, deps.withActionLock]
  );

  const fireMercenary = useCallback(
    (id: string) => {
      deps.withActionLock(() =>
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = fireMercenaryAction(p, id);
          if (!result) return p;
          handleSideEffects(result.sideEffects);
          return result.player;
        })
      );
    },
    [handleSideEffects, deps.withActionLock]
  );

  const refreshMercenaryGuild = useCallback(() => {
    depsRef.current.setPlayer((p) => {
      if (!p) return p;
      const { gameTime } = depsRef.current;
      const { player: newPlayer } = refreshMercenaryGuildAction(p, gameTime, GAME_DATA);
      return newPlayer;
    });
  }, [GAME_DATA]);

  const gainMercenaryXp = useCallback(
    (mercId: string, amount: number) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = gainMercenaryXpAction(p, mercId, amount, GAME_DATA);
        if (!result) return p;
        handleSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA, handleSideEffects]
  );

  const healBrokenLimb = useCallback(
    (targetId: string, limbId: string) => {
      deps.withActionLock(() =>
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = healBrokenLimbAction(p, targetId, limbId);
          if (!result) return p;
          handleSideEffects(result.sideEffects);
          return result.player;
        })
      );
    },
    [handleSideEffects, deps.withActionLock]
  );

  const reviveDownedAlly = useCallback(
    (mercenaryId: string) => {
      deps.withActionLock(() =>
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = reviveDownedAllyAction(p, mercenaryId, GAME_DATA);
          if (!result) return p;
          handleSideEffects(result.sideEffects);
          return result.player;
        })
      );
    },
    [GAME_DATA, handleSideEffects, deps.withActionLock]
  );

  const reviveFallenAlly = useCallback(
    (corpseItem: ItemInstance) => {
      deps.withActionLock(() =>
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = reviveFallenAllyAction(p, corpseItem, GAME_DATA);
          if (!result) return p;
          handleSideEffects(result.sideEffects);
          return result.player;
        })
      );
    },
    [GAME_DATA, handleSideEffects, deps.withActionLock]
  );

  return useMemo(
    () => ({
      hireMercenary,
      fireMercenary,
      refreshMercenaryGuild,
      gainMercenaryXp,
      healBrokenLimb,
      reviveDownedAlly,
      reviveFallenAlly,
    }),
    [hireMercenary, fireMercenary, refreshMercenaryGuild, gainMercenaryXp, healBrokenLimb, reviveDownedAlly, reviveFallenAlly]
  );
};