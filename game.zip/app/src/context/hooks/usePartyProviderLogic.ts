import React, { useCallback, useMemo, useContext } from 'react';
import { ItemInstance, LogType, Loggable, Mercenary, Player, GameData } from 'types';
import { fireMercenaryImpl, gainMercenaryXpImpl, hireMercenaryImpl, refreshMercenaryGuildImpl } from '../actions/partyActions';
import { healBrokenLimbImpl, reviveDownedAllyImpl, reviveFallenAllyImpl } from '../actions/clinicActions';
import { GameDataContext } from 'context/GameDataContext';

interface PartyProviderDeps {
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
  gameTime: Date;
}

export const usePartyProviderLogic = (deps: PartyProviderDeps) => {
  const { setPlayer, logMessage, gameTime } = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const hireMercenary = useCallback((mercenary: Mercenary) => hireMercenaryImpl(mercenary, setPlayer, logMessage), [logMessage, setPlayer]);
  const fireMercenary = useCallback((id: string) => fireMercenaryImpl(id, setPlayer, logMessage), [logMessage, setPlayer]);
  const refreshMercenaryGuild = useCallback(() => refreshMercenaryGuildImpl(setPlayer, gameTime, GAME_DATA), [setPlayer, gameTime, GAME_DATA]);
  const gainMercenaryXp = useCallback(
    (mercId: string, amount: number) => gainMercenaryXpImpl(mercId, amount, setPlayer, logMessage, GAME_DATA),
    [logMessage, setPlayer, GAME_DATA]
  );
  const healBrokenLimb = useCallback((targetId: string, limbId: string) => healBrokenLimbImpl(targetId, limbId, setPlayer, logMessage), [setPlayer, logMessage]);
  const reviveDownedAlly = useCallback((mercenaryId: string) => reviveDownedAllyImpl(mercenaryId, setPlayer, logMessage), [setPlayer, logMessage]);
  const reviveFallenAlly = useCallback((corpseItem: ItemInstance) => reviveFallenAllyImpl(corpseItem, setPlayer, logMessage, GAME_DATA), [setPlayer, logMessage, GAME_DATA]);

  return useMemo(
    () => ({
      hireMercenary,
      fireMercenary,
      refreshMercenaryGuild,
      gainMercenaryXp,
      healBrokenLimb,
      reviveDownedAlly,
      reviveFallenAlly,
    }),
    [hireMercenary, fireMercenary, refreshMercenaryGuild, gainMercenaryXp, healBrokenLimb, reviveDownedAlly, reviveFallenAlly]
  );
};
