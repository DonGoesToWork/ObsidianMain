import { GameDataContext } from 'context/GameDataContext';
import React, { useCallback, useContext, useMemo, useRef } from 'react';
import { GameLocation, GameSideEffect, ItemInstance, LocationState, LogType, Loggable, Mercenary, Player } from 'types';
import { healBrokenLimb as healBrokenLimbAction, reviveDownedAlly as reviveDownedAllyAction, reviveFallenAlly as reviveFallenAllyAction } from '../actions/clinicActions';
import {
  fireMercenary as fireMercenaryAction,
  gainMercenaryXp as gainMercenaryXpAction,
  hireMercenaryAction,
  refreshMercenaryGuildAction,
} from '../actions/partyActions';

interface PartyProviderDeps {
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
  gameTime: Date;
  withActionLock: <T>(action: () => T) => T | undefined;
  currentLocation: GameLocation | null;
  worldLocationsState: Record<string, LocationState>;
  setWorldLocationsState: React.Dispatch<React.SetStateAction<Record<string, LocationState>>>;
}

export const usePartyProviderLogic = (deps: PartyProviderDeps) => {
  const depsRef = useRef(deps);
  depsRef.current = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const handleSideEffects = useCallback((effects: GameSideEffect[]) => {
    effects.forEach((effect) => {
      switch (effect.type) {
        case 'LOG':
          depsRef.current.logMessage(effect.message, effect.logType);
          break;
      }
    });
  }, []);

  const hireMercenary = useCallback(
    (mercenary: Mercenary) => {
      depsRef.current.withActionLock(() => {
        const { currentLocation, worldLocationsState, setWorldLocationsState, setPlayer } = depsRef.current;
        if (!currentLocation) return;
        const locationId = currentLocation.id;
        const currentGuildData = worldLocationsState[locationId]?.mercenaryGuild;

        setPlayer((p) => {
          if (!p) return p;
          const result = hireMercenaryAction(p, mercenary, currentGuildData);
          handleSideEffects(result.sideEffects);
          setWorldLocationsState((wls) => ({
            ...wls,
            [locationId]: {
              ...(wls[locationId] || { id: locationId }),
              mercenaryGuild: result.updatedGuildData,
            },
          }));
          return result.updatedPlayer;
        });
      });
    },
    [handleSideEffects]
  );

  const fireMercenary = useCallback(
    (id: string) => {
      depsRef.current.withActionLock(() =>
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = fireMercenaryAction(p, id);
          if (!result) return p;
          handleSideEffects(result.sideEffects);
          return result.player;
        })
      );
    },
    [handleSideEffects]
  );

  const refreshMercenaryGuild = useCallback(
    (locationLevel: number) => {
      console.log('TEST 1: refreshMercenaryGuild called');
      const { gameTime, currentLocation, worldLocationsState, setWorldLocationsState } = depsRef.current;
      if (!currentLocation) {
        console.warn('refreshMercenaryGuild aborted: no current location');
        return;
      }

      const locationId = currentLocation.id;
      const currentGuildData = worldLocationsState[locationId]?.mercenaryGuild;
      console.log('TEST 2: Current guild data for', locationId, currentGuildData);

      const newGuildData = refreshMercenaryGuildAction(currentGuildData, locationLevel, gameTime, GAME_DATA);
      console.log('TEST 3: New guild data generated:', newGuildData);

      if (newGuildData !== currentGuildData) {
        console.log('TEST 4: Guild data has changed, setting new state.');
        setWorldLocationsState((wls) => {
          console.log('TEST 5: Inside setWorldLocationsState. Previous state:', wls);
          const existingLocationState = wls[locationId] || { id: locationId };
          const newState = {
            ...wls,
            [locationId]: {
              ...existingLocationState,
              mercenaryGuild: newGuildData,
            },
          };
          console.log('TEST 6: New world location state:', newState);
          return newState;
        });
      } else {
        console.log('TEST 4: Guild data has not changed, not setting state.');
      }
    },
    [GAME_DATA]
  );

  const gainMercenaryXp = useCallback(
    (mercId: string, amount: number) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = gainMercenaryXpAction(p, mercId, amount, GAME_DATA);
        if (!result) return p;
        handleSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA, handleSideEffects]
  );

  const healBrokenLimb = useCallback(
    (targetId: string, limbId: string) => {
      depsRef.current.withActionLock(() =>
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = healBrokenLimbAction(p, targetId, limbId);
          if (!result) return p;
          handleSideEffects(result.sideEffects);
          return result.player;
        })
      );
    },
    [handleSideEffects]
  );

  const reviveDownedAlly = useCallback(
    (mercenaryId: string) => {
      depsRef.current.withActionLock(() =>
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = reviveDownedAllyAction(p, mercenaryId, GAME_DATA);
          if (!result) return p;
          handleSideEffects(result.sideEffects);
          return result.player;
        })
      );
    },
    [GAME_DATA, handleSideEffects]
  );

  const reviveFallenAlly = useCallback(
    (corpseItem: ItemInstance) => {
      depsRef.current.withActionLock(() =>
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = reviveFallenAllyAction(p, corpseItem, GAME_DATA);
          if (!result) return p;
          handleSideEffects(result.sideEffects);
          return result.player;
        })
      );
    },
    [GAME_DATA, handleSideEffects]
  );

  return useMemo(
    () => ({
      hireMercenary,
      fireMercenary,
      refreshMercenaryGuild,
      gainMercenaryXp,
      healBrokenLimb,
      reviveDownedAlly,
      reviveFallenAlly,
    }),
    [hireMercenary, fireMercenary, refreshMercenaryGuild, gainMercenaryXp, healBrokenLimb, reviveDownedAlly, reviveFallenAlly]
  );
};