import React, { useCallback, useMemo, useContext, useRef } from 'react';
import { ItemInstance, LogType, Loggable, Mercenary, Player, GameData, GameSideEffect } from 'types';
import {
  fireMercenary as fireMercenaryAction,
  gainMercenaryXp as gainMercenaryXpAction,
  hireMercenary as hireMercenaryAction,
  refreshMercenaryGuild as refreshMercenaryGuildAction,
} from '../actions/partyActions';
import { healBrokenLimb as healBrokenLimbAction, reviveDownedAlly as reviveDownedAllyAction, reviveFallenAlly as reviveFallenAllyAction } from '../actions/clinicActions';
import { GameDataContext } from 'context/GameDataContext';

interface PartyProviderDeps {
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
  gameTime: Date;
}

export const usePartyProviderLogic = (deps: PartyProviderDeps) => {
  const depsRef = useRef(deps);
  depsRef.current = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const handleSideEffects = useCallback((effects: GameSideEffect[]) => {
    effects.forEach((effect) => {
      switch (effect.type) {
        case 'LOG':
          depsRef.current.logMessage(effect.message, effect.logType);
          break;
      }
    });
  }, []);

  const hireMercenary = useCallback(
    (mercenary: Mercenary) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = hireMercenaryAction(p, mercenary);
        handleSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [handleSideEffects],
  );

  const fireMercenary = useCallback(
    (id: string) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = fireMercenaryAction(p, id);
        if (!result) return p;
        handleSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [handleSideEffects],
  );

  const refreshMercenaryGuild = useCallback(() => {
    depsRef.current.setPlayer((p) => {
      if (!p) return p;
      const { gameTime } = depsRef.current;
      const { player: newPlayer } = refreshMercenaryGuildAction(p, gameTime, GAME_DATA);
      return newPlayer;
    });
  }, [GAME_DATA]);

  const gainMercenaryXp = useCallback(
    (mercId: string, amount: number) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = gainMercenaryXpAction(p, mercId, amount, GAME_DATA);
        if (!result) return p;
        handleSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA, handleSideEffects],
  );

  const healBrokenLimb = useCallback(
    (targetId: string, limbId: string) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = healBrokenLimbAction(p, targetId, limbId);
        if (!result) return p;
        handleSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [handleSideEffects],
  );

  const reviveDownedAlly = useCallback(
    (mercenaryId: string) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = reviveDownedAllyAction(p, mercenaryId, GAME_DATA);
        if (!result) return p;
        handleSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA, handleSideEffects],
  );

  const reviveFallenAlly = useCallback(
    (corpseItem: ItemInstance) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = reviveFallenAllyAction(p, corpseItem, GAME_DATA);
        if (!result) return p;
        handleSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA, handleSideEffects],
  );

  return useMemo(
    () => ({
      hireMercenary,
      fireMercenary,
      refreshMercenaryGuild,
      gainMercenaryXp,
      healBrokenLimb,
      reviveDownedAlly,
      reviveFallenAlly,
    }),
    [hireMercenary, fireMercenary, refreshMercenaryGuild, gainMercenaryXp, healBrokenLimb, reviveDownedAlly, reviveFallenAlly],
  );
};