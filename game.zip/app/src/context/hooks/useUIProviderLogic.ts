import { ModalConfig, ModalState, ModalUiSettings } from 'types';
import { useCallback, useMemo } from 'react';

interface UIProviderDeps {
  modalStack: ModalState[];
  setModalStack: React.Dispatch<React.SetStateAction<ModalState[]>>;
  modalUiSettings: Record<string, ModalUiSettings>;
  setModalUiSettings: React.Dispatch<React.SetStateAction<Record<string, ModalUiSettings>>>;
  floatingTexts: { id: number; text: string }[];
  setFloatingTexts: React.Dispatch<React.SetStateAction<{ id: number; text: string }[]>>;
}

export const useUIProviderLogic = (deps: UIProviderDeps) => {
  const { modalStack, setModalStack, modalUiSettings, setModalUiSettings, floatingTexts, setFloatingTexts } = deps;

  const setActiveModal = useCallback(
    (modalId: string | null, options: any = {}, config: ModalConfig = {}) => {
      if (modalId === null) {
        setModalStack((s) => s.slice(0, -1));
        return;
      }

      const newModal = { id: modalId, options, config };

      if (config.history) {
        setModalStack((s) => [...s, newModal]);
      } else {
        setModalStack([newModal]);
      }
    },
    [setModalStack]
  );

  return useMemo(
    () => ({
      modalStack,
      setActiveModal,
      modalUiSettings,
      setModalUiSettings,
      floatingTexts,
      setFloatingTexts,
    }),
    [modalStack, setActiveModal, modalUiSettings, setModalUiSettings, floatingTexts, setFloatingTexts]
  );
};
