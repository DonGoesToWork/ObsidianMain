import { LogEntry, Loggable, LogType } from "types";
import { useCallback, useRef, useMemo } from "react";

interface LogProviderDeps {
  logs: LogEntry[];
  setLogs: React.Dispatch<React.SetStateAction<LogEntry[]>>;
  setFloatingTexts: React.Dispatch<React.SetStateAction<{ id: number; text: string }[]>>;
}

export const useLogProviderLogic = (deps: LogProviderDeps) => {
  const { logs, setLogs, setFloatingTexts } = deps;
  const logIdCounter = useRef(0);
  const floatingTextIdCounter = useRef(0);

  const addLogEntry = useCallback(
    (entry: Omit<LogEntry, "id">) => {
      setLogs((prevLogs) => [...prevLogs.slice(-100), { ...entry, id: logIdCounter.current++ }]);
      const cleanMessage = entry.message.replace(/<[^>]*>?/gm, "");
      if (entry.type !== "time") console.debug(`[${entry.type.toUpperCase()}] ${cleanMessage}`);
    },
    [setLogs],
  );

  const logMessage = useCallback(
    (message: Loggable, type: LogType = "info") => {
      const messageObj = typeof message === "string" ? { detailedText: message } : message;
      const floatingText = messageObj.floatingText || messageObj.detailedText;

      addLogEntry({ message: messageObj.detailedText, type });

      if (type !== "time") {
        const cleanFloatingText = floatingText.replace(/<[^>]*>?/gm, "");
        setFloatingTexts((prev) => [...prev.slice(-4), { id: floatingTextIdCounter.current++, text: cleanFloatingText }]);
      }
    },
    [addLogEntry, setFloatingTexts],
  );

  return useMemo(
    () => ({
      logs,
      addLogEntry,
      logMessage,
    }),
    [logs, addLogEntry, logMessage],
  );
};