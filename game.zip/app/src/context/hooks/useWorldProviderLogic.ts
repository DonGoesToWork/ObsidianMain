import {
  AbilityId,
  AppraiseOptions,
  CharacterContextType,
  ClassId,
  CombatState,
  DungeonState,
  GameData,
  GameLocation,
  GameState,
  GameSideEffect,
  ItemId,
  ItemInstance,
  LogEntry,
  LogType,
  Loggable,
  ModalUiSettings,
  Player,
  ProfessionId,
  RaceId,
  RestOptions,
  StatusEffectId,
  VitalId,
  Zone,
} from 'types';
import { applySkillOutOfCombatImpl, castAbilityOutOfCombatImpl } from '../actions/abilityActions';
import { continueFromDeath as continueFromDeathAction, createPlayerImpl } from '../actions/lifecycleActions';
import { cureAilment as cureAilmentAction, performInnAction as performInnActionAction } from '../actions/townActions';
import { generateNewZoneImpl, travelToImpl } from '../actions/worldActions';
import { useCallback, useContext, useEffect, useMemo, useRef } from 'react';

import { ContextMenuOption } from 'context/ContextMenuContext';
import { GameDataContext } from 'context/GameDataContext';
import { passTimeImpl } from '../actions/timeActions';
import { performWildsActionImpl } from '../actions/wildsActions';

const SAVE_KEY = 'aura_rpg_save_v19';
const jsonReplacer = (key: string, value: any) => (value === Infinity ? 'Infinity' : value);

interface WorldProviderDeps {
  player: Player | null;
  setPlayer: (update: any) => void;
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  gameTime: Date;
  setGameTime: React.Dispatch<React.SetStateAction<Date>>;
  currentLocation: GameLocation | null;
  setCurrentLocation: React.Dispatch<React.SetStateAction<GameLocation | null>>;
  generatedZones: Record<string, Zone>;
  setGeneratedZones: React.Dispatch<React.SetStateAction<Record<string, Zone>>>;
  currentDungeon: DungeonState | null;
  setCurrentDungeon: React.Dispatch<React.SetStateAction<DungeonState | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
  setActiveModal: (modal: string | null, options?: any, config?: any) => void;
  startCombat: (monsterPack: any[], options?: any) => void;
  addItemsToGround: (items: ItemInstance[]) => void;
  setLogs: React.Dispatch<React.SetStateAction<LogEntry[]>>;
  gainProfessionXp: (professionId: ProfessionId, amount: number) => void;
  showContextMenu: (x: number, y: number, options: ContextMenuOption[]) => void;
  applyStatusEffect: (targetId: 'player', effectId: StatusEffectId, options: any) => void;
  updateQuestProgress: CharacterContextType['updateQuestProgress'];
  currentCombat: CombatState | null;
  logs: LogEntry[];
  modalUiSettings: Record<string, ModalUiSettings>;
  queueSideEffects: (effects: GameSideEffect[]) => void;
}

export const useWorldProviderLogic = (deps: WorldProviderDeps) => {
  const depsRef = useRef(deps);
  depsRef.current = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const getZoneData = useCallback(
    (zoneId: string): Zone | undefined => {
      const { generatedZones } = depsRef.current;
      return generatedZones[zoneId] || GAME_DATA.ZONES[zoneId as keyof typeof GAME_DATA.ZONES];
    },
    [GAME_DATA.ZONES],
  );
  const changeGameState = useCallback((newState: GameState, options: any = {}) => {
    const { setGameState, setActiveModal } = depsRef.current;
    setGameState((prevState) => {
      console.debug(`Changing game state from ${prevState} to ${newState}`, options);
      if (newState !== 'combat' && !options.keepModalOpen) setActiveModal(null);
      return newState;
    });
  }, []);

  const passTime = useCallback(
    (minutes: number, options?: RestOptions | AppraiseOptions) => {
      const currentDeps = depsRef.current;
      passTimeImpl(
        {
          gameTime: currentDeps.gameTime,
          setGameTime: currentDeps.setGameTime,
          logMessage: currentDeps.logMessage,
          currentLocation: currentDeps.currentLocation,
          startCombat: currentDeps.startCombat,
          setPlayer: currentDeps.setPlayer,
          player: currentDeps.player,
          setActiveModal: currentDeps.setActiveModal,
          GAME_DATA,
        },
        { minutes, options },
      );
    },
    [GAME_DATA],
  );

  const performInnAction = useCallback(
    (action: 'eat' | 'rest', cost: number) => {
      depsRef.current.setPlayer((p: Player | null) => {
        if (!p) return p;
        const result = performInnActionAction(p, action, cost);
        if (!result) return p;
        depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [],
  );

  const cureAilment = useCallback(
    (vitalId: VitalId, cost: number) => {
      depsRef.current.setPlayer((p: Player | null) => {
        if (!p) return p;
        const result = cureAilmentAction(p, vitalId, cost);
        if (!result) return p;
        depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [],
  );

  const travelTo = useCallback(
    (locationId: string) => {
      const currentDeps = depsRef.current;
      travelToImpl(
        {
          player: currentDeps.player,
          getZoneData,
          logMessage: currentDeps.logMessage,
          currentLocation: currentDeps.currentLocation,
          passTime,
          setCurrentLocation: currentDeps.setCurrentLocation,
          changeGameState,
          setPlayer: currentDeps.setPlayer,
          gameTime: currentDeps.gameTime,
          setGeneratedZones: currentDeps.setGeneratedZones,
          setActiveModal: currentDeps.setActiveModal,
        },
        { locationId },
      );
    },
    [getZoneData, passTime, changeGameState],
  );
  const generateNewZone = useCallback((level: number) => {
    const { setGeneratedZones, logMessage } = depsRef.current;
    generateNewZoneImpl({ setGeneratedZones, logMessage }, { level });
  }, []);
  const performWildsAction = useCallback(
    (actionType: ProfessionId) => {
      const currentDeps = depsRef.current;
      performWildsActionImpl(
        {
          passTime,
          player: currentDeps.player,
          currentLocation: currentDeps.currentLocation,
          logMessage: currentDeps.logMessage,
          gainProfessionXp: currentDeps.gainProfessionXp,
          addItemsToGround: currentDeps.addItemsToGround,
          GAME_DATA,
        },
        { actionType },
      );
    },
    [passTime, GAME_DATA],
  );
  const continueFromDeath = useCallback(() => {
    const { setActiveModal, setPlayer } = depsRef.current;
    setPlayer((p: Player | null) => {
      if (!p) return p;
      const result = continueFromDeathAction(p, GAME_DATA);
      depsRef.current.queueSideEffects(result.sideEffects);
      return result.player;
    });
    travelTo('zone0');
    setActiveModal(null);
  }, [travelTo, GAME_DATA]);

  const createPlayer = useCallback(
    (name: string, race: RaceId, pClass: ClassId) => {
      const { setPlayer, logMessage, setCurrentLocation, setGeneratedZones } = depsRef.current;
      createPlayerImpl(name, race, pClass, setPlayer, changeGameState, logMessage, setCurrentLocation, setGeneratedZones, GAME_DATA);
    },
    [changeGameState, GAME_DATA],
  );
  const resetGame = useCallback(() => {
    const { setPlayer, setCurrentDungeon, setLogs, setActiveModal, setCurrentLocation, setGameState, logMessage } = depsRef.current;
    if (window.confirm('Are you sure you want to reset your game? ALL progress will be lost.')) {
      localStorage.removeItem('aura_rpg_save_v19');
      setPlayer(null);
      setCurrentDungeon(null);
      setLogs([]);
      setActiveModal(null);
      setCurrentLocation(null);
      setGameState('character-creation');
      logMessage('Game Reset.', 'info');
    }
  }, []);

  const grabItemsFromGround = useCallback(
    (itemIndices: number[]) => {
      const { currentLocation, player, logMessage, setCurrentLocation, setPlayer, updateQuestProgress } = depsRef.current;
      if (!currentLocation || !currentLocation.groundLoot || !player) return;

      const validIndices = itemIndices.filter((i) => i >= 0 && i < currentLocation.groundLoot!.length);
      if (validIndices.length === 0) return;

      const itemsToGrab = validIndices.map((i) => currentLocation.groundLoot![i]);
      const totalWeight = itemsToGrab.reduce((sum, item) => sum + (GAME_DATA.ITEMS[item.id]?.weight || 0), 0);

      if (player.currentWeight + totalWeight > player.maxCarryWeight) {
        logMessage('You would be over-encumbered.', 'error');
        return;
      }

      const indicesSet = new Set(validIndices);
      const newLoot = currentLocation.groundLoot.filter((_, index) => !indicesSet.has(index));

      setCurrentLocation((l) => ({ ...l!, groundLoot: newLoot }));

      setPlayer((p: Player | null) => {
        if (!p) return p;
        const newPlayerState = { ...p, inventory: [...p.inventory, ...itemsToGrab] };
        return newPlayerState;
      });

      const itemsByType = itemsToGrab.reduce((acc, item) => {
        acc[item.id] = (acc[item.id] || 0) + 1;
        return acc;
      }, {} as Record<ItemId, number>);

      Object.entries(itemsByType).forEach(([itemId, count]) => {
        if (GAME_DATA.ITEMS[itemId as ItemId].type.includes('material')) {
          updateQuestProgress('gather', itemId, count);
        }
      });

      logMessage(`You pick up ${itemsToGrab.length} item(s).`, 'loot');
    },
    [GAME_DATA],
  );

  const identifyGroundItem = useCallback((groundLootIndex: number) => {
    depsRef.current.logMessage('Identify on ground not fully supported in this refactor yet.', 'info');
  }, []);

  const applySkillOutOfCombat = useCallback(
    (abilityId: AbilityId, targetId: string, limbId: string | null) => {
      const { setPlayer, logMessage, applyStatusEffect } = depsRef.current;
      applySkillOutOfCombatImpl(abilityId, targetId, limbId, setPlayer, logMessage, passTime, applyStatusEffect, GAME_DATA);
    },
    [passTime, GAME_DATA],
  );

  const castAbilityOutOfCombat = useCallback(
    (abilityId: AbilityId, e: React.MouseEvent) => {
      const { player, showContextMenu, logMessage } = depsRef.current;
      if (!player) return;
      castAbilityOutOfCombatImpl(abilityId, e, player, showContextMenu, applySkillOutOfCombat, logMessage, GAME_DATA);
    },
    [applySkillOutOfCombat, GAME_DATA],
  );

  const saveGame = useCallback(() => {
    const { player, currentCombat, currentDungeon, gameTime, currentLocation, gameState, generatedZones, logs, modalUiSettings, logMessage } = depsRef.current;
    if (player && !currentCombat) {
      try {
        const gameStateToSave = {
          player,
          currentDungeon,
          gameTime: gameTime.toISOString(),
          currentLocation,
          gameState,
          generatedZones,
          logs,
          modalUiSettings,
        };
        localStorage.setItem(SAVE_KEY, JSON.stringify(gameStateToSave, jsonReplacer));
        logMessage('Game saved successfully', 'info');
      } catch (e) {
        console.error('Failed to save game:', e);
        logMessage('Failed to save game. Storage might be full.', 'error');
      }
    }
  }, []);

  useEffect(() => {
    const interval = setInterval(saveGame, 30000);
    return () => clearInterval(interval);
  }, [saveGame]);

  return useMemo(
    () => ({
      ...deps,
      changeGameState,
      resetGame,
      createPlayer,
      continueFromDeath,
      performInnAction,
      cureAilment,
      passTime,
      performWildsAction,
      travelTo,
      getZoneData,
      grabItemsFromGround,
      identifyGroundItem,
      debug_teleportToTown: () => travelTo('zone0'),
      castAbilityOutOfCombat,
      saveGame,
      generateNewZone,
    }),
    [
      deps,
      changeGameState,
      resetGame,
      createPlayer,
      continueFromDeath,
      performInnAction,
      cureAilment,
      passTime,
      performWildsAction,
      travelTo,
      getZoneData,
      grabItemsFromGround,
      identifyGroundItem,
      castAbilityOutOfCombat,
      saveGame,
      generateNewZone,
    ],
  );
};