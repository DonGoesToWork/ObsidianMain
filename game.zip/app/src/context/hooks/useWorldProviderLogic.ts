import {
  GameLocation,
  GameState,
  Zone,
  ItemInstance,
  RestOptions,
  ProfessionId,
  VitalId,
  DungeonState,
  Loggable,
  LogType,
  ClassId,
  RaceId,
  Player,
  LogEntry,
  AbilityId,
  StatusEffectId,
  GameData,
} from 'types';
import { useCallback, useMemo, useRef, useContext } from 'react';
import { travelToImpl, generateNewZoneImpl } from '../actions/worldActions';
import { passTimeImpl } from '../actions/timeActions';
import { performWildsActionImpl } from '../actions/wildsActions';
import { performInnActionImpl, cureAilmentImpl } from '../actions/townActions';
import { createPlayerImpl, continueFromDeathImpl } from '../actions/lifecycleActions';
import { castAbilityOutOfCombatImpl, applySkillOutOfCombatImpl } from '../actions/abilityActions';
import { ContextMenuOption } from 'context/ContextMenuContext';
import { GameDataContext } from 'context/GameDataContext';

interface WorldProviderDeps {
  player: Player | null;
  setPlayer: (update: any) => void;
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  gameTime: Date;
  setGameTime: React.Dispatch<React.SetStateAction<Date>>;
  currentLocation: GameLocation | null;
  setCurrentLocation: React.Dispatch<React.SetStateAction<GameLocation | null>>;
  generatedZones: Record<string, Zone>;
  setGeneratedZones: React.Dispatch<React.SetStateAction<Record<string, Zone>>>;
  currentDungeon: DungeonState | null;
  setCurrentDungeon: React.Dispatch<React.SetStateAction<DungeonState | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
  setActiveModal: (modal: string | null, options?: any, config?: any) => void;
  startCombat: (monsterPack: any[], options?: any) => void;
  addItemsToGround: (items: ItemInstance[]) => void;
  setLogs: React.Dispatch<React.SetStateAction<LogEntry[]>>;
  gainProfessionXp: (professionId: ProfessionId, amount: number) => void;
  showContextMenu: (x: number, y: number, options: ContextMenuOption[]) => void;
  applyStatusEffect: (targetId: 'player', effectId: StatusEffectId, options: any) => void;
}

export const useWorldProviderLogic = (deps: WorldProviderDeps) => {
  const {
    player,
    setPlayer,
    gameState,
    setGameState,
    gameTime,
    setGameTime,
    currentLocation,
    setCurrentLocation,
    generatedZones,
    setGeneratedZones,
    currentDungeon,
    setCurrentDungeon,
    logMessage,
    setActiveModal,
    startCombat,
    addItemsToGround,
    setLogs,
    gainProfessionXp,
    showContextMenu,
    applyStatusEffect,
  } = deps;
  const GAME_DATA = useContext(GameDataContext)!;
  const playerRef = useRef(player);
  playerRef.current = player;
  const locationRef = useRef(currentLocation);
  locationRef.current = currentLocation;

  const getZoneData = useCallback(
    (zoneId: string): Zone | undefined => generatedZones[zoneId] || GAME_DATA.ZONES[zoneId as keyof typeof GAME_DATA.ZONES],
    [generatedZones, GAME_DATA.ZONES],
  );
  const changeGameState = useCallback(
    (newState: GameState, options: any = {}) => {
      setGameState((prevState) => {
        console.debug(`Changing game state from ${prevState} to ${newState}`, options);
        if (newState !== 'combat' && !options.keepModalOpen) setActiveModal(null);
        return newState;
      });
    },
    [setGameState, setActiveModal],
  );

  const passTime = useCallback(
    (minutes: number, options?: RestOptions) =>
      passTimeImpl(
        {
          gameTime,
          setGameTime,
          logMessage,
          currentLocation: locationRef.current,
          startCombat,
          setPlayer,
          player: playerRef.current,
          setActiveModal,
          GAME_DATA,
        },
        { minutes, options },
      ),
    [gameTime, setGameTime, logMessage, startCombat, setPlayer, setActiveModal, GAME_DATA],
  );
  const travelTo = useCallback(
    (locationId: string) =>
      travelToImpl(
        {
          player: playerRef.current,
          getZoneData,
          logMessage,
          currentLocation: locationRef.current,
          passTime,
          setCurrentLocation,
          changeGameState,
          setPlayer,
          gameTime,
          setGeneratedZones,
          setActiveModal,
        },
        { locationId },
      ),
    [getZoneData, logMessage, passTime, setCurrentLocation, changeGameState, setPlayer, gameTime, setGeneratedZones, setActiveModal],
  );
  const generateNewZone = useCallback((level: number) => generateNewZoneImpl({ setGeneratedZones, logMessage }, { level }), [setGeneratedZones, logMessage]);
  const performWildsAction = useCallback(
    (actionType: ProfessionId) =>
      performWildsActionImpl(
        {
          passTime,
          player: playerRef.current,
          currentLocation: locationRef.current,
          logMessage,
          gainProfessionXp,
          addItemsToGround,
          GAME_DATA,
        },
        { actionType },
      ),
    [passTime, logMessage, addItemsToGround, gainProfessionXp, GAME_DATA],
  );
  const performInnAction = useCallback(
    (action: 'eat' | 'rest', cost: number) => performInnActionImpl({ setPlayer, logMessage, passTime }, { action, cost }),
    [setPlayer, logMessage, passTime],
  );
  const cureAilment = useCallback((vitalId: VitalId, cost: number) => cureAilmentImpl({ setPlayer, logMessage }, { vitalId, cost }), [setPlayer, logMessage]);
  const continueFromDeath = useCallback(
    () => continueFromDeathImpl({ setPlayer, logMessage, travelTo, setActiveModal, GAME_DATA }, {}),
    [setPlayer, logMessage, travelTo, setActiveModal, GAME_DATA],
  );

  const createPlayer = useCallback(
    (name: string, race: RaceId, pClass: ClassId) =>
      createPlayerImpl(name, race, pClass, setPlayer, changeGameState, logMessage, setCurrentLocation, setGeneratedZones, GAME_DATA),
    [changeGameState, logMessage, setPlayer, setCurrentLocation, setGeneratedZones, GAME_DATA],
  );
  const resetGame = useCallback(() => {
    if (window.confirm('Are you sure you want to reset your game? ALL progress will be lost.')) {
      localStorage.removeItem('aura_rpg_save_v19');
      setPlayer(null);
      setCurrentDungeon(null);
      setLogs([]);
      setActiveModal(null);
      setCurrentLocation(null);
      setGameState('character-creation');
      logMessage('Game Reset.', 'info');
    }
  }, [setPlayer, setCurrentDungeon, setLogs, setActiveModal, setCurrentLocation, setGameState, logMessage]);

  const grabItemsFromGround = useCallback(
    (itemIndices: number[]) => {
      let items: ItemInstance[] = [];
      let grabbed = false;

      setCurrentLocation((l) => {
        if (!l || !l.groundLoot) return l;
        const validIndices = itemIndices.filter((i) => i >= 0 && i < l.groundLoot!.length);
        if (validIndices.length === 0) return l;
        const itemsToGrab = validIndices.map((i) => l.groundLoot![i]);
        const totalWeight = itemsToGrab.reduce((sum, item) => sum + (GAME_DATA.ITEMS[item.id]?.weight || 0), 0);

        if (playerRef.current && playerRef.current.currentWeight + totalWeight > playerRef.current.maxCarryWeight) {
          logMessage('You would be over-encumbered.', 'error');
          return l;
        }
        items = itemsToGrab;
        const indicesSet = new Set(validIndices);
        const newLoot = l.groundLoot.filter((_, index) => !indicesSet.has(index));
        grabbed = true;
        return { ...l, groundLoot: newLoot };
      });

      if (grabbed && items.length > 0) {
        setPlayer((p: Player | null) => {
          if (!p) return p;
          logMessage(`You pick up ${items.length} item(s).`, 'loot');
          // Quest progress update would need to be handled here or another mechanism
          return { ...p, inventory: [...p.inventory, ...items] };
        });
      }
    },
    [setCurrentLocation, setPlayer, logMessage, GAME_DATA],
  );

  const identifyGroundItem = useCallback(
    (groundLootIndex: number) => {
      // This logic depends on player state, which is a bit tricky here.
      // For simplicity, this is a placeholder.
      logMessage('Identify on ground not fully supported in this refactor yet.', 'info');
    },
    [logMessage],
  );

  const applySkillOutOfCombat = useCallback(
    (abilityId: AbilityId, targetId: string, limbId: string | null) => {
      applySkillOutOfCombatImpl(abilityId, targetId, limbId, setPlayer, logMessage, passTime, applyStatusEffect, GAME_DATA);
    },
    [setPlayer, logMessage, passTime, applyStatusEffect, GAME_DATA],
  );

  const castAbilityOutOfCombat = useCallback(
    (abilityId: AbilityId, e: React.MouseEvent) => {
      castAbilityOutOfCombatImpl(abilityId, e, playerRef.current, showContextMenu, applySkillOutOfCombat, logMessage, GAME_DATA);
    },
    [showContextMenu, applySkillOutOfCombat, logMessage, GAME_DATA],
  );

  const saveGame = () => {
    /* This is handled in the main Provider now */
  };

  return useMemo(
    () => ({
      gameState,
      changeGameState,
      gameTime,
      setGameTime,
      currentLocation,
      setCurrentLocation,
      generatedZones,
      setGeneratedZones,
      currentDungeon,
      setCurrentDungeon,
      saveGame,
      resetGame,
      createPlayer,
      continueFromDeath,
      performInnAction,
      cureAilment,
      passTime,
      performWildsAction,
      travelTo,
      getZoneData,
      addItemsToGround,
      grabItemsFromGround,
      identifyGroundItem,
      debug_teleportToTown: () => travelTo('zone0'),
      castAbilityOutOfCombat,
    }),
    [
      gameState,
      changeGameState,
      gameTime,
      setGameTime,
      currentLocation,
      setCurrentLocation,
      generatedZones,
      setGeneratedZones,
      currentDungeon,
      setCurrentDungeon,
      resetGame,
      createPlayer,
      continueFromDeath,
      performInnAction,
      cureAilment,
      passTime,
      performWildsAction,
      travelTo,
      getZoneData,
      addItemsToGround,
      grabItemsFromGround,
      identifyGroundItem,
      castAbilityOutOfCombat,
    ],
  );
};