import { useCallback, useContext, useEffect, useMemo, useRef } from 'react';
import {
  AbilityId,
  AppraiseOptions,
  CharacterContextType,
  ClassId,
  CombatState,
  DungeonState,
  GameLocation,
  GameSideEffect,
  GameState,
  ItemId,
  ItemInstance,
  LocationState,
  LogEntry,
  LogType,
  Loggable,
  ModalUiSettings,
  Player,
  ProfessionId,
  RaceId,
  RestOptions,
  StatusEffectId,
  VitalId,
  Zone,
} from 'types';
import { applySkillOutOfCombatImpl, castAbilityOutOfCombatImpl } from '../actions/abilityActions';
import { continueFromDeath as continueFromDeathAction, createPlayerImpl } from '../actions/lifecycleActions';
import { cureAilment as cureAilmentAction, performInnAction as performInnActionAction } from '../actions/townActions';
import { generateNewZoneImpl, travelToImpl } from '../actions/worldActions';

import { PLAYER_INVENTORY_MAX_STACK_SIZE, PLAYER_INVENTORY_MAX_UNIQUE_ITEMS } from 'config/GLOBAL_QUICK_DEV_CONFIGURATION';
import { ContextMenuOption } from 'context/ContextMenuContext';
import { GameDataContext } from 'context/GameDataContext';
import { areEffectivelyEqual, getItemName, mergeIntoInventory } from 'utils/itemUtils';
import { passTimeImpl } from '../actions/timeActions';
import { performWildsActionImpl } from '../actions/wildsActions';

const SAVE_KEY = 'aura_rpg_save_v19';
const jsonReplacer = (key: string, value: any) => (value === Infinity ? 'Infinity' : value);

interface WorldProviderDeps {
  player: Player | null;
  setPlayer: (update: any) => void;
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  gameTime: Date;
  setGameTime: React.Dispatch<React.SetStateAction<Date>>;
  currentLocation: GameLocation | null;
  setCurrentLocation: React.Dispatch<React.SetStateAction<GameLocation | null>>;
  generatedZones: Record<string, Zone>;
  setGeneratedZones: React.Dispatch<React.SetStateAction<Record<string, Zone>>>;
  worldLocationsState: Record<string, LocationState>;
  setWorldLocationsState: React.Dispatch<React.SetStateAction<Record<string, LocationState>>>;
  currentDungeon: DungeonState | null;
  setCurrentDungeon: React.Dispatch<React.SetStateAction<DungeonState | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
  setActiveModal: (modal: string | null, options?: any, config?: any) => void;
  startCombat: (monsterPack: any[], options?: any) => void;
  addItemsToGround: (items: ItemInstance[]) => void;
  setLogs: React.Dispatch<React.SetStateAction<LogEntry[]>>;
  gainProfessionXp: (professionId: ProfessionId, amount: number) => void;
  showContextMenu: (x: number, y: number, options: ContextMenuOption[]) => void;
  applyStatusEffect: (targetId: 'player', effectId: StatusEffectId, options: any) => void;
  updateQuestProgress: CharacterContextType['updateQuestProgress'];
  currentCombat: CombatState | null;
  setCurrentCombat: React.Dispatch<React.SetStateAction<CombatState | null>>;
  logs: LogEntry[];
  modalUiSettings: Record<string, ModalUiSettings>;
  setModalUiSettings: React.Dispatch<React.SetStateAction<Record<string, ModalUiSettings>>>;
  queueSideEffects: (effects: GameSideEffect[]) => void;
  withActionLock: <T>(action: () => T, options?: { silent?: boolean }) => T | undefined;
  isActionLocked: boolean;
  setFloatingTexts: React.Dispatch<React.SetStateAction<{ id: number; text: string }[]>>;
  setDebugTargets: React.Dispatch<React.SetStateAction<string[]>>;
}

export const useWorldProviderLogic = (deps: WorldProviderDeps) => {
  const depsRef = useRef(deps);
  depsRef.current = deps;
  const GAME_DATA = useContext(GameDataContext)!;
  const { withActionLock, isActionLocked } = deps;

  const getZoneData = useCallback(
    (zoneId: string): Zone | undefined => {
      const { generatedZones } = depsRef.current;
      return generatedZones[zoneId] || GAME_DATA.ZONES[zoneId as keyof typeof GAME_DATA.ZONES];
    },
    [GAME_DATA.ZONES]
  );
  const changeGameState = useCallback((newState: GameState, options: any = {}) => {
    const { setGameState, setActiveModal } = depsRef.current;
    setGameState((prevState) => {
      console.debug(`Changing game state from ${prevState} to ${newState}`, options);
      if (newState !== 'combat' && !options.keepModalOpen) setActiveModal(null);
      return newState;
    });
  }, []);

  const passTime = useCallback(
    (minutes: number, options?: RestOptions | AppraiseOptions) => {
      withActionLock(() => {
        const currentDeps = depsRef.current;
        passTimeImpl(
          {
            gameTime: currentDeps.gameTime,
            setGameTime: currentDeps.setGameTime,
            logMessage: currentDeps.logMessage,
            currentLocation: currentDeps.currentLocation,
            startCombat: currentDeps.startCombat,
            setPlayer: currentDeps.setPlayer,
            player: currentDeps.player,
            setActiveModal: currentDeps.setActiveModal,
            GAME_DATA,
          },
          { minutes, options }
        );
      });
    },
    [GAME_DATA, withActionLock]
  );

  const performInnAction = useCallback(
    (action: 'eat' | 'rest', cost: number) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p: Player | null) => {
          if (!p) return p;
          const result = performInnActionAction(p, action, cost);
          if (!result) return p;
          depsRef.current.queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [withActionLock]
  );

  const cureAilment = useCallback(
    (vitalId: VitalId, cost: number) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p: Player | null) => {
          if (!p) return p;
          const result = cureAilmentAction(p, vitalId, cost);
          if (!result) return p;
          depsRef.current.queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [withActionLock]
  );

  const travelTo = useCallback(
    (locationId: string) => {
      withActionLock(() => {
        const currentDeps = depsRef.current;
        travelToImpl(
          {
            player: currentDeps.player,
            getZoneData,
            logMessage: currentDeps.logMessage,
            currentLocation: currentDeps.currentLocation,
            passTime, // Use wrapped passTime
            setCurrentLocation: currentDeps.setCurrentLocation,
            changeGameState,
            setPlayer: currentDeps.setPlayer,
            gameTime: currentDeps.gameTime,
            setGeneratedZones: currentDeps.setGeneratedZones,
            setActiveModal: currentDeps.setActiveModal,
            worldLocationsState: currentDeps.worldLocationsState,
            setWorldLocationsState: currentDeps.setWorldLocationsState,
          } as any, // Cast to avoid excessive type wrangling
          { locationId }
        );
      });
    },
    [getZoneData, passTime, changeGameState, withActionLock]
  );
  const generateNewZone = useCallback((level: number) => {
    const { setGeneratedZones, logMessage } = depsRef.current;
    generateNewZoneImpl({ setGeneratedZones, logMessage }, { level });
  }, []);
  const performWildsAction = useCallback(
    (actionType: ProfessionId) => {
      withActionLock(() => {
        const currentDeps = depsRef.current;
        performWildsActionImpl(
          {
            passTime,
            player: currentDeps.player,
            currentLocation: currentDeps.currentLocation,
            logMessage: currentDeps.logMessage,
            gainProfessionXp: currentDeps.gainProfessionXp,
            addItemsToGround: currentDeps.addItemsToGround,
            GAME_DATA,
          },
          { actionType }
        );
      });
    },
    [passTime, GAME_DATA, withActionLock]
  );
  const continueFromDeath = useCallback(() => {
    withActionLock(() => {
      const { setActiveModal, setPlayer } = depsRef.current;
      setPlayer((p: Player | null) => {
        if (!p) return p;
        const result = continueFromDeathAction(p, GAME_DATA);
        depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
      travelTo('zone0');
      setActiveModal(null);
    });
  }, [travelTo, GAME_DATA, withActionLock]);

  const createPlayer = useCallback(
    (name: string, race: RaceId, pClass: ClassId) => {
      const { setPlayer, logMessage, setCurrentLocation, setGeneratedZones } = depsRef.current;
      createPlayerImpl(name, race, pClass, setPlayer, changeGameState, logMessage, setCurrentLocation, setGeneratedZones, GAME_DATA);
    },
    [changeGameState, GAME_DATA]
  );
  const resetGame = useCallback(() => {
    const {
      setPlayer,
      setCurrentDungeon,
      setLogs,
      setActiveModal,
      setCurrentLocation,
      setGameState,
      logMessage,
      setGeneratedZones,
      setWorldLocationsState,
      setGameTime,
      setModalUiSettings,
      setDebugTargets,
      setCurrentCombat,
      setFloatingTexts,
    } = depsRef.current;
    if (window.confirm('Are you sure you want to reset your game? ALL progress will be lost.')) {
      localStorage.removeItem(SAVE_KEY);
      setPlayer(null);
      setCurrentDungeon(null);
      setLogs([]);
      setActiveModal(null);
      setCurrentLocation(null);
      setGameState('character-creation');
      setGeneratedZones({});
      setWorldLocationsState({});
      setGameTime(new Date());
      setModalUiSettings({});
      setDebugTargets([]);
      setFloatingTexts([]);
      setCurrentCombat(null);
      logMessage('Game Reset.', 'info');
    }
  }, []);

  const grabItemsFromGround = useCallback(
    (itemsToGrab: { representativeUniqueId: string; quantity: number }[]) => {
      withActionLock(() => {
        const { currentLocation, player, logMessage, setCurrentLocation, setPlayer, updateQuestProgress, gameTime, queueSideEffects } = depsRef.current;
        if (!currentLocation || !currentLocation.groundLoot || !player) return;

        let newGroundLoot = [...currentLocation.groundLoot];
        const itemsToMoveToPlayer: ItemInstance[] = [];
        let totalWeightToGrab = 0;

        // Pre-calculate total weight to check for encumbrance
        for (const { representativeUniqueId, quantity } of itemsToGrab) {
          const templateItem = newGroundLoot.find((i) => i.unique_id === representativeUniqueId);
          if (!templateItem) continue;
          totalWeightToGrab += (GAME_DATA.ITEMS[templateItem.id]?.weight || 0) * quantity;
        }

        if (player.currentWeight + totalWeightToGrab > player.maxCarryWeight) {
          logMessage('You would be over-encumbered.', 'error');
          return;
        }

        // Process the grab
        for (const { representativeUniqueId, quantity } of itemsToGrab) {
          const templateItem = newGroundLoot.find((i) => i.unique_id === representativeUniqueId);
          if (!templateItem) continue;

          let remainingToGrab = quantity;
          const isStackable = GAME_DATA.ITEMS[templateItem.id].stackable;

          if (isStackable) {
            // Prioritize the clicked stack
            const prioritizedStackIndex = newGroundLoot.findIndex((i) => i.unique_id === representativeUniqueId);
            if (prioritizedStackIndex > -1) {
              const stack = newGroundLoot[prioritizedStackIndex];
              const amountFromStack = Math.min(remainingToGrab, stack.quantity);
              itemsToMoveToPlayer.push({ ...stack, quantity: amountFromStack });
              stack.quantity -= amountFromStack;
              remainingToGrab -= amountFromStack;
              if (stack.quantity <= 0) {
                newGroundLoot.splice(prioritizedStackIndex, 1);
              }
            }

            // Grab from other matching stacks if needed
            for (let i = newGroundLoot.length - 1; i >= 0; i--) {
              if (remainingToGrab <= 0) break;
              const groundStack = newGroundLoot[i];
              if (areEffectivelyEqual(groundStack, templateItem) && groundStack.unique_id !== representativeUniqueId) {
                const amountFromStack = Math.min(remainingToGrab, groundStack.quantity);
                itemsToMoveToPlayer.push({ ...groundStack, quantity: amountFromStack });
                groundStack.quantity -= amountFromStack;
                remainingToGrab -= amountFromStack;
                if (groundStack.quantity <= 0) {
                  newGroundLoot.splice(i, 1);
                }
              }
            }
          } else {
            // Unstackable
            const itemIndex = newGroundLoot.findIndex((i) => i.unique_id === representativeUniqueId);
            if (itemIndex > -1) {
              itemsToMoveToPlayer.push(newGroundLoot[itemIndex]);
              newGroundLoot.splice(itemIndex, 1);
            }
          }
        }

        if (itemsToMoveToPlayer.length === 0) return;

        setCurrentLocation((l) => ({ ...l!, groundLoot: newGroundLoot, groundLootTimestamp: gameTime.getTime() }));

        setPlayer((p: Player | null) => {
          if (!p) return p;
          const { newInventory, overflow } = mergeIntoInventory(p.inventory, itemsToMoveToPlayer, GAME_DATA, {
            maxUniqueItems: PLAYER_INVENTORY_MAX_UNIQUE_ITEMS,
            maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
          });
          if (overflow.length > 0) {
            queueSideEffects([{ type: 'DROP_ITEMS', items: overflow }]);
          }
          return { ...p, inventory: newInventory };
        });

        const groupedByName: { [key: string]: number } = itemsToMoveToPlayer.reduce((acc, item) => {
          const name = getItemName(item, GAME_DATA);
          acc[name] = (acc[name] || 0) + item.quantity;
          return acc;
        }, {} as Record<string, number>);

        const messageParts = Object.entries(groupedByName).map(([name, quantity]) => {
          return `${name}${quantity > 1 ? ` (x${quantity})` : ''}`;
        });

        if (messageParts.length > 0) {
          const message = `You pick up ${messageParts.join(', ')}.`;
          console.log('grabItemsFromGround generated message:', message);
          logMessage(message, 'loot');
        }

        const itemsByType = itemsToMoveToPlayer.reduce((acc, item) => {
          acc[item.id] = (acc[item.id] || 0) + item.quantity;
          return acc;
        }, {} as Record<ItemId, number>);

        Object.entries(itemsByType).forEach(([itemId, count]) => {
          if (GAME_DATA.ITEMS[itemId as ItemId].type.includes('material')) {
            updateQuestProgress('gather', itemId, count);
          }
        });
      });
    },
    [GAME_DATA, withActionLock]
  );

  const abandonAllLoot = useCallback(() => {
    withActionLock(() => {
      const { currentLocation, setCurrentLocation, logMessage, setActiveModal, gameTime } = depsRef.current;
      if (!currentLocation || !currentLocation.groundLoot || currentLocation.groundLoot.length === 0) {
        logMessage('There is no loot to abandon.', 'info');
        return;
      }

      const itemCount = currentLocation.groundLoot.reduce((sum, item) => sum + item.quantity, 0);

      setActiveModal(
        'confirmation-modal',
        {
          title: 'Abandon Loot',
          message: `Are you sure you want to permanently destroy all ${itemCount} item(s) on the ground?`,
          onConfirm: () => {
            console.log('Abandoning all loot on ground.');
            setCurrentLocation((l) => (l ? { ...l, groundLoot: [], groundLootTimestamp: gameTime.getTime() } : l));
            logMessage(`You abandon all loot on the ground.`, 'info');
            setActiveModal(null);
          },
          onCancel: () => setActiveModal(null),
        },
        { history: true }
      );
    });
  }, [withActionLock]);

  const applySkillOutOfCombat = useCallback(
    (abilityId: AbilityId, targetId: string, limbId: string | null) => {
      withActionLock(() => {
        const { setPlayer, logMessage, applyStatusEffect } = depsRef.current;
        applySkillOutOfCombatImpl(abilityId, targetId, limbId, setPlayer, logMessage, passTime, applyStatusEffect, GAME_DATA);
      });
    },
    [passTime, GAME_DATA, withActionLock]
  );

  const castAbilityOutOfCombat = useCallback(
    (abilityId: AbilityId, e: React.MouseEvent) => {
      const { player, showContextMenu, logMessage } = depsRef.current;
      if (!player) return;
      castAbilityOutOfCombatImpl(abilityId, e, player, showContextMenu, applySkillOutOfCombat, logMessage, GAME_DATA);
    },
    [applySkillOutOfCombat, GAME_DATA]
  );

  const saveGame = useCallback(() => {
    const { player, currentCombat, currentDungeon, gameTime, currentLocation, gameState, generatedZones, worldLocationsState, logs, modalUiSettings, logMessage } = depsRef.current;
    if (player && !currentCombat) {
      try {
        const gameStateToSave = {
          player,
          currentDungeon,
          gameTime: gameTime.toISOString(),
          currentLocation,
          gameState,
          generatedZones,
          worldLocationsState,
          logs,
          modalUiSettings,
        };
        localStorage.setItem(SAVE_KEY, JSON.stringify(gameStateToSave, jsonReplacer));
        logMessage('Game saved successfully', 'info');
      } catch (e) {
        console.error('Failed to save game:', e);
        logMessage('Failed to save game. Storage might be full.', 'error');
      }
    }
  }, []);

  useEffect(() => {
    const interval = setInterval(saveGame, 30000);
    return () => clearInterval(interval);
  }, [saveGame]);

  return useMemo(
    () => ({
      ...deps,
      changeGameState,
      resetGame,
      createPlayer,
      continueFromDeath,
      performInnAction,
      cureAilment,
      passTime,
      performWildsAction,
      travelTo,
      getZoneData,
      grabItemsFromGround,
      abandonAllLoot,
      debug_teleportToTown: () => travelTo('zone0'),
      castAbilityOutOfCombat,
      saveGame,
      generateNewZone,
      isActionLocked,
      withActionLock,
    }),
    [
      deps,
      changeGameState,
      resetGame,
      createPlayer,
      continueFromDeath,
      performInnAction,
      cureAilment,
      passTime,
      performWildsAction,
      travelTo,
      getZoneData,
      grabItemsFromGround,
      abandonAllLoot,
      castAbilityOutOfCombat,
      saveGame,
      generateNewZone,
      isActionLocked,
      withActionLock,
    ]
  );
};