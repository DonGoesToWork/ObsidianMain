import React, { useCallback, useMemo, useContext } from "react";
import { ItemInstance, LogType, Loggable, Player } from "types";
import {
  executeTradeImpl,
  getShopStockImpl,
  refreshShopInventoryImpl,
} from "../actions/shopActions";
import { GameDataContext } from "context/GameDataContext";

interface ShopProviderDeps {
  player: Player | null;
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
  gameTime: Date;
}

export const useShopProviderLogic = (deps: ShopProviderDeps) => {
  const { player, setPlayer, logMessage, gameTime } = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const getShopStock = useCallback(
    (locationId: string) => getShopStockImpl(player, locationId),
    [player],
  );
  const refreshShopInventory = useCallback(
    (locationId: string, locationLevel: number) => {
      refreshShopInventoryImpl(locationId, locationLevel, setPlayer, gameTime, GAME_DATA, true);
      logMessage("The shopkeeper has restocked their wares.", "info");
    },
    [setPlayer, gameTime, logMessage, GAME_DATA],
  );
  const executeTrade = useCallback(
    (locationId: string, playerOfferItems: ItemInstance[], merchantOfferItems: ItemInstance[]) => {
      executeTradeImpl(locationId, playerOfferItems, merchantOfferItems, setPlayer, logMessage, GAME_DATA);
    },
    [setPlayer, logMessage, GAME_DATA],
  );

  return useMemo(
    () => ({
      getShopStock,
      refreshShopInventory,
      executeTrade,
    }),
    [getShopStock, refreshShopInventory, executeTrade],
  );
};