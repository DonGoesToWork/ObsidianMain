import { GameDataContext } from 'context/GameDataContext';
import React, { useCallback, useContext, useMemo, useRef } from 'react';
import { GameSideEffect, ItemInstance, LogType, Loggable, Player } from 'types';
import { executeTrade as executeTradeAction, getShopStockImpl, refreshShopInventory as refreshShopInventoryAction } from '../actions/shopActions';

interface ShopProviderDeps {
  player: Player | null;
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
  gameTime: Date;
  withActionLock: <T>(action: () => T, options?: { silent?: boolean }) => T | undefined;
  queueSideEffects: (effects: GameSideEffect[]) => void;
}

export const useShopContextLogic = (deps: ShopProviderDeps) => {
  const GAME_DATA = useContext(GameDataContext)!;
  const depsRef = useRef(deps);
  depsRef.current = deps;

  const getShopStock = useCallback((locationId: string) => getShopStockImpl(depsRef.current.player, locationId), []);

  const refreshShopInventory = useCallback(
    (locationId: string, locationLevel: number, force: boolean = false) => {
      depsRef.current.withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const { gameTime, queueSideEffects } = depsRef.current;
          const result = refreshShopInventoryAction(p, locationId, locationLevel, gameTime, GAME_DATA, force);
          if (result.sideEffects.length) {
            queueSideEffects(result.sideEffects);
          }
          return result.player;
        });
      }, { silent: true });
    },
    [GAME_DATA]
  );

  const executeTrade = useCallback(
    (locationId: string, playerOfferItems: ItemInstance[], merchantOfferItems: ItemInstance[]) => {
      depsRef.current.withActionLock(() => {
        const { setPlayer, queueSideEffects } = depsRef.current;
        setPlayer((p) => {
          if (!p) return p;
          const result = executeTradeAction(p, locationId, playerOfferItems, merchantOfferItems, GAME_DATA);
          if (result.sideEffects.length) {
            queueSideEffects(result.sideEffects);
          }
          return result.player;
        });
      });
    },
    [GAME_DATA]
  );

  return useMemo(
    () => ({
      getShopStock,
      refreshShopInventory,
      executeTrade,
    }),
    [getShopStock, refreshShopInventory, executeTrade]
  );
};