import { GameDataContext } from 'context/GameDataContext';
import React, { useCallback, useContext, useMemo, useRef } from 'react';
import { GameSideEffect, ItemInstance, LocationState, LogType, Loggable, Player } from 'types';
import { executeTrade as executeTradeAction, getShopStockImpl, refreshShopInventoryAction } from '../actions/shopActions';

interface ShopProviderDeps {
  player: Player | null;
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
  gameTime: Date;
  withActionLock: <T>(action: () => T, options?: { silent?: boolean }) => T | undefined;
  queueSideEffects: (effects: GameSideEffect[]) => void;
  worldLocationsState: Record<string, LocationState>;
  setWorldLocationsState: React.Dispatch<React.SetStateAction<Record<string, LocationState>>>;
}

export const useShopContextLogic = (deps: ShopProviderDeps) => {
  const GAME_DATA = useContext(GameDataContext)!;
  const depsRef = useRef(deps);
  depsRef.current = deps;

  const getShopStock = useCallback(
    (locationId: string) => {
      const { worldLocationsState } = depsRef.current;
      const locationState = worldLocationsState[locationId];
      return getShopStockImpl(locationState);
    },
    [] // worldLocationsState is accessed via ref, so no dependency needed
  );

  const refreshShopInventory = useCallback(
    (locationId: string, locationLevel: number, force: boolean = false) => {
      depsRef.current.withActionLock(
        () => {
          console.log('SHOP TEST 1: refreshShopInventory called for', locationId);
          const { gameTime, queueSideEffects, worldLocationsState, setWorldLocationsState } = depsRef.current;
          const currentShopData = worldLocationsState[locationId]?.shopInventory;
          console.log('SHOP TEST 2: Current shop data:', currentShopData);

          const { updatedShopData, sideEffects } = refreshShopInventoryAction(currentShopData, locationLevel, gameTime, GAME_DATA, force);
          console.log('SHOP TEST 3: New shop data generated:', updatedShopData);

          if (sideEffects.length) {
            queueSideEffects(sideEffects);
          }

          if (updatedShopData !== currentShopData) {
            console.log('SHOP TEST 4: Shop data has changed, setting new state.');
            setWorldLocationsState((wls) => {
              console.log('SHOP TEST 5: Inside setWorldLocationsState. Previous state:', wls);
              const existingLocationState = wls[locationId] || { id: locationId };
              const newState = {
                ...wls,
                [locationId]: {
                  ...existingLocationState,
                  shopInventory: updatedShopData,
                },
              };
              console.log('SHOP TEST 6: New world location state:', newState);
              return newState;
            });
          } else {
            console.log('SHOP TEST 4: Shop data has not changed, not setting state.');
          }
        },
        { silent: true }
      );
    },
    [GAME_DATA]
  );

  const executeTrade = useCallback(
    (locationId: string, playerOfferItems: ItemInstance[], merchantOfferItems: ItemInstance[]) => {
      depsRef.current.withActionLock(() => {
        const { setPlayer, queueSideEffects, worldLocationsState, setWorldLocationsState } = depsRef.current;
        const currentShopData = worldLocationsState[locationId]?.shopInventory;

        setPlayer((p) => {
          if (!p) return p;
          const result = executeTradeAction(p, currentShopData, playerOfferItems, merchantOfferItems, GAME_DATA);
          if (result.sideEffects.length) {
            queueSideEffects(result.sideEffects);
          }
          setWorldLocationsState((wls) => {
            const existingLocationState = wls[locationId] || { id: locationId };
            return {
              ...wls,
              [locationId]: {
                ...existingLocationState,
                shopInventory: result.updatedShopData,
              },
            };
          });
          return result.updatedPlayer;
        });
      });
    },
    [GAME_DATA]
  );

  return useMemo(
    () => ({
      getShopStock,
      refreshShopInventory,
      executeTrade,
    }),
    [getShopStock, refreshShopInventory, executeTrade]
  );
};