import React, { useCallback, useMemo, useContext, useRef } from 'react';
import { ItemInstance, LogType, Loggable, Player } from 'types';
import { executeTradeImpl, getShopStockImpl, refreshShopInventoryImpl } from '../actions/shopActions';
import { GameDataContext } from 'context/GameDataContext';

interface ShopProviderDeps {
  player: Player | null;
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
  gameTime: Date;
}

export const useShopContextLogic = (deps: ShopProviderDeps) => {
  const GAME_DATA = useContext(GameDataContext)!;
  const depsRef = useRef(deps);
  depsRef.current = deps;

  const getShopStock = useCallback((locationId: string) => getShopStockImpl(depsRef.current.player, locationId), []);

  const refreshShopInventory = useCallback(
    (locationId: string, locationLevel: number, force: boolean = false) => {
      const { setPlayer, gameTime, logMessage } = depsRef.current;
      refreshShopInventoryImpl(locationId, locationLevel, setPlayer, gameTime, GAME_DATA, force);
      if (force) {
        logMessage('The shopkeeper has restocked their wares.', 'info');
      }
    },
    [GAME_DATA],
  );

  const executeTrade = useCallback(
    (locationId: string, playerOfferItems: ItemInstance[], merchantOfferItems: ItemInstance[]) => {
      const { setPlayer, logMessage } = depsRef.current;
      executeTradeImpl(locationId, playerOfferItems, merchantOfferItems, setPlayer, logMessage, GAME_DATA);
    },
    [GAME_DATA],
  );

  return useMemo(
    () => ({
      getShopStock,
      refreshShopInventory,
      executeTrade,
    }),
    [getShopStock, refreshShopInventory, executeTrade],
  );
};