import React, { useCallback, useMemo, useContext, useRef } from 'react';
import { ItemInstance, LogType, Loggable, Player, GameSideEffect } from 'types';
import { executeTrade as executeTradeAction, getShopStockImpl, refreshShopInventory as refreshShopInventoryAction } from '../actions/shopActions';
import { GameDataContext } from 'context/GameDataContext';

interface ShopProviderDeps {
  player: Player | null;
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>;
  logMessage: (message: Loggable, type?: LogType) => void;
  gameTime: Date;
}

export const useShopContextLogic = (deps: ShopProviderDeps) => {
  const GAME_DATA = useContext(GameDataContext)!;
  const depsRef = useRef(deps);
  depsRef.current = deps;

  const getShopStock = useCallback((locationId: string) => getShopStockImpl(depsRef.current.player, locationId), []);

  const refreshShopInventory = useCallback(
    (locationId: string, locationLevel: number, force: boolean = false) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const { gameTime, logMessage } = depsRef.current;
        const result = refreshShopInventoryAction(p, locationId, locationLevel, gameTime, GAME_DATA, force);
        if (result.sideEffects.length) {
          result.sideEffects.forEach((effect) => {
            if (effect.type === 'LOG') {
              logMessage(effect.message, effect.logType);
            }
          });
        }
        return result.player;
      });
    },
    [GAME_DATA],
  );

  const executeTrade = useCallback(
    (locationId: string, playerOfferItems: ItemInstance[], merchantOfferItems: ItemInstance[]) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = executeTradeAction(p, locationId, playerOfferItems, merchantOfferItems, GAME_DATA);
        if (result.sideEffects.length) {
          result.sideEffects.forEach((effect) => {
            if (effect.type === 'LOG') {
              depsRef.current.logMessage(effect.message, effect.logType);
            }
          });
        }
        return result.player;
      });
    },
    [GAME_DATA],
  );

  return useMemo(
    () => ({
      getShopStock,
      refreshShopInventory,
      executeTrade,
    }),
    [getShopStock, refreshShopInventory, executeTrade],
  );
};