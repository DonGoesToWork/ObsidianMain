import { ItemId, ItemInstance, ProfessionId, Recipe, RequirementCheck, UseCraftingReturn } from 'types';
import React, { useContext, useEffect, useMemo, useState } from 'react';
import { calculateCraftSuccessChance, getCraftingChecks, getRequirementStatus } from 'utils/craftingUtils';
import { countItems, groupItems } from 'utils/itemUtils';

import { GameDataContext } from 'context/GameDataContext';
import { LogContext } from 'context/LogContext';
import { PlayerContext } from 'context/PlayerContext';
import { ProfessionsContext } from 'context/ProfessionsContext';
import { WorldContext } from 'context/WorldContext';

const MAX_TOOLS = 4;
const MAX_INGREDIENTS = 10;

export const useCrafting = (): UseCraftingReturn => {
  const { player } = useContext(PlayerContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { craftItem } = useContext(ProfessionsContext)!;
  const { currentLocation } = useContext(WorldContext)!;
  const { logMessage } = useContext(LogContext)!;

  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [tools, setTools] = useState<ItemInstance[]>([]);
  const [ingredients, setIngredients] = useState<ItemInstance[]>([]);
  const [recipeProfession, setRecipeProfession] = useState<ProfessionId>('smithing');

  const { playerInventoryForDisplay, playerInventoryMap } = useMemo(() => {
    if (!player) return { playerInventoryForDisplay: [], playerInventoryMap: [] };
    const itemsInCrafting = new Set([...tools, ...ingredients]);
    const displayItems: ItemInstance[] = [];
    const displayMap: number[] = [];
    player.inventory.forEach((item: ItemInstance, index: number) => {
      if (!itemsInCrafting.has(item) && !item.isUnidentified) {
        displayItems.push(item);
        displayMap.push(index);
      }
    });
    return {
      playerInventoryForDisplay: displayItems,
      playerInventoryMap: displayMap,
    };
  }, [player, tools, ingredients]);

  const groupedIngredients = useMemo(() => groupItems(ingredients, GAME_DATA), [ingredients, GAME_DATA]);

  const knownRecipes = useMemo(() => {
    if (!player) return [];
    return Object.values(GAME_DATA.ALL_RECIPES).filter((r) => r.profession === recipeProfession && player.knownRecipes[r.id]);
  }, [player?.knownRecipes, recipeProfession, GAME_DATA.ALL_RECIPES]);

  const discoveredRecipe = useMemo(() => {
    if (ingredients.length === 0 && tools.length === 0) return undefined;

    const ingredientCounts: Record<string, number> = {};
    for (const ing of ingredients) {
      ingredientCounts[ing.id] = (ingredientCounts[ing.id] || 0) + 1;
    }
    const providedToolIds = new Set(tools.map((t) => t.id));

    return Object.values(GAME_DATA.ALL_RECIPES).find((r) => {
      const recipeMatKeys = Object.keys(r.materials);
      const providedIngKeys = Object.keys(ingredientCounts);
      if (recipeMatKeys.length !== providedIngKeys.length) return false;
      const ingredientsMatch = recipeMatKeys.every((key) => ingredientCounts[key] === r.materials[key as ItemId]);
      if (!ingredientsMatch) return false;

      const requiredToolIds = new Set(r.tools || []);
      if (r.requiresForge) {
        requiredToolIds.add('item_forge');
      }
      const providedWithForge = new Set(providedToolIds);
      if (r.requiresForge && currentLocation?.type === 'town') {
        providedWithForge.add('item_forge');
      }

      if (requiredToolIds.size !== providedWithForge.size) return false;

      const toolsMatch = Array.from(requiredToolIds).every((toolId) => providedWithForge.has(toolId as ItemId));
      if (!toolsMatch) return false;

      return true;
    });
  }, [ingredients, tools, GAME_DATA.ALL_RECIPES, currentLocation]);

  useEffect(() => {
    if (discoveredRecipe && player?.knownRecipes[discoveredRecipe.id]) {
      setSelectedRecipe(discoveredRecipe);
    } else {
      setSelectedRecipe(null);
    }
  }, [discoveredRecipe, player?.knownRecipes]);

  const requirementChecks = useMemo(() => {
    if (!player) return {};
    const recipe = selectedRecipe || discoveredRecipe || null;

    // When a recipe is selected, ingredients/tools are populated into the state.
    // Thus, the checks should always be against the ingredients/tools state, not the full inventory.
    const checks = getCraftingChecks(player, recipe, tools, currentLocation, !!selectedRecipe, GAME_DATA, { materialSource: ingredients });

    if (recipe?.profession) {
      const playerSkill = player.professions[recipe.profession].level;
      checks.dr = { ok: true, text: `DR: ${recipe.levelReq} (vs ${playerSkill})` };
      checks.success = { ok: true, text: `Success: ${calculateCraftSuccessChance(playerSkill, recipe.levelReq).toFixed(1)}%` };
      checks.failure = { ok: true, text: `Failure consumes materials.` };
    }

    return checks;
  }, [player, selectedRecipe, discoveredRecipe, tools, ingredients, currentLocation, GAME_DATA]);

  const canCraftSingle = useMemo(() => {
    const recipe = selectedRecipe || discoveredRecipe;
    if (!recipe) {
      return ingredients.length > 0;
    }
    return getRequirementStatus(requirementChecks) === 'full';
  }, [selectedRecipe, discoveredRecipe, ingredients.length, requirementChecks]);

  const canCraftMultiple = (quantity: number) => {
    if (!selectedRecipe || !player) return false;
    if (getRequirementStatus(requirementChecks) !== 'full') return false;

    const invCounts = groupItems(player.inventory, GAME_DATA);
    for (const [matId, count] of Object.entries(selectedRecipe.materials)) {
      const matKey = Object.keys(invCounts).find((k) => invCounts[k].item.id === matId);
      if (!matKey || invCounts[matKey].count < count * quantity) return false;
    }
    return true;
  };

  const handleAddItemToCraft = (itemsToAdd: ItemInstance[]) => {
    let currentTools = [...tools];
    let currentIngredients = [...ingredients];

    for (const item of itemsToAdd) {
      const itemData = GAME_DATA.ITEMS[item.id];
      if (itemData.type.includes('tool') || item.id === 'item_forge') {
        if (currentTools.length < MAX_TOOLS) {
          currentTools.push(item);
        } else {
          logMessage('Tool slots are full.', 'error');
          break;
        }
      } else {
        if (currentIngredients.length < MAX_INGREDIENTS) {
          currentIngredients.push(item);
        } else {
          logMessage('Ingredient slots are full.', 'error');
          break;
        }
      }
    }

    setTools(currentTools);
    setIngredients(currentIngredients);
  };

  const handleSelectRecipe = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    if (!player) return;

    let availableInventory = [...player.inventory];
    const neededIngredients: ItemInstance[] = [];

    // Gather available ingredients
    for (const [matId, requiredCount] of Object.entries(recipe.materials)) {
      let foundCount = 0;
      for (let i = availableInventory.length - 1; i >= 0; i--) {
        if (foundCount >= requiredCount) break;
        if (availableInventory[i].id === matId) {
          neededIngredients.push(availableInventory.splice(i, 1)[0]);
          foundCount++;
        }
      }
    }

    // Gather available tools
    const neededTools: ItemInstance[] = [];
    if (recipe.tools) {
      for (const toolId of recipe.tools) {
        const toolIndex = availableInventory.findIndex((item) => item.id === toolId);
        if (toolIndex !== -1) {
          neededTools.push(availableInventory.splice(toolIndex, 1)[0]);
        }
      }
    }

    // Check for forge in inventory if needed
    if (recipe.requiresForge) {
      const forgeIndex = availableInventory.findIndex((item) => item.id === 'item_forge');
      if (forgeIndex !== -1) {
        neededTools.push(availableInventory.splice(forgeIndex, 1)[0]);
      }
    }

    setIngredients(neededIngredients);
    setTools(neededTools);
  };

  const handleCraft = (quantity: number) => {
    if (!player) return;

    const recipeToCraft = selectedRecipe || discoveredRecipe;

    if (!recipeToCraft) {
      if (quantity > 1) {
        logMessage('Cannot multi-craft an unknown experimental recipe.', 'error');
        return;
      }
      if (ingredients.length === 0) {
        logMessage("You haven't added any ingredients to experiment with.", 'error');
        return;
      }
      craftItem(null, 1, tools, ingredients);
      setIngredients([]);
      setTools([]);
      setSelectedRecipe(null);
      return;
    }

    if (quantity > 1 && !selectedRecipe) {
      logMessage('Multi-craft only available for known recipes selected from the list.', 'error');
      return;
    }

    if (quantity > 1 && !canCraftMultiple(quantity)) {
      logMessage(`You lack the requirements to craft ${quantity}x of ${recipeToCraft.name}.`, 'error');
      return;
    }
    if (quantity === 1 && !canCraftSingle) {
      logMessage(`You lack the requirements to craft ${recipeToCraft.name}.`, 'error');
      return;
    }

    let ingredientsToConsume: ItemInstance[] = [];
    if (quantity === 1 && discoveredRecipe) {
      ingredientsToConsume = [...ingredients];
    } else {
      let tempInventory = [...player.inventory];
      for (const [matId, count] of Object.entries(recipeToCraft.materials)) {
        const totalToConsume = count * quantity;
        let consumed = 0;
        for (let i = tempInventory.length - 1; i >= 0; i--) {
          if (consumed === totalToConsume) break;
          if (tempInventory[i].id === matId) {
            ingredientsToConsume.push(tempInventory.splice(i, 1)[0]);
            consumed++;
          }
        }
      }
    }

    craftItem(recipeToCraft, quantity, tools, ingredientsToConsume);
    setIngredients([]);
    setTools([]);
    setSelectedRecipe(null);
  };

  const handleRemoveItem = (item: ItemInstance, setFn: React.Dispatch<React.SetStateAction<ItemInstance[]>>, transferAmount: number) => {
    setFn((prev) => {
      let countToRemove = transferAmount;
      const newItems = [...prev];
      for (let i = newItems.length - 1; i >= 0; i--) {
        if (countToRemove === 0) break;
        // Compare by instance for tools, by ID for stackable ingredients
        const isTool = GAME_DATA.ITEMS[item.id].type.includes('tool');
        const match = isTool ? newItems[i] === item : newItems[i].id === item.id;
        if (match) {
          newItems.splice(i, 1);
          countToRemove--;
        }
      }
      return newItems;
    });
  };

  return {
    player,
    tools,
    setTools,
    ingredients,
    setIngredients,
    selectedRecipe,
    recipeProfession,
    setRecipeProfession,
    playerInventoryForDisplay,
    playerInventoryMap,
    groupedIngredients,
    knownRecipes,
    discoveredRecipe,
    requirementChecks,
    canCraftSingle,
    canCraftMultiple,
    handleAddItemToCraft,
    handleSelectRecipe,
    handleCraft,
    handleRemoveItem,
  };
};