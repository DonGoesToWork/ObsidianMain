import React, { useContext, useEffect, useMemo, useState } from 'react';
import { ItemInstance, ProfessionId, Recipe, UseCraftingReturn } from 'types';
import { calculateCraftSuccessChance, findDiscoveredRecipe, getCraftingChecks, getRequirementStatus } from 'utils/craftingUtils';
import { groupItems } from 'utils/itemUtils';

import { GameDataContext } from 'context/GameDataContext';
import { LogContext } from 'context/LogContext';
import { PlayerContext } from 'context/PlayerContext';
import { ProfessionsContext } from 'context/ProfessionsContext';
import { WorldContext } from 'context/WorldContext';

const MAX_TOOLS = 4;
const MAX_INGREDIENTS = 10;

export const useCrafting = (): UseCraftingReturn => {
  const { player } = useContext(PlayerContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { craftItem } = useContext(ProfessionsContext)!;
  const { currentLocation } = useContext(WorldContext)!;
  const { logMessage } = useContext(LogContext)!;

  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [tools, setTools] = useState<ItemInstance[]>([]);
  const [ingredients, setIngredients] = useState<ItemInstance[]>([]);
  const [recipeProfession, setRecipeProfession] = useState<ProfessionId>('smithing');

  const { playerInventoryForDisplay, playerInventoryMap } = useMemo(() => {
    if (!player) return { playerInventoryForDisplay: [], playerInventoryMap: [] };
    const itemsInCrafting = new Set([...tools.map((t) => t.unique_id), ...ingredients.map((i) => i.unique_id)]);
    const displayItems: ItemInstance[] = [];
    const displayMap: number[] = [];
    player.inventory.forEach((item: ItemInstance, index: number) => {
      if (!itemsInCrafting.has(item.unique_id) && !item.isUnidentified) {
        displayItems.push(item);
        displayMap.push(index);
      }
    });
    return {
      playerInventoryForDisplay: displayItems,
      playerInventoryMap: displayMap,
    };
  }, [player, tools, ingredients]);

  const groupedIngredients = useMemo(() => groupItems(ingredients, GAME_DATA), [ingredients, GAME_DATA]);

  const knownRecipes = useMemo(() => {
    if (!player) return [];
    return Object.values(GAME_DATA.ALL_RECIPES).filter((r) => r.profession === recipeProfession && player.knownRecipes[r.id]);
  }, [player?.knownRecipes, recipeProfession, GAME_DATA.ALL_RECIPES]);

  const discoveredRecipe = useMemo(() => {
    return findDiscoveredRecipe(ingredients, tools, currentLocation, GAME_DATA.ALL_RECIPES);
  }, [ingredients, tools, currentLocation, GAME_DATA.ALL_RECIPES]);

  useEffect(() => {
    if (discoveredRecipe && player?.knownRecipes[discoveredRecipe.id]) {
      setSelectedRecipe(discoveredRecipe);
    } else {
      setSelectedRecipe(null);
    }
  }, [discoveredRecipe, player?.knownRecipes]);

  const requirementChecks = useMemo(() => {
    if (!player) return {};
    const recipe = selectedRecipe || discoveredRecipe || null;
    const checks = getCraftingChecks(player, recipe, tools, currentLocation, !!selectedRecipe, GAME_DATA, { materialSource: ingredients });

    if (recipe?.profession) {
      const playerSkill = player.professions[recipe.profession].level;
      checks.dr = { ok: true, text: `DR: ${recipe.levelReq} (vs ${playerSkill})` };
      checks.success = { ok: true, text: `Success: ${calculateCraftSuccessChance(playerSkill, recipe.levelReq).toFixed(1)}%` };
      checks.failure = { ok: true, text: `Failure consumes materials.` };
    }

    return checks;
  }, [player, selectedRecipe, discoveredRecipe, tools, ingredients, currentLocation, GAME_DATA]);

  const canCraftSingle = useMemo(() => {
    const recipe = selectedRecipe || discoveredRecipe;
    if (!recipe) {
      return ingredients.length > 0;
    }
    return getRequirementStatus(requirementChecks) === 'full';
  }, [selectedRecipe, discoveredRecipe, ingredients.length, requirementChecks]);

  const canCraftMultiple = (quantity: number) => {
    if (!selectedRecipe || !player) return false;
    if (getRequirementStatus(requirementChecks) !== 'full') return false;

    const invCounts = groupItems(player.inventory, GAME_DATA);
    for (const [matId, count] of Object.entries(selectedRecipe.materials)) {
      const matKey = Object.keys(invCounts).find((k) => invCounts[k].item.id === matId);
      if (!matKey || invCounts[matKey].count < count * quantity) return false;
    }
    return true;
  };

  const handleAddItemToCraft = (itemsToAdd: ItemInstance[]) => {
    const newTools = [...tools];
    const newIngredients = [...ingredients];

    for (const item of itemsToAdd) {
      const itemData = GAME_DATA.ITEMS[item.id];
      const isTool = itemData.type.includes('tool') || item.id === 'item_forge';

      if (isTool) {
        if (!newTools.find((t) => t.unique_id === item.unique_id) && newTools.length < MAX_TOOLS) {
          newTools.push(item);
        } else if (newTools.length >= MAX_TOOLS) {
          logMessage('Tool slots are full.', 'error');
          break;
        }
      } else {
        const existingStack = newIngredients.find((i) => i.id === item.id);
        if (existingStack) {
          existingStack.quantity += item.quantity;
        } else if (newIngredients.length < MAX_INGREDIENTS) {
          newIngredients.push({ ...item });
        } else {
          logMessage('Ingredient slots are full.', 'error');
          break;
        }
      }
    }
    setTools(newTools);
    setIngredients(newIngredients);
  };

  const handleSelectRecipe = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    if (!player) return;

    const availableInventory = JSON.parse(JSON.stringify(player.inventory));
    const neededIngredients: ItemInstance[] = [];

    for (const [matId, requiredCount] of Object.entries(recipe.materials)) {
      let foundCount = 0;
      for (let i = availableInventory.length - 1; i >= 0; i--) {
        if (foundCount >= requiredCount) break;
        const item = availableInventory[i];
        if (item.id === matId) {
          const takeAmount = Math.min(item.quantity, requiredCount - foundCount);

          const existingStackInCrafting = neededIngredients.find((s) => s.id === matId);
          if (existingStackInCrafting) {
            existingStackInCrafting.quantity += takeAmount;
          } else {
            neededIngredients.push({ ...item, quantity: takeAmount });
          }

          item.quantity -= takeAmount;
          foundCount += takeAmount;

          if (item.quantity <= 0) {
            availableInventory.splice(i, 1);
          }
        }
      }
    }

    const neededTools: ItemInstance[] = [];
    if (recipe.tools) {
      for (const toolId of recipe.tools) {
        const toolIndex = availableInventory.findIndex((item: ItemInstance) => item.id === toolId);
        if (toolIndex !== -1) {
          neededTools.push(availableInventory.splice(toolIndex, 1)[0]);
        }
      }
    }

    if (recipe.requiresForge) {
      const forgeIndex = availableInventory.findIndex((item: ItemInstance) => item.id === 'item_forge');
      if (forgeIndex !== -1) {
        neededTools.push(availableInventory.splice(forgeIndex, 1)[0]);
      }
    }

    setIngredients(neededIngredients);
    setTools(neededTools);
  };

  const handleCraft = (quantity: number) => {
    if (!player) return;

    const recipeToCraft = selectedRecipe || discoveredRecipe;

    if (!recipeToCraft) {
      if (quantity > 1) {
        logMessage('Cannot multi-craft an unknown experimental recipe.', 'error');
        return;
      }
      if (ingredients.length === 0) {
        logMessage("You haven't added any ingredients to experiment with.", 'error');
        return;
      }
      craftItem(null, 1, tools, ingredients);
      setIngredients([]);
      setTools([]);
      setSelectedRecipe(null);
      return;
    }

    if (quantity > 1 && !selectedRecipe) {
      logMessage('Multi-craft only available for known recipes selected from the list.', 'error');
      return;
    }

    if (quantity > 1 && !canCraftMultiple(quantity)) {
      logMessage(`You lack the requirements to craft ${quantity}x of ${recipeToCraft.name}.`, 'error');
      return;
    }
    if (quantity === 1 && !canCraftSingle) {
      logMessage(`You lack the requirements to craft ${recipeToCraft.name}.`, 'error');
      return;
    }

    let ingredientsToConsume: ItemInstance[] = [];
    if (quantity === 1 && discoveredRecipe) {
      ingredientsToConsume = [...ingredients];
    } else {
      let tempInventory = [...player.inventory];
      for (const [matId, count] of Object.entries(recipeToCraft.materials)) {
        const totalToConsume = count * quantity;
        let consumed = 0;
        for (let i = tempInventory.length - 1; i >= 0; i--) {
          if (consumed >= totalToConsume) break;
          const item = tempInventory[i];
          if (item.id === matId) {
            const takeAmount = Math.min(item.quantity, totalToConsume - consumed);
            const existing = ingredientsToConsume.find((it) => it.id === matId);
            if (existing) {
              existing.quantity += takeAmount;
            } else {
              ingredientsToConsume.push({ ...item, quantity: takeAmount });
            }
            item.quantity -= takeAmount;
            consumed += takeAmount;
            if (item.quantity <= 0) {
              tempInventory.splice(i, 1);
            }
          }
        }
      }
    }

    craftItem(recipeToCraft, quantity, tools, ingredientsToConsume);
    setIngredients([]);
    setTools([]);
    setSelectedRecipe(null);
  };

  const handleRemoveItem = (item: ItemInstance, setFn: React.Dispatch<React.SetStateAction<ItemInstance[]>>, transferAmount: number) => {
    setFn((prev) => {
      let countToRemove = transferAmount;
      const newItems = [...prev];
      const isTool = GAME_DATA.ITEMS[item.id].type.includes('tool');

      for (let i = newItems.length - 1; i >= 0; i--) {
        if (countToRemove === 0) break;
        const currentItem = newItems[i];
        const match = isTool ? currentItem.unique_id === item.unique_id : currentItem.id === item.id;

        if (match) {
          const canRemove = Math.min(countToRemove, currentItem.quantity);
          currentItem.quantity -= canRemove;
          countToRemove -= canRemove;
          if (currentItem.quantity <= 0) {
            newItems.splice(i, 1);
          }
        }
      }
      return newItems;
    });
  };

  return {
    player,
    tools,
    setTools,
    ingredients,
    setIngredients,
    selectedRecipe,
    recipeProfession,
    setRecipeProfession,
    playerInventoryForDisplay,
    playerInventoryMap,
    groupedIngredients,
    knownRecipes,
    discoveredRecipe,
    requirementChecks,
    canCraftSingle,
    canCraftMultiple,
    handleAddItemToCraft,
    handleSelectRecipe,
    handleCraft,
    handleRemoveItem,
  };
};