import React, { useState, useEffect, useCallback, useRef, useMemo, useContext } from 'react';
import {
  AbilityId,
  StatusEffectInstance,
  Combatant,
  Limb,
  PlayerEquipmentSlot,
  CombatState,
  Player,
  Loggable,
  LogType,
  CombatContextType,
  PlayerContextType,
  UIContextType,
  LogContextType,
  MonsterId,
  WorldContextType,
  ItemInstance,
  CharacterContextType,
  InventoryContextType,
  GameData,
} from 'types';
import { createDamageMessage, isCombatantDefeated, recalculateCombatantStats, processLimbDamage, processFieldEffectsForState, isCombatEndForState } from 'utils/combatUtils';
import { processNpcTurnLogic } from 'services/combatAIService';
import { startCombatImpl, endCombatImpl, fleeCombatImpl } from '../actions/combatActions';
import { GameDataContext } from 'context/GameDataContext';

export interface CombatProviderDeps {
  player: Player | null;
  setPlayer: PlayerContextType['setPlayer'];
  currentCombat: CombatState | null;
  setCurrentCombat: React.Dispatch<React.SetStateAction<CombatState | null>>;
  logMessage: LogContextType['logMessage'];
  setActiveModal: UIContextType['setActiveModal'];
  addItemsToGround: WorldContextType['addItemsToGround'];
  gainXp: CharacterContextType['gainXp'];
  gainMercenaryXp: any; // from party context
  addGold: CharacterContextType['addGold'];
  updateQuestProgress: CharacterContextType['updateQuestProgress'];
  removeItem: InventoryContextType['removeItem'];
  passTime: WorldContextType['passTime'];
  damageItemDurability: InventoryContextType['damageItemDurability'];
  applyStatusEffect: CharacterContextType['applyStatusEffect'];
  endTurnCallbackRef: React.MutableRefObject<(() => void) | null>;
  changeGameState: WorldContextType['changeGameState'];
  currentLocation: WorldContextType['currentLocation'];
}

export const useCombatProviderLogic = (deps: CombatProviderDeps) => {
  const depsRef = useRef(deps);
  depsRef.current = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const [selectedTargetId, setSelectedTargetId] = useState<string | null>(null);
  const [selectedLimbId, setSelectedLimbId] = useState<string | null>(null);
  const [selectedAction, setSelectedAction] = useState<CombatState['selectedAction']>(null);

  const combatStateRef = useRef(deps.currentCombat);
  useEffect(() => {
    combatStateRef.current = deps.currentCombat;
  }, [deps.currentCombat]);

  const applyStateChange = useCallback(
    (changeFn: (cs: CombatState) => CombatState | null) => {
      depsRef.current.setCurrentCombat((c) => (c ? changeFn(c) : c));
    },
    [],
  );

  const endCombat = useCallback(
    (victory: boolean) => {
      const {
        currentCombat,
        player,
        logMessage,
        setCurrentCombat,
        setPlayer,
        removeItem,
        changeGameState,
        currentLocation,
        gainXp,
        gainMercenaryXp,
        addGold,
        addItemsToGround,
        updateQuestProgress,
      } = depsRef.current;
      endCombatImpl(
        {
          currentCombat,
          player,
          logMessage,
          setCurrentCombat,
          setPlayer,
          removeItem,
          changeGameState,
          currentLocation,
          gainXp,
          gainMercenaryXp,
          addGold,
          addItemsToGround,
          updateQuestProgress,
          GAME_DATA,
        } as any,
        { victory },
      );
    },
    [GAME_DATA],
  );

  const checkCombatEnd = useCallback(
    (state?: CombatState) => {
      const combat = state || combatStateRef.current;
      if (!combat) return true;
      if (isCombatEndForState(combat)) {
        const victory = Object.values(combat.combatants).filter((c: Combatant) => c.team === 'player' && !isCombatantDefeated(c)).length > 0;
        endCombat(victory);
        return true;
      }
      return false;
    },
    [endCombat],
  );

  const endPlayerTurn = useCallback(
    (lastAction?: Player['lastAction']) => {
      if (!combatStateRef.current) return;
      const { setPlayer } = depsRef.current;
      setPlayer((p) => (p ? { ...p, lastAction: lastAction || null } : p));
      applyStateChange((c) => (c ? { ...c, isPlayerTurn: false } : c));
    },
    [applyStateChange],
  );

  deps.endTurnCallbackRef.current = () => endPlayerTurn();

  const startPlayerTurn = useCallback(
    (cs?: CombatState) => {
      const combatState = cs || combatStateRef.current;
      if (!combatState || checkCombatEnd(combatState)) return;

      const playerCombatant = combatState.combatants['player'];
      if (isCombatantDefeated(playerCombatant)) {
        endPlayerTurn();
        return;
      }

      applyStateChange((c) => (c ? { ...c, fieldEffects: processFieldEffectsForState(c.fieldEffects) } : c));
      if (checkCombatEnd()) return;

      depsRef.current.logMessage('Your turn.', 'combat');
      applyStateChange((c) => (c ? { ...c, isPlayerTurn: true } : c));
    },
    [checkCombatEnd, applyStateChange, endPlayerTurn],
  );

  const executeNpcTurns = useCallback(() => {
    if (!combatStateRef.current || checkCombatEnd()) return;
    let combatState: CombatState = { ...combatStateRef.current };
    const npcs = combatState.turnOrder.slice(1);
    const { logMessage, setCurrentCombat, passTime } = depsRef.current;

    for (const npcId of npcs) {
      if (isCombatantDefeated(combatState.combatants[npcId])) continue;
      combatState = {
        ...combatState,
        fieldEffects: processFieldEffectsForState(combatState.fieldEffects),
      };
      if (isCombatEndForState(combatState)) break;

      const { newState, logs: turnLogs } = processNpcTurnLogic(combatState, npcId, GAME_DATA);
      combatState = newState;
      turnLogs.forEach((log) => logMessage(log.message, log.type));

      if (isCombatEndForState(combatState)) break;
    }
    setCurrentCombat(combatState);
    if (!isCombatEndForState(combatState)) {
      passTime(0.1);
      startPlayerTurn(combatState);
    } else {
      checkCombatEnd(combatState);
    }
  }, [checkCombatEnd, startPlayerTurn, GAME_DATA]);

  useEffect(() => {
    const { currentCombat } = depsRef.current;
    if (currentCombat && !currentCombat.isPlayerTurn && currentCombat.isActive) {
      if (combatStateRef.current?.isActive) executeNpcTurns();
    }
  }, [deps.currentCombat?.isPlayerTurn, deps.currentCombat?.isActive, executeNpcTurns]);

  const playerAttack = useCallback(
    (targetId: string, limbId: string, isRandom: boolean) => {
      if (!combatStateRef.current || !combatStateRef.current.isPlayerTurn) return;
      const playerCombatant = combatStateRef.current.combatants['player'];
      const target = combatStateRef.current.combatants[targetId];
      if (!target) return;
      const isCrit = Math.random() < playerCombatant.totalStats.critChance / 100;
      const damage = playerCombatant.totalStats.attackPower * (isCrit ? 1.5 : 1);

      let combatEnded = false;
      applyStateChange((c) => {
        if (!c) return c;
        let t = c.combatants[targetId];
        if (!t.body[limbId] || t.body[limbId].state === 'Destroyed') return c;
        const { updatedLimb, logMessages } = processLimbDamage(t.body[limbId], damage, [], t.name, GAME_DATA);
        logMessages.forEach((msg) => depsRef.current.logMessage(msg));
        t.body[limbId] = updatedLimb;
        if (isCombatEndForState(c)) combatEnded = true;
        return c;
      });
      if (combatEnded) checkCombatEnd();

      depsRef.current.logMessage(createDamageMessage(playerCombatant.name, target.name, target.body[limbId].displayName, damage, isCrit), 'combat');
      endPlayerTurn({
        type: 'attack',
        skillId: null,
        targetId,
        limbId,
        isRandom,
      });
    },
    [applyStateChange, endPlayerTurn, checkCombatEnd, GAME_DATA],
  );

  const playerUseSkill = useCallback(
    (abilityId: AbilityId, targetId: string | null, limbId: string | null, isRandom: boolean) => {
      if (!combatStateRef.current || !combatStateRef.current.isPlayerTurn || !targetId) return;
      const { player } = depsRef.current;
      const abilityData = GAME_DATA.SKILLS[abilityId];
      depsRef.current.logMessage(`${player?.name} uses ${abilityData.name}!`, 'combat');
      endPlayerTurn({ type: 'skill', skillId: abilityId, targetId, limbId, isRandom });
    },
    [endPlayerTurn, GAME_DATA.SKILLS],
  );

  const playerTargetRandomLimb = useCallback(
    (targetId: string, actionType: 'attack' | 'skill', abilityId: AbilityId | null) => {
      const target = combatStateRef.current?.combatants[targetId];
      if (!target) return;
      const validLimbs = Object.values(target.body).filter((l) => l.state !== 'Destroyed');
      if (validLimbs.length > 0) {
        const randomLimb = validLimbs[Math.floor(Math.random() * validLimbs.length)];
        if (actionType === 'attack') playerAttack(targetId, randomLimb.id, true);
        else if (abilityId) playerUseSkill(abilityId, targetId, randomLimb.id, true);
      }
    },
    [playerAttack, playerUseSkill],
  );

  const playerRepeatLastAction = useCallback(() => {
    const { player } = depsRef.current;
    if (!player?.lastAction) return;
    const { type, skillId, targetId, limbId, isRandom } = player.lastAction;
    if (isRandom) playerTargetRandomLimb(targetId, type, skillId || null);
    else if (type === 'attack' && limbId) playerAttack(targetId, limbId, false);
    else if (skillId) playerUseSkill(skillId, targetId, limbId, false);
  }, [playerTargetRandomLimb, playerAttack, playerUseSkill]);

  const playerFlee = useCallback(() => {
    const { currentCombat, player, logMessage, removeItem, setCurrentCombat, setPlayer, changeGameState, currentLocation } = depsRef.current;
    fleeCombatImpl(
      {
        currentCombat,
        player,
        logMessage,
        removeItem,
        setCurrentCombat,
        setPlayer,
        changeGameState,
        currentLocation,
        GAME_DATA,
      },
      {},
    );
  }, [GAME_DATA]);

  useEffect(() => {
    const { currentCombat } = depsRef.current;
    if (currentCombat?.isActive && !selectedTargetId) {
      setSelectedTargetId(currentCombat.turnOrder.find((id) => currentCombat.combatants[id].team === 'enemy') || null);
    }
  }, [deps.currentCombat, selectedTargetId]);

  const startCombat = useCallback(
    (monsterPack: MonsterId[], options?: { zoneId?: string; source?: 'rest' | 'wilds' }) => {
      const { player, logMessage, changeGameState, setCurrentCombat } = depsRef.current;
      startCombatImpl({ player, logMessage, changeGameState, setCurrentCombat, GAME_DATA }, { monsterPack, options });
    },
    [GAME_DATA],
  );

  const combatContextValue: CombatContextType = useMemo(
    () => ({
      currentCombat: deps.currentCombat,
      setCurrentCombat: deps.setCurrentCombat,
      startCombat,
      endCombat,
      fleeCombat: playerFlee,
      playerActionTaken: () => {},
      endTurnCallbackRef: deps.endTurnCallbackRef,
      enemies: deps.currentCombat ? Object.values(deps.currentCombat.combatants).filter((c: Combatant) => c.team === 'enemy') : [],
      selectedTargetId,
      setSelectedTargetId,
      selectedLimbId,
      setSelectedLimbId,
      playerAttack,
      playerUseSkill,
      endPlayerTurn,
      playerFlee,
      playerTargetRandomLimb,
      playerRepeatLastAction,
      setSelectedAction,
      selectedAction,
    }),
    [
      deps.currentCombat,
      deps.setCurrentCombat,
      startCombat,
      endCombat,
      playerFlee,
      deps.endTurnCallbackRef,
      selectedTargetId,
      selectedLimbId,
      playerAttack,
      playerUseSkill,
      endPlayerTurn,
      playerTargetRandomLimb,
      playerRepeatLastAction,
      selectedAction,
    ],
  );

  return { combatContextValue, startCombat };
};