import { GameDataContext } from 'context/GameDataContext';
import { useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { calculateXpToNextLevel } from 'services/statService';
import { EnchantDef, EnchantmentRecipeId, GameLocation, GameSideEffect, ItemInstance, Player, ProfessionId, Recipe, RecipeId } from '../../types';
import { craftItem as craftItemAction } from '../actions/professions/craft';
import { enchantItem as enchantItemAction } from '../actions/professions/enchant';
import { identifyAllItems as identifyAllItemsAction } from '../actions/professions/identify';
import { learnEnchantmentRecipe, learnRecipe as learnRecipeAction } from '../actions/professions/learn';
import { repairAllItems as repairAllItemsAction, repairItem as repairItemAction } from '../actions/professions/repair';
import { upgradeItem as upgradeItemAction } from '../actions/professions/upgrade';

interface ProfessionsProviderDeps {
  player: Player | null;
  setPlayer: (update: React.SetStateAction<Player | null>) => void;
  currentLocation: GameLocation | null;
  queueSideEffects: (effects: GameSideEffect[]) => void;
  withActionLock: <T>(action: () => T) => T | undefined;
}

export const useProfessionsProviderLogic = (deps: ProfessionsProviderDeps) => {
  const depsRef = useRef(deps);
  depsRef.current = deps;
  const GAME_DATA = useContext(GameDataContext)!;
  const { withActionLock } = deps;
  const [onEnchantComplete, setOnEnchantComplete] = useState<{ cb: (item: ItemInstance | null) => void; item: ItemInstance | null } | null>(null);

  useEffect(() => {
    if (onEnchantComplete) {
      onEnchantComplete.cb(onEnchantComplete.item);
      setOnEnchantComplete(null);
    }
  }, [onEnchantComplete]);

  const gainProfessionXp = useCallback((professionId: ProfessionId, amount: number) => {
    depsRef.current.setPlayer((p) => {
      if (!p) return p;
      const newPlayer = { ...p };
      const profState = newPlayer.professions[professionId];
      if (!profState) return p;

      profState.xp += amount;

      const percent = ((profState.xp / profState.xpToNextLevel) * 100).toFixed(0);
      depsRef.current.queueSideEffects([
        {
          type: 'LOG',
          message: {
            floatingText: `+${amount} ${professionId}`,
            detailedText: `+${amount} ${professionId} Exp - ${percent}% to next level - ${profState.xp}/${profState.xpToNextLevel}`,
          },
          logType: 'skill',
        },
      ]);

      while (profState.xp >= profState.xpToNextLevel) {
        profState.xp -= profState.xpToNextLevel;
        profState.level++;
        profState.xpToNextLevel = calculateXpToNextLevel(profState.level);
        depsRef.current.queueSideEffects([
          {
            type: 'LOG',
            message: `${professionId.charAt(0).toUpperCase() + professionId.slice(1)} skill increased to ${profState.level}!`,
            logType: 'skill',
          },
        ]);
      }

      return newPlayer;
    });
  }, []);

  const craftItem = useCallback(
    (recipe: Recipe | null, quantity: number, tools: ItemInstance[], ingredients: ItemInstance[]) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = craftItemAction(p, recipe, quantity, tools, ingredients, GAME_DATA);
          depsRef.current.queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );

  const repairItem = useCallback(
    (targetItem: ItemInstance, materials: ItemInstance[], tools: ItemInstance[]) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = repairItemAction(p, targetItem, materials, tools, GAME_DATA);
          if (!result) return p;
          depsRef.current.queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );

  const repairAllItems = useCallback(() => {
    withActionLock(() => {
      const { currentLocation, queueSideEffects } = depsRef.current;
      if (currentLocation) {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = repairAllItemsAction(p, GAME_DATA, currentLocation);
          queueSideEffects(result.sideEffects);
          return result.player;
        });
      } else {
        queueSideEffects([{ type: 'LOG', message: 'Cannot repair all items: location data is missing.', logType: 'error' }]);
      }
    });
  }, [GAME_DATA, withActionLock]);

  const upgradeItem = useCallback(
    (targetItem: ItemInstance) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = upgradeItemAction(p, targetItem, GAME_DATA);
          if (!result) return p;
          depsRef.current.queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );

  const enchantItem = useCallback(
    (itemUniqueId: string, enchantDef: EnchantDef, enchantRank: number, onComplete?: (newItem: ItemInstance | null) => void) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = enchantItemAction(p, itemUniqueId, enchantDef, enchantRank, GAME_DATA);
          if (!result) {
            if (onComplete) {
              setOnEnchantComplete({ cb: onComplete, item: null });
            }
            return p;
          }
          depsRef.current.queueSideEffects(result.sideEffects);
          if (onComplete) {
            setOnEnchantComplete({ cb: onComplete, item: result.newItem || null });
          }
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );

  const identifyAllItems = useCallback(
    (cost: number) => {
      withActionLock(() => {
        depsRef.current.setPlayer((p) => {
          if (!p) return p;
          const result = identifyAllItemsAction(p, cost, GAME_DATA);
          if (!result) return p;
          depsRef.current.queueSideEffects(result.sideEffects);
          return result.player;
        });
      });
    },
    [GAME_DATA, withActionLock]
  );

  const learnRecipe = useCallback(
    (recipeId: RecipeId) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = learnRecipeAction(p, recipeId, GAME_DATA);
        if (!result) return p;
        depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA]
  );

  const learnEnchantment = useCallback(
    (enchantmentRecipeId: EnchantmentRecipeId) => {
      depsRef.current.setPlayer((p) => {
        if (!p) return p;
        const result = learnEnchantmentRecipe(p, enchantmentRecipeId, GAME_DATA);
        if (!result) return p;
        depsRef.current.queueSideEffects(result.sideEffects);
        return result.player;
      });
    },
    [GAME_DATA]
  );

  return useMemo(
    () => ({
      craftItem,
      repairItem,
      repairAllItems,
      upgradeItem,
      enchantItem,
      identifyAllItems,
      gainProfessionXp: gainProfessionXp,
      learnRecipe,
      learnEnchantment,
    }),
    [craftItem, repairItem, repairAllItems, upgradeItem, enchantItem, identifyAllItems, gainProfessionXp, learnRecipe, learnEnchantment]
  );
};