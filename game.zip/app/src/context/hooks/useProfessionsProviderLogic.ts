import { useCallback, useMemo, useContext } from 'react';
import { Player, Recipe, ItemInstance, ProfessionId, RecipeId, GameData } from 'types';
import { gainProfessionXpImpl } from '../actions/characterActions';
import { craftItemImpl } from '../actions/professions/craft';
import { enchantItemImpl } from '../actions/professions/enchant';
import { identifyAllItemsImpl, identifyItemImpl } from '../actions/professions/identify';
import { learnRecipeImpl } from '../actions/professions/learn';
import { repairItemImpl } from '../actions/professions/repair';
import { upgradeItemImpl } from '../actions/professions/upgrade';
import { GameDataContext } from 'context/GameDataContext';

interface ProfessionsProviderDeps {
  setPlayer: (update: React.SetStateAction<Player | null>) => void;
  logMessage: (message: any, type?: any) => void;
}

export const useProfessionsProviderLogic = (deps: ProfessionsProviderDeps) => {
  const { setPlayer, logMessage } = deps;
  const GAME_DATA = useContext(GameDataContext)!;

  const gainProfessionXp = useCallback(
    (professionId: ProfessionId, amount: number) => gainProfessionXpImpl(professionId, amount, setPlayer, logMessage),
    [setPlayer, logMessage]
  );

  const craftItem = useCallback(
    (recipe: Recipe, quantity: number, tools: ItemInstance[], ingredients: ItemInstance[]) =>
      craftItemImpl(recipe, quantity, tools, ingredients, setPlayer, logMessage, gainProfessionXp, GAME_DATA),
    [setPlayer, logMessage, gainProfessionXp, GAME_DATA]
  );

  const repairItem = useCallback(
    (targetItem: ItemInstance, materials: ItemInstance[], tools: ItemInstance[]) =>
      repairItemImpl(targetItem, materials, tools, setPlayer, logMessage, gainProfessionXp, GAME_DATA),
    [setPlayer, logMessage, gainProfessionXp, GAME_DATA]
  );

  const upgradeItem = useCallback(
    (targetItem: ItemInstance) => upgradeItemImpl(targetItem, setPlayer, logMessage, gainProfessionXp, GAME_DATA),
    [setPlayer, logMessage, gainProfessionXp, GAME_DATA]
  );

  const enchantItem = useCallback(
    (itemUniqueId: string, enchantDef: any, enchantRank: number) => enchantItemImpl(itemUniqueId, enchantDef, enchantRank, setPlayer, logMessage, gainProfessionXp, GAME_DATA),
    [setPlayer, logMessage, gainProfessionXp, GAME_DATA]
  );

  const identifyItem = useCallback(
    (itemUniqueId: string) => identifyItemImpl(itemUniqueId, setPlayer, logMessage, gainProfessionXp, GAME_DATA),
    [setPlayer, logMessage, gainProfessionXp, GAME_DATA]
  );

  const identifyAllItems = useCallback(
    (cost: number) => identifyAllItemsImpl(cost, setPlayer, logMessage, gainProfessionXp, GAME_DATA),
    [setPlayer, logMessage, gainProfessionXp, GAME_DATA]
  );

  const learnRecipe = useCallback((recipeId: RecipeId) => learnRecipeImpl(recipeId, setPlayer, logMessage, GAME_DATA), [setPlayer, logMessage, GAME_DATA]);

  return useMemo(
    () => ({
      craftItem,
      repairItem,
      upgradeItem,
      enchantItem,
      identifyItem,
      identifyAllItems,
      gainProfessionXp,
      learnRecipe,
    }),
    [craftItem, repairItem, upgradeItem, enchantItem, identifyItem, identifyAllItems, gainProfessionXp, learnRecipe]
  );
};
