import { createLocationFromZone } from 'utils/locationUtils';
import { calculateDistance } from 'utils/mathUtils';
import { LogContextType, Mercenary, Player, PlayerContextType, UIContextType, WorldContextType, Zone } from '../../types';

type WorldActionContext = Pick<
  WorldContextType,
  'getZoneData' | 'currentLocation' | 'passTime' | 'setCurrentLocation' | 'changeGameState' | 'gameTime' | 'setGeneratedZones'
> &
  Pick<LogContextType, 'logMessage'> &
  Pick<UIContextType, 'setActiveModal'> &
  Pick<PlayerContextType, 'player' | 'setPlayer'>;

function proceedWithTravel(context: WorldActionContext, payload: { locationId: string }) {
  const { player, getZoneData, logMessage, currentLocation, passTime, setCurrentLocation, changeGameState, setPlayer, gameTime } = context;
  const { locationId } = payload;
  if (!player) return;

  const zoneData = getZoneData(locationId);
  if (!zoneData) {
    logMessage(`Error: Could not find location data for ${locationId}`, 'error');
    return;
  }

  const destinationName = zoneData.name;
  logMessage(`Traveling to ${destinationName}...`, 'info');

  if (currentLocation) {
    passTime(Math.round(calculateDistance(currentLocation.pos, zoneData.pos)));
  }

  setPlayer((p: Player | null) => {
    if (!p) return p;

    const newPlayerState = { ...p };

    // Save state of current location
    if (currentLocation) {
      newPlayerState.locationStates = {
        ...(newPlayerState.locationStates || {}),
        [currentLocation.id]: {
          groundLoot: currentLocation.groundLoot,
          groundLootTimestamp: currentLocation.groundLootTimestamp,
        },
      };
    }

    // Create new location and load its state
    const newLocation = createLocationFromZone(locationId, zoneData);
    const locationState = newPlayerState.locationStates?.[locationId];

    if (locationState) {
      const oneDay = 24 * 60 * 60 * 1000;
      const now = gameTime.getTime();

      if (locationState.groundLootTimestamp && now - locationState.groundLootTimestamp < oneDay) {
        newLocation.groundLoot = locationState.groundLoot;
        newLocation.groundLootTimestamp = locationState.groundLootTimestamp;
      }
    }

    setCurrentLocation(newLocation);
    changeGameState(newLocation.type);
    logMessage(`You have arrived at ${zoneData.name}.`, 'info');

    return newPlayerState;
  });
}

function handleBleedingTravelConsequences(bleedingCharacters: (Player | Mercenary)[], context: WorldActionContext) {
  const { setPlayer, logMessage } = context;

  let fameLoss = 0;
  const deadMercNames: string[] = [];

  const playerIsBleeding = bleedingCharacters.some((c) => 'professions' in c);

  for (const char of bleedingCharacters) {
    if ('mercenaryId' in char) {
      deadMercNames.push(char.name);
      fameLoss += 100;
    }
  }

  if (deadMercNames.length > 0) {
    logMessage(`${deadMercNames.join(', ')} died from their wounds during travel.`, 'error');
  }

  setPlayer((p) => {
    if (!p) return null;
    let newPlayer = { ...p };

    newPlayer.party = newPlayer.party.filter((merc) => !deadMercNames.includes(merc.name));

    if (fameLoss > 0) {
      newPlayer.fame = (newPlayer.fame || 0) - fameLoss;
      logMessage(`Your fame has decreased by ${fameLoss} for abandoning your companions.`, 'error');
    }

    if (playerIsBleeding) {
      logMessage('You have died from your wounds during travel.', 'error');
      // Set all limbs to 0 HP to trigger death state.
      Object.values(newPlayer.body).forEach((limb) => (limb.currentHp = 0));
    }

    return newPlayer;
  });
}

export function travelToImpl(context: WorldActionContext, payload: { locationId: string }) {
  const { player, logMessage, setActiveModal } = context;
  if (!player) return;

  if (player.currentWeight > player.maxCarryWeight) {
    logMessage(
      {
        floatingText: 'Encumbered!',
        detailedText: 'You are too encumbered to travel.',
      },
      'error'
    );
    return;
  }

  const bleedingCharacters: (Player | Mercenary)[] = [];
  const allChars = [player, ...player.party];
  for (const char of allChars) {
    const hasBleed = Object.values(char.body).some((limb) => limb.statusEffects.some((se) => se.id === 'external_bleed'));
    if (hasBleed) {
      bleedingCharacters.push(char);
    }
  }

  if (bleedingCharacters.length > 0) {
    const firstBleeding = bleedingCharacters[0];
    setActiveModal(
      'confirmation-modal',
      {
        title: 'Travel Warning',
        message: `${firstBleeding.name} is bleeding. Are you sure you would like to travel? This will be fatal.`,
        onConfirm: () => {
          handleBleedingTravelConsequences(bleedingCharacters, context);
          setActiveModal(null);
          const playerDied = bleedingCharacters.some((c) => 'professions' in c);
          if (!playerDied) {
            proceedWithTravel(context, payload);
          }
        },
        onCancel: () => setActiveModal(null),
      },
      { history: true }
    );
    return;
  }

  proceedWithTravel(context, payload);
}

export function generateNewZoneImpl(context: Pick<WorldContextType, 'setGeneratedZones'> & Pick<LogContextType, 'logMessage'>, payload: { level: number }) {
  const { setGeneratedZones, logMessage } = context;
  const { level } = payload;
  const zoneId = `gen_${Date.now()}`;
  const zoneType = Math.random() < 0.3 ? 'dungeon' : 'wilderness';
  const newZone: Zone = {
    name: `Generated Zone (Lvl ${level})`,
    levelReq: level,
    pos: {
      x: Math.round((Math.random() - 0.5) * 60),
      y: Math.round((Math.random() - 0.5) * 60),
    },
    type: zoneType,
    gather: [],
    monsterPacks: [],
    dangerLevel: 0.05 + level * 0.01,
  };

  setGeneratedZones((prev: Record<string, Zone>) => ({ ...prev, [zoneId]: newZone }));
  logMessage(`A new area has been discovered: ${newZone.name}`, 'quest');
}
