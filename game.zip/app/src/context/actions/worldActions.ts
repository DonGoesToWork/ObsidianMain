import { GameLocation, Player, Zone } from "../../types";
import { calculateDistance } from "utils/mathUtils";
import { createLocationFromZone } from "utils/locationUtils";
import { WorldContextType, LogContextType, PlayerContextType } from "../../types";
import { LogType, Loggable } from "types/game";

type WorldActionContext = Pick<
  WorldContextType,
  | "getZoneData"
  | "currentLocation"
  | "passTime"
  | "setCurrentLocation"
  | "changeGameState"
  | "gameTime"
  | "setGeneratedZones"
> &
  Pick<LogContextType, "logMessage"> &
  Pick<PlayerContextType, "player" | "setPlayer">;

export function travelToImpl(context: WorldActionContext, payload: { locationId: string }) {
  const { player, getZoneData, logMessage, currentLocation, passTime, setCurrentLocation, changeGameState, setPlayer, gameTime } = context;
  const { locationId } = payload;
  if (!player) return;
  if (player.currentWeight > player.maxWeight) {
    logMessage(
      {
        floatingText: "Encumbered!",
        detailedText: "You are too encumbered to travel.",
      },
      "error",
    );
    return;
  }

  const zoneData = getZoneData(locationId);
  if (!zoneData) {
    logMessage(`Error: Could not find location data for ${locationId}`, "error");
    return;
  }

  const destinationName = zoneData.name;
  logMessage(`Traveling to ${destinationName}...`, "info");

  if (currentLocation) {
    passTime(Math.round(calculateDistance(currentLocation.pos, zoneData.pos)));
  }

  setPlayer((p: Player | null) => {
    if (!p) return p;

    const newPlayerState = { ...p };

    // Save state of current location
    if (currentLocation) {
      newPlayerState.locationStates = {
        ...(newPlayerState.locationStates || {}),
        [currentLocation.id]: {
          groundLoot: currentLocation.groundLoot,
          groundLootTimestamp: currentLocation.groundLootTimestamp,
        },
      };
    }

    // Create new location and load its state
    const newLocation = createLocationFromZone(locationId, zoneData);
    const locationState = newPlayerState.locationStates?.[locationId];

    if (locationState) {
      const oneDay = 24 * 60 * 60 * 1000;
      const now = gameTime.getTime();

      if (locationState.groundLootTimestamp && now - locationState.groundLootTimestamp < oneDay) {
        newLocation.groundLoot = locationState.groundLoot;
        newLocation.groundLootTimestamp = locationState.groundLootTimestamp;
      }
    }

    setCurrentLocation(newLocation);
    changeGameState(newLocation.type);
    logMessage(`You have arrived at ${zoneData.name}.`, "info");

    newPlayerState.location = newLocation;
    return newPlayerState;
  });
}

export function generateNewZoneImpl(context: Pick<WorldContextType, "setGeneratedZones"> & Pick<LogContextType, "logMessage">, payload: { level: number }) {
  const { setGeneratedZones, logMessage } = context;
  const { level } = payload;
  const zoneId = `gen_${Date.now()}`;
  const zoneType = Math.random() < 0.3 ? "dungeon" : "wilderness";
  const newZone: Zone = {
    name: `Generated Zone (Lvl ${level})`,
    levelReq: level,
    pos: {
      x: Math.round((Math.random() - 0.5) * 60),
      y: Math.round((Math.random() - 0.5) * 60),
    },
    type: zoneType,
    gather: [],
    monsterPacks: [],
    dangerLevel: 0.05 + level * 0.01,
  };

  setGeneratedZones((prev: Record<string, Zone>) => ({ ...prev, [zoneId]: newZone }));
  logMessage(`A new area has been discovered: ${newZone.name}`, "quest");
}