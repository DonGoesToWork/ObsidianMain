import {
  AppraiseOptions,
  Limb,
  Mercenary,
  Player,
  RestOptions,
  StatusEffectInstance,
  WorldContextType,
  PlayerContextType,
  UIContextType,
  LogContextType,
  GameData,
  CombatContextType,
  Loggable,
  LogType,
  ItemInstance,
} from '../../types';
import { calculateCharacterStats, calculateXpToNextLevel } from '../../services/statService';
import { formatDuration } from 'utils/formatUtils';
import { isCombatantDefeated } from 'utils/combatUtils';
import { deepCloneWithInfinity } from 'utils/mathUtils';
import { calculateItemLevel } from 'utils/itemUtils';
import { calculateDifficultyBonus } from 'utils/gameMechanics';

type TimeActionContext = Pick<WorldContextType, 'gameTime' | 'setGameTime' | 'currentLocation'> &
  Pick<PlayerContextType, 'player' | 'setPlayer'> &
  Pick<CombatContextType, 'startCombat'> &
  Pick<UIContextType, 'setActiveModal'> &
  Pick<LogContextType, 'logMessage'> & { GAME_DATA: GameData };

const THIRST_DECAY_PER_MINUTE = 100 / (72 * 60); // 100 points over 72 hours
const HUNGER_DECAY_PER_MINUTE = 100 / (7 * 24 * 60); // 100 points over 1 week

// Helper to process 1 minute of non-critical effects for a character.
function processMinuteEffects(char: Player | Mercenary, isResting: boolean, quality: number, GAME_DATA: GameData, logMessage: (message: Loggable, type?: LogType) => void) {
  // 1. Vitals
  if (char.vitals) {
    char.vitals.thirst.current = Math.max(0, char.vitals.thirst.current - THIRST_DECAY_PER_MINUTE);
    char.vitals.hunger.current = Math.max(0, char.vitals.hunger.current - HUNGER_DECAY_PER_MINUTE);
  }

  // 2. Status Effect Durations
  const processDurations = (effects: StatusEffectInstance[]) => {
    let healedCuts: StatusEffectInstance[] = [];
    const remainingEffects = effects
      .map((b) => {
        if (b.durationInMinutes > 0 && b.durationInMinutes !== Infinity) {
          const newDuration = parseFloat((b.durationInMinutes - 1).toPrecision(15));
          if (b.id === 'cut' && newDuration <= 0) {
            healedCuts.push({ ...b, durationInMinutes: 0 });
            return null;
          }
          return { ...b, durationInMinutes: newDuration };
        }
        return b;
      })
      .filter((b): b is StatusEffectInstance => {
        if (!b) return false;
        if (b.id === 'external_bleed') return true; // Bleeds are handled by ticks, not duration.
        return (b.durationInMinutes || 0) > 0.001 || b.durationInMinutes === Infinity || b.turnsRemaining === Infinity;
      });
    return { remainingEffects, healedCuts };
  };

  char.statusEffects = processDurations(char.statusEffects).remainingEffects;
  Object.values(char.body).forEach((limb: any) => {
    const { remainingEffects, healedCuts } = processDurations(limb.statusEffects);
    limb.statusEffects = remainingEffects;

    if (healedCuts.length > 0) {
      healedCuts.forEach((healedCut) => {
        const newStage = healedCut.currentStage! - 1;
        if (newStage > 0) {
          const newDurations = { 1: 30, 2: 24 * 60, 3: 24 * 60, 4: 24 * 60 };
          const newCut: StatusEffectInstance = { ...healedCut, currentStage: newStage, durationInMinutes: newDurations[newStage as keyof typeof newDurations] };
          if (healedCut.isClosed) newCut.isClosed = true; // Preserve patched state
          limb.statusEffects.push(newCut);

          logMessage(
            `The ${GAME_DATA.STATUS_EFFECTS.cut.stages![healedCut.currentStage! - 1].name.toLowerCase()} on ${char.name}'s ${
              limb.displayName
            } has healed into a ${GAME_DATA.STATUS_EFFECTS.cut.stages![newStage - 1].name.toLowerCase()}.`,
            'heal'
          );

          const linkedBleed = limb.statusEffects.find((se: any) => se.linkedToInstanceId === healedCut.instanceId);
          if (linkedBleed) {
            const newBleedStage = newStage - 1;
            if (newBleedStage > 0) {
              linkedBleed.currentStage = newBleedStage;
            } else {
              limb.statusEffects = limb.statusEffects.filter((se: any) => se.instanceId !== linkedBleed.instanceId);
            }
          }
        } else {
          logMessage(`The ${GAME_DATA.STATUS_EFFECTS.cut.stages![healedCut.currentStage! - 1].name.toLowerCase()} on ${char.name}'s ${limb.displayName} has fully healed.`, 'heal');
          limb.statusEffects = limb.statusEffects.filter((se: any) => se.linkedToInstanceId !== healedCut.instanceId);
        }
      });
    }
  });

  // 3. Regeneration
  const calculatedChar = calculateCharacterStats(char, GAME_DATA)!;
  const regenMultiplier = isResting ? 3 * quality : 1;
  const hpRegenPerMinute = (calculatedChar.totalStats.worldHpRegen || 0) * regenMultiplier;
  (Object.values(char.body) as Limb[]).forEach((limb) => {
    if ((limb.state === 'Healthy' || limb.state === 'Injured') && limb.currentHp < limb.maxHp) {
      limb.currentHp = Math.min(limb.maxHp, limb.currentHp + hpRegenPerMinute);
      if (limb.currentHp >= limb.maxHp) {
        limb.state = 'Healthy';
      }
    }
  });
  char.mp = Math.min(calculatedChar.maxMp, char.mp + (calculatedChar.totalStats.worldMpRegen || 0) * regenMultiplier);
  char.sp = Math.min(calculatedChar.maxSp, char.sp + (calculatedChar.totalStats.worldSpRegen || 0) * regenMultiplier);
}

// Helper function to process bleed damage for a single character over one 6-second tick.
function processBleedTick(char: Player | Mercenary, GAME_DATA: GameData): number {
  let bleedDamageAmount = 0;
  const totalMaxHp = Object.values(char.body).reduce((sum: number, l: any) => sum + l.maxHp, 0);
  if (totalMaxHp === 0) return 0;

  const allCuts = Object.values(char.body).flatMap((l: any) => l.statusEffects.filter((se: StatusEffectInstance) => se.id === 'cut'));

  Object.values(char.body).forEach((limb: any) => {
    limb.statusEffects.forEach((effect: StatusEffectInstance) => {
      if (effect.id !== 'external_bleed') return;

      const linkedCut = allCuts.find((c: any) => c.instanceId === effect.linkedToInstanceId);
      if (linkedCut && linkedCut.isClosed) return;

      const stageIndex = (effect.currentStage || 1) - 1;
      const bleedStageData = GAME_DATA.STATUS_EFFECTS.external_bleed.stages![stageIndex];
      if (bleedStageData.effects?.onTurn?.type === 'damage_percent_max_hp') {
        const percent = (bleedStageData.effects.onTurn as any).percent;
        const damage = totalMaxHp * (percent / 100);
        bleedDamageAmount += damage;

        let limbToDamage: Limb = limb;
        if (limbToDamage.state === 'Destroyed') {
          const torso = Object.values(char.body).find((l: any) => l.id === 'torso' || l.id === 'body');
          limbToDamage =
            (torso as Limb) && (torso as Limb).state !== 'Destroyed' ? (torso as Limb) : (Object.values(char.body).find((l: any) => l.state !== 'Destroyed') as Limb);
        }

        if (limbToDamage) {
          const oldHp = limbToDamage.currentHp;
          limbToDamage.currentHp = Math.max(0, limbToDamage.currentHp - damage);
          if (limbToDamage.currentHp === 0 && oldHp > 0) {
            limbToDamage.state = 'Destroyed';
          }
        }
      }
    });
  });
  return bleedDamageAmount;
}

export function passTimeImpl(context: TimeActionContext, payload: { minutes: number; options?: RestOptions | AppraiseOptions }) {
  const { gameTime, setGameTime, logMessage, currentLocation, startCombat, setPlayer, player, GAME_DATA } = context;
  const { minutes, options } = payload;
  if (minutes <= 0 || !player) return;

  let tempPlayer = deepCloneWithInfinity(player);
  let minutesPassed = 0;
  let interrupted = false;

  const isResting = options && 'isResting' in options && options.isResting;
  const isAppraising = options && 'isAppraising' in options && options.isAppraising;

  // Setup options-based variables
  let identifiedItemsCount = 0;
  let revealedEnchantmentsCount = 0;
  let xpGained = 0;
  const initialAppraisalLevel = isAppraising ? tempPlayer.professions.appraisal.level : 0;
  let quality = 1.0;
  let encounterMod = 1.0;

  if (isResting && options) {
    switch (options.alertnessLevel) {
      case 'passive':
        quality = 1.5;
        encounterMod = 1.0;
        break;
      case 'half-awake':
        quality = 1.25;
        encounterMod = 0.5;
        break;
      case 'fully-alert':
        quality = 1.0;
        encounterMod = 0.1;
        break;
    }
    options.aids.forEach((aidId) => {
      const aidData = GAME_DATA.ITEMS[aidId];
      if (aidData.restAid?.type === 'quality_bonus') quality += aidData.restAid.value;
      if (aidData.restAid?.type === 'encounter_reduction') encounterMod *= 1 - aidData.restAid.value;
    });
  }

  // Main loop: iterate minute by minute
  for (let m = 0; m < minutes; m++) {
    const charactersToUpdate: (Player | Mercenary)[] = [tempPlayer, ...tempPlayer.party];

    // 1. Process 1 minute of non-critical effects for all characters
    for (const char of charactersToUpdate) {
      if (!char) continue;
      processMinuteEffects(char, !!isResting, quality, GAME_DATA, logMessage);
    }

    // 2. Process 10 ticks of bleed damage for this minute, as it can be fatal
    let tookBleedDamageThisMinute = false;
    for (let tick = 0; tick < 10; tick++) {
      let characterDied = false;
      for (const char of charactersToUpdate) {
        if (!char) continue;
        const damage = processBleedTick(char, GAME_DATA);
        if (damage > 0) {
          tookBleedDamageThisMinute = true;
          logMessage(`${char.name} took ${damage.toFixed(1)} bleed damage.`, 'damage');
        }
        if (isCombatantDefeated(char as any)) {
          logMessage({ floatingText: 'Bled to death!', detailedText: `${char.name} has bled to death.` }, 'error');
          interrupted = true;
          characterDied = true;
          break;
        }
      }
      if (characterDied) break;
    }
    if (interrupted) break;

    // Interrupt rest if bleed damage was taken
    if (isResting && tookBleedDamageThisMinute) {
      interrupted = true;
    }
    if (interrupted) break;

    // 3. Handle per-minute game mechanics (appraisal, ambush)
    if (isAppraising) {
      const unidentifiedItems = tempPlayer.inventory.filter((item: ItemInstance) => item.isUnidentified);
      for (const item of unidentifiedItems) {
        if (!item.isUnidentified) continue;
        const difficulty = calculateItemLevel(item, GAME_DATA);
        const successChance = calculateDifficultyBonus(tempPlayer.professions.appraisal.level, difficulty) * 0.05; // 10 ticks per minute
        if (Math.random() < successChance) {
          const itemInPlayer = tempPlayer.inventory.find((i: ItemInstance) => i.unique_id === item.unique_id);
          if (itemInPlayer) {
            itemInPlayer.isUnidentified = false;
            identifiedItemsCount++;
            revealedEnchantmentsCount += Object.keys(itemInPlayer.enchantments).length;
            xpGained += Math.max(1, difficulty);
          }
        }
      }
    }

    // Check for interruptions like ambushes every 10 minutes (to reduce RNG calls)
    if ((m + 1) % 10 === 0) {
      if (isResting && currentLocation && Math.random() < currentLocation.dangerLevel * encounterMod * 10) {
        logMessage({ floatingText: 'Ambush!', detailedText: 'Your rest is interrupted!' }, 'combat');
        if (currentLocation?.monsterPacks?.[0]) {
          startCombat(currentLocation.monsterPacks[Math.floor(Math.random() * currentLocation.monsterPacks.length)], { source: 'rest' });
        }
        interrupted = true;
      } else if (isAppraising && currentLocation && Math.random() < currentLocation.dangerLevel * 10) {
        logMessage({ floatingText: 'Ambush!', detailedText: 'Your work is interrupted!' }, 'combat');
        if (currentLocation?.monsterPacks?.[0]) {
          startCombat(currentLocation.monsterPacks[Math.floor(Math.random() * currentLocation.monsterPacks.length)], { source: 'wilds' });
        }
        interrupted = true;
      }
    }

    if (interrupted) break;
    minutesPassed++;
  }

  // Finalization
  if (isAppraising) {
    if (xpGained > 0) {
      tempPlayer.professions.appraisal.xp += xpGained;
      while (tempPlayer.professions.appraisal.xp >= tempPlayer.professions.appraisal.xpToNextLevel) {
        const prof = tempPlayer.professions.appraisal;
        prof.xp -= prof.xpToNextLevel;
        prof.level++;
        prof.xpToNextLevel = calculateXpToNextLevel(prof.level);
      }
      if (tempPlayer.professions.appraisal.level > initialAppraisalLevel) {
        logMessage(`Appraisal skill increased to ${tempPlayer.professions.appraisal.level}!`, 'skill');
      }
    }
    if (identifiedItemsCount > 0) {
      logMessage(`Your character inspects ${identifiedItemsCount} items and reveals ${revealedEnchantmentsCount} enchantments.`, 'skill');
    } else {
      logMessage(`Your character inspects their items but fails to reveal any new properties.`, 'info');
    }
  }

  setPlayer(tempPlayer);
  const newTime = new Date(gameTime.getTime() + minutesPassed * 60000);
  setGameTime(newTime);
  logMessage(`${formatDuration(minutesPassed)} pass.`, 'time');
}