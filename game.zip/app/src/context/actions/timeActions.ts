import { Limb, Mercenary, Player, RestOptions, StatusEffectInstance, WorldContextType, PlayerContextType, UIContextType, LogContextType, GameData, CombatContextType } from "../../types";
import { calculateCharacterStats } from "../../services/statService";
import { formatDuration } from "utils/formatUtils";
import { isCombatantDefeated } from "utils/combatUtils";

type TimeActionContext = Pick<WorldContextType, "gameTime" | "setGameTime" | "currentLocation"> &
  Pick<PlayerContextType, "player" | "setPlayer"> &
  Pick<CombatContextType, "startCombat"> &
  Pick<UIContextType, "setActiveModal"> &
  Pick<LogContextType, "logMessage"> & { GAME_DATA: GameData };

export function passTimeImpl(
  context: TimeActionContext,
  payload: { minutes: number; options?: RestOptions },
) {
  const { gameTime, setGameTime, logMessage, currentLocation, startCombat, setPlayer, player, setActiveModal, GAME_DATA } = context;
  const { minutes, options } = payload;
  if (minutes <= 0 || !player) return;

  const THIRST_DECAY_PER_MINUTE = 100 / (72 * 60); // 100 points over 72 hours
  const HUNGER_DECAY_PER_MINUTE = 100 / (7 * 24 * 60); // 100 points over 1 week

  let tempPlayer = JSON.parse(JSON.stringify(player));
  const totalTicks = Math.round(minutes / 0.1);
  let minutesPassed = 0;
  let interrupted = false;

  for (let i = 0; i < totalTicks; i++) {
    minutesPassed = (i + 1) * 0.1;

    const charactersToUpdate: (Player | Mercenary)[] = [tempPlayer, ...tempPlayer.party];

    for (const char of charactersToUpdate) {
      if (!char) continue;

      if (char.vitals) {
        char.vitals.thirst.current = Math.max(0, char.vitals.thirst.current - THIRST_DECAY_PER_MINUTE * 0.1);
        char.vitals.hunger.current = Math.max(0, char.vitals.hunger.current - HUNGER_DECAY_PER_MINUTE * 0.1);

        if (char.vitals.thirst.current <= 0) {
          logMessage(`${char.name} has died of thirst.`, "error");
          if (char.body.torso) char.body.torso.currentHp = 0;
          if (char.body.body) char.body.body.currentHp = 0;
          if ("professions" in char) interrupted = true;
        }
        if (char.vitals.hunger.current <= 0) {
          logMessage(`${char.name} has died of starvation.`, "error");
          if (char.body.torso) char.body.torso.currentHp = 0;
          if (char.body.body) char.body.body.currentHp = 0;
          if ("professions" in char) interrupted = true;
        }
      }

      let tookBleedDamage = false;
      let bleedDamageAmount = 0;
      const totalMaxHp = Object.values(char.body).reduce((sum: number, l: any) => sum + l.maxHp, 0);

      Object.values(char.body).forEach((limb: any) => {
        limb.statusEffects.forEach((effect: StatusEffectInstance) => {
          if (effect.id === "external_bleed" && !effect.isClosed) {
            const stageIndex = (effect.currentStage || 1) - 1;
            const bleedStageData = GAME_DATA.STATUS_EFFECTS.external_bleed.stages![stageIndex];
            if (bleedStageData.effects?.onTurn?.type === "damage_percent_max_hp") {
              const percent = (bleedStageData.effects.onTurn as any).percent;
              const damage = totalMaxHp * (percent / 100);
              bleedDamageAmount += damage;

              let limbToDamage: Limb = limb;
              if (limbToDamage.state === "Destroyed") {
                const torso = Object.values(char.body).find((l: any) => l.id === "torso" || l.id === "body");
                limbToDamage =
                  (torso as Limb) && (torso as Limb).state !== "Destroyed"
                    ? (torso as Limb)
                    : (Object.values(char.body).find((l: any) => l.state !== "Destroyed") as Limb);
              }

              if (limbToDamage) {
                const oldHp = limbToDamage.currentHp;
                limbToDamage.currentHp = Math.max(0, limbToDamage.currentHp - damage);
                if (limbToDamage.currentHp === 0 && oldHp > 0) {
                  limbToDamage.state = "Destroyed";
                }
              }
            }
          }
        });
      });

      if (bleedDamageAmount > 0) {
        logMessage(`${char.name} has taken ${bleedDamageAmount.toFixed(1)} damage from bleeding.`, "damage");
        tookBleedDamage = true;
      }
      if (isCombatantDefeated(char as any)) {
        if ("professions" in char) {
          logMessage({ floatingText: "Bled to death!", detailedText: "You have bled to death." }, "error");
          interrupted = true;
        }
      }
      if (options?.isResting && tookBleedDamage) {
        interrupted = true;
      }

      const updateEffectDuration = (effects: StatusEffectInstance[]): StatusEffectInstance[] => {
        return effects
          .map((b) => (b.durationInMinutes > 0 && b.durationInMinutes !== Infinity ? { ...b, durationInMinutes: b.durationInMinutes - 0.1 } : b))
          .filter(
            (b) => (b.durationInMinutes || 0) > 0.001 || (b.turnsRemaining || 0) > 0 || b.durationInMinutes === Infinity || b.turnsRemaining === Infinity,
          );
      };

      char.statusEffects = updateEffectDuration(char.statusEffects);
      Object.values(char.body).forEach((limb: any) => {
        limb.statusEffects = updateEffectDuration(limb.statusEffects);
      });
    }

    if (interrupted) break;

    let quality = 1.0;
    if (options?.isResting) {
      switch (options.alertnessLevel) {
        case "passive":
          quality = 1.5;
          break;
        case "half-awake":
          quality = 1.25;
          break;
        case "fully-alert":
          quality = 1.0;
          break;
      }
      options.aids.forEach((aidId) => {
        if (GAME_DATA.ITEMS[aidId].restAid?.type === "quality_bonus") quality += GAME_DATA.ITEMS[aidId].restAid!.value;
      });
    }

    const calculatedPlayer = calculateCharacterStats(tempPlayer, GAME_DATA)!;
    const hpRegenPerTick = calculatedPlayer.totalStats.worldHpRegen * (options?.isResting ? 3 * quality : 1) * 0.1;

    (Object.values(tempPlayer.body) as Limb[]).forEach((limb) => {
      if ((limb.state === "Healthy" || limb.state === "Injured") && limb.currentHp < limb.maxHp) {
        limb.currentHp = Math.min(limb.maxHp, limb.currentHp + hpRegenPerTick);
      }
    });

    const mpRegenPerTick = calculatedPlayer.totalStats.worldMpRegen * (options?.isResting ? 3 * quality : 1) * 0.1;
    tempPlayer.mp = Math.min(calculatedPlayer.maxMp, tempPlayer.mp + mpRegenPerTick);

    const spRegenPerTick = calculatedPlayer.totalStats.worldSpRegen * (options?.isResting ? 3 * quality : 1) * 0.1;
    tempPlayer.sp = Math.min(calculatedPlayer.maxSp, tempPlayer.sp + spRegenPerTick);

    if (options?.isResting) {
      tempPlayer.party.forEach((merc: Mercenary) => {
        const calculatedMerc = calculateCharacterStats(merc, GAME_DATA)!;
        const mercHpRegenPerTick = (calculatedMerc.totalStats.maxHp / 100) * (3 * quality) * 0.1;
        (Object.values(merc.body) as Limb[]).forEach((limb) => {
          if ((limb.state === "Healthy" || limb.state === "Injured") && limb.currentHp < limb.maxHp) {
            limb.currentHp = Math.min(limb.maxHp, limb.currentHp + mercHpRegenPerTick);
          }
        });
        const mercMpRegenPerTick = (calculatedMerc.maxMp / 100) * (3 * quality) * 0.1;
        merc.mp = Math.min(calculatedMerc.maxMp, merc.mp + mercMpRegenPerTick);
        const mercSpRegenPerTick = (calculatedMerc.maxSp / 100) * (3 * quality) * 0.1;
        merc.sp = Math.min(calculatedMerc.maxSp, merc.sp + mercSpRegenPerTick);
      });
    }

    if (options?.isResting && (i + 1) % 100 === 0) {
      let encounterMod = 1.0;
      switch (options.alertnessLevel) {
        case "passive":
          encounterMod = 1.0;
          break;
        case "half-awake":
          encounterMod = 0.5;
          break;
        case "fully-alert":
          encounterMod = 0.1;
          break;
      }
      options.aids.forEach((aidId) => {
        const aidData = GAME_DATA.ITEMS[aidId];
        if (aidData.restAid?.type === "encounter_reduction") encounterMod *= 1 - aidData.restAid.value;
      });
      if (currentLocation && Math.random() < currentLocation.dangerLevel * encounterMod) {
        logMessage(
          {
            floatingText: "Ambush!",
            detailedText: "Your rest is interrupted!",
          },
          "combat",
        );
        if (currentLocation?.monsterPacks?.[0]) {
          startCombat(currentLocation.monsterPacks[Math.floor(Math.random() * currentLocation.monsterPacks.length)], { source: "rest" });
        }
        interrupted = true;
        break;
      }
    }
  }

  setPlayer(tempPlayer);
  const newTime = new Date(gameTime.getTime() + minutesPassed * 60000);
  setGameTime(newTime);
  logMessage(`${formatDuration(minutesPassed)} pass.`, "time");
}