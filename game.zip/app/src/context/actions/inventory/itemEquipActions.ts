import { GameData, GameSideEffect, Player, PlayerEquipmentSlot, PLAYER_INVENTORY_MAX_STACK_SIZE, PLAYER_INVENTORY_MAX_UNIQUE_ITEMS } from '../../../types';

import { calculateCharacterStats } from 'services/statService';
import { mergeIntoInventory } from 'utils/itemUtils';

type PairedSlotInfo = {
  pairedSlots: [PlayerEquipmentSlot, PlayerEquipmentSlot];
  nextSlotProp: keyof Player;
  nextPreference: any;
  updateNext: (equippedSlot: PlayerEquipmentSlot) => Partial<Player>;
};

const pairedSlotLogicMap: Partial<Record<string, PairedSlotInfo>> = {
  ring: {
    pairedSlots: ['left_ring', 'right_ring'],
    nextSlotProp: 'nextRingSlotToEquip',
    nextPreference: 'left',
    updateNext: (s) => ({ nextRingSlotToEquip: s === 'left_ring' ? 'right' : 'left' }),
  },
  amulet: {
    pairedSlots: ['amulet1', 'amulet2'],
    nextSlotProp: 'nextAmuletSlotToEquip',
    nextPreference: '1',
    updateNext: (s) => ({ nextAmuletSlotToEquip: s === 'amulet1' ? '2' : '1' }),
  },
  armlet: {
    pairedSlots: ['left_armlet', 'right_armlet'],
    nextSlotProp: 'nextArmletSlotToEquip',
    nextPreference: 'left',
    updateNext: (s) => ({ nextArmletSlotToEquip: s === 'left_armlet' ? 'right' : 'left' }),
  },
  glove: {
    pairedSlots: ['left_glove', 'right_glove'],
    nextSlotProp: 'nextGloveSlotToEquip',
    nextPreference: 'left',
    updateNext: (s) => ({ nextGloveSlotToEquip: s === 'left_glove' ? 'right' : 'left' }),
  },
  leggings: {
    pairedSlots: ['left_legging', 'right_legging'],
    nextSlotProp: 'nextLeggingSlotToEquip',
    nextPreference: 'left',
    updateNext: (s) => ({ nextLeggingSlotToEquip: s === 'left_legging' ? 'right' : 'left' }),
  },
  feet: {
    pairedSlots: ['left_foot', 'right_foot'],
    nextSlotProp: 'nextFootSlotToEquip',
    nextPreference: 'left',
    updateNext: (s) => ({ nextFootSlotToEquip: s === 'left_foot' ? 'right' : 'left' }),
  },
};

export function equipItem(
  player: Player,
  itemUniqueId: string,
  GAME_DATA: GameData,
  slot?: PlayerEquipmentSlot
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const inventoryIndex = player.inventory.findIndex((i) => i.unique_id === itemUniqueId);
  if (inventoryIndex === -1) {
    return { player, sideEffects: [{ type: 'LOG', message: 'Item to equip not found.', logType: 'error' }] };
  }

  const itemInstance = player.inventory[inventoryIndex];
  if (!itemInstance) return null;

  if (itemInstance.isUnidentified) {
    return { player, sideEffects: [{ type: 'LOG', message: 'Cannot equip an unidentified item.', logType: 'error' }] };
  }

  if (itemInstance.isBroken) {
    return { player, sideEffects: [{ type: 'LOG', message: 'Cannot equip a broken item.', logType: 'error' }] };
  }

  const itemData = GAME_DATA.ITEMS[itemInstance.id];
  if (!itemData.type.includes('equipment') || !itemData.slot) {
    return { player, sideEffects: [{ type: 'LOG', message: 'This item is not equippable.', logType: 'info' }] };
  }

  const newPlayer = {
    ...player,
    inventory: [...player.inventory],
    equipment: { ...player.equipment },
  };

  const tempStats = calculateCharacterStats(
    {
      ...newPlayer,
      inventory: newPlayer.inventory.filter((_, i) => i !== inventoryIndex),
    },
    GAME_DATA
  );
  if (tempStats && tempStats.currentWeight + (itemData.weight || 0) > tempStats.maxCarryWeight) {
    return { player, sideEffects: [{ type: 'LOG', message: 'You would be over-encumbered if you equip this item.', logType: 'error' }] };
  }

  let slotToEquip: PlayerEquipmentSlot | null = slot || null;

  if (!slot) {
    const itemSlotType = itemData.slot;
    const pairedConfig = pairedSlotLogicMap[itemSlotType!];

    if (itemData.twoHanded) {
      slotToEquip = 'weapon';
    } else if (pairedConfig) {
      const [slot1, slot2] = pairedConfig.pairedSlots;
      const nextSlotPref = newPlayer[pairedConfig.nextSlotProp] as any;
      if (newPlayer.equipment[slot1] === null) slotToEquip = slot1;
      else if (newPlayer.equipment[slot2] === null) slotToEquip = slot2;
      else slotToEquip = nextSlotPref === pairedConfig.nextPreference ? slot1 : slot2;
    } else if (itemSlotType === 'weapon') {
      slotToEquip = newPlayer.equipment.weapon === null ? 'weapon' : newPlayer.nextHandSlotToEquip;
    } else if (itemSlotType === 'shield') {
      slotToEquip = 'shield';
    } else {
      slotToEquip = itemSlotType as PlayerEquipmentSlot;
    }
  }

  if (!slotToEquip) return null;

  const otherSlot = slotToEquip === 'weapon' ? 'shield' : 'weapon';
  const itemInOtherHand = newPlayer.equipment[otherSlot];

  if (itemData.twoHanded || (itemInOtherHand && GAME_DATA.ITEMS[itemInOtherHand.id].twoHanded)) {
    if (itemInOtherHand && !itemInOtherHand.isUnarmed) {
      const { newInventory } = mergeIntoInventory(newPlayer.inventory, [itemInOtherHand], GAME_DATA, {
        maxUniqueItems: PLAYER_INVENTORY_MAX_UNIQUE_ITEMS,
        maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
      });
      newPlayer.inventory = newInventory;
      // Note: overflow from two-handed unequipping is not handled, as it's an edge case.
      newPlayer.equipment[otherSlot] = null;
    }
  }

  const previouslyEquipped = newPlayer.equipment[slotToEquip];

  const itemToEquip = newPlayer.inventory[inventoryIndex];
  if (itemToEquip.quantity > 1) {
    itemToEquip.quantity -= 1;
    newPlayer.equipment[slotToEquip] = { ...itemToEquip, quantity: 1 };
  } else {
    newPlayer.inventory.splice(inventoryIndex, 1);
    newPlayer.equipment[slotToEquip] = itemToEquip;
  }

  const sideEffects: GameSideEffect[] = [];
  if (previouslyEquipped && !previouslyEquipped.isUnarmed) {
    const { newInventory, overflow } = mergeIntoInventory(newPlayer.inventory, [previouslyEquipped], GAME_DATA, {
      maxUniqueItems: PLAYER_INVENTORY_MAX_UNIQUE_ITEMS,
      maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
    });
    newPlayer.inventory = newInventory;
    if (overflow.length > 0) {
      sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
    }
  }

  const pairedConfig = pairedSlotLogicMap[itemData.slot!];
  if (pairedConfig && slotToEquip) {
    Object.assign(newPlayer, pairedConfig.updateNext(slotToEquip));
  } else if (itemData.slot === 'weapon' || itemData.slot === 'shield') {
    newPlayer.nextHandSlotToEquip = slotToEquip === 'weapon' ? 'shield' : 'weapon';
  }

  return { player: newPlayer, sideEffects };
}

export function unequipItem(player: Player, slot: PlayerEquipmentSlot, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  if (!player.equipment[slot] || player.equipment[slot]?.isUnarmed) return null;

  const itemToUnequip = player.equipment[slot]!;
  const newEquipment = { ...player.equipment, [slot]: null };
  const { newInventory, overflow } = mergeIntoInventory(player.inventory, [itemToUnequip], GAME_DATA, {
    maxUniqueItems: PLAYER_INVENTORY_MAX_UNIQUE_ITEMS,
    maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
  });

  const sideEffects: GameSideEffect[] = [];
  if (overflow.length > 0) {
    sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
  }

  const newPlayer = {
    ...player,
    equipment: newEquipment,
    inventory: newInventory,
  };

  return { player: newPlayer, sideEffects };
}

export function damageItemDurability(player: Player, slot: PlayerEquipmentSlot, amount: number, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  const item = player.equipment[slot];
  if (!item || item.isBroken || item.isUnarmed) return null;

  const newItem = { ...item };
  newItem.currentDurability = (newItem.currentDurability || 0) - amount;

  const sideEffects: GameSideEffect[] = [];

  if (newItem.currentDurability <= 0) {
    newItem.currentDurability = 0;
    newItem.isBroken = true;
    const itemName = GAME_DATA.ITEMS[newItem.id].name;
    sideEffects.push({ type: 'LOG', message: `${itemName} has broken!`, logType: 'error' });
  }

  const newEquipment = { ...player.equipment, [slot]: newItem };
  return { player: { ...player, equipment: newEquipment }, sideEffects };
}