import { GameData, GameSideEffect, ItemInstance, Player, PlayerEquipmentSlot } from '../../../types';

import { calculateCharacterStats } from 'services/statService';
import { getItemName } from 'utils/itemUtils';

export function equipItem(
  player: Player,
  itemUniqueId: string,
  GAME_DATA: GameData,
  slot?: PlayerEquipmentSlot
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const inventoryIndex = player.inventory.findIndex((i) => i.unique_id === itemUniqueId);
  if (inventoryIndex === -1) {
    return { player, sideEffects: [{ type: 'LOG', message: 'Item to equip not found.', logType: 'error' }] };
  }

  const itemInstance = player.inventory[inventoryIndex];
  if (!itemInstance) return null;

  if (itemInstance.isUnidentified) {
    return { player, sideEffects: [{ type: 'LOG', message: 'Cannot equip an unidentified item.', logType: 'error' }] };
  }

  if (itemInstance.isBroken) {
    return { player, sideEffects: [{ type: 'LOG', message: 'Cannot equip a broken item.', logType: 'error' }] };
  }

  const itemData = GAME_DATA.ITEMS[itemInstance.id];
  if (!itemData.type.includes('equipment') || !itemData.slot) {
    return { player, sideEffects: [{ type: 'LOG', message: 'This item is not equippable.', logType: 'info' }] };
  }

  const newPlayer = {
    ...player,
    inventory: [...player.inventory],
    equipment: { ...player.equipment },
  };

  const tempStats = calculateCharacterStats(
    {
      ...newPlayer,
      inventory: newPlayer.inventory.filter((_, i) => i !== inventoryIndex),
    },
    GAME_DATA
  );
  if (tempStats && tempStats.currentWeight + (itemData.weight || 0) > tempStats.maxCarryWeight) {
    return { player, sideEffects: [{ type: 'LOG', message: 'You would be over-encumbered if you equip this item.', logType: 'error' }] };
  }

  let slotToEquip: PlayerEquipmentSlot | null = slot || null;

  if (!slot) {
    if (itemData.twoHanded) {
      slotToEquip = 'weapon';
    } else if (itemData.slot === 'ring') {
      slotToEquip = player.equipment.left_ring === null ? 'left_ring' : player.equipment.right_ring === null ? 'right_ring' : player.nextRingSlotToEquip === 'left' ? 'left_ring' : 'right_ring';
    } else if (itemData.slot === 'amulet') {
      slotToEquip = player.equipment.amulet1 === null ? 'amulet1' : player.nextAmuletSlotToEquip === '1' ? 'amulet1' : 'amulet2';
    } else if (itemData.slot === 'shield') {
      slotToEquip = 'shield';
    } else if (itemData.slot === 'weapon') {
      slotToEquip = player.equipment.weapon === null ? 'weapon' : player.nextHandSlotToEquip;
    } else if (itemData.slot === 'armlet') {
      slotToEquip = player.equipment.left_armlet === null ? 'left_armlet' : 'right_armlet';
    } else if (itemData.slot === 'glove') {
      slotToEquip = player.equipment.left_glove === null ? 'left_glove' : 'right_glove';
    } else if (itemData.slot === 'leggings') {
      slotToEquip = player.equipment.left_legging === null ? 'left_legging' : 'right_legging';
    } else if (itemData.slot === 'feet') {
      slotToEquip = player.equipment.left_foot === null ? 'left_foot' : 'right_foot';
    } else {
      slotToEquip = itemData.slot as PlayerEquipmentSlot;
    }
  }

  if (!slotToEquip) return null;

  const otherSlot = slotToEquip === 'weapon' ? 'shield' : 'weapon';
  const itemInOtherHand = newPlayer.equipment[otherSlot];

  if (itemData.twoHanded || (itemInOtherHand && GAME_DATA.ITEMS[itemInOtherHand.id].twoHanded)) {
    if (itemInOtherHand && !itemInOtherHand.isUnarmed) {
      newPlayer.inventory.push(itemInOtherHand);
      newPlayer.equipment[otherSlot] = null;
    }
  }

  const previouslyEquipped = newPlayer.equipment[slotToEquip];
  newPlayer.inventory.splice(inventoryIndex, 1);
  if (previouslyEquipped && !previouslyEquipped.isUnarmed) {
    newPlayer.inventory.push(previouslyEquipped);
  }
  newPlayer.equipment[slotToEquip] = itemInstance;

  if (itemData.slot === 'ring') newPlayer.nextRingSlotToEquip = slotToEquip === 'left_ring' ? 'right' : 'left';
  else if (itemData.slot === 'amulet') newPlayer.nextAmuletSlotToEquip = slotToEquip === 'amulet1' ? '2' : '1';
  else if (itemData.slot === 'weapon' || itemData.slot === 'shield') newPlayer.nextHandSlotToEquip = slotToEquip === 'weapon' ? 'shield' : 'weapon';
  else if (itemData.slot === 'armlet') newPlayer.nextArmletSlotToEquip = slotToEquip === 'left_armlet' ? 'right' : 'left';
  else if (itemData.slot === 'glove') newPlayer.nextGloveSlotToEquip = slotToEquip === 'left_glove' ? 'right' : 'left';
  else if (itemData.slot === 'leggings') newPlayer.nextLeggingSlotToEquip = slotToEquip === 'left_legging' ? 'right' : 'left';
  else if (itemData.slot === 'feet') newPlayer.nextFootSlotToEquip = slotToEquip === 'left_foot' ? 'right' : 'left';

  return { player: newPlayer, sideEffects: [] };
}

export function unequipItem(player: Player, slot: PlayerEquipmentSlot): { player: Player } | null {
  if (!player.equipment[slot] || player.equipment[slot]?.isUnarmed) return null;

  const itemToUnequip = player.equipment[slot];
  const newPlayer = {
    ...player,
    inventory: [...player.inventory, itemToUnequip!],
    equipment: { ...player.equipment, [slot]: null },
  };
  return { player: newPlayer };
}

export function damageItemDurability(player: Player, slot: PlayerEquipmentSlot, amount: number, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  const item = player.equipment[slot];
  if (!item || item.isBroken || item.isUnarmed) return null;

  const newItem = { ...item };
  newItem.currentDurability = (newItem.currentDurability || 0) - amount;

  const sideEffects: GameSideEffect[] = [];

  if (newItem.currentDurability <= 0) {
    newItem.currentDurability = 0;
    newItem.isBroken = true;
    sideEffects.push({ type: 'LOG', message: `${getItemName(newItem, GAME_DATA)} has broken!`, logType: 'error' });
  }

  const newEquipment = { ...player.equipment, [slot]: newItem };
  return { player: { ...player, equipment: newEquipment }, sideEffects };
}