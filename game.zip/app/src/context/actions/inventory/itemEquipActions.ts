import { Player, PlayerEquipmentSlot, ItemInstance, GameData } from '../../../types';
import { calculateCharacterStats } from 'services/statService';
import { getItemName } from 'utils/itemUtils';

export function equipItemImpl(
  itemUniqueId: string,
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>,
  logMessage: (message: string, type: any) => void,
  playerActionTaken: () => void,
  GAME_DATA: GameData
) {
  let equipped = false;
  setPlayer((p: Player | null) => {
    if (!p) return p;

    const inventoryIndex = p.inventory.findIndex((i) => i.unique_id === itemUniqueId);
    if (inventoryIndex === -1) {
      logMessage('Item to equip not found.', 'error');
      return p;
    }

    const itemInstance = p.inventory[inventoryIndex];
    if (!itemInstance) return p;

    if (itemInstance.isUnidentified) {
      logMessage('Cannot equip an unidentified item.', 'error');
      return p;
    }

    if (itemInstance.isBroken) {
      logMessage('Cannot equip a broken item.', 'error');
      return p;
    }

    const newPlayer = {
      ...p,
      inventory: [...p.inventory],
      equipment: { ...p.equipment },
    };
    const itemData = GAME_DATA.ITEMS[itemInstance.id];
    if (!itemData.type.includes('equipment') || !itemData.slot) return p;

    const tempStats = calculateCharacterStats(
      {
        ...newPlayer,
        inventory: newPlayer.inventory.filter((_, i) => i !== inventoryIndex),
      },
      GAME_DATA
    );
    if (tempStats && tempStats.currentWeight + itemData.weight > tempStats.maxCarryWeight) {
      logMessage('You would be over-encumbered if you equip this item.', 'error');
      return p;
    }

    let slotToEquip: PlayerEquipmentSlot | null =
      itemData.slot === 'ring' ? (!newPlayer.equipment.ring1 ? 'ring1' : !newPlayer.equipment.ring2 ? 'ring2' : 'ring1') : (itemData.slot as PlayerEquipmentSlot);

    if (!slotToEquip) return p;

    equipped = true;
    const previouslyEquipped = newPlayer.equipment[slotToEquip];
    newPlayer.inventory.splice(inventoryIndex, 1);
    if (previouslyEquipped && !previouslyEquipped.isUnarmed) newPlayer.inventory.push(previouslyEquipped);
    newPlayer.equipment[slotToEquip] = itemInstance;

    if (itemData.twoHanded && newPlayer.equipment.shield) {
      if (!newPlayer.equipment.shield.isUnarmed) newPlayer.inventory.push(newPlayer.equipment.shield);
      newPlayer.equipment.shield = null;
    }
    if (itemData.slot === 'shield' && newPlayer.equipment.weapon) {
      const weaponData = GAME_DATA.ITEMS[newPlayer.equipment.weapon.id];
      if (weaponData.type.includes('equipment') && weaponData.twoHanded) {
        if (!newPlayer.equipment.weapon.isUnarmed) newPlayer.inventory.push(newPlayer.equipment.weapon);
        newPlayer.equipment.weapon = null;
      }
    }
    return newPlayer;
  });
  if (equipped) playerActionTaken();
}

export function unequipItemImpl(slot: PlayerEquipmentSlot, setPlayer: React.Dispatch<React.SetStateAction<Player | null>>, playerActionTaken: () => void) {
  let unequipped = false;
  setPlayer((p: Player | null) => {
    if (!p || !p.equipment[slot]) return p;
    const itemToUnequip = p.equipment[slot];
    if (itemToUnequip?.isUnarmed) {
      return p;
    }
    const newPlayer = {
      ...p,
      inventory: [...p.inventory],
      equipment: { ...p.equipment },
    };
    if (itemToUnequip) {
      newPlayer.inventory.push(itemToUnequip);
      newPlayer.equipment[slot] = null;
      unequipped = true;
    }
    return newPlayer;
  });
  if (unequipped) playerActionTaken();
}

export function damageItemDurabilityImpl(
  slot: PlayerEquipmentSlot,
  amount: number,
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>,
  logMessage: (message: string, type: any) => void,
  GAME_DATA: GameData
) {
  setPlayer((p) => {
    if (!p) return p;
    const newEquipment = { ...p.equipment };
    const item = newEquipment[slot];

    if (!item || item.isBroken || item.isUnarmed) {
      return p;
    }

    const newItem = { ...item };
    newItem.currentDurability = (newItem.currentDurability || 0) - amount;

    if (newItem.currentDurability <= 0) {
      newItem.currentDurability = 0;
      newItem.isBroken = true;
      logMessage(`${getItemName(newItem, GAME_DATA)} has broken!`, 'error');
    }

    newEquipment[slot] = newItem;
    return { ...p, equipment: newEquipment };
  });
}