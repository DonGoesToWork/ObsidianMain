import { GameData, GameSideEffect, ItemInstance, Player, PLAYER_INVENTORY_MAX_STACK_SIZE, PLAYER_INVENTORY_MAX_UNIQUE_ITEMS } from '../../../types';
import { mergeIntoInventory } from 'utils/itemUtils';

export function dropItemsAction(
  player: Player,
  itemsToDrop: { unique_id: string; quantity?: number }[]
): { player: Player; droppedItems: ItemInstance[]; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];
  let tempPlayer = { ...player, inventory: [...player.inventory] };
  const droppedItems: ItemInstance[] = [];

  for (const { unique_id, quantity } of itemsToDrop) {
    const itemIdx = tempPlayer.inventory.findIndex((i) => i.unique_id === unique_id);
    if (itemIdx === -1) continue;

    const stack = tempPlayer.inventory[itemIdx];
    const amountToDrop = quantity ?? stack.quantity;

    if (amountToDrop >= stack.quantity) {
      droppedItems.push(stack);
      tempPlayer.inventory.splice(itemIdx, 1);
    } else {
      const droppedPart: ItemInstance = { ...stack, quantity: amountToDrop };
      droppedItems.push(droppedPart);
      stack.quantity -= amountToDrop;
    }
  }

  if (droppedItems.length > 0) {
    const totalCount = droppedItems.reduce((acc, item) => acc + item.quantity, 0);
    sideEffects.push({ type: 'LOG', message: `You drop ${totalCount} item(s).`, logType: 'info' });
  }

  return { player: tempPlayer, droppedItems: droppedItems, sideEffects };
}

export function moveItemToBankAction(player: Player, itemUniqueId: string, quantity: number | undefined, GAME_DATA: GameData): Player | null {
  const inventoryIndex = player.inventory.findIndex((i) => i.unique_id === itemUniqueId);
  if (inventoryIndex === -1) return null;

  const newInventory = [...player.inventory];
  const itemInInventory = newInventory[inventoryIndex];
  const amountToMove = quantity ?? itemInInventory.quantity;

  let itemToMove: ItemInstance;

  if (amountToMove >= itemInInventory.quantity) {
    itemToMove = itemInInventory;
    newInventory.splice(inventoryIndex, 1);
  } else {
    itemToMove = { ...itemInInventory, quantity: amountToMove };
    itemInInventory.quantity -= amountToMove;
  }

  const { newInventory: newBank } = mergeIntoInventory(player.bank, [itemToMove], GAME_DATA, { maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE });
  return { ...player, inventory: newInventory, bank: newBank };
}

export function moveItemsToBankAction(player: Player, itemsToMove: { unique_id: string; quantity: number }[], GAME_DATA: GameData): Player | null {
  const itemsToAdd: ItemInstance[] = [];
  const newInventory = [...player.inventory];
  const movedIds = new Set<string>();

  for (const { unique_id, quantity } of itemsToMove) {
    if (movedIds.has(unique_id)) continue;
    const itemIdx = newInventory.findIndex((i) => i.unique_id === unique_id);
    if (itemIdx === -1) continue;

    const stack = newInventory[itemIdx];
    const amountToMove = Math.min(quantity, stack.quantity);

    if (amountToMove >= stack.quantity) {
      itemsToAdd.push(stack);
      newInventory.splice(itemIdx, 1);
    } else {
      itemsToAdd.push({ ...stack, quantity: amountToMove });
      stack.quantity -= amountToMove;
    }
    movedIds.add(unique_id);
  }

  if (itemsToAdd.length === 0) return null;

  const { newInventory: newBank } = mergeIntoInventory(player.bank, itemsToAdd, GAME_DATA, { maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE });
  return { ...player, inventory: newInventory, bank: newBank };
}

export function moveItemFromBankAction(
  player: Player,
  itemUniqueId: string,
  quantity: number | undefined,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const bankIndex = player.bank.findIndex((i) => i.unique_id === itemUniqueId);
  if (bankIndex === -1) return null;

  const newBank = [...player.bank];
  const itemInBank = newBank[bankIndex];
  const amountToMove = quantity ?? itemInBank.quantity;

  let itemToMove: ItemInstance;

  if (amountToMove >= itemInBank.quantity) {
    itemToMove = itemInBank;
    newBank.splice(bankIndex, 1);
  } else {
    itemToMove = { ...itemInBank, quantity: amountToMove };
    itemInBank.quantity -= amountToMove;
  }

  const { newInventory, overflow } = mergeIntoInventory(player.inventory, [itemToMove], GAME_DATA, {
    maxUniqueItems: PLAYER_INVENTORY_MAX_UNIQUE_ITEMS,
    maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
  });

  const sideEffects: GameSideEffect[] = [];
  if (overflow.length > 0) {
    sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
  }

  return { player: { ...player, inventory: newInventory, bank: newBank }, sideEffects };
}

export function moveItemsFromBankAction(
  player: Player,
  itemsToMove: { unique_id: string; quantity: number }[],
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const itemsToAdd: ItemInstance[] = [];
  const newBank = [...player.bank];
  const movedIds = new Set<string>();

  for (const { unique_id, quantity } of itemsToMove) {
    if (movedIds.has(unique_id)) continue;
    const itemIdx = newBank.findIndex((i) => i.unique_id === unique_id);
    if (itemIdx === -1) continue;

    const stack = newBank[itemIdx];
    const amountToMove = Math.min(quantity, stack.quantity);

    if (amountToMove >= stack.quantity) {
      itemsToAdd.push(stack);
      newBank.splice(itemIdx, 1);
    } else {
      itemsToAdd.push({ ...stack, quantity: amountToMove });
      stack.quantity -= amountToMove;
    }
    movedIds.add(unique_id);
  }

  if (itemsToAdd.length === 0) return null;

  const { newInventory, overflow } = mergeIntoInventory(player.inventory, itemsToAdd, GAME_DATA, {
    maxUniqueItems: PLAYER_INVENTORY_MAX_UNIQUE_ITEMS,
    maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
  });

  const sideEffects: GameSideEffect[] = [];
  if (overflow.length > 0) {
    sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
  }

  return { player: { ...player, inventory: newInventory, bank: newBank }, sideEffects };
}

export function moveItemToContainerAction(
  player: Player,
  itemUniqueId: string,
  quantity: number,
  containerUniqueId: string,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];

  const playerInvIndex = player.inventory.findIndex((i) => i.unique_id === itemUniqueId);
  if (playerInvIndex === -1) {
    sideEffects.push({ type: 'LOG', message: 'Item to move not found.', logType: 'error' });
    return { player, sideEffects };
  }
  const itemToMove = player.inventory[playerInvIndex];
  const containerItem = player.inventory.find((i) => i.unique_id === containerUniqueId);

  if (!containerItem) {
    sideEffects.push({ type: 'LOG', message: 'Invalid container.', logType: 'error' });
    return { player, sideEffects };
  }
  if (itemToMove.unique_id === containerUniqueId) {
    sideEffects.push({ type: 'LOG', message: 'Cannot put a container in itself.', logType: 'error' });
    return { player, sideEffects };
  }
  if (!GAME_DATA.ITEMS[containerItem.id].type.includes('container')) {
    sideEffects.push({ type: 'LOG', message: 'Target is not a container.', logType: 'error' });
    return { player, sideEffects };
  }
  if (GAME_DATA.ITEMS[itemToMove.id].type.includes('container')) {
    sideEffects.push({ type: 'LOG', message: 'Unable to add containers to containers.', logType: 'error' });
    return { player, sideEffects };
  }

  let currentContainerState = containerItem.containerState;
  if (!currentContainerState) {
    const containerData = GAME_DATA.ITEMS[containerItem.id];
    currentContainerState = {
      items: [],
      capacity: containerData.capacity || 50,
    };
  }

  if (currentContainerState.items.length >= 900) {
    sideEffects.push({ type: 'LOG', message: 'Container is at its maximum item capacity (900).', logType: 'error' });
    return { player, sideEffects };
  }
  const currentContainerWeight = currentContainerState.items.reduce((sum, i) => sum + (GAME_DATA.ITEMS[i.id]?.weight || 0), 0);
  const itemToMoveWeight = GAME_DATA.ITEMS[itemToMove.id].weight;
  if (currentContainerWeight + itemToMoveWeight > currentContainerState.capacity) {
    sideEffects.push({ type: 'LOG', message: 'Container is full.', logType: 'error' });
    return { player, sideEffects };
  }

  const newInventory = [...player.inventory];
  let movedItem: ItemInstance;

  if (itemToMove.quantity > quantity) {
    movedItem = { ...itemToMove, quantity };
    const originalStack = newInventory[playerInvIndex];
    originalStack.quantity -= quantity;
  } else {
    [movedItem] = newInventory.splice(playerInvIndex, 1);
  }

  const newContainerIndex = newInventory.findIndex((c) => c.unique_id === containerUniqueId);

  if (newContainerIndex === -1) {
    sideEffects.push({ type: 'LOG', message: 'Container consistency error during transfer.', logType: 'error' });
    return { player, sideEffects };
  }

  const currentContainer = newInventory[newContainerIndex];
  const oldContainerItems = currentContainer.containerState?.items || [];
  const { newInventory: newContainerItems } = mergeIntoInventory(oldContainerItems, [movedItem], GAME_DATA, { maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE });

  const updatedContainer: ItemInstance = {
    ...currentContainer,
    containerState: {
      ...currentContainer.containerState!,
      items: newContainerItems,
    },
  };

  newInventory[newContainerIndex] = updatedContainer;
  return { player: { ...player, inventory: newInventory }, sideEffects };
}

export function moveItemFromContainerAction(
  player: Player,
  itemUniqueIdInContainer: string,
  quantity: number,
  containerUniqueId: string,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];
  const containerIndex = player.inventory.findIndex((i) => i.unique_id === containerUniqueId);
  if (containerIndex === -1) {
    sideEffects.push({ type: 'LOG', message: 'Container not found.', logType: 'error' });
    return { player, sideEffects };
  }

  let newInventory = [...player.inventory];
  const containerItem = newInventory[containerIndex];

  if (!containerItem || !GAME_DATA.ITEMS[containerItem.id].type.includes('container') || !containerItem.containerState) {
    sideEffects.push({ type: 'LOG', message: 'Invalid container.', logType: 'error' });
    return { player, sideEffects };
  }

  const itemIndexInContainer = containerItem.containerState.items.findIndex((i) => i.unique_id === itemUniqueIdInContainer);
  if (itemIndexInContainer === -1) {
    sideEffects.push({ type: 'LOG', message: 'Item not found in container.', logType: 'error' });
    return { player, sideEffects };
  }

  const itemToMove = containerItem.containerState.items[itemIndexInContainer];
  if (!itemToMove) {
    sideEffects.push({ type: 'LOG', message: 'Invalid item.', logType: 'error' });
    return { player, sideEffects };
  }

  const itemToMoveWeight = GAME_DATA.ITEMS[itemToMove.id].weight;
  if (player.currentWeight + itemToMoveWeight > player.maxCarryWeight) {
    sideEffects.push({ type: 'LOG', message: 'You would be over-encumbered.', logType: 'error' });
    return { player, sideEffects };
  }

  const newContainerItems = [...containerItem.containerState.items];
  let movedItem: ItemInstance;

  if (itemToMove.quantity > quantity) {
    movedItem = { ...itemToMove, quantity };
    newContainerItems[itemIndexInContainer].quantity -= quantity;
  } else {
    [movedItem] = newContainerItems.splice(itemIndexInContainer, 1);
  }

  const newContainerState = {
    ...containerItem.containerState,
    items: newContainerItems,
  };
  const updatedContainerItem = {
    ...containerItem,
    containerState: newContainerState,
  };

  newInventory[containerIndex] = updatedContainerItem;
  const { newInventory: finalInventory, overflow } = mergeIntoInventory(newInventory, [movedItem], GAME_DATA, {
    maxUniqueItems: PLAYER_INVENTORY_MAX_UNIQUE_ITEMS,
    maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
  });

  if (overflow.length > 0) {
    sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
  }

  return { player: { ...player, inventory: finalInventory }, sideEffects };
}