import { Player, ItemInstance, GameLocation, GameData, GameSideEffect } from '../../../types';

export function dropItemsImpl(player: Player, itemUniqueIds: string[]): { player: Player; itemsToDrop: ItemInstance[]; sideEffects: GameSideEffect[] } {
  const idsSet = new Set(itemUniqueIds);
  const itemsToDrop = player.inventory.filter((item) => idsSet.has(item.unique_id));
  const sideEffects: GameSideEffect[] = [];

  if (itemsToDrop.length === 0) return { player, itemsToDrop: [], sideEffects };

  const newInventory = player.inventory.filter((item) => !idsSet.has(item.unique_id));
  sideEffects.push({ type: 'LOG', message: `You drop ${itemsToDrop.length} item(s).`, logType: 'info' });

  return { player: { ...player, inventory: newInventory }, itemsToDrop, sideEffects };
}

export function moveItemToBankAction(player: Player, itemUniqueId: string): Player | null {
  const inventoryIndex = player.inventory.findIndex((i) => i.unique_id === itemUniqueId);
  if (inventoryIndex === -1) return null;
  const item = player.inventory[inventoryIndex];

  const newInventory = [...player.inventory];
  newInventory.splice(inventoryIndex, 1);
  const newBank = [...player.bank, item];
  return { ...player, inventory: newInventory, bank: newBank };
}

export function moveItemsToBankAction(player: Player, itemUniqueIds: string[]): Player | null {
  const idsSet = new Set(itemUniqueIds);
  const itemsToMove = player.inventory.filter((item) => idsSet.has(item.unique_id));
  if (itemsToMove.length === 0) return null;

  const newInventory = player.inventory.filter((item) => !idsSet.has(item.unique_id));
  const newBank = [...player.bank, ...itemsToMove];
  return { ...player, inventory: newInventory, bank: newBank };
}

export function moveItemFromBankAction(player: Player, itemUniqueId: string): Player | null {
  const bankIndex = player.bank.findIndex((i) => i.unique_id === itemUniqueId);
  if (bankIndex === -1) return null;
  const item = player.bank[bankIndex];

  const newBank = [...player.bank];
  newBank.splice(bankIndex, 1);
  const newInventory = [...player.inventory, item];
  return { ...player, inventory: newInventory, bank: newBank };
}

export function moveItemsFromBankAction(player: Player, itemUniqueIds: string[]): Player | null {
  const idsSet = new Set(itemUniqueIds);
  const itemsToMove = player.bank.filter((item) => idsSet.has(item.unique_id));
  if (itemsToMove.length === 0) return null;

  const newBank = player.bank.filter((item) => !idsSet.has(item.unique_id));
  const newInventory = [...player.inventory, ...itemsToMove];
  return { ...player, inventory: newInventory, bank: newBank };
}

export function moveItemToContainerAction(
  player: Player,
  itemUniqueId: string,
  containerUniqueId: string,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];

  const playerInvIndex = player.inventory.findIndex((i) => i.unique_id === itemUniqueId);
  if (playerInvIndex === -1) {
    sideEffects.push({ type: 'LOG', message: 'Item to move not found.', logType: 'error' });
    return { player, sideEffects };
  }
  const itemToMove = player.inventory[playerInvIndex];
  const containerItem = player.inventory.find((i) => i.unique_id === containerUniqueId);

  if (!containerItem) {
    sideEffects.push({ type: 'LOG', message: 'Invalid container.', logType: 'error' });
    return { player, sideEffects };
  }
  if (itemToMove.unique_id === containerUniqueId) {
    sideEffects.push({ type: 'LOG', message: 'Cannot put a container in itself.', logType: 'error' });
    return { player, sideEffects };
  }
  if (!GAME_DATA.ITEMS[containerItem.id].type.includes('container')) {
    sideEffects.push({ type: 'LOG', message: 'Target is not a container.', logType: 'error' });
    return { player, sideEffects };
  }
  if (GAME_DATA.ITEMS[itemToMove.id].type.includes('container')) {
    sideEffects.push({ type: 'LOG', message: 'Unable to add containers to containers.', logType: 'error' });
    return { player, sideEffects };
  }

  let currentContainerState = containerItem.containerState;
  if (!currentContainerState) {
    const containerData = GAME_DATA.ITEMS[containerItem.id];
    currentContainerState = {
      items: [],
      capacity: containerData.capacity || 50,
    };
  }

  if (currentContainerState.items.length >= 900) {
    sideEffects.push({ type: 'LOG', message: 'Container is at its maximum item capacity (900).', logType: 'error' });
    return { player, sideEffects };
  }
  const currentContainerWeight = currentContainerState.items.reduce((sum, i) => sum + (GAME_DATA.ITEMS[i.id]?.weight || 0), 0);
  const itemToMoveWeight = GAME_DATA.ITEMS[itemToMove.id].weight;
  if (currentContainerWeight + itemToMoveWeight > currentContainerState.capacity) {
    sideEffects.push({ type: 'LOG', message: 'Container is full.', logType: 'error' });
    return { player, sideEffects };
  }

  const newInventory = [...player.inventory];
  const [movedItem] = newInventory.splice(playerInvIndex, 1);
  const newContainerIndex = newInventory.findIndex((c) => c.unique_id === containerUniqueId);

  if (newContainerIndex === -1) {
    sideEffects.push({ type: 'LOG', message: 'Container consistency error during transfer.', logType: 'error' });
    newInventory.splice(playerInvIndex, 0, movedItem);
    return { player: { ...player, inventory: newInventory }, sideEffects };
  }

  const currentContainer = newInventory[newContainerIndex];
  const updatedContainer: ItemInstance = {
    ...currentContainer,
    containerState: {
      ...currentContainer.containerState!,
      items: [...currentContainer.containerState!.items, movedItem],
    },
  };

  newInventory[newContainerIndex] = updatedContainer;
  return { player: { ...player, inventory: newInventory }, sideEffects };
}

export function moveItemFromContainerAction(
  player: Player,
  itemUniqueIdInContainer: string,
  containerUniqueId: string,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];
  const containerIndex = player.inventory.findIndex((i) => i.unique_id === containerUniqueId);
  if (containerIndex === -1) {
    sideEffects.push({ type: 'LOG', message: 'Container not found.', logType: 'error' });
    return { player, sideEffects };
  }

  let newInventory = [...player.inventory];
  const containerItem = newInventory[containerIndex];

  if (!containerItem || !GAME_DATA.ITEMS[containerItem.id].type.includes('container') || !containerItem.containerState) {
    sideEffects.push({ type: 'LOG', message: 'Invalid container.', logType: 'error' });
    return { player, sideEffects };
  }

  const itemIndexInContainer = containerItem.containerState.items.findIndex((i) => i.unique_id === itemUniqueIdInContainer);
  if (itemIndexInContainer === -1) {
    sideEffects.push({ type: 'LOG', message: 'Item not found in container.', logType: 'error' });
    return { player, sideEffects };
  }

  const itemToMove = containerItem.containerState.items[itemIndexInContainer];
  if (!itemToMove) {
    sideEffects.push({ type: 'LOG', message: 'Invalid item.', logType: 'error' });
    return { player, sideEffects };
  }

  const itemToMoveWeight = GAME_DATA.ITEMS[itemToMove.id].weight;
  if (player.currentWeight + itemToMoveWeight > player.maxCarryWeight) {
    sideEffects.push({ type: 'LOG', message: 'You would be over-encumbered.', logType: 'error' });
    return { player, sideEffects };
  }

  const newContainerItems = [...containerItem.containerState.items];
  newContainerItems.splice(itemIndexInContainer, 1);

  const newContainerState = {
    ...containerItem.containerState,
    items: newContainerItems,
  };
  const updatedContainerItem = {
    ...containerItem,
    containerState: newContainerState,
  };

  newInventory[containerIndex] = updatedContainerItem;
  newInventory.push(itemToMove);

  return { player: { ...player, inventory: newInventory }, sideEffects };
}