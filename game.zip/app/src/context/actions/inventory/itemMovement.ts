import { GameData, GameSideEffect, ItemInstance, Player } from '../../../types';
import { getItemName, getItemWeight, mergeIntoInventory } from 'utils/itemUtils';
import { PLAYER_INVENTORY_MAX_UNIQUE_ITEMS } from 'config/GLOBAL_QUICK_DEV_CONFIGURATION';

export function reorderInventoryAction(
  player: Player,
  draggedItemUniqueId: string,
  targetIndex: number
): { player: Player; sideEffects: GameSideEffect[] } | null {
  console.log(`[DragDrop Action] Reordering inventory. Item: ${draggedItemUniqueId}, Target Index: ${targetIndex}.`);

  const workInventory: (ItemInstance | null)[] = [...player.inventory];
  const sourceIndex = workInventory.findIndex((item) => item?.unique_id === draggedItemUniqueId);

  if (sourceIndex === -1) {
    console.error(`[DragDrop Action] Could not find dragged item ${draggedItemUniqueId} in inventory.`);
    return null;
  }

  if (sourceIndex === targetIndex) {
    return null;
  }

  // Ensure the work inventory is large enough to accommodate the target index
  while (workInventory.length <= targetIndex) {
    workInventory.push(null);
  }

  const itemToMove = workInventory[sourceIndex];
  const itemAtTarget = workInventory[targetIndex];

  // Perform a direct swap. If the target was empty (null), the source slot becomes empty.
  workInventory[targetIndex] = itemToMove;
  workInventory[sourceIndex] = itemAtTarget;

  // Clean up any trailing nulls from the end of the array to keep it tidy.
  let lastItemIndex = -1;
  for (let i = workInventory.length - 1; i >= 0; i--) {
    if (workInventory[i]) {
      lastItemIndex = i;
      break;
    }
  }
  workInventory.length = Math.max(0, lastItemIndex + 1);

  console.log(`[DragDrop Action] Reordering complete. New inventory length: ${workInventory.length}`);
  return { player: { ...player, inventory: workInventory as ItemInstance[] }, sideEffects: [] };
}

export function dropItemsAction(
  player: Player,
  itemsToDrop: { unique_id: string; quantity?: number }[],
  GAME_DATA: GameData
): { player: Player; droppedItems: ItemInstance[]; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];
  let tempPlayer = { ...player, inventory: [...player.inventory] };
  const droppedItems: ItemInstance[] = [];

  console.log('dropItemsAction START', { itemsToDrop });

  for (const { unique_id, quantity } of itemsToDrop) {
    const itemIdx = tempPlayer.inventory.findIndex((i) => i?.unique_id === unique_id);
    if (itemIdx === -1 || !tempPlayer.inventory[itemIdx]) continue;

    const stack = tempPlayer.inventory[itemIdx]!;
    const amountToDrop = quantity ?? stack.quantity;

    if (amountToDrop >= stack.quantity) {
      droppedItems.push(stack);
      // Replace with null instead of splicing to preserve indices
      (tempPlayer.inventory as (ItemInstance | null)[])[itemIdx] = null;
    } else {
      const droppedPart: ItemInstance = { ...stack, quantity: amountToDrop };
      droppedItems.push(droppedPart);
      stack.quantity -= amountToDrop;
    }
  }

  // Clean up trailing nulls
  const inv = tempPlayer.inventory as (ItemInstance | null)[];
  let lastItemIndex = -1;
  for (let i = inv.length - 1; i >= 0; i--) {
    if (inv[i]) {
      lastItemIndex = i;
      break;
    }
  }
  inv.length = lastItemIndex + 1;
  tempPlayer.inventory = inv as ItemInstance[];

  console.log('dropItemsAction droppedItems', { droppedItems });

  if (droppedItems.length > 0) {
    const groupedByName = droppedItems.reduce((acc, item) => {
      const name = getItemName(item, GAME_DATA);
      acc[name] = (acc[name] || 0) + item.quantity;
      return acc;
    }, {} as Record<string, number>);

    const messageParts = Object.entries(groupedByName).map(([name, quantity]) => {
      return `${name}${quantity > 1 ? ` (x${quantity})` : ''}`;
    });

    if (messageParts.length > 0) {
      const message = `You drop ${messageParts.join(', ')}.`;
      console.log('dropItemsAction generated message:', message);
      sideEffects.push({ type: 'LOG', message, logType: 'info' });
    }
  }

  console.log('dropItemsAction END', { sideEffects });
  return { player: tempPlayer, droppedItems: droppedItems, sideEffects };
}

export function moveItemToBankAction(player: Player, itemUniqueId: string, quantity: number | undefined, GAME_DATA: GameData): Player | null {
  const inventoryIndex = player.inventory.findIndex((i) => i?.unique_id === itemUniqueId);
  if (inventoryIndex === -1) return null;

  const newInventory = [...player.inventory];
  const itemInInventory = newInventory[inventoryIndex]!;
  const amountToMove = quantity ?? itemInInventory.quantity;

  let itemToMove: ItemInstance;

  if (amountToMove >= itemInInventory.quantity) {
    itemToMove = itemInInventory;
    (newInventory as (ItemInstance | null)[])[inventoryIndex] = null;
  } else {
    itemToMove = { ...itemInInventory, quantity: amountToMove };
    itemInInventory.quantity -= amountToMove;
  }

  const compactedInventory = newInventory.filter((i): i is ItemInstance => i !== null);

  const { newInventory: newBank } = mergeIntoInventory(player.bank, [itemToMove], GAME_DATA);
  return { ...player, inventory: compactedInventory, bank: newBank };
}

export function moveItemsToBankAction(player: Player, itemsToMove: { unique_id: string; quantity: number }[], GAME_DATA: GameData): Player | null {
  const itemsToAdd: ItemInstance[] = [];
  const newInventory = [...player.inventory];
  const movedIds = new Set<string>();

  for (const { unique_id, quantity } of itemsToMove) {
    if (movedIds.has(unique_id)) continue;
    const itemIdx = newInventory.findIndex((i) => i?.unique_id === unique_id);
    if (itemIdx === -1) continue;

    const stack = newInventory[itemIdx]!;
    const amountToMove = Math.min(quantity, stack.quantity);

    if (amountToMove >= stack.quantity) {
      itemsToAdd.push(stack);
      (newInventory as (ItemInstance | null)[])[itemIdx] = null;
    } else {
      itemsToAdd.push({ ...stack, quantity: amountToMove });
      stack.quantity -= amountToMove;
    }
    movedIds.add(unique_id);
  }

  if (itemsToAdd.length === 0) return null;

  const compactedInventory = newInventory.filter((i): i is ItemInstance => i !== null);

  const { newInventory: newBank } = mergeIntoInventory(player.bank, itemsToAdd, GAME_DATA);
  return { ...player, inventory: compactedInventory, bank: newBank };
}

export function moveItemFromBankAction(
  player: Player,
  itemUniqueId: string,
  quantity: number | undefined,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const bankIndex = player.bank.findIndex((i) => i?.unique_id === itemUniqueId);
  if (bankIndex === -1) return null;

  const newBank = [...player.bank];
  const itemInBank = newBank[bankIndex]!;
  const amountToMove = quantity ?? itemInBank.quantity;

  let itemToMove: ItemInstance;

  if (amountToMove >= itemInBank.quantity) {
    itemToMove = itemInBank;
    (newBank as (ItemInstance | null)[])[bankIndex] = null;
  } else {
    itemToMove = { ...itemInBank, quantity: amountToMove };
    itemInBank.quantity -= amountToMove;
  }
  const compactedBank = newBank.filter((i): i is ItemInstance => i !== null);

  const { newInventory, overflow } = mergeIntoInventory(player.inventory, [itemToMove], GAME_DATA);

  const sideEffects: GameSideEffect[] = [];
  if (overflow.length > 0) {
    sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
  }

  return { player: { ...player, inventory: newInventory, bank: compactedBank }, sideEffects };
}

export function moveItemsFromBankAction(
  player: Player,
  itemsToMove: { unique_id: string; quantity: number }[],
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const itemsToAdd: ItemInstance[] = [];
  const newBank = [...player.bank];
  const movedIds = new Set<string>();

  for (const { unique_id, quantity } of itemsToMove) {
    if (movedIds.has(unique_id)) continue;
    const itemIdx = newBank.findIndex((i) => i?.unique_id === unique_id);
    if (itemIdx === -1) continue;

    const stack = newBank[itemIdx]!;
    const amountToMove = Math.min(quantity, stack.quantity);

    if (amountToMove >= stack.quantity) {
      itemsToAdd.push(stack);
      (newBank as (ItemInstance | null)[])[itemIdx] = null;
    } else {
      itemsToAdd.push({ ...stack, quantity: amountToMove });
      stack.quantity -= amountToMove;
    }
    movedIds.add(unique_id);
  }

  if (itemsToAdd.length === 0) return null;

  const compactedBank = newBank.filter((i): i is ItemInstance => i !== null);

  const { newInventory, overflow } = mergeIntoInventory(player.inventory, itemsToAdd, GAME_DATA);

  const sideEffects: GameSideEffect[] = [];
  if (overflow.length > 0) {
    sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
  }

  return { player: { ...player, inventory: newInventory, bank: compactedBank }, sideEffects };
}

export function moveItemToContainerAction(
  player: Player,
  itemUniqueId: string,
  quantity: number,
  containerUniqueId: string,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[]; newContainerId?: string } {
  const sideEffects: GameSideEffect[] = [];
  let newContainerId: string | undefined = undefined;

  let newInventory = [...player.inventory];

  const playerInvIndex = newInventory.findIndex((i) => i?.unique_id === itemUniqueId);
  if (playerInvIndex === -1) {
    sideEffects.push({ type: 'LOG', message: 'Item to move not found.', logType: 'error' });
    return { player, sideEffects };
  }
  const itemToMoveSource = newInventory[playerInvIndex]!;

  let containerIndex = newInventory.findIndex((i) => i?.unique_id === containerUniqueId);
  if (containerIndex === -1) {
    sideEffects.push({ type: 'LOG', message: 'Container not found.', logType: 'error' });
    return { player, sideEffects };
  }
  let containerItem = newInventory[containerIndex]!;

  if (itemToMoveSource.unique_id === containerUniqueId) {
    sideEffects.push({ type: 'LOG', message: 'Cannot put a container in itself.', logType: 'error' });
    return { player, sideEffects };
  }
  if (!GAME_DATA.ITEMS[containerItem.id].type.includes('container')) {
    sideEffects.push({ type: 'LOG', message: 'Target is not a container.', logType: 'error' });
    return { player, sideEffects };
  }
  if (GAME_DATA.ITEMS[itemToMoveSource.id].type.includes('container')) {
    sideEffects.push({ type: 'LOG', message: 'Unable to add containers to containers.', logType: 'error' });
    return { player, sideEffects };
  }

  let currentContainerState = containerItem.containerState;
  if (!currentContainerState) {
    const containerData = GAME_DATA.ITEMS[containerItem.id];
    currentContainerState = {
      items: [],
      capacity: containerData.capacity || 50,
    };
  }

  if (currentContainerState.items.length >= 900) {
    sideEffects.push({ type: 'LOG', message: 'Container is at its maximum item capacity (900).', logType: 'error' });
    return { player, sideEffects };
  }
  const currentContainerWeight = currentContainerState.items.reduce((sum, i) => sum + getItemWeight(i, GAME_DATA), 0);
  const itemToMoveWeight = getItemWeight({ ...itemToMoveSource, quantity }, GAME_DATA);
  if (currentContainerWeight + itemToMoveWeight > currentContainerState.capacity) {
    sideEffects.push({ type: 'LOG', message: 'Container is full.', logType: 'error' });
    return { player, sideEffects };
  }

  // Stack splitting logic
  if (containerItem.quantity > 1) {
    console.log('TEST 1: Container stack detected. Quantity:', containerItem.quantity);
    if (newInventory.filter(Boolean).length >= PLAYER_INVENTORY_MAX_UNIQUE_ITEMS) {
      sideEffects.push({ type: 'LOG', message: 'Not enough space in your inventory to separate the container from its stack.', logType: 'error' });
      return { player, sideEffects };
    }

    const originalStack = newInventory.find((i) => i?.unique_id === containerUniqueId)!;
    originalStack.quantity -= 1;

    const newSingleContainer: ItemInstance = {
      ...originalStack,
      quantity: 1,
      unique_id: `item_${Date.now()}_${Math.random()}`,
    };
    newInventory.push(newSingleContainer);

    containerItem = newSingleContainer;
    newContainerId = newSingleContainer.unique_id;
    console.log('TEST 2: New container created with ID:', newContainerId);
  }

  // Item moving logic - re-find indices as they might have changed
  const finalItemIndex = newInventory.findIndex((i) => i?.unique_id === itemUniqueId);
  const itemStackToModify = newInventory[finalItemIndex]!;

  let movedItem: ItemInstance;
  if (itemStackToModify.quantity > quantity) {
    movedItem = { ...itemStackToModify, quantity };
    itemStackToModify.quantity -= quantity;
  } else {
    [movedItem] = (newInventory as (ItemInstance | null)[]).splice(finalItemIndex, 1, null) as ItemInstance[];
  }

  const finalContainerIndex = newInventory.findIndex((c) => c?.unique_id === containerItem.unique_id);
  const containerToUpdate = newInventory[finalContainerIndex]!;

  const oldContainerItems = containerToUpdate.containerState?.items || [];
  const { newInventory: newContainerItems } = mergeIntoInventory(oldContainerItems, [movedItem], GAME_DATA);

  const updatedContainer: ItemInstance = {
    ...containerToUpdate,
    containerState: {
      ...(containerToUpdate.containerState || { items: [], capacity: GAME_DATA.ITEMS[containerToUpdate.id].capacity || 50 }),
      items: newContainerItems,
    },
  };
  newInventory[finalContainerIndex] = updatedContainer;

  return { player: { ...player, inventory: newInventory as ItemInstance[] }, sideEffects, newContainerId };
}

export function moveItemFromContainerAction(
  player: Player,
  itemUniqueIdInContainer: string,
  quantity: number,
  containerUniqueId: string,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];
  const containerIndex = player.inventory.findIndex((i) => i?.unique_id === containerUniqueId);
  if (containerIndex === -1) {
    sideEffects.push({ type: 'LOG', message: 'Container not found.', logType: 'error' });
    return { player, sideEffects };
  }

  let newInventory = [...player.inventory];
  const containerItem = newInventory[containerIndex]!;

  if (!containerItem || !GAME_DATA.ITEMS[containerItem.id].type.includes('container') || !containerItem.containerState) {
    sideEffects.push({ type: 'LOG', message: 'Invalid container.', logType: 'error' });
    return { player, sideEffects };
  }

  const itemIndexInContainer = containerItem.containerState.items.findIndex((i) => i.unique_id === itemUniqueIdInContainer);
  if (itemIndexInContainer === -1) {
    sideEffects.push({ type: 'LOG', message: 'Item not found in container.', logType: 'error' });
    return { player, sideEffects };
  }

  const itemToMove = containerItem.containerState.items[itemIndexInContainer];
  if (!itemToMove) {
    sideEffects.push({ type: 'LOG', message: 'Invalid item.', logType: 'error' });
    return { player, sideEffects };
  }

  const itemToMoveWeight = getItemWeight({ ...itemToMove, quantity }, GAME_DATA);
  if (player.currentWeight + itemToMoveWeight > player.maxCarryWeight) {
    sideEffects.push({ type: 'LOG', message: 'You would be over-encumbered.', logType: 'error' });
    return { player, sideEffects };
  }

  const newContainerItems = [...containerItem.containerState.items];
  let movedItem: ItemInstance;

  if (itemToMove.quantity > quantity) {
    movedItem = { ...itemToMove, quantity };
    newContainerItems[itemIndexInContainer].quantity -= quantity;
  } else {
    [movedItem] = newContainerItems.splice(itemIndexInContainer, 1);
  }

  const newContainerState = {
    ...containerItem.containerState,
    items: newContainerItems,
  };
  const updatedContainerItem = {
    ...containerItem,
    containerState: newContainerState,
  };

  newInventory[containerIndex] = updatedContainerItem;
  const { newInventory: finalInventory, overflow } = mergeIntoInventory(newInventory as ItemInstance[], [movedItem], GAME_DATA);

  if (overflow.length > 0) {
    sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
  }

  return { player: { ...player, inventory: finalInventory }, sideEffects };
}