import { Player, ItemInstance, GameLocation, GameData } from "../../../types";

export function dropItemsImpl(
  itemUniqueIds: string[],
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>,
  setCurrentLocation: (update: React.SetStateAction<GameLocation | null>) => void,
  logMessage: (message: string, type: any) => void,
  gameTime: Date,
) {
  let itemsToDrop: ItemInstance[] = [];
  setPlayer((p) => {
    if (!p) return p;
    const idsSet = new Set(itemUniqueIds);
    itemsToDrop = p.inventory.filter((item) => idsSet.has(item.unique_id));
    if (itemsToDrop.length === 0) return p;

    const newInventory = p.inventory.filter((item) => !idsSet.has(item.unique_id));
    logMessage(`You drop ${itemsToDrop.length} item(s).`, "info");
    return { ...p, inventory: newInventory };
  });

  if (itemsToDrop.length > 0) {
    setCurrentLocation((l) => {
      if (!l) return l;
      return { ...l, groundLoot: [...(l.groundLoot || []), ...itemsToDrop], groundLootTimestamp: gameTime.getTime() };
    });
  }
}

export function moveItemToBankImpl(itemUniqueId: string, setPlayer: React.Dispatch<React.SetStateAction<Player | null>>) {
  setPlayer((p) => {
    if (!p) return p;
    const inventoryIndex = p.inventory.findIndex((i) => i.unique_id === itemUniqueId);
    if (inventoryIndex === -1) return p;
    const item = p.inventory[inventoryIndex];

    const newInventory = [...p.inventory];
    newInventory.splice(inventoryIndex, 1);
    const newBank = [...p.bank, item];
    return { ...p, inventory: newInventory, bank: newBank };
  });
}

export function moveItemsToBankImpl(itemUniqueIds: string[], setPlayer: React.Dispatch<React.SetStateAction<Player | null>>) {
  setPlayer((p) => {
    if (!p) return p;
    const idsSet = new Set(itemUniqueIds);
    const itemsToMove = p.inventory.filter((item) => idsSet.has(item.unique_id));
    if (itemsToMove.length === 0) return p;

    const newInventory = p.inventory.filter((item) => !idsSet.has(item.unique_id));
    const newBank = [...p.bank, ...itemsToMove];
    return { ...p, inventory: newInventory, bank: newBank };
  });
}

export function moveItemFromBankImpl(itemUniqueId: string, setPlayer: React.Dispatch<React.SetStateAction<Player | null>>) {
  setPlayer((p) => {
    if (!p) return p;
    const bankIndex = p.bank.findIndex((i) => i.unique_id === itemUniqueId);
    if (bankIndex === -1) return p;
    const item = p.bank[bankIndex];

    const newBank = [...p.bank];
    newBank.splice(bankIndex, 1);
    const newInventory = [...p.inventory, item];
    return { ...p, inventory: newInventory, bank: newBank };
  });
}

export function moveItemsFromBankImpl(itemUniqueIds: string[], setPlayer: React.Dispatch<React.SetStateAction<Player | null>>) {
  setPlayer((p) => {
    if (!p) return p;
    const idsSet = new Set(itemUniqueIds);
    const itemsToMove = p.bank.filter((item) => idsSet.has(item.unique_id));
    if (itemsToMove.length === 0) return p;

    const newBank = p.bank.filter((item) => !idsSet.has(item.unique_id));
    const newInventory = [...p.inventory, ...itemsToMove];
    return { ...p, inventory: newInventory, bank: newBank };
  });
}

export function moveItemToContainerImpl(
  itemUniqueId: string,
  containerUniqueId: string,
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>,
  logMessage: (message: string, type: any) => void,
  GAME_DATA: GameData,
) {
  setPlayer((p) => {
    if (!p) return p;

    const playerInvIndex = p.inventory.findIndex((i) => i.unique_id === itemUniqueId);
    if (playerInvIndex === -1) {
      logMessage("Item to move not found.", "error");
      return p;
    }
    const itemToMove = p.inventory[playerInvIndex];
    const containerItem = p.inventory.find((i) => i.unique_id === containerUniqueId);

    if (!containerItem) {
      logMessage("Invalid container.", "error");
      return p;
    }
    if (itemToMove.unique_id === containerUniqueId) {
      logMessage("Cannot put a container in itself.", "error");
      return p;
    }
    if (!GAME_DATA.ITEMS[containerItem.id].type.includes("container")) {
      logMessage("Target is not a container.", "error");
      return p;
    }
    if (GAME_DATA.ITEMS[itemToMove.id].type.includes("container")) {
      logMessage("Unable to add containers to containers.", "error");
      return p;
    }

    let currentContainerState = containerItem.containerState;
    if (!currentContainerState) {
      const containerData = GAME_DATA.ITEMS[containerItem.id];
      currentContainerState = {
        items: [],
        capacity: containerData.capacity || 50,
      };
    }

    if (currentContainerState.items.length >= 900) {
      logMessage("Container is at its maximum item capacity (900).", "error");
      return p;
    }
    const currentContainerWeight = currentContainerState.items.reduce((sum, i) => sum + (GAME_DATA.ITEMS[i.id]?.weight || 0), 0);
    const itemToMoveWeight = GAME_DATA.ITEMS[itemToMove.id].weight;
    if (currentContainerWeight + itemToMoveWeight > currentContainerState.capacity) {
      logMessage("Container is full.", "error");
      return p;
    }

    const newInventory = [...p.inventory];
    const [movedItem] = newInventory.splice(playerInvIndex, 1);
    const newContainerIndex = newInventory.findIndex((c) => c.unique_id === containerUniqueId);

    if (newContainerIndex === -1) {
      logMessage("Container consistency error during transfer.", "error");
      newInventory.splice(playerInvIndex, 0, movedItem);
      return { ...p, inventory: newInventory };
    }

    const currentContainer = newInventory[newContainerIndex];
    const updatedContainer: ItemInstance = {
      ...currentContainer,
      containerState: {
        ...(currentContainer.containerState!),
        items: [...currentContainer.containerState!.items, movedItem],
      },
    };

    newInventory[newContainerIndex] = updatedContainer;
    return { ...p, inventory: newInventory };
  });
}

export function moveItemFromContainerImpl(
  itemUniqueIdInContainer: string,
  containerUniqueId: string,
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>,
  logMessage: (message: string, type: any) => void,
  GAME_DATA: GameData,
) {
  setPlayer((p) => {
    if (!p) return p;

    const containerIndex = p.inventory.findIndex((i) => i.unique_id === containerUniqueId);
    if (containerIndex === -1) {
      logMessage("Container not found.", "error");
      return p;
    }

    let newInventory = [...p.inventory];
    const containerItem = newInventory[containerIndex];

    if (!containerItem || !GAME_DATA.ITEMS[containerItem.id].type.includes("container") || !containerItem.containerState) {
      logMessage("Invalid container.", "error");
      return p;
    }

    const itemIndexInContainer = containerItem.containerState.items.findIndex(
      (i) => i.unique_id === itemUniqueIdInContainer,
    );
    if (itemIndexInContainer === -1) {
      logMessage("Item not found in container.", "error");
      return p;
    }

    const itemToMove = containerItem.containerState.items[itemIndexInContainer];
    if (!itemToMove) {
      logMessage("Invalid item.", "error");
      return p;
    }

    const itemToMoveWeight = GAME_DATA.ITEMS[itemToMove.id].weight;
    if (p.currentWeight + itemToMoveWeight > p.maxWeight) {
      logMessage("You would be over-encumbered.", "error");
      return p;
    }

    const newContainerItems = [...containerItem.containerState.items];
    newContainerItems.splice(itemIndexInContainer, 1);

    const newContainerState = {
      ...containerItem.containerState,
      items: newContainerItems,
    };
    const updatedContainerItem = {
      ...containerItem,
      containerState: newContainerState,
    };

    newInventory[containerIndex] = updatedContainerItem;
    newInventory.push(itemToMove);

    return { ...p, inventory: newInventory };
  });
}