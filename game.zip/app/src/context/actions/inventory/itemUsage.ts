import { Player, ItemInstance, StatusEffectId, AbilityId, RecipeId, Mercenary, GameData, GameSideEffect } from '../../../types';
import { getItemName } from 'utils/itemUtils';
import { reviveCharacter } from 'utils/playerUtils';
import { deepCloneWithInfinity } from 'utils/mathUtils';

export function consumeItem(
  player: Player,
  itemUniqueId: string,
  targetId: string | undefined,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const inventoryIndex = player.inventory.findIndex((i) => i.unique_id === itemUniqueId);
  if (inventoryIndex === -1) {
    return { player, sideEffects: [{ type: 'LOG', message: 'Item to consume not found.', logType: 'error' }] };
  }

  const itemInstance = player.inventory[inventoryIndex];
  const itemData = GAME_DATA.ITEMS[itemInstance.id];
  const sideEffects: GameSideEffect[] = [];
  let playerStateAfterEffect = deepCloneWithInfinity(player);

  if (itemData.type.includes('note')) {
    if (itemData.teachesRecipe) {
      if (player.knownRecipes[itemData.teachesRecipe]) {
        sideEffects.push({ type: 'LOG', message: 'You already know this recipe.', logType: 'info' });
        return { player, sideEffects };
      }
      sideEffects.push({ type: 'LEARN_RECIPE', recipeId: itemData.teachesRecipe } as GameSideEffect);
    } else if (itemData.teachesAbility) {
      if (player.skills[itemData.teachesAbility]) {
        const ability = GAME_DATA.SKILLS[itemData.teachesAbility];
        sideEffects.push({ type: 'LOG', message: `You already know ${ability.name}.`, logType: 'info' });
        return { player, sideEffects };
      }
      sideEffects.push({ type: 'LEARN_ABILITY', abilityId: itemData.teachesAbility } as GameSideEffect);
    } else {
      sideEffects.push({ type: 'LOG', message: 'The writing is illegible.', logType: 'info' });
      return { player, sideEffects };
    }
  } else if (itemData.type.includes('potion')) {
    if (itemInstance.charges !== undefined && itemInstance.charges <= 0) {
      sideEffects.push({ type: 'LOG', message: `${getItemName(itemInstance, GAME_DATA)} is empty.`, logType: 'info' });
      return { player, sideEffects };
    }

    const effect = itemData.effect;
    if (effect?.revive) {
      if (!targetId) {
        sideEffects.push({ type: 'LOG', message: 'You must select a target to revive.', logType: 'error' });
        return { player, sideEffects };
      }
      const newPlayer = deepCloneWithInfinity(player);

      const corpseIndex = newPlayer.inventory.findIndex((i: ItemInstance) => i.unique_id === targetId);
      if (corpseIndex === -1) {
        sideEffects.push({ type: 'LOG', message: 'Invalid target.', logType: 'error' });
        return { player, sideEffects };
      }
      const corpseItem = newPlayer.inventory[corpseIndex];
      if (!corpseItem.deceasedCharacter) {
        sideEffects.push({ type: 'LOG', message: 'Invalid target.', logType: 'error' });
        return { player, sideEffects };
      }
      if (newPlayer.party.length >= 3) {
        sideEffects.push({ type: 'LOG', message: 'Your party is full.', logType: 'error' });
        return { player, sideEffects };
      }

      const mercToRevive = corpseItem.deceasedCharacter;
      const revivedMerc = reviveCharacter(mercToRevive, effect.revive.percentHealth, GAME_DATA) as Mercenary;

      newPlayer.party.push(revivedMerc);
      newPlayer.inventory.splice(corpseIndex, 1);

      sideEffects.push({ type: 'LOG', message: `${mercToRevive.name} has been revived by a ${itemData.name}!`, logType: 'heal' });
      playerStateAfterEffect = newPlayer;
    } else if (effect?.closesCutOfStage) {
      if (!targetId) {
        sideEffects.push({ type: 'LOG', message: 'You must select a limb to apply this to.', logType: 'error' });
        return { player, sideEffects };
      }
      playerStateAfterEffect = deepCloneWithInfinity(player);
      const targetLimb = playerStateAfterEffect.body[targetId];
      if (!targetLimb) {
        sideEffects.push({ type: 'LOG', message: 'Invalid limb target.', logType: 'error' });
        return { player, sideEffects };
      }
      const cutToClose = targetLimb.statusEffects.find((se: any) => se.id === 'cut' && !se.isClosed && se.currentStage! <= effect.closesCutOfStage!);
      if (!cutToClose) {
        sideEffects.push({ type: 'LOG', message: `Your ${targetLimb.displayName} has no open wound this bandage can treat.`, logType: 'info' });
        return { player, sideEffects };
      }
      cutToClose.isClosed = true;
      targetLimb.statusEffects = targetLimb.statusEffects.filter((se: any) => se.linkedToInstanceId !== cutToClose.instanceId);
      sideEffects.push({
        type: 'LOG',
        message: `You apply the ${getItemName(itemInstance, GAME_DATA)} to the wound on your ${targetLimb.displayName}. The bleeding stops.`,
        logType: 'heal',
      });
    } else if (effect?.applyStatusEffect) {
      sideEffects.push({
        type: 'APPLY_STATUS_EFFECT',
        effectId: effect.applyStatusEffect.id,
        options: {
          turns: effect.applyStatusEffect.turns || 0,
          durationInMinutes: effect.applyStatusEffect.durationInMinutes,
        },
      } as GameSideEffect);
    } else if (effect?.cureStatusEffect) {
      let cured = false;
      playerStateAfterEffect = deepCloneWithInfinity(player);
      playerStateAfterEffect.statusEffects = playerStateAfterEffect.statusEffects.filter((b) => {
        if (b.id !== effect.cureStatusEffect) return true;
        cured = true;
        return false;
      });
      for (const limbId in playerStateAfterEffect.body) {
        playerStateAfterEffect.body[limbId].statusEffects = playerStateAfterEffect.body[limbId].statusEffects.filter((b) => {
          if (b.id !== effect.cureStatusEffect) return true;
          cured = true;
          return false;
        });
      }
      if (cured) {
        sideEffects.push({ type: 'LOG', message: `You use the ${getItemName(itemInstance, GAME_DATA)} to treat your ${GAME_DATA.STATUS_EFFECTS[effect.cureStatusEffect].name}.`, logType: 'heal' });
      } else {
        sideEffects.push({ type: 'LOG', message: 'You have nothing to cure with this item.', logType: 'info' });
        return { player, sideEffects };
      }
    } else {
      sideEffects.push({ type: 'LOG', message: `${getItemName(itemInstance, GAME_DATA)} has no effect.`, logType: 'info' });
      return { player, sideEffects };
    }
  } else {
    return null; // Not a consumable item type
  }

  const finalPlayerState = { ...playerStateAfterEffect };
  const finalInventory = [...finalPlayerState.inventory];
  const finalItemIndex = finalInventory.findIndex((i) => i.unique_id === itemUniqueId);

  if (finalItemIndex === -1) {
    return { player: finalPlayerState, sideEffects };
  }

  const itemToConsume = { ...finalInventory[finalItemIndex] };

  if (itemToConsume.charges !== undefined && itemToConsume.charges > 0) {
    itemToConsume.charges -= 1;
    if (itemToConsume.charges <= 0 && itemData.destroyOnEmpty) {
      finalInventory.splice(finalItemIndex, 1);
    } else {
      finalInventory[finalItemIndex] = itemToConsume;
    }
  } else if (itemToConsume.charges === undefined) {
    finalInventory.splice(finalItemIndex, 1);
  }

  return { player: { ...finalPlayerState, inventory: finalInventory }, sideEffects };
}