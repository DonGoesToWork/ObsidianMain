import { mergeIntoInventory } from 'utils/itemUtils';
import { deepCloneWithInfinity } from 'utils/mathUtils';
import { reviveCharacter } from 'utils/playerUtils';
import { GameData, GameSideEffect, ItemInstance, Mercenary, Player, PlayerEquipmentSlot } from '../../../types';
import { calculateItemLevel, calculateItemTier, getItemName } from 'utils/itemUtils';

export function itemOnItemAction(
  player: Player,
  heldItemUniqueId: string,
  targetItemUniqueId: string,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const sideEffects: GameSideEffect[] = [];

  const heldItemIndex = player.inventory.findIndex((i) => i.unique_id === heldItemUniqueId);
  if (heldItemIndex === -1) return null;

  const heldItem = player.inventory[heldItemIndex];
  const heldItemData = GAME_DATA.ITEMS[heldItem.id];

  let targetItem: ItemInstance | undefined | null = null;
  let targetLocation: 'inventory' | PlayerEquipmentSlot | null = null;

  // Find target in inventory or equipment
  const targetInventoryIndex = player.inventory.findIndex((i) => i.unique_id === targetItemUniqueId);
  if (targetInventoryIndex > -1) {
    targetItem = player.inventory[targetInventoryIndex];
    targetLocation = 'inventory';
  } else {
    for (const slot in player.equipment) {
      const equippedItem = player.equipment[slot as PlayerEquipmentSlot];
      if (equippedItem?.unique_id === targetItemUniqueId) {
        targetItem = equippedItem;
        targetLocation = slot as PlayerEquipmentSlot;
        break;
      }
    }
  }

  if (!targetItem || !targetLocation) {
    sideEffects.push({ type: 'LOG', message: 'Invalid target item.', logType: 'error' });
    return { player, sideEffects };
  }

  const targetItemData = GAME_DATA.ITEMS[targetItem.id];

  // --- Plus Stone Logic --
  if (heldItemData.plusStoneTier) {
    if (!targetItemData.type.includes('equipment') || targetItemData.isUnarmed) {
      sideEffects.push({ type: 'LOG', message: 'This can only be used on equipment.', logType: 'info' });
      return { player, sideEffects };
    }

    const currentPlus = targetItem.plus_value || 0;
    if (currentPlus >= heldItemData.plusStoneTier) {
      sideEffects.push({ type: 'LOG', message: `This stone can only upgrade items with a plus value below ${heldItemData.plusStoneTier}.`, logType: 'error' });
      return { player, sideEffects };
    }

    let newPlayer = deepCloneWithInfinity(player);

    const stoneInInventory = newPlayer.inventory.find((i) => i.unique_id === heldItem.unique_id)!;
    if (stoneInInventory.quantity > 1) {
      stoneInInventory.quantity -= 1;
    } else {
      newPlayer.inventory = newPlayer.inventory.filter((i) => i.unique_id !== heldItem.unique_id);
    }

    const upgradedSingleItem: ItemInstance = { ...targetItem, quantity: 1, plus_value: currentPlus + 1, unique_id: `item_${Date.now()}_${Math.random()}` };

    if (targetLocation === 'inventory') {
      const targetStackIndex = newPlayer.inventory.findIndex((i) => i.unique_id === targetItem!.unique_id);
      if (targetStackIndex > -1) {
        const originalStack = newPlayer.inventory[targetStackIndex];
        originalStack.quantity -= 1;
        if (originalStack.quantity <= 0) {
          newPlayer.inventory.splice(targetStackIndex, 1);
        }
      }
      const { newInventory, overflow } = mergeIntoInventory(newPlayer.inventory, [upgradedSingleItem], GAME_DATA);
      newPlayer.inventory = newInventory;
      if (overflow.length > 0) {
        sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
      }
    } else {
      newPlayer.equipment[targetLocation] = upgradedSingleItem;
    }

    sideEffects.push({ type: 'LOG', message: `${getItemName(targetItem, GAME_DATA)} was successfully upgraded to +${upgradedSingleItem.plus_value}!`, logType: 'skill' });
    return { player: newPlayer, sideEffects };
  } else if (heldItemData.bestowsEnchantment) {
    const orbEnchantInfo = heldItemData.bestowsEnchantment;

    if (!targetItemData.type.includes('equipment') || targetItemData.isUnarmed) {
      sideEffects.push({ type: 'LOG', message: 'This can only be used on equipment.', logType: 'info' });
      return { player, sideEffects };
    }
    if (targetItem.isUnidentified) {
      sideEffects.push({ type: 'LOG', message: 'Cannot enchant an unidentified item.', logType: 'error' });
      return { player, sideEffects };
    }

    const itemLevel = calculateItemLevel(targetItem, GAME_DATA);
    const itemTier = calculateItemTier(itemLevel);
    if (orbEnchantInfo.tier > itemTier) {
      sideEffects.push({ type: 'LOG', message: `This item's tier is too low for a Tier ${orbEnchantInfo.tier} enchantment.`, logType: 'error' });
      return { player, sideEffects };
    }

    const currentEnchants = targetItem.enchantments || {};
    const currentTierOfThisEnchant = currentEnchants[orbEnchantInfo.id] || 0;
    if (orbEnchantInfo.tier <= currentTierOfThisEnchant) {
      sideEffects.push({ type: 'LOG', message: `This item already has this enchantment at Tier ${currentTierOfThisEnchant} or higher.`, logType: 'error' });
      return { player, sideEffects };
    }

    const isNewEnchant = !currentEnchants[orbEnchantInfo.id];
    const numEnchants = Object.keys(currentEnchants).length;
    const maxEnchants = Object.keys(GAME_DATA.ITEM_RARITY_TIERS).length - 1;
    if (isNewEnchant && numEnchants >= maxEnchants) {
      sideEffects.push({ type: 'LOG', message: 'This item has reached its maximum number of enchantments.', logType: 'error' });
      return { player, sideEffects };
    }

    let newPlayer = deepCloneWithInfinity(player);

    const orbInInventory = newPlayer.inventory.find((i) => i.unique_id === heldItem.unique_id)!;
    if (orbInInventory.quantity > 1) {
      orbInInventory.quantity -= 1;
    } else {
      newPlayer.inventory = newPlayer.inventory.filter((i) => i.unique_id !== heldItem.unique_id);
    }

    const newEnchantments = { ...currentEnchants, [orbEnchantInfo.id]: orbEnchantInfo.tier };
    const enchantedSingleItem: ItemInstance = { ...targetItem, quantity: 1, enchantments: newEnchantments, unique_id: `item_${Date.now()}_${Math.random()}` };

    if (targetLocation === 'inventory') {
      const targetStackIndex = newPlayer.inventory.findIndex((i) => i.unique_id === targetItem!.unique_id);
      if (targetStackIndex > -1) {
        const originalStack = newPlayer.inventory[targetStackIndex];
        originalStack.quantity -= 1;
        if (originalStack.quantity <= 0) {
          newPlayer.inventory.splice(targetStackIndex, 1);
        }
      }
      const { newInventory, overflow } = mergeIntoInventory(newPlayer.inventory, [enchantedSingleItem], GAME_DATA);
      newPlayer.inventory = newInventory;
      if (overflow.length > 0) {
        sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
      }
    } else {
      newPlayer.equipment[targetLocation] = enchantedSingleItem;
    }

    sideEffects.push({ type: 'LOG', message: `${getItemName(targetItem, GAME_DATA)} was successfully enchanted!`, logType: 'skill' });
    return { player: newPlayer, sideEffects };
  }

  return null;
}

export function consumeItem(
  player: Player,
  itemUniqueId: string,
  targetId: string | undefined,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const inventoryIndex = player.inventory.findIndex((i) => i.unique_id === itemUniqueId);
  if (inventoryIndex === -1) {
    return { player, sideEffects: [{ type: 'LOG', message: 'Item to consume not found.', logType: 'error' }] };
  }

  const itemInstance = player.inventory[inventoryIndex];
  const itemData = GAME_DATA.ITEMS[itemInstance.id];
  const sideEffects: GameSideEffect[] = [];
  let playerStateAfterEffect = deepCloneWithInfinity(player);

  if (itemData.type.includes('knowledge')) {
    if (itemData.teachesRecipe) {
      if (player.knownRecipes[itemData.teachesRecipe]) {
        sideEffects.push({ type: 'LOG', message: 'You already know this recipe.', logType: 'info' });
        return { player, sideEffects };
      }
      sideEffects.push({ type: 'LEARN_RECIPE', recipeId: itemData.teachesRecipe } as GameSideEffect);
    } else if (itemData.teachesEnchantmentRecipe) {
      if (player.knownEnchantments[itemData.teachesEnchantmentRecipe]) {
        sideEffects.push({ type: 'LOG', message: 'You already know this enchantment recipe.', logType: 'info' });
        return { player, sideEffects };
      }
      sideEffects.push({ type: 'LEARN_ENCHANTMENT', enchantmentRecipeId: itemData.teachesEnchantmentRecipe } as GameSideEffect);
    } else if (itemData.teachesAbility) {
      if (player.skills[itemData.teachesAbility]) {
        const ability = GAME_DATA.SKILLS[itemData.teachesAbility];
        sideEffects.push({ type: 'LOG', message: `You already know ${ability.name}.`, logType: 'info' });
        return { player, sideEffects };
      }
      sideEffects.push({ type: 'LEARN_ABILITY', abilityId: itemData.teachesAbility } as GameSideEffect);
    } else {
      sideEffects.push({ type: 'LOG', message: 'The writing is illegible.', logType: 'info' });
      return { player, sideEffects };
    }
  } else if (itemData.type.includes('consumable')) {
    const effect = itemData.effect;
    if (effect?.revive) {
      if (!targetId) {
        sideEffects.push({ type: 'LOG', message: 'You must select a target to revive.', logType: 'error' });
        return { player, sideEffects };
      }
      const newPlayer = deepCloneWithInfinity(player);

      const corpseIndex = newPlayer.inventory.findIndex((i: ItemInstance) => i.unique_id === targetId);
      if (corpseIndex === -1) {
        sideEffects.push({ type: 'LOG', message: 'Invalid target.', logType: 'error' });
        return { player, sideEffects };
      }
      const corpseItem = newPlayer.inventory[corpseIndex];
      if (!corpseItem.deceasedCharacter) {
        sideEffects.push({ type: 'LOG', message: 'Invalid target.', logType: 'error' });
        return { player, sideEffects };
      }
      if (newPlayer.party.length >= 3) {
        sideEffects.push({ type: 'LOG', message: 'Your party is full.', logType: 'error' });
        return { player, sideEffects };
      }

      const mercToRevive = corpseItem.deceasedCharacter;
      const revivedMerc = reviveCharacter(mercToRevive, effect.revive.percentHealth, GAME_DATA) as Mercenary;

      newPlayer.party.push(revivedMerc);
      newPlayer.inventory.splice(corpseIndex, 1);

      sideEffects.push({ type: 'LOG', message: `${mercToRevive.name} has been revived by a ${itemData.name}!`, logType: 'heal' });
      playerStateAfterEffect = newPlayer;
    } else if (effect?.closesCutOfStage) {
      if (!targetId) {
        sideEffects.push({ type: 'LOG', message: 'You must select a limb to apply this to.', logType: 'error' });
        return { player, sideEffects };
      }
      playerStateAfterEffect = deepCloneWithInfinity(player);
      const targetLimb = playerStateAfterEffect.body[targetId];
      if (!targetLimb) {
        sideEffects.push({ type: 'LOG', message: 'Invalid limb target.', logType: 'error' });
        return { player, sideEffects };
      }
      const cutToClose = targetLimb.statusEffects.find((se: any) => se.id === 'cut' && !se.isClosed && se.currentStage! <= effect.closesCutOfStage!);
      if (!cutToClose) {
        sideEffects.push({ type: 'LOG', message: `Your ${targetLimb.displayName} has no open wound this bandage can treat.`, logType: 'info' });
        return { player, sideEffects };
      }
      cutToClose.isClosed = true;
      targetLimb.statusEffects = targetLimb.statusEffects.filter((se: any) => se.linkedToInstanceId !== cutToClose.instanceId);
      sideEffects.push({
        type: 'LOG',
        message: `You apply the ${itemInstance.name} to the wound on your ${targetLimb.displayName}. The bleeding stops.`,
        logType: 'heal',
      });
    } else if (effect?.applyStatusEffect) {
      sideEffects.push({
        type: 'APPLY_STATUS_EFFECT',
        effectId: effect.applyStatusEffect.id,
        options: {
          turns: effect.applyStatusEffect.turns || 0,
          durationInMinutes: effect.applyStatusEffect.durationInMinutes,
        },
      } as GameSideEffect);
    } else if (effect?.cureStatusEffect) {
      let cured = false;
      playerStateAfterEffect = deepCloneWithInfinity(player);
      playerStateAfterEffect.statusEffects = playerStateAfterEffect.statusEffects.filter((b) => {
        if (b.id !== effect.cureStatusEffect) return true;
        cured = true;
        return false;
      });
      for (const limbId in playerStateAfterEffect.body) {
        playerStateAfterEffect.body[limbId].statusEffects = playerStateAfterEffect.body[limbId].statusEffects.filter((b) => {
          if (b.id !== effect.cureStatusEffect) return true;
          cured = true;
          return false;
        });
      }
      if (cured) {
        sideEffects.push({
          type: 'LOG',
          message: `You use the ${itemInstance.name} to treat your ${GAME_DATA.STATUS_EFFECTS[effect.cureStatusEffect].name}.`,
          logType: 'heal',
        });
      } else {
        sideEffects.push({ type: 'LOG', message: 'You have nothing to cure with this item.', logType: 'info' });
        return { player, sideEffects };
      }
    } else {
      sideEffects.push({ type: 'LOG', message: `${itemInstance.name} has no effect.`, logType: 'info' });
    }
  } else {
    return null; // Not a consumable item type
  }

  const finalPlayerState = { ...playerStateAfterEffect };
  let finalInventory = [...finalPlayerState.inventory];
  const finalItemIndex = finalInventory.findIndex((i) => i.unique_id === itemUniqueId);

  if (finalItemIndex > -1) {
    const stack = finalInventory[finalItemIndex];

    const singleItemInstance: ItemInstance = { ...stack, quantity: 1 };

    if (singleItemInstance.charges !== undefined) {
      singleItemInstance.charges -= 1;
    }

    if (stack.quantity > 1) {
      stack.quantity -= 1;
    } else {
      finalInventory.splice(finalItemIndex, 1);
    }

    if (singleItemInstance.charges !== undefined) {
      if (singleItemInstance.charges > 0 || !itemData.destroyOnEmpty) {
        singleItemInstance.unique_id = `item_${Date.now()}_${Math.random()}`;
        const { newInventory, overflow } = mergeIntoInventory(finalInventory, [singleItemInstance], GAME_DATA);
        finalInventory = newInventory;
        if (overflow.length > 0) {
          sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
        }
      }
    }
  }

  return { player: { ...finalPlayerState, inventory: finalInventory }, sideEffects };
}