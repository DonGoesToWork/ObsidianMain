import { mergeIntoInventory } from 'utils/itemUtils';
import { deepCloneWithInfinity } from 'utils/mathUtils';
import { reviveCharacter } from 'utils/playerUtils';
import { GameData, GameSideEffect, ItemInstance, Mercenary, Player, PLAYER_INVENTORY_MAX_UNIQUE_ITEMS, PLAYER_INVENTORY_MAX_STACK_SIZE } from '../../../types';

export function consumeItem(
  player: Player,
  itemUniqueId: string,
  targetId: string | undefined,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const inventoryIndex = player.inventory.findIndex((i) => i.unique_id === itemUniqueId);
  if (inventoryIndex === -1) {
    return { player, sideEffects: [{ type: 'LOG', message: 'Item to consume not found.', logType: 'error' }] };
  }

  const itemInstance = player.inventory[inventoryIndex];
  const itemData = GAME_DATA.ITEMS[itemInstance.id];
  const sideEffects: GameSideEffect[] = [];
  let playerStateAfterEffect = deepCloneWithInfinity(player);

  if (itemData.type.includes('note')) {
    if (itemData.teachesRecipe) {
      if (player.knownRecipes[itemData.teachesRecipe]) {
        sideEffects.push({ type: 'LOG', message: 'You already know this recipe.', logType: 'info' });
        return { player, sideEffects };
      }
      sideEffects.push({ type: 'LEARN_RECIPE', recipeId: itemData.teachesRecipe } as GameSideEffect);
    } else if (itemData.teachesEnchantmentRecipe) {
      if (player.knownEnchantments[itemData.teachesEnchantmentRecipe]) {
        sideEffects.push({ type: 'LOG', message: 'You already know this enchantment recipe.', logType: 'info' });
        return { player, sideEffects };
      }
      sideEffects.push({ type: 'LEARN_ENCHANTMENT', enchantmentRecipeId: itemData.teachesEnchantmentRecipe } as GameSideEffect);
    } else if (itemData.teachesAbility) {
      if (player.skills[itemData.teachesAbility]) {
        const ability = GAME_DATA.SKILLS[itemData.teachesAbility];
        sideEffects.push({ type: 'LOG', message: `You already know ${ability.name}.`, logType: 'info' });
        return { player, sideEffects };
      }
      sideEffects.push({ type: 'LEARN_ABILITY', abilityId: itemData.teachesAbility } as GameSideEffect);
    } else {
      sideEffects.push({ type: 'LOG', message: 'The writing is illegible.', logType: 'info' });
      return { player, sideEffects };
    }
  } else if (itemData.type.includes('potion')) {
    const effect = itemData.effect;
    if (effect?.revive) {
      if (!targetId) {
        sideEffects.push({ type: 'LOG', message: 'You must select a target to revive.', logType: 'error' });
        return { player, sideEffects };
      }
      const newPlayer = deepCloneWithInfinity(player);

      const corpseIndex = newPlayer.inventory.findIndex((i: ItemInstance) => i.unique_id === targetId);
      if (corpseIndex === -1) {
        sideEffects.push({ type: 'LOG', message: 'Invalid target.', logType: 'error' });
        return { player, sideEffects };
      }
      const corpseItem = newPlayer.inventory[corpseIndex];
      if (!corpseItem.deceasedCharacter) {
        sideEffects.push({ type: 'LOG', message: 'Invalid target.', logType: 'error' });
        return { player, sideEffects };
      }
      if (newPlayer.party.length >= 3) {
        sideEffects.push({ type: 'LOG', message: 'Your party is full.', logType: 'error' });
        return { player, sideEffects };
      }

      const mercToRevive = corpseItem.deceasedCharacter;
      const revivedMerc = reviveCharacter(mercToRevive, effect.revive.percentHealth, GAME_DATA) as Mercenary;

      newPlayer.party.push(revivedMerc);
      newPlayer.inventory.splice(corpseIndex, 1);

      sideEffects.push({ type: 'LOG', message: `${mercToRevive.name} has been revived by a ${itemData.name}!`, logType: 'heal' });
      playerStateAfterEffect = newPlayer;
    } else if (effect?.closesCutOfStage) {
      if (!targetId) {
        sideEffects.push({ type: 'LOG', message: 'You must select a limb to apply this to.', logType: 'error' });
        return { player, sideEffects };
      }
      playerStateAfterEffect = deepCloneWithInfinity(player);
      const targetLimb = playerStateAfterEffect.body[targetId];
      if (!targetLimb) {
        sideEffects.push({ type: 'LOG', message: 'Invalid limb target.', logType: 'error' });
        return { player, sideEffects };
      }
      const cutToClose = targetLimb.statusEffects.find((se: any) => se.id === 'cut' && !se.isClosed && se.currentStage! <= effect.closesCutOfStage!);
      if (!cutToClose) {
        sideEffects.push({ type: 'LOG', message: `Your ${targetLimb.displayName} has no open wound this bandage can treat.`, logType: 'info' });
        return { player, sideEffects };
      }
      cutToClose.isClosed = true;
      targetLimb.statusEffects = targetLimb.statusEffects.filter((se: any) => se.linkedToInstanceId !== cutToClose.instanceId);
      sideEffects.push({
        type: 'LOG',
        message: `You apply the ${itemInstance.name} to the wound on your ${targetLimb.displayName}. The bleeding stops.`,
        logType: 'heal',
      });
    } else if (effect?.applyStatusEffect) {
      sideEffects.push({
        type: 'APPLY_STATUS_EFFECT',
        effectId: effect.applyStatusEffect.id,
        options: {
          turns: effect.applyStatusEffect.turns || 0,
          durationInMinutes: effect.applyStatusEffect.durationInMinutes,
        },
      } as GameSideEffect);
    } else if (effect?.cureStatusEffect) {
      let cured = false;
      playerStateAfterEffect = deepCloneWithInfinity(player);
      playerStateAfterEffect.statusEffects = playerStateAfterEffect.statusEffects.filter((b) => {
        if (b.id !== effect.cureStatusEffect) return true;
        cured = true;
        return false;
      });
      for (const limbId in playerStateAfterEffect.body) {
        playerStateAfterEffect.body[limbId].statusEffects = playerStateAfterEffect.body[limbId].statusEffects.filter((b) => {
          if (b.id !== effect.cureStatusEffect) return true;
          cured = true;
          return false;
        });
      }
      if (cured) {
        sideEffects.push({
          type: 'LOG',
          message: `You use the ${itemInstance.name} to treat your ${GAME_DATA.STATUS_EFFECTS[effect.cureStatusEffect].name}.`,
          logType: 'heal',
        });
      } else {
        sideEffects.push({ type: 'LOG', message: 'You have nothing to cure with this item.', logType: 'info' });
        return { player, sideEffects };
      }
    } else {
      sideEffects.push({ type: 'LOG', message: `${itemInstance.name} has no effect.`, logType: 'info' });
    }
  } else {
    return null; // Not a consumable item type
  }

  const finalPlayerState = { ...playerStateAfterEffect };
  let finalInventory = [...finalPlayerState.inventory];
  const finalItemIndex = finalInventory.findIndex((i) => i.unique_id === itemUniqueId);

  if (finalItemIndex > -1) {
    const stack = finalInventory[finalItemIndex];

    const singleItemInstance: ItemInstance = { ...stack, quantity: 1 };

    if (singleItemInstance.charges !== undefined) {
      singleItemInstance.charges -= 1;
    }

    if (stack.quantity > 1) {
      stack.quantity -= 1;
    } else {
      finalInventory.splice(finalItemIndex, 1);
    }

    if (singleItemInstance.charges !== undefined) {
      if (singleItemInstance.charges > 0 || !itemData.destroyOnEmpty) {
        singleItemInstance.unique_id = `item_${Date.now()}_${Math.random()}`;
        const { newInventory, overflow } = mergeIntoInventory(finalInventory, [singleItemInstance], GAME_DATA, {
          maxUniqueItems: PLAYER_INVENTORY_MAX_UNIQUE_ITEMS,
          maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
        });
        finalInventory = newInventory;
        if (overflow.length > 0) {
          sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
        }
      }
    }
  }

  return { player: { ...finalPlayerState, inventory: finalInventory }, sideEffects };
}