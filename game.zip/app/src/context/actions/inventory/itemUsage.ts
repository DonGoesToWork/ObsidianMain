import { Player, ItemInstance, StatusEffectId, AbilityId, RecipeId, Mercenary, GameData } from "../../../types";
import { getItemName } from "utils/itemUtils";
import { reviveCharacter } from "utils/playerUtils";

export function consumeItemImpl(
  itemUniqueId: string,
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>,
  logMessage: (message: any, type: any) => void,
  applyStatusEffect: (
    targetId: "player",
    effectId: StatusEffectId,
    options: {
      turns?: number;
      durationInMinutes?: number;
      instanceId?: string;
      linkedToInstanceId?: string;
      isClosed?: boolean;
      stage?: number;
    },
  ) => void,
  playerActionTaken: () => void,
  learnRecipe: (recipeId: RecipeId) => void,
  learnAbility: (abilityId: AbilityId) => void,
  targetId: string | undefined,
  GAME_DATA: GameData,
) {
  setPlayer((p) => {
    if (!p) return p;

    const inventoryIndex = p.inventory.findIndex((i) => i.unique_id === itemUniqueId);
    if (inventoryIndex === -1) {
      logMessage("Item to consume not found.", "error");
      return p;
    }

    const itemInstance = p.inventory[inventoryIndex];
    const itemData = GAME_DATA.ITEMS[itemInstance.id];

    let playerStateAfterEffect = { ...p };

    if (itemData.type.includes("note")) {
      if (itemData.teachesRecipe) {
        if (p.knownRecipes[itemData.teachesRecipe]) {
          logMessage("You already know this recipe.", "info");
          return p;
        }
        learnRecipe(itemData.teachesRecipe);
      } else if (itemData.teachesAbility) {
        if (p.skills[itemData.teachesAbility]) {
          const ability = GAME_DATA.SKILLS[itemData.teachesAbility];
          logMessage(`You already know ${ability.name}.`, "info");
          return p;
        }
        learnAbility(itemData.teachesAbility);
      } else {
        logMessage("The writing is illegible.", "info");
        return p;
      }
    } else if (itemData.type.includes("potion")) {
      if (itemInstance.charges !== undefined && itemInstance.charges <= 0) {
        logMessage(`${getItemName(itemInstance)} is empty.`, "info");
        return p;
      }

      const effect = itemData.effect;
      if (effect?.revive) {
        if (!targetId) {
          logMessage("You must select a target to revive.", "error");
          return p;
        }
        const newPlayer = JSON.parse(JSON.stringify(p));

        const corpseIndex = newPlayer.inventory.findIndex((i: ItemInstance) => i.unique_id === targetId);
        if (corpseIndex === -1) {
          logMessage("Invalid target.", "error");
          return p;
        }
        const corpseItem = newPlayer.inventory[corpseIndex];
        if (!corpseItem.deceasedCharacter) {
          logMessage("Invalid target.", "error");
          return p;
        }
        if (newPlayer.party.length >= 3) {
          logMessage("Your party is full.", "error");
          return p;
        }

        const mercToRevive = corpseItem.deceasedCharacter;
        const revivedMerc = reviveCharacter(mercToRevive, effect.revive.percentHealth, GAME_DATA) as Mercenary;

        newPlayer.party.push(revivedMerc);
        newPlayer.inventory.splice(corpseIndex, 1);

        logMessage(`${mercToRevive.name} has been revived by a ${itemData.name}!`, "heal");
        playerStateAfterEffect = newPlayer;
      } else if (effect?.applyStatusEffect) {
        applyStatusEffect("player", effect.applyStatusEffect.id, {
          turns: effect.applyStatusEffect.turns,
          durationInMinutes: effect.applyStatusEffect.durationInMinutes,
        });
      } else if (effect?.cureStatusEffect) {
        let cured = false;
        playerStateAfterEffect = JSON.parse(JSON.stringify(p));
        playerStateAfterEffect.statusEffects = playerStateAfterEffect.statusEffects.filter((b) => {
          if (b.id !== effect.cureStatusEffect) return true;
          cured = true;
          return false;
        });

        for (const limbId in playerStateAfterEffect.body) {
          playerStateAfterEffect.body[limbId].statusEffects = playerStateAfterEffect.body[limbId].statusEffects.filter((b) => {
            if (b.id !== effect.cureStatusEffect) return true;
            cured = true;
            return false;
          });
        }

        if (cured) {
          logMessage(`You use the ${getItemName(itemInstance)} to treat your ${GAME_DATA.STATUS_EFFECTS[effect.cureStatusEffect].name}.`, "heal");
        } else {
          logMessage("You have nothing to cure with this item.", "info");
          return p;
        }
      } else if (effect?.closesCutOfStage) {
        let woundClosed = false;
        let highestStageClosed = 0;
        let targetLimbId: string | undefined = undefined;
        playerStateAfterEffect = JSON.parse(JSON.stringify(p));

        Object.values(playerStateAfterEffect.body).forEach((limb) => {
          limb.statusEffects.forEach((se) => {
            if (se.id === "cut" && !se.isClosed && se.currentStage! <= effect.closesCutOfStage! && se.currentStage! > highestStageClosed) {
              highestStageClosed = se.currentStage!;
              targetLimbId = limb.id;
            }
          });
        });

        if (targetLimbId) {
          const limb = playerStateAfterEffect.body[targetLimbId];
          const cut = limb.statusEffects.find((se) => se.id === "cut" && se.currentStage === highestStageClosed && !se.isClosed)!;
          cut.isClosed = true;
          limb.statusEffects = limb.statusEffects.filter((se) => se.linkedToInstanceId !== cut.instanceId);
          woundClosed = true;
          logMessage(
            `You apply the ${itemData.name} to the ${GAME_DATA.STATUS_EFFECTS.cut.stages![cut.currentStage! - 1].name.toLowerCase()} on your ${
              limb.displayName
            }. The bleeding stops.`,
            "heal"
          );
        }

        if (!woundClosed) {
          logMessage(`You have no open wounds that this ${itemData.name} can treat.`, "info");
          return p;
        }
      } else {
        logMessage(`${getItemName(itemInstance)} has no effect.`, "info");
        return p;
      }
    } else {
      return p; // Not a consumable item type
    }

    const finalPlayerState = { ...playerStateAfterEffect };
    const finalInventory = [...finalPlayerState.inventory];
    const finalItemIndex = finalInventory.findIndex((i) => i.unique_id === itemUniqueId);

    if (finalItemIndex === -1) {
      // Item was already removed by some logic (e.g. revive character did a full state replace)
      return finalPlayerState;
    }

    const itemToConsume = { ...finalInventory[finalItemIndex] };

    if (itemToConsume.charges !== undefined) {
      itemToConsume.charges -= 1;
      if (itemToConsume.charges <= 0 && itemData.destroyOnEmpty) {
        finalInventory.splice(finalItemIndex, 1);
      } else {
        finalInventory[finalItemIndex] = itemToConsume;
      }
    } else {
      finalInventory.splice(finalItemIndex, 1);
    }

    playerActionTaken();
    return { ...finalPlayerState, inventory: finalInventory };
  });
}