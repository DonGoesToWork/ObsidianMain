import { Player, ItemId, ItemInstance, GameData, GameSideEffect, ProfessionId } from '../../../types';
import { createItemInstances } from 'utils/itemUtils';

export function addItem(
  player: Player,
  itemId: ItemId,
  quantity: number,
  options: { isUnidentified?: boolean; plus_value?: number; initialDurabilityPercent?: number } | undefined,
  GAME_DATA: GameData
): { player: Player; newItems: ItemInstance[]; sideEffects: GameSideEffect[] } {
  const newItems = createItemInstances(itemId, quantity, options, GAME_DATA);
  if (newItems.length === 0) return { player, newItems: [], sideEffects: [] };

  const sideEffects: GameSideEffect[] = [];
  let tempPlayer = { ...player };

  const autoIdSkill = tempPlayer.skills['p_appraisal01'];
  if (autoIdSkill && autoIdSkill.rank > 0) {
    const autoIdChance = GAME_DATA.SKILLS['p_appraisal01'].effect.value * autoIdSkill.rank;
    newItems.forEach((item) => {
      if (item.isUnidentified && Math.random() < autoIdChance) {
        item.isUnidentified = false;
        sideEffects.push({
          type: 'LOG',
          message: `Your keen eye instantly identifies the ${GAME_DATA.ITEMS[item.id].name}!`,
          logType: 'skill',
        });
        sideEffects.push({
          type: 'GAIN_PROFESSION_XP',
          professionId: 'appraisal',
          amount: GAME_DATA.ITEMS[item.id].itemLevel,
        } as GameSideEffect); // Cast needed if GAIN_PROFESSION_XP is a custom type
      }
    });
  }

  tempPlayer.inventory = [...tempPlayer.inventory, ...newItems];

  sideEffects.push({
    type: 'LOG',
    message: `You obtained ${GAME_DATA.ITEMS[itemId].name} ${quantity > 1 ? `(x${quantity})` : ''}.`,
    logType: 'loot',
  });

  if (GAME_DATA.ITEMS[itemId].type.includes('material')) {
    sideEffects.push({
      type: 'UPDATE_QUEST_PROGRESS',
      questType: 'gather',
      target: itemId,
      count: quantity,
    } as GameSideEffect);
  }

  return { player: tempPlayer, newItems, sideEffects };
}

export function removeItem(player: Player, itemId: ItemId, quantity: number): { player: Player } | null {
  const newInventory = [...player.inventory];
  let removedCount = 0;

  const filteredInventory = newInventory.filter((item) => {
    if (item.id === itemId && removedCount < quantity) {
      removedCount++;
      return false;
    }
    return true;
  });

  if (removedCount > 0) {
    return { player: { ...player, inventory: filteredInventory } };
  }

  return null;
}

export function removeItemByInstance(player: Player, itemToRemove: ItemInstance): { player: Player } | null {
  const index = player.inventory.findIndex((invItem) => invItem.unique_id === itemToRemove.unique_id);
  if (index > -1) {
    const newInventory = [...player.inventory];
    newInventory.splice(index, 1);
    return { player: { ...player, inventory: newInventory } };
  }
  return null;
}