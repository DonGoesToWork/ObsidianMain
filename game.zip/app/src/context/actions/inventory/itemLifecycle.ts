import { createItemInstances, mergeIntoInventory } from 'utils/itemUtils';
import { GameData, GameSideEffect, ItemId, ItemInstance, Player } from '../../../types';

export function addItem(
  player: Player,
  itemId: ItemId,
  quantity: number,
  options: { isUnidentified?: boolean; plus_value?: number; initialDurabilityPercent?: number; addRandomEnchantments?: boolean },
  GAME_DATA: GameData
): { player: Player; newItems: ItemInstance[]; sideEffects: GameSideEffect[] } {
  const itemData = GAME_DATA.ITEMS[itemId];
  if (!itemData) return { player, newItems: [], sideEffects: [] };

  const sideEffects: GameSideEffect[] = [];
  let newItems = createItemInstances(itemId, quantity, options, GAME_DATA);

  if (newItems.length === 0) {
    return { player, newItems: [], sideEffects: [] };
  }

  // Handle pre-merge logic like auto-identification
  const autoIdSkill = player.skills['p_appraisal01'];
  if (autoIdSkill && autoIdSkill.rank > 0) {
    const autoIdChance = GAME_DATA.SKILLS['p_appraisal01'].effect.value * autoIdSkill.rank;
    newItems = newItems.map((item) => {
      if (item.isUnidentified && Math.random() < autoIdChance) {
        sideEffects.push({
          type: 'LOG',
          message: `Your keen eye instantly identifies the ${GAME_DATA.ITEMS[item.id].name}!`,
          logType: 'skill',
        });
        sideEffects.push({
          type: 'GAIN_PROFESSION_XP',
          professionId: 'appraisal',
          amount: GAME_DATA.ITEMS[item.id].itemLevel,
        } as GameSideEffect);
        return { ...item, isUnidentified: false };
      }
      return item;
    });
  }

  const { newInventory, overflow } = mergeIntoInventory(player.inventory, newItems, GAME_DATA);

  if (overflow.length > 0) {
    sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
  }

  const tempPlayer = { ...player, inventory: newInventory };

  sideEffects.push({
    type: 'LOG',
    message: `You obtained ${GAME_DATA.ITEMS[itemId].name} ${quantity > 1 ? `(x${quantity})` : ''}.`,
    logType: 'loot',
  });

  if (GAME_DATA.ITEMS[itemId].type.includes('material')) {
    sideEffects.push({
      type: 'UPDATE_QUEST_PROGRESS',
      questType: 'gather',
      target: itemId,
      count: quantity,
    } as GameSideEffect);
  }

  return { player: tempPlayer, newItems, sideEffects };
}

export function removeItem(player: Player, itemId: ItemId, quantity: number): { player: Player } | null {
  const newInventory = [...player.inventory];
  let removedCount = 0;

  for (let i = newInventory.length - 1; i >= 0; i--) {
    if (removedCount >= quantity) break;

    const item = newInventory[i];
    if (item.id === itemId) {
      const amountToRemoveFromStack = Math.min(item.quantity, quantity - removedCount);
      item.quantity -= amountToRemoveFromStack;
      removedCount += amountToRemoveFromStack;

      if (item.quantity <= 0) {
        newInventory.splice(i, 1);
      }
    }
  }

  if (removedCount > 0) {
    return { player: { ...player, inventory: newInventory } };
  }

  return null;
}

export function removeItemByInstance(player: Player, itemToRemove: ItemInstance): { player: Player } | null {
  const index = player.inventory.findIndex((invItem) => invItem.unique_id === itemToRemove.unique_id);
  if (index > -1) {
    const newInventory = [...player.inventory];
    const itemInInventory = newInventory[index];

    if (itemInInventory.quantity > 1) {
      itemInInventory.quantity -= 1;
    } else {
      newInventory.splice(index, 1);
    }
    return { player: { ...player, inventory: newInventory } };
  }
  return null;
}