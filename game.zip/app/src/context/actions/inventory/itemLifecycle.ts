import { Player, ItemId, ItemQuality, ItemInstance, GameData } from "../../../types";
import { createItemInstances } from "utils/itemUtils";

export function addItemImpl(
  itemId: ItemId,
  quantity: number,
  options: { isUnidentified?: boolean; quality?: ItemQuality; initialDurabilityPercent?: number } | undefined,
  setPlayer: React.Dispatch<React.SetStateAction<Player | null>>,
  logMessage: (message: string, type: any) => void,
  gainProfessionXp: (professionId: any, amount: number) => void,
  updateQuestProgress: (type: "kill" | "gather", target: string, count?: number) => void,
  GAME_DATA: GameData,
): ItemInstance[] {
  const newItems = createItemInstances(itemId, quantity, options, GAME_DATA);
  if (newItems.length === 0) return [];

  setPlayer((p) => {
    if (!p) return p;
    const autoIdSkill = p.skills["p_appraisal01"];
    if (autoIdSkill && autoIdSkill.rank > 0) {
      const autoIdChance = GAME_DATA.SKILLS["p_appraisal01"].effect.value * autoIdSkill.rank;
      newItems.forEach((item) => {
        if (item.isUnidentified && Math.random() < autoIdChance) {
          item.isUnidentified = false;
          logMessage(`Your keen eye instantly identifies the ${GAME_DATA.ITEMS[item.id].name}!`, "skill");
          gainProfessionXp("appraisal", GAME_DATA.ITEMS[item.id].itemLevel);
        }
      });
    }
    return { ...p, inventory: [...p.inventory, ...newItems] };
  });

  logMessage(`You obtained ${GAME_DATA.ITEMS[itemId].name} ${quantity > 1 ? `(x${quantity})` : ""}.`, "loot");
  if (GAME_DATA.ITEMS[itemId].type.includes("material")) {
    updateQuestProgress("gather", itemId, quantity);
  }
  return newItems;
}

export function removeItemImpl(itemId: ItemId, quantity: number, setPlayer: React.Dispatch<React.SetStateAction<Player | null>>) {
  setPlayer((p: Player | null) => {
    if (!p) return p;
    const newInventory = [...p.inventory];
    let removedCount = 0;

    const filteredInventory = newInventory.filter((item) => {
      if (item.id === itemId && removedCount < quantity) {
        removedCount++;
        return false;
      }
      return true;
    });

    if (removedCount > 0) {
      return { ...p, inventory: filteredInventory };
    }

    return p;
  });
}

export function removeItemByInstanceImpl(itemToRemove: ItemInstance, setPlayer: React.Dispatch<React.SetStateAction<Player | null>>) {
  setPlayer((p) => {
    if (!p) return p;
    const index = p.inventory.findIndex((invItem) => invItem.unique_id === itemToRemove.unique_id);
    if (index > -1) {
      const newInventory = [...p.inventory];
      newInventory.splice(index, 1);
      return { ...p, inventory: newInventory };
    }
    return p;
  });
}