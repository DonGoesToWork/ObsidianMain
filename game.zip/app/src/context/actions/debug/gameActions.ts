import { calculateXpToNextLevel } from '../../../services/statService';
import { AbilityId, EnchantmentRecipeId, GameData, ItemId, ItemInstance, Loggable, LogType, Player, ProfessionId, RecipeId, PLAYER_INVENTORY_MAX_UNIQUE_ITEMS, PLAYER_INVENTORY_MAX_STACK_SIZE } from 'types';
import { DebugExecuteOnTargetsDeps } from './utils';
import { deepCloneWithInfinity } from 'utils/mathUtils';
import { addItem } from '../inventory/itemLifecycle';
import { applyFullHealLogic } from 'utils/playerUtils';
import { BaseStatBlock } from 'types/gameData';

type GameDebugActionsDeps = DebugExecuteOnTargetsDeps & {
  GAME_DATA: GameData;
  travelTo: (locationId: string) => void;
  setGameTime: React.Dispatch<React.SetStateAction<Date>>;
  setPlayer: (update: React.SetStateAction<Player | null>) => void;
  logMessage: (message: Loggable, type: LogType) => void;
};

export const debug_teleportToTown = ({ travelTo, logMessage }: GameDebugActionsDeps) => {
  travelTo('zone0');
  logMessage('DEBUG: Teleported to Westhaven.', 'info');
};

export const debug_maxProfessions = (deps: GameDebugActionsDeps) => {
  deps.execute((char) => {
    if ('professions' in char) {
      const newProfessions = { ...char.professions };
      Object.values(newProfessions).forEach((prof) => {
        prof.level = 100;
        prof.xp = 0;
      });
      return { ...char, professions: newProfessions };
    }
    return char;
  }, 'All professions set to 100.');
};

export const debug_setProfessionLevel = (deps: GameDebugActionsDeps, level: number) => {
  deps.execute((char) => {
    if ('professions' in char) {
      const newProfessions = { ...char.professions };
      Object.keys(newProfessions).forEach((profId) => {
        const prof = newProfessions[profId as ProfessionId];
        prof.level = level;
        prof.xp = 0;
        prof.xpToNextLevel = calculateXpToNextLevel(level);
      });
      return { ...char, professions: newProfessions };
    }
    return char;
  }, `All professions set to ${level}.`);
};

export const debug_learnAllRecipes = (deps: GameDebugActionsDeps) => {
  deps.execute((char) => {
    if ('professions' in char) {
      const allRecipeIds = Object.keys(deps.GAME_DATA.ALL_RECIPES) as RecipeId[];
      const newKnownRecipes = { ...char.knownRecipes };
      allRecipeIds.forEach((id) => (newKnownRecipes[id] = true));
      return { ...char, knownRecipes: newKnownRecipes };
    }
    return char;
  }, `Learned all ${Object.keys(deps.GAME_DATA.ALL_RECIPES).length} recipes.`);
};

export const debug_learnAllEnchantmentRecipes = (deps: GameDebugActionsDeps) => {
  deps.execute((char) => {
    if ('professions' in char) {
      const newKnown = { ...char.knownEnchantments };
      deps.GAME_DATA.ENCHANTS.forEach((enchant) => {
        enchant.scaling.forEach((_, index) => {
          const tier = index + 1;
          const recipeId = `${enchant.id}_t${tier}`;
          newKnown[recipeId as EnchantmentRecipeId] = true;
        });
      });
      return { ...char, knownEnchantments: newKnown };
    }
    return char;
  }, 'Learned all enchantment recipes.');
};

export const debug_learnAllSpells = (deps: GameDebugActionsDeps) => {
  const allSpellIds = Object.keys(deps.GAME_DATA.SKILLS).filter((id) => deps.GAME_DATA.SKILLS[id].abilityType === 'Spell');
  deps.execute((char) => {
    const newSkills = { ...char.skills };
    allSpellIds.forEach((id) => (newSkills[id as AbilityId] = { rank: 1 }));
    return { ...char, skills: newSkills };
  }, `Learned all spells`);
};

export const debug_learnAllSkills = (deps: GameDebugActionsDeps) => {
  const allSkillIds = Object.keys(deps.GAME_DATA.SKILLS).filter((id) => deps.GAME_DATA.SKILLS[id].abilityType === 'Skill');
  deps.execute((char) => {
    const newSkills = { ...char.skills };
    allSkillIds.forEach((id) => (newSkills[id as AbilityId] = { rank: 1 }));
    return { ...char, skills: newSkills };
  }, `Learned all skills`);
};

export const debug_unlockAll = ({ GAME_DATA, setPlayer, logMessage }: GameDebugActionsDeps) => {
  setPlayer((p) => {
    if (!p) return p;
    let newPlayer = { ...p };
    const allRecipeIds = Object.keys(GAME_DATA.ALL_RECIPES) as RecipeId[];
    allRecipeIds.forEach((id) => (newPlayer.knownRecipes[id] = true));
    GAME_DATA.ENCHANTS.forEach((enchant) => {
      enchant.scaling.forEach((_, index) => {
        const tier = index + 1;
        const recipeId = `${enchant.id}_t${tier}`;
        newPlayer.knownEnchantments[recipeId as EnchantmentRecipeId] = true;
      });
    });
    const allSkillIds = Object.keys(GAME_DATA.SKILLS).filter((id) => GAME_DATA.SKILLS[id].abilityType === 'Skill' || GAME_DATA.SKILLS[id].abilityType === 'Spell');
    allSkillIds.forEach((id) => (newPlayer.skills[id as AbilityId] = { rank: 1 }));
    Object.values(newPlayer.professions).forEach((prof) => (prof.level = 100));
    logMessage('DEBUG: All unlocks applied for player.', 'info');
    return newPlayer;
  });
};

export const debug_lockAll = ({ setPlayer, logMessage }: GameDebugActionsDeps) => {
  setPlayer((p) => {
    if (!p) return p;
    let newPlayer = { ...p };
    newPlayer.knownRecipes = {};
    newPlayer.knownEnchantments = {};
    newPlayer.skills = {};
    Object.values(newPlayer.professions).forEach((prof) => {
      prof.level = 1;
      prof.xp = 0;
      prof.xpToNextLevel = calculateXpToNextLevel(1);
    });
    logMessage('DEBUG: All unlocks removed from player.', 'info');
    return newPlayer;
  });
};

export const debug_setGameTimeToStartOfDay = ({ setGameTime, logMessage }: GameDebugActionsDeps) => {
  setGameTime((currentTime) => {
    const newTime = new Date(currentTime);
    newTime.setHours(0, 0, 0, 0);
    logMessage(`DEBUG: Game time set to ${newTime.toLocaleTimeString()}.`, 'info');
    return newTime;
  });
};

export const debug_test_all = ({ GAME_DATA, logMessage, setPlayer }: GameDebugActionsDeps) => {
  logMessage('DEBUG: Applying all test options...', 'info');
  const modifyChar = (charToModify: Player): Player => {
    let char = deepCloneWithInfinity(charToModify);
    char.level = 100;
    char.xp = 0;
    char.xpToNextLevel = calculateXpToNextLevel(100);
    (Object.keys(char.baseStats) as (keyof BaseStatBlock)[]).forEach((stat) => (char.baseStats[stat] = (char.baseStats[stat] || 0) + 10000));
    const allSkillIds = Object.keys(GAME_DATA.SKILLS);
    allSkillIds.forEach((id) => (char.skills[id as AbilityId] = { rank: 1 }));
    return char;
  };
  setPlayer((p: Player | null) => {
    if (!p) return p;
    let newPlayer = modifyChar(p) as Player;
    newPlayer.party = newPlayer.party.map((merc) => modifyChar(merc as any) as any);
    newPlayer.gold = 999999;
    const allRecipeIds = Object.keys(GAME_DATA.ALL_RECIPES) as RecipeId[];
    allRecipeIds.forEach((id) => (newPlayer.knownRecipes[id] = true));
    let healedPlayer = applyFullHealLogic(newPlayer, GAME_DATA) as Player;
    healedPlayer.party = healedPlayer.party.map((merc) => applyFullHealLogic(merc, GAME_DATA) as any);
    return healedPlayer;
  });
};

export const debug_craftGod = ({ GAME_DATA, setPlayer, logMessage }: GameDebugActionsDeps) => {
  setPlayer((p: Player | null) => {
    if (!p) return p;
    let newPlayer = deepCloneWithInfinity(p);

    newPlayer.inventory = []; // Clear inventory first to ensure it's predictable

    const itemsToGive = (Object.keys(GAME_DATA.ITEMS) as ItemId[])
      .filter((itemId) => {
        const itemData = GAME_DATA.ITEMS[itemId];
        return itemData && !itemData.isUnarmed && (itemData.type.includes('material') || itemData.type.includes('tool'));
      })
      .slice(0, PLAYER_INVENTORY_MAX_UNIQUE_ITEMS);

    for (const itemId of itemsToGive) {
      // Use addItem to respect stacking logic, but give a predictable amount.
      const result = addItem(newPlayer, itemId, PLAYER_INVENTORY_MAX_STACK_SIZE, {}, GAME_DATA);
      newPlayer = result.player;
    }

    Object.values(newPlayer.professions).forEach((prof) => {
      prof.level = 1000;
      prof.xp = 0;
      prof.xpToNextLevel = calculateXpToNextLevel(1000);
    });
    Object.keys(GAME_DATA.ALL_RECIPES).forEach((id) => (newPlayer.knownRecipes[id as RecipeId] = true));
    Object.keys(GAME_DATA.SKILLS).forEach((id) => (newPlayer.skills[id as AbilityId] = { rank: 1 }));
    GAME_DATA.ENCHANTS.forEach((enchant) => {
      enchant.scaling.forEach((_, index) => {
        const tier = index + 1;
        const recipeId = `${enchant.id}_t${tier}`;
        newPlayer.knownEnchantments[recipeId as EnchantmentRecipeId] = true;
      });
    });

    logMessage('DEBUG: Craft God mode activated. Materials, tools, and recipes granted.', 'info');
    return newPlayer;
  });
};