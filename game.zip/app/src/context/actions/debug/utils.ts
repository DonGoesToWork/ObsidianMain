import { Combatant, CombatState, Loggable, LogType, Mercenary, Player } from 'types';
import { deepCloneWithInfinity } from 'utils/mathUtils';

export type ExecuteOnTargetsFunction = (modificationFn: (char: Player | Mercenary | Combatant) => Player | Mercenary | Combatant, message: string) => void;

export type DebugExecuteOnTargetsDeps = {
  execute: ExecuteOnTargetsFunction;
  setPlayer: (update: React.SetStateAction<Player | null>) => void;
  logMessage: (message: Loggable, type: LogType) => void;
};

export const createExecuteOnTargets = (
  debugTargets: string[],
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  setCurrentCombat: React.Dispatch<React.SetStateAction<CombatState | null>>,
  logMessage: (message: Loggable, type: LogType) => void
): ExecuteOnTargetsFunction => {
  return (modificationFn, message) => {
    if (debugTargets.length === 0) {
      logMessage('DEBUG: No targets selected.', 'error');
      return;
    }

    setPlayer((p) => {
      if (!p) return p;
      let tempPlayer = deepCloneWithInfinity(p);
      let modified = false;

      if (debugTargets.includes('player')) {
        tempPlayer = modificationFn(tempPlayer) as Player;
        modified = true;
      }

      tempPlayer.party = tempPlayer.party.map((merc) => {
        if (debugTargets.includes(merc.id)) {
          modified = true;
          return modificationFn(merc) as Mercenary;
        }
        return merc;
      });
      return modified ? tempPlayer : p;
    });

    setCurrentCombat((c) => {
      if (!c) return c;
      let tempCombat = deepCloneWithInfinity(c);
      let modified = false;
      Object.keys(tempCombat.combatants).forEach((id) => {
        if (debugTargets.includes(id) && tempCombat.combatants[id].team === 'enemy') {
          tempCombat.combatants[id] = modificationFn(tempCombat.combatants[id]) as Combatant;
          modified = true;
        }
      });
      return modified ? tempCombat : c;
    });

    logMessage(`DEBUG: ${message} on target(s).`, 'info');
  };
};
