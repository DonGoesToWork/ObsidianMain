import { GameData, ItemId, ItemInstance, Player, PLAYER_INVENTORY_MAX_STACK_SIZE, PLAYER_INVENTORY_MAX_UNIQUE_ITEMS } from 'types';
import { mergeIntoInventory } from 'utils/itemUtils';
import { DebugExecuteOnTargetsDeps } from './utils';
import { addItem } from '../inventory/itemLifecycle';

type InventoryDebugActionsDeps = DebugExecuteOnTargetsDeps & {
  GAME_DATA: GameData;
};

export const debug_addGold = (deps: InventoryDebugActionsDeps, amount: number) => {
  deps.execute((char) => ('gold' in char ? { ...char, gold: (char.gold || 0) + amount } : char), `Added ${amount} gold`);
};

export const debug_setGold = (deps: InventoryDebugActionsDeps, amount: number) => {
  deps.execute((char) => ('gold' in char ? { ...char, gold: amount } : char), `Set gold to ${amount}`);
};

export const debug_duplicateItems = (deps: InventoryDebugActionsDeps) => {
  const { GAME_DATA } = deps;
  deps.execute((char) => {
    if ('inventory' in char) {
      if (char.inventory.length === 0) return char;
      const newItems = char.inventory.map((item) => ({ ...item, unique_id: `item_${Date.now()}_${Math.random()}` }));
      const { newInventory } = mergeIntoInventory(char.inventory, newItems, GAME_DATA, {
        maxUniqueItems: PLAYER_INVENTORY_MAX_UNIQUE_ITEMS,
        maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
      });
      return { ...char, inventory: newInventory };
    }
    return char;
  }, `Duplicated items`);
};

export const debug_giveRandomItems = (deps: InventoryDebugActionsDeps, count: number, options?: { unidentifiedWithEnchantments?: boolean }) => {
  const { GAME_DATA, setPlayer, logMessage } = deps;
  let allItemIds = Object.keys(GAME_DATA.ITEMS) as ItemId[];
  if (options?.unidentifiedWithEnchantments) {
    allItemIds = allItemIds.filter((id) => GAME_DATA.ITEMS[id].type.includes('equipment') && !GAME_DATA.ITEMS[id].isUnarmed && GAME_DATA.ITEMS[id].slot);
  }

  setPlayer((p: any) => {
    if (!p) return p;
    let tempPlayer = { ...p };
    for (let i = 0; i < count; i++) {
      const randomId = allItemIds[Math.floor(Math.random() * allItemIds.length)];
      const createOpts = options?.unidentifiedWithEnchantments ? { isUnidentified: true, addRandomEnchantments: true } : undefined;
      const result = require('../inventory/itemLifecycle').addItem(tempPlayer, randomId, 1, createOpts, GAME_DATA);
      tempPlayer = result.player;
      if (result.sideEffects.some((se: any) => se.type === 'DROP_ITEMS')) {
        logMessage('DEBUG: Overflowed some random items to the ground.', 'error');
      }
    }
    return tempPlayer;
  });

  logMessage(`DEBUG: Added ${count} random items` + (options?.unidentifiedWithEnchantments ? ' (unidentified enchanted)' : ''), 'info');
};

export const debug_giveDamagedItem = (deps: InventoryDebugActionsDeps, count: number) => {
  const { GAME_DATA, execute } = deps;
  execute((char) => {
    if ('inventory' in char) {
      let newPlayer = { ...char } as Player; // Type assertion
      const result = addItem(newPlayer, 'gen_smithing_mat_ingot_iron_shortsword', count, { isUnidentified: false, initialDurabilityPercent: 0.5 }, GAME_DATA);
      return result.player;
    }
    return char;
  }, `Gave ${count} damaged Iron Shortsword(s)`);
};

export const debug_giveAntiGravityChest = (deps: InventoryDebugActionsDeps, count: number) => {
  const { GAME_DATA, execute } = deps;
  execute((char) => {
    if ('inventory' in char) {
      const chests = require('utils/itemUtils').createItemInstances('gen_smithing_mat_equip_wood_chest', count, { isUnidentified: false }, GAME_DATA);
      chests.forEach((chest: ItemInstance) => (chest.enchantments['univ_anti_gravity'] = 1));
      const { newInventory } = mergeIntoInventory(char.inventory, chests, GAME_DATA, {
        maxUniqueItems: PLAYER_INVENTORY_MAX_UNIQUE_ITEMS,
        maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
      });
      return { ...char, inventory: newInventory };
    }
    return char;
  }, `Gave ${count} Anti-Gravity chest(s)`);
};

export const debug_clearInventory = (deps: InventoryDebugActionsDeps) => {
  deps.execute((char) => ('inventory' in char ? { ...char, inventory: [] } : char), `Inventory cleared`);
};

export const debug_giveAllRecipeItems = (deps: InventoryDebugActionsDeps) => {
  const { GAME_DATA, setPlayer, logMessage } = deps;

  const recipeItems = (Object.keys(GAME_DATA.ITEMS) as ItemId[]).filter((itemId) => {
    const itemData = GAME_DATA.ITEMS[itemId];
    return itemData.teachesRecipe || itemData.teachesAbility || itemData.teachesEnchantmentRecipe;
  });

  setPlayer((p) => {
    if (!p) return p;
    let tempPlayer = { ...p };
    recipeItems.forEach((itemId) => {
      const result = require('../inventory/itemLifecycle').addItem(tempPlayer, itemId, 1, {}, GAME_DATA);
      tempPlayer = result.player;
      if (result.sideEffects.some((se: any) => se.type === 'DROP_ITEMS')) {
        logMessage(`DEBUG: Overflowed ${itemId} to the ground.`, 'error');
      }
    });
    logMessage(`DEBUG: Gave all ${recipeItems.length} recipe items.`, 'info');
    return tempPlayer;
  });
};