import { BaseStatBlock, Combatant, GameData, Limb, Mercenary, Player, TotalPlayerStats, VitalId } from 'types';
import { applyClearDebuffsLogic, applyFullHealLogic, applyRestoreResourcesLogic } from 'utils/playerUtils';

import { calculateXpToNextLevel } from 'services/statService';
import { processLimbDamage } from 'utils/combatUtils';
import { DebugExecuteOnTargetsDeps } from './utils';

type CharacterDebugActionsDeps = DebugExecuteOnTargetsDeps & { GAME_DATA: GameData };

const isCombatant = (char: Player | Mercenary | Combatant): char is Combatant => 'team' in char;

export const debug_fullHeal = ({ GAME_DATA, execute }: CharacterDebugActionsDeps) => {
  execute((char) => applyFullHealLogic(char, GAME_DATA), 'Full heal applied');
};

export const debug_restoreResources = ({ execute }: CharacterDebugActionsDeps) => {
  execute(applyRestoreResourcesLogic, 'Resources restored');
};

export const debug_clearDebuffs = ({ GAME_DATA, execute }: CharacterDebugActionsDeps) => {
  execute((char) => applyClearDebuffsLogic(char, GAME_DATA), 'Debuffs cleared');
};

export const debug_addPoints = (deps: CharacterDebugActionsDeps, type: 'perk' | 'stat', amount: number) => {
  deps.execute((char) => {
    if ('professions' in char) {
      if (type === 'perk') {
        return { ...char, perkPoints: char.perkPoints + amount };
      }
      return { ...char, attributePoints: char.attributePoints + amount };
    }
    return char;
  }, `Added ${amount} ${type} point(s)`);
};

export const debug_setStatPoints = (deps: CharacterDebugActionsDeps, amount: number) => {
  deps.execute((char) => ('professions' in char ? { ...char, attributePoints: amount } : char), `Set stat points to ${amount}`);
};

export const debug_setPerkPoints = (deps: CharacterDebugActionsDeps, amount: number) => {
  deps.execute((char) => ('professions' in char ? { ...char, perkPoints: amount } : char), `Set perk points to ${amount}`);
};

export const debug_addXP = (deps: CharacterDebugActionsDeps, amount: number) => {
  const modificationFn = (char: Player | Mercenary | Combatant) => {
    if ('xp' in char && 'xpToNextLevel' in char) {
      let newChar = { ...char, xp: char.xp + amount };
      while (newChar.xp >= newChar.xpToNextLevel) {
        newChar.xp -= newChar.xpToNextLevel;
        newChar.level++;
        if ('professions' in newChar) (newChar as Player).perkPoints++;
        newChar.xpToNextLevel = calculateXpToNextLevel(newChar.level);
      }
      return newChar;
    }
    return char;
  };
  deps.execute(modificationFn, `Added ${amount} XP`);
};

export const debug_setXP = (deps: CharacterDebugActionsDeps, xp: number) => {
  deps.execute((char) => ('xp' in char ? { ...char, xp } : char), `Set XP to ${xp}`);
};

export const debug_addLevel = (deps: CharacterDebugActionsDeps, levels: number) => {
  const applyFn = (char: Player | Mercenary | Combatant) => {
    const newChar: any = { ...char, level: char.level + levels };
    newChar.xp = 0;
    newChar.xpToNextLevel = calculateXpToNextLevel(newChar.level);
    if ('professions' in newChar) {
      (newChar as Player).perkPoints += levels;
      (newChar as Player).attributePoints += levels * 5;
    }
    return newChar;
  };
  deps.execute(applyFn, `Added ${levels} level(s)`);
};

export const debug_setLevel = (deps: CharacterDebugActionsDeps, level: number) => {
  deps.execute((char) => {
    const newChar: any = { ...char, level: level };
    newChar.xp = 0;
    newChar.xpToNextLevel = calculateXpToNextLevel(newChar.level);
    return newChar;
  }, `Set level to ${level}`);
};

export const debug_addAttributes = (deps: CharacterDebugActionsDeps, amount: number) => {
  const applyFn = (char: Player | Mercenary | Combatant): Player | Mercenary | Combatant => {
    if (isCombatant(char)) {
      const newBaseStats: TotalPlayerStats = { ...char.baseStats };
      newBaseStats.strength += amount;
      newBaseStats.constitution += amount;
      newBaseStats.intelligence += amount;
      newBaseStats.dexterity += amount;
      return { ...char, baseStats: newBaseStats };
    } else {
      const newBaseStats: BaseStatBlock = { ...char.baseStats };
      newBaseStats.strength += amount;
      newBaseStats.constitution += amount;
      newBaseStats.intelligence += amount;
      newBaseStats.dexterity += amount;
      return { ...char, baseStats: newBaseStats };
    }
  };
  deps.execute(applyFn, `Added ${amount} to all attributes`);
};

export const debug_setAttributes = (deps: CharacterDebugActionsDeps, amount: number) => {
  const applyFn = (char: Player | Mercenary | Combatant): Player | Mercenary | Combatant => {
    if (isCombatant(char)) {
      const newBaseStats: TotalPlayerStats = { ...char.baseStats };
      newBaseStats.strength = amount;
      newBaseStats.constitution = amount;
      newBaseStats.intelligence = amount;
      newBaseStats.dexterity = amount;
      return { ...char, baseStats: newBaseStats };
    } else {
      const newBaseStats: BaseStatBlock = { ...char.baseStats };
      newBaseStats.strength = amount;
      newBaseStats.constitution = amount;
      newBaseStats.intelligence = amount;
      newBaseStats.dexterity = amount;
      return { ...char, baseStats: newBaseStats };
    }
  };
  deps.execute(applyFn, `Set all base attributes to ${amount}`);
};

export const debug_modifyVitals = (deps: CharacterDebugActionsDeps, vital: VitalId, amount: number) => {
  deps.execute((char) => {
    if ('vitals' in char) {
      const newVitals = { ...char.vitals };
      newVitals[vital].current = Math.max(0, Math.min(newVitals[vital].max, newVitals[vital].current + amount));
      return { ...char, vitals: newVitals };
    }
    return char;
  }, `Modified ${vital}`);
};

export const debug_setVital = (deps: CharacterDebugActionsDeps, vital: VitalId, amount: number) => {
  deps.execute((char) => {
    if ('vitals' in char) {
      const newVitals = { ...char.vitals };
      newVitals[vital].current = Math.max(0, Math.min(newVitals[vital].max, amount));
      return { ...char, vitals: newVitals };
    }
    return char;
  }, `Set ${vital} to ${amount}`);
};

export const debug_setLimbHp = (deps: CharacterDebugActionsDeps, limbId: string, value: number, isPercent: boolean) => {
  deps.execute((char) => {
    if (char.body[limbId]) {
      const newBody = { ...char.body };
      const newLimb = { ...newBody[limbId] };
      const hpValue = isPercent ? Math.round(newLimb.maxHp * (value / 100)) : value;
      newLimb.currentHp = Math.max(0, Math.min(newLimb.maxHp, hpValue));
      newLimb.state = newLimb.currentHp <= 0 ? 'Destroyed' : newLimb.currentHp < newLimb.maxHp ? 'Injured' : 'Healthy';
      newBody[limbId] = newLimb;
      return { ...char, body: newBody };
    }
    return char;
  }, `Set ${limbId} HP to ${value}${isPercent ? '%' : ''}`);
};

export const debug_applyDirectDamage = (
  { GAME_DATA, setPlayer, logMessage }: CharacterDebugActionsDeps,
  targetId: string,
  limbId: string,
  damage: number,
  damageTypes: string[]
) => {
  setPlayer((p) => {
    if (!p) return p;

    const applyDamage = <T extends Player | Mercenary>(char: T): T => {
      const limbToDamage = char.body[limbId as keyof typeof char.body];
      if (!limbToDamage || limbToDamage.state === 'Destroyed') {
        logMessage(`Limb is already destroyed.`, 'info');
        return char;
      }
      const { updatedLimb, logMessages } = processLimbDamage(limbToDamage, damage, damageTypes, char.name, GAME_DATA);
      logMessages.forEach((msg) => logMessage(msg, 'combat'));
      return { ...char, body: { ...char.body, [limbId]: updatedLimb as Limb } };
    };

    if (targetId === 'player') {
      return applyDamage(p);
    } else {
      return {
        ...p,
        party: p.party.map((m) => (m.id === targetId ? applyDamage(m) : m)),
      };
    }
  });
};
