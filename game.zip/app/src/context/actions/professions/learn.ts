import { toRoman } from 'utils/formatUtils';
import { EnchantmentRecipeId, GameData, GameSideEffect, Player, RecipeId } from '../../../types';

export function learnRecipe(player: Player, recipeId: RecipeId, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  if (player.knownRecipes[recipeId]) {
    return { player, sideEffects: [{ type: 'LOG', message: 'You already know this recipe.', logType: 'info' }] };
  }
  const newKnownRecipes = { ...player.knownRecipes, [recipeId]: true };
  const recipeData = GAME_DATA.ALL_RECIPES[recipeId];
  if (!recipeData) return null;

  const sideEffects: GameSideEffect[] = [{ type: 'LOG', message: `You have learned the recipe for ${recipeData.name}!`, logType: 'skill' }];
  return { player: { ...player, knownRecipes: newKnownRecipes }, sideEffects };
}

export function learnEnchantmentRecipe(
  player: Player,
  enchantmentRecipeId: EnchantmentRecipeId,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  if (player.knownEnchantments[enchantmentRecipeId]) {
    return { player, sideEffects: [{ type: 'LOG', message: 'You already know this enchantment.', logType: 'info' }] };
  }
  const newKnownEnchantments = { ...player.knownEnchantments, [enchantmentRecipeId]: true };

  const parts = enchantmentRecipeId.split('_');
  const tierStr = parts[parts.length - 1];
  const tier = parseInt(tierStr.substring(1), 10);
  const enchantId = parts.slice(0, -1).join('_');
  const enchantDef = GAME_DATA.ENCHANTS.find((e) => e.id === enchantId);
  if (!enchantDef) return null;

  const enchantName = `${enchantDef.name} ${toRoman(tier)}`;
  const sideEffects: GameSideEffect[] = [{ type: 'LOG', message: `You have learned the enchantment for ${enchantName}!`, logType: 'skill' }];

  return { player: { ...player, knownEnchantments: newKnownEnchantments }, sideEffects };
}