import { Player, RecipeId, GameData, GameSideEffect } from '../../../types';

export function learnRecipe(player: Player, recipeId: RecipeId, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  if (player.knownRecipes[recipeId]) {
    return { player, sideEffects: [{ type: 'LOG', message: 'You already know this recipe.', logType: 'info' }] };
  }
  const newKnownRecipes = { ...player.knownRecipes, [recipeId]: true };
  const recipeData = GAME_DATA.ALL_RECIPES[recipeId];
  if (!recipeData) return null;

  const sideEffects: GameSideEffect[] = [{ type: 'LOG', message: `You have learned the recipe for ${recipeData.name}!`, logType: 'skill' }];
  return { player: { ...player, knownRecipes: newKnownRecipes }, sideEffects };
}