import { Player, RecipeId, GameData } from "../../../types";

export function learnRecipeImpl(
  recipeId: RecipeId,
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: string, type: any) => void,
  GAME_DATA: GameData,
) {
  setPlayer((p) => {
    if (!p || p.knownRecipes[recipeId]) {
      logMessage("You already know this recipe.", "info");
      return p;
    }
    const newKnownRecipes = { ...p.knownRecipes, [recipeId]: true };
    const recipeData = GAME_DATA.ALL_RECIPES[recipeId];
    if (recipeData) logMessage(`You have learned the recipe for ${recipeData.name}!`, "skill");
    return { ...p, knownRecipes: newKnownRecipes };
  });
}