import { GameData, GameLocation, GameSideEffect, ItemId, ItemInstance, Player, PlayerEquipmentSlot, ProfessionId } from '../../../types';
import { getEquippedToolBonus, getItemName } from 'utils/itemUtils';
import { getRepairChecks, getRequirementStatus } from 'utils/craftingUtils';

import { calculateDifficultyBonus } from 'utils/gameMechanics';
import { calculateXpToNextLevel } from 'services/statService';
import { deepCloneWithInfinity } from 'utils/mathUtils';

export function repairItem(
  player: Player,
  targetItemInstance: ItemInstance,
  materials: ItemInstance[],
  _tools: ItemInstance[],
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const sideEffects: GameSideEffect[] = [];

  let itemLocation: 'inventory' | PlayerEquipmentSlot | null = null;
  const itemInInventory = player.inventory.find((i) => i.unique_id === targetItemInstance.unique_id);
  if (itemInInventory) {
    itemLocation = 'inventory';
  } else {
    for (const slot in player.equipment) {
      if (player.equipment[slot as PlayerEquipmentSlot]?.unique_id === targetItemInstance.unique_id) {
        itemLocation = slot as PlayerEquipmentSlot;
        break;
      }
    }
  }
  if (!itemLocation) {
    sideEffects.push({ type: 'LOG', message: 'Target item not found.', logType: 'error' });
    return { player, sideEffects };
  }

  const itemData = GAME_DATA.ITEMS[targetItemInstance.id];
  if (!itemData.recipeId) {
    sideEffects.push({ type: 'LOG', message: 'This item cannot be repaired.', logType: 'error' });
    return { player, sideEffects };
  }

  const recipe = GAME_DATA.ALL_RECIPES[itemData.recipeId];
  if (!recipe) {
    sideEffects.push({ type: 'LOG', message: 'Repair recipe not found.', logType: 'error' });
    return { player, sideEffects };
  }

  if (!player.knownRecipes[recipe.id]) {
    sideEffects.push({ type: 'LOG', message: "You don't know how to repair this item.", logType: 'error' });
    return { player, sideEffects };
  }

  const toolBonus = getEquippedToolBonus(player, recipe.profession);
  const playerSkill = player.professions[recipe.profession].level + toolBonus;
  const effectiveness = calculateDifficultyBonus(playerSkill, recipe.levelReq);

  const totalRequiredMats: Record<ItemId, number> = recipe.materials;
  const providedMatsGrouped = materials.reduce((acc, m) => {
    acc[m.id] = (acc[m.id] || 0) + 1;
    return acc;
  }, {} as Record<ItemId, number>);

  let repairRatio = 1.0;
  for (const matId in totalRequiredMats) {
    const required = totalRequiredMats[matId as ItemId];
    const provided = providedMatsGrouped[matId as ItemId] || 0;
    repairRatio = Math.min(repairRatio, provided / required);
  }

  if (repairRatio <= 0) {
    sideEffects.push({ type: 'LOG', message: "You haven't provided enough materials.", logType: 'error' });
    return { player, sideEffects };
  }

  const successChance = Math.min(0.95, effectiveness);
  const didSucceed = Math.random() < successChance;

  let finalItem = { ...targetItemInstance };

  if (didSucceed) {
    const durabilityToRestore = (finalItem.maxDurability || 0) * repairRatio * effectiveness;
    let newDurability = Math.min(finalItem.maxDurability!, (finalItem.currentDurability || 0) + durabilityToRestore);
    if (finalItem.maxDurability! - newDurability < 0.001) {
      newDurability = finalItem.maxDurability!;
    }
    finalItem.currentDurability = newDurability;

    if (finalItem.currentDurability > 0) {
      finalItem.isBroken = false;
    }
    sideEffects.push({ type: 'LOG', message: `Successfully repaired ${getItemName(finalItem, GAME_DATA)}.`, logType: 'skill' });
    sideEffects.push({ type: 'GAIN_PROFESSION_XP', professionId: recipe.profession, amount: recipe.xp * repairRatio } as GameSideEffect);
  } else {
    const catastrophicFailureChance = 0.2 * (1 - successChance);
    if (Math.random() < catastrophicFailureChance) {
      const durabilityLoss = (finalItem.maxDurability || 0) * 0.25;
      finalItem.currentDurability = (finalItem.currentDurability || 0) - durabilityLoss;
      sideEffects.push({ type: 'LOG', message: `Catastrophic failure! ${getItemName(finalItem, GAME_DATA)} was damaged further.`, logType: 'error' });
      if (finalItem.currentDurability < 0) {
        finalItem.currentDurability = 0;
        finalItem.isBroken = true;
        finalItem.isUnrepairable = true;
        sideEffects.push({ type: 'LOG', message: `${getItemName(finalItem, GAME_DATA)} is now unrepairable.`, logType: 'error' });
      }
    } else {
      sideEffects.push({ type: 'LOG', message: `Repair failed. The materials were consumed.`, logType: 'error' });
    }
  }

  const matIdsToRemove = new Set(materials.map((m) => m.unique_id));
  const newInventory: ItemInstance[] = [];
  let tempPlayer = { ...player };

  for (const item of tempPlayer.inventory) {
    if (matIdsToRemove.has(item.unique_id)) {
      continue;
    }
    if (itemLocation === 'inventory' && item.unique_id === targetItemInstance.unique_id) {
      newInventory.push(finalItem);
    } else {
      newInventory.push(item);
    }
  }

  tempPlayer.inventory = newInventory;
  if (itemLocation !== 'inventory') {
    tempPlayer.equipment = {
      ...tempPlayer.equipment,
      [itemLocation]: finalItem,
    };
  }

  return { player: tempPlayer, sideEffects };
}

export function repairAllItems(player: Player, GAME_DATA: GameData, currentLocation: GameLocation | null): { player: Player; sideEffects: GameSideEffect[] } {
  let tempPlayer = deepCloneWithInfinity(player);
  let sideEffects: GameSideEffect[] = [];

  const itemsToTryRepairing = [...tempPlayer.inventory, ...Object.values(tempPlayer.equipment).filter((i): i is ItemInstance => !!i)];

  let totalRepairedCount = 0;
  let totalFailedCount = 0;
  const xpGains: Partial<Record<ProfessionId, number>> = {};

  for (const targetItemInstance of itemsToTryRepairing) {
    if (
      !targetItemInstance?.id ||
      !GAME_DATA.ITEMS[targetItemInstance.id] ||
      !(
        targetItemInstance.currentDurability !== undefined &&
        targetItemInstance.maxDurability !== undefined &&
        targetItemInstance.currentDurability < targetItemInstance.maxDurability
      ) ||
      targetItemInstance.isUnrepairable ||
      targetItemInstance.isUnidentified
    ) {
      continue;
    }

    const itemData = GAME_DATA.ITEMS[targetItemInstance.id];
    if (!itemData.recipeId || !tempPlayer.knownRecipes[itemData.recipeId]) {
      continue;
    }

    const recipe = GAME_DATA.ALL_RECIPES[itemData.recipeId];
    if (!recipe) continue;

    const checks = getRepairChecks(tempPlayer, recipe, tempPlayer.inventory, tempPlayer.inventory, currentLocation, GAME_DATA, true);
    if (getRequirementStatus(checks) !== 'full') {
      continue;
    }

    const materialsToConsume: ItemInstance[] = [];
    const requiredMaterials = { ...recipe.materials };
    let canAffordMaterials = true;
    const tempInventoryWithoutConsumed = [...tempPlayer.inventory];

    for (const matId in requiredMaterials) {
      let requiredCount = requiredMaterials[matId as ItemId];
      for (let i = tempInventoryWithoutConsumed.length - 1; i >= 0 && requiredCount > 0; i--) {
        if (tempInventoryWithoutConsumed[i].id === matId) {
          materialsToConsume.push(tempInventoryWithoutConsumed.splice(i, 1)[0]);
          requiredCount--;
        }
      }
      if (requiredCount > 0) {
        canAffordMaterials = false;
        break;
      }
    }

    if (!canAffordMaterials) continue;

    tempPlayer.inventory = tempInventoryWithoutConsumed;

    const toolBonus = getEquippedToolBonus(tempPlayer, recipe.profession);
    const playerSkill = tempPlayer.professions[recipe.profession].level + toolBonus;
    const effectiveness = calculateDifficultyBonus(playerSkill, recipe.levelReq);
    const successChance = Math.min(0.95, effectiveness);
    const didSucceed = Math.random() < successChance;

    let finalItem = JSON.parse(JSON.stringify(targetItemInstance));

    if (didSucceed) {
      totalRepairedCount++;
      const durabilityToRestore = (finalItem.maxDurability || 0) * effectiveness;
      let newDurability = Math.min(finalItem.maxDurability!, (finalItem.currentDurability || 0) + durabilityToRestore);
      if (finalItem.maxDurability! - newDurability < 0.001) {
        newDurability = finalItem.maxDurability!;
      }
      finalItem.currentDurability = newDurability;

      if (finalItem.currentDurability > 0) {
        finalItem.isBroken = false;
      }
      xpGains[recipe.profession] = (xpGains[recipe.profession] || 0) + recipe.xp;
    } else {
      totalFailedCount++;
      const catastrophicFailureChance = 0.2 * (1 - successChance);
      if (Math.random() < catastrophicFailureChance) {
        const durabilityLoss = (finalItem.maxDurability || 0) * 0.25;
        finalItem.currentDurability = (finalItem.currentDurability || 0) - durabilityLoss;
        if (finalItem.currentDurability < 0) {
          finalItem.currentDurability = 0;
          finalItem.isBroken = true;
          finalItem.isUnrepairable = true;
        }
      }
    }

    const invIndex = tempPlayer.inventory.findIndex((i: ItemInstance) => i.unique_id === finalItem.unique_id);
    if (invIndex !== -1) {
      tempPlayer.inventory[invIndex] = finalItem;
    } else {
      for (const slot in tempPlayer.equipment) {
        if (tempPlayer.equipment[slot as PlayerEquipmentSlot]?.unique_id === finalItem.unique_id) {
          tempPlayer.equipment[slot as PlayerEquipmentSlot] = finalItem;
          break;
        }
      }
    }
  }

  if (totalRepairedCount === 0 && totalFailedCount === 0) {
    sideEffects.push({ type: 'LOG', message: 'No items could be repaired with available materials.', logType: 'info' });
  }

  if (totalRepairedCount > 0) {
    sideEffects.push({ type: 'LOG', message: `Successfully repaired ${totalRepairedCount} item(s).`, logType: 'skill' });
  }
  if (totalFailedCount > 0) {
    sideEffects.push({ type: 'LOG', message: `Failed to repair ${totalFailedCount} item(s).`, logType: 'error' });
  }

  for (const profIdStr in xpGains) {
    sideEffects.push({ type: 'GAIN_PROFESSION_XP', professionId: profIdStr as ProfessionId, amount: xpGains[profIdStr as ProfessionId]! } as GameSideEffect);
  }

  return { player: tempPlayer, sideEffects };
}