import { getEquippedToolBonus, getItemName, mergeIntoInventory } from 'utils/itemUtils';
import { GameData, GameSideEffect, ItemId, ItemInstance, Player, PlayerEquipmentSlot, ProfessionId } from '../../../types';

import { calculateDifficultyBonus } from 'utils/gameMechanics';
import { deepCloneWithInfinity } from 'utils/mathUtils';

type RepairOutcome = {
  success: boolean;
  newItem: ItemInstance;
  xpGained: number;
  log: GameSideEffect;
};

/**
 * A pure function to calculate the outcome of a single repair attempt.
 * Does not mutate any state.
 */
function calculateRepairOutcome(player: Player, targetItem: ItemInstance, repairRatio: number, GAME_DATA: GameData): RepairOutcome {
  const itemData = GAME_DATA.ITEMS[targetItem.id];
  const recipe = GAME_DATA.ALL_RECIPES[itemData.recipeId!];

  const toolBonus = getEquippedToolBonus(player, recipe.profession);
  const playerSkill = player.professions[recipe.profession].level + toolBonus;
  const effectiveness = calculateDifficultyBonus(playerSkill, recipe.levelReq);
  const successChance = Math.min(0.95, effectiveness);

  let newItem = deepCloneWithInfinity(targetItem);
  let xpGained = 0;
  let log: GameSideEffect;

  const didSucceed = Math.random() < successChance;

  if (didSucceed) {
    const durabilityToRestore = (newItem.maxDurability || 0) * repairRatio * effectiveness;
    let newDurability = Math.min(newItem.maxDurability!, (newItem.currentDurability || 0) + durabilityToRestore);
    if (newItem.maxDurability! - newDurability < 0.001) {
      newDurability = newItem.maxDurability!;
    }
    newItem.currentDurability = newDurability;

    if (newItem.currentDurability > 0) {
      newItem.isBroken = false;
    }
    xpGained = recipe.xp * repairRatio;
    log = { type: 'LOG', message: `Successfully repaired ${getItemName(newItem, GAME_DATA)}.`, logType: 'skill' };
  } else {
    const catastrophicFailureChance = 0.2 * (1 - successChance);
    if (Math.random() < catastrophicFailureChance) {
      const durabilityLoss = (newItem.maxDurability || 0) * 0.25;
      newItem.currentDurability = (newItem.currentDurability || 0) - durabilityLoss;
      log = { type: 'LOG', message: `Catastrophic failure! ${getItemName(newItem, GAME_DATA)} was damaged further.`, logType: 'error' };

      if (newItem.currentDurability <= 0) {
        newItem.currentDurability = 0;
        newItem.isBroken = true;
        newItem.isUnrepairable = true;
        log.message += ` It is now unrepairable.`;
      }
    } else {
      log = { type: 'LOG', message: `Repair failed on ${getItemName(newItem, GAME_DATA)}. The materials were consumed.`, logType: 'error' };
    }
  }

  return { success: didSucceed, newItem, xpGained, log };
}

export function repairItem(
  player: Player,
  targetItemInstance: ItemInstance,
  materials: ItemInstance[],
  _tools: ItemInstance[], // Tools are now derived from equipped items, keeping param for API consistency.
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const sideEffects: GameSideEffect[] = [];

  // 1. Find the item
  let itemLocation: 'inventory' | PlayerEquipmentSlot | null = null;
  const itemInInventory = player.inventory.find((i) => i.unique_id === targetItemInstance.unique_id);
  if (itemInInventory) {
    itemLocation = 'inventory';
  } else {
    for (const slot in player.equipment) {
      if (player.equipment[slot as PlayerEquipmentSlot]?.unique_id === targetItemInstance.unique_id) {
        itemLocation = slot as PlayerEquipmentSlot;
        break;
      }
    }
  }

  if (!itemLocation) {
    sideEffects.push({ type: 'LOG', message: 'Target item not found.', logType: 'error' });
    return { player, sideEffects };
  }

  // 2. Validate the repairability
  const itemData = GAME_DATA.ITEMS[targetItemInstance.id];
  if (!itemData.recipeId) {
    sideEffects.push({ type: 'LOG', message: 'This item cannot be repaired.', logType: 'error' });
    return { player, sideEffects };
  }
  const recipe = GAME_DATA.ALL_RECIPES[itemData.recipeId];
  if (!recipe || !player.knownRecipes[recipe.id]) {
    sideEffects.push({ type: 'LOG', message: "You don't know how to repair this item.", logType: 'error' });
    return { player, sideEffects };
  }

  // 3. Calculate material ratio
  const totalRequiredMats: Record<ItemId, number> = recipe.materials;
  const providedMatsGrouped = materials.reduce((acc, m) => {
    acc[m.id] = (acc[m.id] || 0) + m.quantity;
    return acc;
  }, {} as Record<ItemId, number>);

  let repairRatio = 1.0;
  for (const matId in totalRequiredMats) {
    const required = totalRequiredMats[matId as ItemId];
    const provided = providedMatsGrouped[matId as ItemId] || 0;
    repairRatio = Math.min(repairRatio, provided / required);
  }

  if (repairRatio <= 0) {
    sideEffects.push({ type: 'LOG', message: "You haven't provided enough materials.", logType: 'error' });
    return { player, sideEffects };
  }

  // 4. Get the outcome
  const outcome = calculateRepairOutcome(player, targetItemInstance, repairRatio, GAME_DATA);
  sideEffects.push(outcome.log);
  if (outcome.xpGained > 0) {
    sideEffects.push({ type: 'GAIN_PROFESSION_XP', professionId: recipe.profession, amount: outcome.xpGained });
  }

  // 5. Apply changes to player state
  let tempPlayer = deepCloneWithInfinity(player);

  for (const matStack of materials) {
    let toConsume = matStack.quantity;
    for (let i = tempPlayer.inventory.length - 1; i >= 0; i--) {
      if (toConsume <= 0) break;
      const invItem = tempPlayer.inventory[i];
      if (invItem.id === matStack.id) {
        const take = Math.min(toConsume, invItem.quantity);
        invItem.quantity -= take;
        toConsume -= take;
        if (invItem.quantity <= 0) {
          tempPlayer.inventory.splice(i, 1);
        }
      }
    }
  }

  const itemIndexInNewInv = tempPlayer.inventory.findIndex((i) => i.unique_id === targetItemInstance.unique_id);

  if (itemLocation === 'inventory' && itemIndexInNewInv !== -1) {
    tempPlayer.inventory[itemIndexInNewInv] = outcome.newItem;
  } else if (itemLocation !== 'inventory') {
    tempPlayer.equipment = {
      ...tempPlayer.equipment,
      [itemLocation]: outcome.newItem,
    };
  }

  return { player: tempPlayer, sideEffects };
}

export function repairAllItems(player: Player, GAME_DATA: GameData, _currentLocation: any): { player: Player; sideEffects: GameSideEffect[] } {
  let tempPlayer = deepCloneWithInfinity(player);
  const sideEffects: GameSideEffect[] = [];
  const allPlayerItems = [...tempPlayer.inventory, ...Object.values(tempPlayer.equipment).filter((i): i is ItemInstance => !!i)];
  const repairedItems: ItemInstance[] = [];
  const xpGains: Partial<Record<ProfessionId, number>> = {};
  let repairedCount = 0;
  let failedCount = 0;

  const repairableItems = allPlayerItems.filter((item) => {
    const data = item && GAME_DATA.ITEMS[item.id];
    return (
      data &&
      data.recipeId &&
      tempPlayer.knownRecipes[data.recipeId] &&
      item.currentDurability !== undefined &&
      item.maxDurability !== undefined &&
      item.currentDurability < item.maxDurability &&
      !item.isUnrepairable &&
      !item.isUnidentified
    );
  });

  const availableMaterialQuantities = tempPlayer.inventory.reduce((acc, item) => {
    if (GAME_DATA.ITEMS[item.id].type.includes('material')) {
      acc[item.id] = (acc[item.id] || 0) + item.quantity;
    }
    return acc;
  }, {} as Record<ItemId, number>);

  for (const item of repairableItems) {
    const recipe = GAME_DATA.ALL_RECIPES[GAME_DATA.ITEMS[item.id].recipeId!];
    if (!recipe) continue;

    const matsForThisItem: Record<ItemId, number> = {};
    let canAfford = true;
    for (const matId in recipe.materials) {
      const requiredCount = recipe.materials[matId as ItemId];
      if ((availableMaterialQuantities[matId as ItemId] || 0) < requiredCount) {
        canAfford = false;
        break;
      }
      matsForThisItem[matId as ItemId] = requiredCount;
    }

    if (canAfford) {
      const outcome = calculateRepairOutcome(player, item, 1.0, GAME_DATA);
      if (outcome.success) {
        repairedCount++;
        const prof = recipe.profession;
        xpGains[prof] = (xpGains[prof] || 0) + outcome.xpGained;
        repairedItems.push(outcome.newItem);
        for (const matId in matsForThisItem) {
          availableMaterialQuantities[matId as ItemId] -= matsForThisItem[matId as ItemId];
        }
      } else {
        failedCount++;
      }
      sideEffects.push(outcome.log);
    }
  }

  if (repairedCount === 0 && failedCount === 0) {
    sideEffects.push({ type: 'LOG', message: 'No items could be repaired with available materials.', logType: 'info' });
    return { player, sideEffects };
  }

  // Update inventory with consumed materials
  let newInventory: ItemInstance[] = [];
  tempPlayer.inventory.forEach((item) => {
    if (GAME_DATA.ITEMS[item.id].type.includes('material')) {
      const remaining = availableMaterialQuantities[item.id];
      if (remaining > 0) {
        newInventory.push({ ...item, quantity: remaining });
        delete availableMaterialQuantities[item.id];
      }
    } else {
      newInventory.push({ ...item });
    }
  });

  const repairedItemIds = new Set(repairedItems.map((i) => i.unique_id));
  newInventory = newInventory.filter((i) => !repairedItemIds.has(i.unique_id));
  const { newInventory: finalInventory, overflow } = mergeIntoInventory(newInventory, repairedItems, GAME_DATA);
  tempPlayer.inventory = finalInventory;
  if (overflow.length > 0) {
    sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
  }

  if (repairedCount > 0) sideEffects.push({ type: 'LOG', message: `Successfully repaired ${repairedCount} item(s).`, logType: 'skill' });
  if (failedCount > 0) sideEffects.push({ type: 'LOG', message: `Failed to repair ${failedCount} item(s).`, logType: 'error' });

  for (const profIdStr in xpGains) {
    sideEffects.push({ type: 'GAIN_PROFESSION_XP', professionId: profIdStr as ProfessionId, amount: xpGains[profIdStr as ProfessionId]! });
  }

  return { player: tempPlayer, sideEffects };
}