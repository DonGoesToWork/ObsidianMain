import { Player, ItemInstance, Recipe, ProfessionId, PlayerEquipmentSlot, ItemId, GameData } from '../../../types';
import { calculateDifficultyBonus } from 'utils/gameMechanics';
import { getEquippedToolBonus, getItemName } from 'utils/itemUtils';

export function repairItemImpl(
  targetItemInstance: ItemInstance,
  materials: ItemInstance[],
  _tools: ItemInstance[],
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: string, type: any) => void,
  gainProfessionXp: (professionId: ProfessionId, amount: number) => void,
  GAME_DATA: GameData
) {
  setPlayer((p) => {
    if (!p) return p;

    let itemLocation: 'inventory' | PlayerEquipmentSlot | null = null;
    let itemIndex = -1;

    itemIndex = p.inventory.findIndex((i) => i === targetItemInstance);
    if (itemIndex !== -1) {
      itemLocation = 'inventory';
    } else {
      for (const slot in p.equipment) {
        if (p.equipment[slot as PlayerEquipmentSlot] === targetItemInstance) {
          itemLocation = slot as PlayerEquipmentSlot;
          break;
        }
      }
    }
    if (!itemLocation) {
      logMessage('Target item not found.', 'error');
      return p;
    }

    const itemData = GAME_DATA.ITEMS[targetItemInstance.id];
    if (!itemData.recipeId) {
      logMessage('This item cannot be repaired.', 'error');
      return p;
    }

    const recipe = GAME_DATA.ALL_RECIPES[itemData.recipeId];
    if (!recipe) {
      logMessage('Repair recipe not found.', 'error');
      return p;
    }

    if (!p.knownRecipes[recipe.id]) {
      logMessage("You don't know how to repair this item.", 'error');
      return p;
    }

    const toolBonus = getEquippedToolBonus(p, recipe.profession);
    const playerSkill = p.professions[recipe.profession].level + toolBonus;
    const effectiveness = calculateDifficultyBonus(playerSkill, recipe.levelReq);

    const totalRequiredMats: Record<ItemId, number> = recipe.materials;
    const providedMatsGrouped = materials.reduce((acc, m) => {
      acc[m.id] = (acc[m.id] || 0) + 1;
      return acc;
    }, {} as Record<ItemId, number>);

    let repairRatio = 1.0;
    for (const matId in totalRequiredMats) {
      const required = totalRequiredMats[matId as ItemId];
      const provided = providedMatsGrouped[matId as ItemId] || 0;
      repairRatio = Math.min(repairRatio, provided / required);
    }

    if (repairRatio <= 0) {
      logMessage("You haven't provided enough materials.", 'error');
      return p;
    }

    let tempInventory = [...p.inventory];
    materials.forEach((mat) => {
      const index = tempInventory.findIndex((invItem) => invItem === mat);
      if (index > -1) tempInventory.splice(index, 1);
    });

    const successChance = Math.min(0.95, effectiveness);
    const didSucceed = Math.random() < successChance;

    let newPlayerState = { ...p, inventory: tempInventory };
    let finalItem = { ...targetItemInstance };

    if (didSucceed) {
      const durabilityToRestore = (finalItem.maxDurability || 0) * repairRatio * effectiveness;
      finalItem.currentDurability = Math.min(finalItem.maxDurability!, (finalItem.currentDurability || 0) + durabilityToRestore);
      if (finalItem.currentDurability > 0) {
        finalItem.isBroken = false;
      }
      logMessage(`Successfully repaired ${getItemName(finalItem, GAME_DATA)}.`, 'skill');
      gainProfessionXp(recipe.profession, recipe.xp * repairRatio);
    } else {
      const catastrophicFailureChance = 0.2 * (1 - successChance);
      if (Math.random() < catastrophicFailureChance) {
        const durabilityLoss = (finalItem.maxDurability || 0) * 0.25;
        finalItem.currentDurability = (finalItem.currentDurability || 0) - durabilityLoss;
        logMessage(`Catastrophic failure! ${getItemName(finalItem, GAME_DATA)} was damaged further.`, 'error');
        if (finalItem.currentDurability < 0) {
          finalItem.currentDurability = 0;
          finalItem.isBroken = true;
          finalItem.isUnrepairable = true;
          logMessage(`${getItemName(finalItem, GAME_DATA)} is now unrepairable.`, 'error');
        }
      } else {
        logMessage(`Repair failed. The materials were consumed.`, 'error');
      }
    }

    if (itemLocation === 'inventory') {
      const originalIndex = p.inventory.findIndex((i) => i === targetItemInstance);
      newPlayerState.inventory[originalIndex] = finalItem;
    } else {
      newPlayerState.equipment = {
        ...newPlayerState.equipment,
        [itemLocation]: finalItem,
      };
    }

    return newPlayerState;
  });
}