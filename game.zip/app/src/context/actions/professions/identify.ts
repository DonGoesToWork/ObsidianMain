import { calculateItemLevel } from 'utils/itemUtils';
import { GameData, GameSideEffect, Player } from '../../../types';

export function identifyAllItems(player: Player, cost: number, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  const unidentifiedItems = player.inventory.filter((i) => i.isUnidentified);
  if (unidentifiedItems.length === 0) {
    return { player, sideEffects: [{ type: 'LOG', message: 'You have no items to identify.', logType: 'info' }] };
  }

  if (player.gold < cost) {
    return { player, sideEffects: [{ type: 'LOG', message: "You can't afford this service.", logType: 'error' }] };
  }

  let totalXpGained = 0;
  const newInventory = player.inventory.map((item) => {
    if (item.isUnidentified) {
      totalXpGained += Math.max(1, calculateItemLevel(item, GAME_DATA));
      return { ...item, isUnidentified: false };
    }
    return item;
  });

  const sideEffects: GameSideEffect[] = [
    {
      type: 'LOG',
      message: `The appraiser identifies ${unidentifiedItems.length} items for ${cost} gold.`,
      logType: 'skill',
    },
    { type: 'GAIN_PROFESSION_XP', professionId: 'appraisal', amount: totalXpGained } as GameSideEffect,
  ];

  const newPlayer: Player = { ...player, gold: player.gold - cost, inventory: newInventory };
  return { player: newPlayer, sideEffects };
}
