import { Player, ItemInstance, ProfessionId, GameData } from "../../../types";
import { calculateDifficultyBonus } from "utils/gameMechanics";
import { getEquippedToolBonus, calculateItemLevel } from "utils/itemUtils";

export function identifyItemImpl(
  itemUniqueId: string,
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: string, type: any) => void,
  gainProfessionXp: (professionId: ProfessionId, amount: number) => void,
  GAME_DATA: GameData,
) {
  setPlayer((p) => {
    if (!p) return p;

    const inventoryIndex = p.inventory.findIndex((i) => i.unique_id === itemUniqueId);
    if (inventoryIndex === -1) {
      logMessage("Item to identify not found.", "error");
      return p;
    }

    const itemInstance = p.inventory[inventoryIndex];
    if (!itemInstance || !itemInstance.isUnidentified) {
      logMessage("This item is already identified.", "info");
      return p;
    }

    const itemData = GAME_DATA.ITEMS[itemInstance.id];
    const difficulty = calculateItemLevel(itemInstance, GAME_DATA);
    const toolBonus = getEquippedToolBonus(p, "appraisal");
    const totalSkill = p.professions.appraisal.level + toolBonus;
    const successChance = calculateDifficultyBonus(totalSkill, difficulty) * 0.5;

    if (Math.random() < successChance) {
      const newInventory = [...p.inventory];
      newInventory[inventoryIndex] = { ...itemInstance, isUnidentified: false };
      logMessage(`You successfully identify the ${itemData.name}.`, "skill");
      gainProfessionXp("appraisal", Math.max(1, difficulty));
      return { ...p, inventory: newInventory };
    }
    logMessage("You failed to identify the item.", "error");
    return p;
  });
}

export function identifyAllItemsImpl(
  cost: number,
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: string, type: any) => void,
  gainProfessionXp: (professionId: ProfessionId, amount: number) => void,
  GAME_DATA: GameData,
) {
  setPlayer((p) => {
    if (!p) return p;

    const unidentifiedItems = p.inventory.filter((i) => i.isUnidentified);
    if (unidentifiedItems.length === 0) {
      logMessage("You have no items to identify.", "info");
      return p;
    }

    if (p.gold < cost) {
      logMessage("You can't afford this service.", "error");
      return p;
    }

    let totalXpGained = 0;
    const newInventory = p.inventory.map((item) => {
      if (item.isUnidentified) {
        totalXpGained += Math.max(1, calculateItemLevel(item, GAME_DATA));
        return { ...item, isUnidentified: false };
      }
      return item;
    });

    logMessage(`The appraiser identifies ${unidentifiedItems.length} items for ${cost} gold.`, "skill");
    gainProfessionXp("appraisal", totalXpGained);

    return { ...p, gold: p.gold - cost, inventory: newInventory };
  });
}