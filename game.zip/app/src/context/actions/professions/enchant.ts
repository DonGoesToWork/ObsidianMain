import { EnchantDef, GameData, GameSideEffect, ItemId, ItemInstance, Player, StatBlock } from 'types';
import { calculateItemLevel, calculateItemTier, countItems, mergeIntoInventory } from 'utils/itemUtils';

import { calculateEnchantSuccessChance } from 'utils/craftingUtils';

export function enchantItem(
  player: Player,
  itemUniqueId: string,
  enchantDef: EnchantDef,
  enchantRank: number,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[]; newItem?: ItemInstance } | null {
  const sideEffects: GameSideEffect[] = [];

  const itemIdx = player.inventory.findIndex((i) => i.unique_id === itemUniqueId);
  if (itemIdx === -1) {
    sideEffects.push({ type: 'LOG', message: 'Item to enchant not found.', logType: 'error' });
    return { player, sideEffects };
  }
  const originalItemStack = player.inventory[itemIdx];
  const itemToEnchant: ItemInstance = { ...originalItemStack, quantity: 1 };
  const itemData = GAME_DATA.ITEMS[itemToEnchant.id];

  const tier = enchantRank + 1;
  const recipeId = `${enchantDef.id}_t${tier}`;
  if (!player.knownEnchantments[recipeId]) {
    sideEffects.push({ type: 'LOG', message: 'You do not know how to perform this enchantment.', logType: 'error' });
    return { player, sideEffects };
  }

  if (enchantDef.type === 'local' && enchantDef.appliesTo) {
    const { hasStat, hasItemType } = enchantDef.appliesTo;
    let canApply = false;
    if (hasStat && hasStat.some((s) => itemData.stats && itemData.stats[s as keyof StatBlock])) {
      canApply = true;
    }
    if (hasItemType && hasItemType.some((t) => itemData.type.includes(t))) {
      canApply = true;
    }
    if (!canApply) {
      sideEffects.push({ type: 'LOG', message: 'This enchantment cannot be applied to this type of item.', logType: 'error' });
      return { player, sideEffects };
    }
  }

  const currentTier = itemToEnchant.enchantments[enchantDef.id] || 0;
  if (tier <= currentTier) {
    sideEffects.push({ type: 'LOG', message: 'You can only enchant to a higher tier.', logType: 'error' });
    return { player, sideEffects };
  }

  const calculatedLevel = calculateItemLevel(itemToEnchant, GAME_DATA);
  const itemTier = calculateItemTier(calculatedLevel);
  if (tier > itemTier) {
    sideEffects.push({ type: 'LOG', message: `This item is not high enough level for a tier ${tier} enchantment.`, logType: 'error' });
    return { player, sideEffects };
  }

  const numEnchantments = Object.keys(itemToEnchant.enchantments).length;
  const isNewEnchant = !itemToEnchant.enchantments[enchantDef.id];
  if (isNewEnchant && numEnchantments >= Object.keys(GAME_DATA.ITEM_RARITY_TIERS).length - 1) {
    sideEffects.push({ type: 'LOG', message: 'This item cannot hold any more different enchantments.', logType: 'error' });
    return { player, sideEffects };
  }

  if (!enchantDef.cost[enchantRank]) {
    sideEffects.push({ type: 'LOG', message: 'This rank cannot be enchanted.', logType: 'error' });
    return { player, sideEffects };
  }
  const crystalId = Object.keys(enchantDef.cost[enchantRank])[0] as ItemId;
  const crystalCost = enchantDef.cost[enchantRank][crystalId];

  if (countItems(player.inventory, crystalId) < crystalCost) {
    sideEffects.push({ type: 'LOG', message: 'You lack the required materials.', logType: 'error' });
    return { player, sideEffects };
  }

  let tempPlayer = { ...player };
  let crystalsToRemove = crystalCost;
  const newInventory: ItemInstance[] = [];
  for (const item of tempPlayer.inventory) {
    const newItem = { ...item };
    if (newItem.id === crystalId && crystalsToRemove > 0) {
      const amountToRemove = Math.min(crystalsToRemove, newItem.quantity);
      newItem.quantity -= amountToRemove;
      crystalsToRemove -= amountToRemove;
    }
    if (newItem.quantity > 0) {
      newInventory.push(newItem);
    }
  }
  tempPlayer.inventory = newInventory;

  const itemIdxAfterCrystalRemoval = tempPlayer.inventory.findIndex((i) => i.unique_id === itemUniqueId);
  const originalStackAfterCrystalRemoval = itemIdxAfterCrystalRemoval !== -1 ? tempPlayer.inventory[itemIdxAfterCrystalRemoval] : null;

  const playerSkill = tempPlayer.professions.enchanting.level;
  const numExistingEnchants = Object.keys(itemToEnchant.enchantments).length;
  const baseDr = (enchantRank + 1) * 10;
  const finalDr = baseDr + numExistingEnchants;
  const successChance = calculateEnchantSuccessChance(playerSkill, finalDr) / 100;
  let finalNewItem: ItemInstance | undefined = undefined;

  const handleStacking = (
    inventory: ItemInstance[],
    originalStack: ItemInstance | null,
    itemToHandle: ItemInstance | null,
    itemIndex: number
  ): { inventory: ItemInstance[]; item: ItemInstance | null } => {
    let newInv = [...inventory];
    if (originalStack && originalStack.quantity > 1) {
      originalStack.quantity--;
      if (itemToHandle) {
        const mergeResult = mergeIntoInventory(newInv, [itemToHandle], GAME_DATA);
        newInv = mergeResult.newInventory;
        if (mergeResult.overflow.length > 0) sideEffects.push({ type: 'DROP_ITEMS', items: mergeResult.overflow });
      }
    } else if (itemIndex !== -1) {
      if (itemToHandle) {
        newInv[itemIndex] = itemToHandle;
      } else {
        newInv.splice(itemIndex, 1);
      }
    }
    return { inventory: newInv, item: itemToHandle };
  };

  if (Math.random() < successChance) {
    sideEffects.push({ type: 'LOG', message: 'Enchantment successful!', logType: 'skill' });
    const newEnchantedItem: ItemInstance = {
      ...itemToEnchant,
      unique_id: `item_${Date.now()}_${Math.random()}`,
      enchantments: { ...itemToEnchant.enchantments, [enchantDef.id]: tier },
    };
    finalNewItem = newEnchantedItem;

    const { inventory: updatedInventory } = handleStacking(tempPlayer.inventory, originalStackAfterCrystalRemoval, newEnchantedItem, itemIdxAfterCrystalRemoval);
    tempPlayer.inventory = updatedInventory;

    const xpGained = calculateItemLevel(itemToEnchant, GAME_DATA) + tier * 10;
    sideEffects.push({ type: 'GAIN_PROFESSION_XP', professionId: 'enchanting', amount: xpGained } as GameSideEffect);
  } else {
    sideEffects.push({ type: 'LOG', message: 'The enchantment failed and the materials were lost.', logType: 'error' });
    if (successChance > 0 && tier >= 5 && Math.random() < (tier - 4) * 0.25) {
      if (Math.random() < 0.5) {
        sideEffects.push({ type: 'LOG', message: 'Catastrophic failure! The enchantment backfired and destroyed your item!', logType: 'error' });
        const { inventory: updatedInventory } = handleStacking(tempPlayer.inventory, originalStackAfterCrystalRemoval, null, itemIdxAfterCrystalRemoval);
        tempPlayer.inventory = updatedInventory;
      } else {
        const existingTier = itemToEnchant.enchantments[enchantDef.id];
        if (existingTier) {
          sideEffects.push({ type: 'LOG', message: 'The enchantment failed and weakened the existing magic on the item!', logType: 'error' });
          const downgradedItem: ItemInstance = {
            ...itemToEnchant,
            unique_id: `item_${Date.now()}_${Math.random()}`,
            enchantments: { ...itemToEnchant.enchantments },
          };
          finalNewItem = downgradedItem;

          if (existingTier > 1) {
            downgradedItem.enchantments[enchantDef.id] = existingTier - 1;
          } else {
            delete downgradedItem.enchantments[enchantDef.id];
          }

          const { inventory: updatedInventory } = handleStacking(tempPlayer.inventory, originalStackAfterCrystalRemoval, downgradedItem, itemIdxAfterCrystalRemoval);
          tempPlayer.inventory = updatedInventory;
        }
      }
    }
  }
  return { player: tempPlayer, sideEffects, newItem: finalNewItem };
}
