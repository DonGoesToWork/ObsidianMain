import { EnchantDef, GameData, GameSideEffect, ItemId, ItemInstance, Player, ProfessionId, StatBlock } from 'types';
import { ITEM_RARITY_TIERS, calculateItemLevel, countItems } from 'utils/itemUtils';

import { calculateEnchantSuccessChance } from 'utils/craftingUtils';

export function enchantItem(
  player: Player,
  itemUniqueId: string,
  enchantDef: EnchantDef,
  enchantRank: number,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  let tempPlayer = { ...player, inventory: [...player.inventory] };
  const sideEffects: GameSideEffect[] = [];

  const itemIdx = tempPlayer.inventory.findIndex((i) => i.unique_id === itemUniqueId);
  if (itemIdx === -1) {
    sideEffects.push({ type: 'LOG', message: 'Item to enchant not found.', logType: 'error' });
    return { player, sideEffects };
  }
  const itemToEnchant = { ...tempPlayer.inventory[itemIdx] };
  const itemData = GAME_DATA.ITEMS[itemToEnchant.id];

  if (enchantDef.type === 'local' && enchantDef.appliesTo) {
    const { hasStat, hasItemType } = enchantDef.appliesTo;
    let canApply = false;
    if (hasStat && hasStat.some((s) => itemData.stats && itemData.stats[s as keyof StatBlock])) {
      canApply = true;
    }
    if (hasItemType && hasItemType.some((t) => itemData.type.includes(t))) {
      canApply = true;
    }
    if (!canApply) {
      sideEffects.push({ type: 'LOG', message: 'This enchantment cannot be applied to this type of item.', logType: 'error' });
      return { player, sideEffects };
    }
  }

  const tier = enchantRank + 1;
  const currentTier = itemToEnchant.enchantments[enchantDef.id] || 0;
  if (tier <= currentTier) {
    sideEffects.push({ type: 'LOG', message: 'You can only enchant to a higher tier.', logType: 'error' });
    return { player, sideEffects };
  }

  const calculatedLevel = calculateItemLevel(itemToEnchant, GAME_DATA);
  const itemTier = Math.floor(calculatedLevel / 10) + 1;
  if (tier > itemTier) {
    sideEffects.push({ type: 'LOG', message: `This item is not high enough level for a tier ${tier} enchantment.`, logType: 'error' });
    return { player, sideEffects };
  }

  const numEnchantments = Object.keys(itemToEnchant.enchantments).length;
  const isNewEnchant = !itemToEnchant.enchantments[enchantDef.id];
  if (isNewEnchant && numEnchantments >= Object.keys(ITEM_RARITY_TIERS).length - 1) {
    sideEffects.push({ type: 'LOG', message: 'This item cannot hold any more different enchantments.', logType: 'error' });
    return { player, sideEffects };
  }

  if (!enchantDef.cost[enchantRank]) {
    sideEffects.push({ type: 'LOG', message: 'This rank cannot be enchanted.', logType: 'error' });
    return { player, sideEffects };
  }
  const crystalId = Object.keys(enchantDef.cost[enchantRank])[0] as ItemId;
  const crystalCost = enchantDef.cost[enchantRank][crystalId];

  if (countItems(player.inventory, crystalId) < crystalCost) {
    sideEffects.push({ type: 'LOG', message: 'You lack the required materials.', logType: 'error' });
    return { player, sideEffects };
  }

  let crystalsToRemove = crystalCost;
  tempPlayer.inventory = tempPlayer.inventory.filter((item) => {
    if (item.id === crystalId && crystalsToRemove > 0) {
      crystalsToRemove--;
      return false;
    }
    return true;
  });

  const itemIdxAfterCrystalRemoval = tempPlayer.inventory.findIndex((i) => i.unique_id === itemUniqueId);
  if (itemIdxAfterCrystalRemoval === -1) {
    sideEffects.push({ type: 'LOG', message: 'Item disappeared after removing crystals, this should not happen.', logType: 'error' });
    return { player: tempPlayer, sideEffects };
  }

  const playerSkill = tempPlayer.professions.enchanting.level;
  const numExistingEnchants = Object.keys(itemToEnchant.enchantments).length;
  const baseDr = (enchantRank + 1) * 10;
  const finalDr = baseDr + numExistingEnchants;
  const successChance = calculateEnchantSuccessChance(playerSkill, finalDr) / 100;

  if (Math.random() < successChance) {
    sideEffects.push({ type: 'LOG', message: 'Enchantment successful!', logType: 'skill' });
    const newEnchantedItem = {
      ...itemToEnchant,
      enchantments: { ...itemToEnchant.enchantments },
    };

    newEnchantedItem.enchantments[enchantDef.id] = tier;

    tempPlayer.inventory[itemIdxAfterCrystalRemoval] = newEnchantedItem;

    const xpGained = calculateItemLevel(itemToEnchant, GAME_DATA) + tier * 10;
    sideEffects.push({ type: 'GAIN_PROFESSION_XP', professionId: 'enchanting', amount: xpGained } as GameSideEffect);
  } else {
    if (tier >= 5) {
      const penaltyChance = (tier - 4) * 0.25;
      if (Math.random() < penaltyChance) {
        const destroyChance = 0.5;
        if (Math.random() < destroyChance) {
          sideEffects.push({ type: 'LOG', message: 'Catastrophic failure! The enchantment backfired and destroyed your item!', logType: 'error' });
          tempPlayer.inventory.splice(itemIdxAfterCrystalRemoval, 1);
        } else {
          sideEffects.push({ type: 'LOG', message: 'The enchantment failed and weakened the existing magic on the item!', logType: 'error' });
          const downgradedItem = {
            ...itemToEnchant,
            enchantments: { ...itemToEnchant.enchantments },
          };
          if (enchantRank === 0) {
            delete downgradedItem.enchantments[enchantDef.id];
          } else {
            downgradedItem.enchantments[enchantDef.id] = enchantRank;
          }
          tempPlayer.inventory[itemIdxAfterCrystalRemoval] = downgradedItem;
        }
        return { player: tempPlayer, sideEffects };
      }
    }
    sideEffects.push({ type: 'LOG', message: 'The enchantment failed and the materials were lost.', logType: 'error' });
  }

  return { player: tempPlayer, sideEffects };
}