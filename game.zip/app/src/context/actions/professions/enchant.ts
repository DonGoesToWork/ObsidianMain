import { Player, ItemInstance, ProfessionId, StatBlock, GameData } from '../../../types';
import { calculateItemLevel, countItems } from 'utils/itemUtils';

export function enchantItemImpl(
  itemUniqueId: string,
  enchantDef: any,
  enchantRank: number,
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: string, type: any) => void,
  gainProfessionXp: (professionId: ProfessionId, amount: number) => void,
  GAME_DATA: GameData
) {
  setPlayer((p) => {
    if (!p) return p;
    const itemToEnchant = p.inventory.find((i) => i.unique_id === itemUniqueId);
    if (!itemToEnchant) {
      logMessage('Item to enchant not found.', 'error');
      return p;
    }

    const goldCost = enchantDef.gold[enchantRank];
    const crystalId = Object.keys(enchantDef.cost[enchantRank])[0];
    const crystalCost = enchantDef.cost[enchantRank][crystalId];

    if (p.gold < goldCost || countItems(p.inventory, crystalId) < crystalCost) {
      logMessage('You lack the required materials.', 'error');
      return p;
    }

    let finalPlayer = { ...p, gold: p.gold - goldCost };
    let crystalsToRemove = crystalCost;
    finalPlayer.inventory = finalPlayer.inventory.filter((item) => {
      if (item.id === crystalId && crystalsToRemove > 0) {
        crystalsToRemove--;
        return false;
      }
      return true;
    });

    const itemIdx = finalPlayer.inventory.findIndex((i) => i.unique_id === itemUniqueId);
    if (itemIdx === -1) {
      return finalPlayer;
    }

    const playerSkill = finalPlayer.professions.enchanting.level;
    const successChanceRaw = 100 - (enchantRank + 1) * 5 + playerSkill / 2;
    const successChance = Math.max(0, Math.min(100, successChanceRaw)) / 100;

    const stat = enchantDef.stat as keyof StatBlock;

    if (Math.random() < successChance) {
      logMessage('Enchantment successful!', 'skill');
      const newEnchantedItem = {
        ...itemToEnchant,
        enchantments: { ...itemToEnchant.enchantments },
      };
      const value = enchantDef.scaling[enchantRank];
      newEnchantedItem.enchantments[stat] = value;
      finalPlayer.inventory[itemIdx] = newEnchantedItem;

      const xpGained = calculateItemLevel(itemToEnchant, GAME_DATA) + (enchantRank + 1) * 10;
      gainProfessionXp('enchanting', xpGained);
    } else {
      if (enchantRank >= 4) {
        const penaltyChance = (enchantRank - 3) * 0.25;
        if (Math.random() < penaltyChance) {
          const destroyChance = 0.5;
          if (Math.random() < destroyChance) {
            logMessage('Catastrophic failure! The enchantment backfired and destroyed your item!', 'error');
            finalPlayer.inventory.splice(itemIdx, 1);
          } else {
            logMessage('The enchantment failed and weakened the existing magic on the item!', 'error');
            const downgradedItem = {
              ...itemToEnchant,
              enchantments: { ...itemToEnchant.enchantments },
            };
            if (enchantRank === 0) {
              delete downgradedItem.enchantments[stat];
            } else {
              downgradedItem.enchantments[stat] = enchantDef.scaling[enchantRank - 1];
            }
            finalPlayer.inventory[itemIdx] = downgradedItem;
          }
          return finalPlayer;
        }
      }
      logMessage('The enchantment failed and the materials were lost.', 'error');
    }

    return finalPlayer;
  });
}
