import { calculateCraftSuccessChance } from 'utils/craftingUtils';
import { createItemInstances, mergeIntoInventory } from 'utils/itemUtils';
import { GameData, GameSideEffect, ItemInstance, Player, Recipe } from '../../../types';

export function craftItem(
  player: Player,
  recipe: Recipe | null,
  quantity: number,
  _tools: ItemInstance[],
  ingredientsToConsume: ItemInstance[],
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];

  if (ingredientsToConsume.length === 0) {
    sideEffects.push({ type: 'LOG', message: 'No ingredients provided.', logType: 'error' });
    return { player, sideEffects };
  }

  let tempInventory = [...player.inventory];
  for (const ingredientStack of ingredientsToConsume) {
    let remainingToConsume = ingredientStack.quantity;
    for (let i = tempInventory.length - 1; i >= 0; i--) {
      if (remainingToConsume <= 0) break;
      const invItem = tempInventory[i];
      if (invItem.id === ingredientStack.id) {
        const takeAmount = Math.min(invItem.quantity, remainingToConsume);
        invItem.quantity -= takeAmount;
        remainingToConsume -= takeAmount;
        if (invItem.quantity <= 0) {
          tempInventory.splice(i, 1);
        }
      }
    }
    if (remainingToConsume > 0) {
      sideEffects.push({ type: 'LOG', message: `A material was missing from your inventory: ${GAME_DATA.ITEMS[ingredientStack.id].name}.`, logType: 'error' });
      return { player, sideEffects };
    }
  }

  if (!recipe) {
    sideEffects.push({ type: 'LOG', message: 'You combine the materials, but they fizzle into a useless pile of dust.', logType: 'error' });
    return { player: { ...player, inventory: tempInventory }, sideEffects };
  }

  if (recipe.profession === 'smithing') {
    const playerSkill = player.professions.smithing.level;
    const successChance = calculateCraftSuccessChance(playerSkill, recipe.levelReq) / 100;
    if (Math.random() > successChance) {
      sideEffects.push({ type: 'LOG', message: `You failed to craft ${recipe.name}. The materials were lost.`, logType: 'error' });
      return { player: { ...player, inventory: tempInventory }, sideEffects };
    }
  }

  const createdItems: ItemInstance[] = [];
  for (let i = 0; i < quantity; i++) {
    createdItems.push(...createItemInstances(recipe.creates, recipe.quantity, { isUnidentified: false, plus_value: 0 }, GAME_DATA));
  }

  const newKnownRecipes = player.knownRecipes[recipe.id] ? player.knownRecipes : { ...player.knownRecipes, [recipe.id]: true };
  if (!player.knownRecipes[recipe.id]) {
    sideEffects.push({ type: 'LOG', message: `You discovered the recipe for ${recipe.name}!`, logType: 'skill' });
  }

  sideEffects.push({ type: 'LOG', message: `You crafted ${GAME_DATA.ITEMS[recipe.creates].name} x${recipe.quantity * quantity}.`, logType: 'skill' });
  sideEffects.push({ type: 'GAIN_PROFESSION_XP', professionId: recipe.profession, amount: recipe.xp * quantity } as GameSideEffect);

  const { newInventory, overflow } = mergeIntoInventory(tempInventory, createdItems, GAME_DATA);

  if (overflow.length > 0) {
    sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
  }

  return {
    player: {
      ...player,
      inventory: newInventory,
      knownRecipes: newKnownRecipes,
    },
    sideEffects,
  };
}