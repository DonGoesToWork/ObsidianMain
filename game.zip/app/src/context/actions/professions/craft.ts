import { Player, ItemInstance, Recipe, ProfessionId, GameData, GameSideEffect } from '../../../types';
import { calculateDifficultyBonus } from 'utils/gameMechanics';
import { getEquippedToolBonus, createItemInstances } from 'utils/itemUtils';
import { calculateCraftSuccessChance } from 'utils/craftingUtils';

export function craftItem(
  player: Player,
  recipe: Recipe | null,
  quantity: number,
  _tools: ItemInstance[],
  ingredients: ItemInstance[],
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];

  if (ingredients.length === 0) {
    sideEffects.push({ type: 'LOG', message: 'No ingredients provided.', logType: 'error' });
    return { player, sideEffects };
  }

  let tempInventory = [...player.inventory];
  for (const ingredient of ingredients) {
    const index = tempInventory.findIndex((invItem) => invItem.unique_id === ingredient.unique_id);
    if (index > -1) {
      tempInventory.splice(index, 1);
    } else {
      sideEffects.push({ type: 'LOG', message: 'A material was missing from your inventory.', logType: 'error' });
      return { player, sideEffects };
    }
  }

  if (!recipe) {
    sideEffects.push({ type: 'LOG', message: 'You combine the materials, but they fizzle into a useless pile of dust.', logType: 'error' });
    return { player: { ...player, inventory: tempInventory }, sideEffects };
  }

  if (recipe.profession === 'smithing') {
    const playerSkill = player.professions.smithing.level;
    const successChance = calculateCraftSuccessChance(playerSkill, recipe.levelReq) / 100;
    if (Math.random() > successChance) {
      sideEffects.push({ type: 'LOG', message: `You failed to craft ${recipe.name}. The materials were lost.`, logType: 'error' });
      return { player: { ...player, inventory: tempInventory }, sideEffects };
    }
  }

  const createdItems: ItemInstance[] = [];
  for (let i = 0; i < quantity; i++) {
    createdItems.push(...createItemInstances(recipe.creates, recipe.quantity, { isUnidentified: false, plus_value: 0 }, GAME_DATA));
  }

  const newKnownRecipes = player.knownRecipes[recipe.id] ? player.knownRecipes : { ...player.knownRecipes, [recipe.id]: true };
  if (!player.knownRecipes[recipe.id]) {
    sideEffects.push({ type: 'LOG', message: `You discovered the recipe for ${recipe.name}!`, logType: 'skill' });
  }

  sideEffects.push({ type: 'LOG', message: `You crafted ${GAME_DATA.ITEMS[recipe.creates].name} x${recipe.quantity * quantity}.`, logType: 'skill' });
  sideEffects.push({ type: 'GAIN_PROFESSION_XP', professionId: recipe.profession, amount: recipe.xp * quantity } as GameSideEffect);

  return {
    player: {
      ...player,
      inventory: [...tempInventory, ...createdItems],
      knownRecipes: newKnownRecipes,
    },
    sideEffects,
  };
}