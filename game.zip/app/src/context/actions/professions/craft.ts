import { Player, ItemInstance, Recipe, ProfessionId, GameData } from "../../../types";
import { calculateDifficultyBonus, generateRandomQuality } from "utils/gameMechanics";
import { getEquippedToolBonus, createItemInstances } from "utils/itemUtils";

export function craftItemImpl(
  recipe: Recipe,
  quantity: number,
  _tools: ItemInstance[],
  ingredients: ItemInstance[],
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: string, type: any) => void,
  gainProfessionXp: (professionId: ProfessionId, amount: number) => void,
  GAME_DATA: GameData,
) {
  setPlayer((p) => {
    if (!p) return p;

    let tempInventory = [...p.inventory];
    for (const ingredient of ingredients) {
      const index = tempInventory.findIndex((invItem) => invItem === ingredient);
      if (index > -1) tempInventory.splice(index, 1);
      else {
        logMessage("A material was missing from your inventory.", "error");
        return p;
      }
    }

    const toolBonus = getEquippedToolBonus(p, recipe.profession);
    const totalSkill = p.professions[recipe.profession].level + toolBonus;
    const difficultyBonus = calculateDifficultyBonus(totalSkill, recipe.levelReq);

    const createdItems: ItemInstance[] = [];
    for (let i = 0; i < quantity; i++) {
      const quality = generateRandomQuality(difficultyBonus);
      const newItems = createItemInstances(recipe.creates, recipe.quantity, {
        isUnidentified: false,
        quality: quality,
      }, GAME_DATA);
      createdItems.push(...newItems);
    }

    const newKnownRecipes = p.knownRecipes[recipe.id] ? p.knownRecipes : { ...p.knownRecipes, [recipe.id]: true };
    if (!p.knownRecipes[recipe.id]) logMessage(`You discovered the recipe for ${recipe.name}!`, "skill");

    logMessage(`You crafted ${GAME_DATA.ITEMS[recipe.creates].name} x${recipe.quantity * quantity}.`, "skill");
    gainProfessionXp(recipe.profession, recipe.xp * quantity);

    return {
      ...p,
      inventory: [...tempInventory, ...createdItems],
      knownRecipes: newKnownRecipes,
    };
  });
}