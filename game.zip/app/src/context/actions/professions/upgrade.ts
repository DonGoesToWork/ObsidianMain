import { Player, ItemInstance, PlayerEquipmentSlot, ItemId, GameData } from '../../../types';
import { countItems, calculateItemLevel, getItemName, getQualityGrade, ITEM_QUALITY_ORDER } from 'utils/itemUtils';
import { calculateUpgradeSuccessChance } from 'utils/craftingUtils';

export function upgradeItemImpl(
  targetItemInstance: ItemInstance,
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: string, type: any) => void,
  gainProfessionXp: (professionId: any, amount: number) => void,
  GAME_DATA: GameData
) {
  setPlayer((p) => {
    if (!p) return p;

    let itemLocation: 'inventory' | PlayerEquipmentSlot | null = null;
    let itemIndex = -1;

    itemIndex = p.inventory.findIndex((i) => i === targetItemInstance);
    if (itemIndex !== -1) {
      itemLocation = 'inventory';
    } else {
      for (const slot in p.equipment) {
        if (p.equipment[slot as PlayerEquipmentSlot] === targetItemInstance) {
          itemLocation = slot as PlayerEquipmentSlot;
          break;
        }
      }
    }
    if (!itemLocation) {
      logMessage('Target item not found.', 'error');
      return p;
    }

    const itemData = GAME_DATA.ITEMS[targetItemInstance.id];
    const quality = targetItemInstance.quality || 'Average';

    if (quality === 'One-of-a-kind' || !itemData.recipeId) {
      logMessage('This item cannot be upgraded further.', 'error');
      return p;
    }

    const grade = getQualityGrade(quality);
    const itemLevel = calculateItemLevel(targetItemInstance, GAME_DATA);
    const requiredTier = Math.min(11, Math.max(1, Math.floor(itemLevel / 10) + 1));
    const emberId = `mat_reforge_ember_t${requiredTier}` as ItemId;

    const materialCost = grade + 1;
    const goldCost = itemData.value * (grade + 1) * 5;
    const knowsRecipe = !!p.knownRecipes[itemData.recipeId];

    if (!knowsRecipe) {
      logMessage('You must know the original recipe to upgrade this item.', 'error');
      return p;
    }
    if (p.gold < goldCost || countItems(p.inventory, emberId) < materialCost) {
      logMessage('You lack the required materials to upgrade this item.', 'error');
      return p;
    }

    let finalPlayer = { ...p, gold: p.gold - goldCost };
    let embersToRemove = materialCost;
    finalPlayer.inventory = finalPlayer.inventory.filter((item) => {
      if (item.id === emberId && embersToRemove > 0) {
        embersToRemove--;
        return false;
      }
      return true;
    });

    const playerSkill = finalPlayer.professions.smithing.level;
    const successChance = calculateUpgradeSuccessChance(grade, playerSkill) / 100;

    const findOriginalItemIndex = () => {
      if (itemLocation === 'inventory') {
        return finalPlayer.inventory.findIndex((i) => i === targetItemInstance);
      }
      return -1;
    };

    if (Math.random() < successChance) {
      const nextQuality = ITEM_QUALITY_ORDER[grade + 1];
      const newItem = { ...targetItemInstance, quality: nextQuality };

      const oldMax = newItem.maxDurability || 100;
      const currentDurabilityPercent = (newItem.currentDurability ?? oldMax) / oldMax;

      const baseDurability = itemData.baseDurability || 100;
      const newQualityMultiplier = GAME_DATA.ITEM_QUALITIES[nextQuality]?.multiplier || 1.0;
      newItem.maxDurability = Math.round(baseDurability * newQualityMultiplier);
      newItem.currentDurability = Math.round(newItem.maxDurability * currentDurabilityPercent);

      if (itemLocation === 'inventory') {
        const originalIndex = findOriginalItemIndex();
        if (originalIndex > -1) finalPlayer.inventory[originalIndex] = newItem;
      } else {
        finalPlayer.equipment = {
          ...finalPlayer.equipment,
          [itemLocation]: newItem,
        };
      }
      logMessage(`Upgrade successful! Your ${getItemName(targetItemInstance, GAME_DATA)} is now ${nextQuality}.`, 'skill');
      gainProfessionXp('smithing', itemData.itemLevel * 5 * (grade + 1));
    } else {
      if (itemLocation === 'inventory') {
        const originalIndex = findOriginalItemIndex();
        if (originalIndex > -1) finalPlayer.inventory.splice(originalIndex, 1);
      } else {
        finalPlayer.equipment = {
          ...finalPlayer.equipment,
          [itemLocation]: null,
        };
      }
      logMessage(`Upgrade failed! Your ${getItemName(targetItemInstance, GAME_DATA)} has been destroyed.`, 'error');
    }

    return finalPlayer;
  });
}