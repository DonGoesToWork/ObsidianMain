import { calculateEnchantSuccessChance } from 'utils/craftingUtils';
import { calculateItemLevel, calculateItemTier, countItems, getItemName } from 'utils/itemUtils';
import { GameData, GameSideEffect, ItemInstance, Player, PlayerEquipmentSlot } from '../../../types';

export function upgradeItem(player: Player, targetItemInstance: ItemInstance, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  let itemLocation: 'inventory' | PlayerEquipmentSlot | null = null;
  const sideEffects: GameSideEffect[] = [];

  const itemInInventory = player.inventory.find((i) => i.unique_id === targetItemInstance.unique_id);
  if (itemInInventory) {
    itemLocation = 'inventory';
  } else {
    for (const slot in player.equipment) {
      if (player.equipment[slot as PlayerEquipmentSlot]?.unique_id === targetItemInstance.unique_id) {
        itemLocation = slot as PlayerEquipmentSlot;
        break;
      }
    }
  }

  if (!itemLocation) {
    sideEffects.push({ type: 'LOG', message: 'Target item not found.', logType: 'error' });
    return { player, sideEffects };
  }

  const itemData = GAME_DATA.ITEMS[targetItemInstance.id];
  const currentPlus = targetItemInstance.plus_value || 0;
  const itemLevel = calculateItemLevel(targetItemInstance, GAME_DATA);
  const itemTier = calculateItemTier(itemLevel);

  if (!itemData.recipeId) {
    sideEffects.push({ type: 'LOG', message: 'This item cannot be upgraded.', logType: 'error' });
    return { player, sideEffects };
  }
  if (currentPlus >= itemTier) {
    sideEffects.push({ type: 'LOG', message: 'This item cannot be upgraded further.', logType: 'error' });
    return { player, sideEffects };
  }

  const emberId = `mat_reforge_ember_t${itemTier}`;
  const materialCost = itemTier;
  const knowsRecipe = !!player.knownRecipes[itemData.recipeId];

  if (!knowsRecipe) {
    sideEffects.push({ type: 'LOG', message: 'You must know the original recipe to upgrade this item.', logType: 'error' });
    return { player, sideEffects };
  }
  if (countItems(player.inventory, emberId) < materialCost) {
    sideEffects.push({ type: 'LOG', message: 'You lack the required materials to upgrade this item.', logType: 'error' });
    return { player, sideEffects };
  }

  let finalPlayer = { ...player };
  let embersToRemove = materialCost;
  const newInventory: ItemInstance[] = [];
  for (const item of finalPlayer.inventory) {
    const newItem = { ...item };
    if (newItem.id === emberId && embersToRemove > 0) {
      const amountToRemove = Math.min(embersToRemove, newItem.quantity);
      newItem.quantity -= amountToRemove;
      embersToRemove -= amountToRemove;
    }
    if (newItem.quantity > 0) {
      newInventory.push(newItem);
    }
  }
  finalPlayer.inventory = newInventory;

  const playerSkill = finalPlayer.professions.smithing.level;
  const targetPlusValue = currentPlus + 1;
  const baseDr = (itemTier - 1) * 10 + 5;
  const finalDr = baseDr + Math.max(0, currentPlus);
  const successChance = calculateEnchantSuccessChance(playerSkill, finalDr) / 100;

  const findOriginalItemIndex = () => {
    if (itemLocation === 'inventory') {
      return finalPlayer.inventory.findIndex((i) => i.unique_id === targetItemInstance.unique_id);
    }
    return -1;
  };

  if (Math.random() < successChance) {
    const newItem = { ...targetItemInstance, plus_value: targetPlusValue };
    if (itemLocation === 'inventory') {
      const originalIndex = findOriginalItemIndex();
      if (originalIndex > -1) finalPlayer.inventory[originalIndex] = newItem;
    } else {
      finalPlayer.equipment = {
        ...finalPlayer.equipment,
        [itemLocation]: newItem,
      };
    }
    sideEffects.push({
      type: 'LOG',
      message: `Upgrade successful! Your ${getItemName(targetItemInstance, GAME_DATA)} is now ${getItemName(newItem, GAME_DATA)}.`,
      logType: 'skill',
    });
    sideEffects.push({
      type: 'GAIN_PROFESSION_XP',
      professionId: 'smithing',
      amount: itemData.itemLevel * 5 * (Math.abs(currentPlus) + 1),
    } as GameSideEffect);
  } else {
    if (itemLocation === 'inventory') {
      const originalIndex = findOriginalItemIndex();
      if (originalIndex > -1) finalPlayer.inventory.splice(originalIndex, 1);
    } else {
      finalPlayer.equipment = {
        ...finalPlayer.equipment,
        [itemLocation]: null,
      };
    }
    sideEffects.push({
      type: 'LOG',
      message: `Upgrade failed! Your ${getItemName(targetItemInstance, GAME_DATA)} has been destroyed.`,
      logType: 'error',
    });
  }

  return { player: finalPlayer, sideEffects };
}