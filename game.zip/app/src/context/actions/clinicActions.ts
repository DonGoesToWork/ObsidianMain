import { GameData, GameSideEffect, ItemInstance, LogType, Loggable, Mercenary, Player, PlayerContextType } from '../../types';
import { calculateCharacterStats, calculateXpToNextLevel } from '../../services/statService';

import { deepCloneWithInfinity } from 'utils/mathUtils';
import { isCombatantDefeated } from 'utils/combatUtils';
import { reviveCharacter } from 'utils/playerUtils';

const HEAL_BROKEN_LIMB_COST = 10000;
const REVIVE_ALLY_COST = 50000;

export function healBrokenLimb(player: Player, targetId: string, limbId: string): { player: Player; sideEffects: GameSideEffect[] } | null {
  const sideEffects: GameSideEffect[] = [];
  if (player.gold < HEAL_BROKEN_LIMB_COST) {
    sideEffects.push({ type: 'LOG', message: 'You cannot afford this service.', logType: 'error' });
    return { player, sideEffects };
  }

  const isPlayerTarget = targetId === 'player';
  const target = isPlayerTarget ? player : player.party.find((m: Mercenary) => m.id === targetId);
  if (!target) {
    sideEffects.push({ type: 'LOG', message: 'Could not find the target.', logType: 'error' });
    return { player, sideEffects };
  }
  const limb = target.body[limbId];
  if (!limb || limb.state !== 'Destroyed') {
    sideEffects.push({ type: 'LOG', message: 'This limb does not require this service.', logType: 'info' });
    return { player, sideEffects };
  }

  sideEffects.push({
    type: 'LOG',
    message: {
      floatingText: `Healed ${limb.displayName}!`,
      detailedText: `The physician heals ${target.name}'s ${limb.displayName} for ${HEAL_BROKEN_LIMB_COST.toLocaleString()} gold.`,
    },
    logType: 'heal',
  });

  if (isPlayerTarget) {
    return {
      player: {
        ...player,
        gold: player.gold - HEAL_BROKEN_LIMB_COST,
        body: {
          ...player.body,
          [limbId]: { ...limb, state: 'Healthy', currentHp: limb.maxHp, statusEffects: [] },
        },
      },
      sideEffects,
    };
  } else {
    return {
      player: {
        ...player,
        gold: player.gold - HEAL_BROKEN_LIMB_COST,
        party: player.party.map((m) =>
          m.id === targetId ? { ...m, body: { ...m.body, [limbId]: { ...limb, state: 'Healthy', currentHp: limb.maxHp, statusEffects: [] } } } : m
        ),
      },
      sideEffects,
    };
  }
}

export function reviveDownedAlly(player: Player, mercenaryId: string, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  const sideEffects: GameSideEffect[] = [];
  if (player.gold < REVIVE_ALLY_COST) {
    sideEffects.push({ type: 'LOG', message: 'You cannot afford this service.', logType: 'error' });
    return { player, sideEffects };
  }

  const mercIndex = player.party.findIndex((m: Mercenary) => m.id === mercenaryId);
  if (mercIndex === -1) {
    sideEffects.push({ type: 'LOG', message: 'Could not find the mercenary.', logType: 'error' });
    return { player, sideEffects };
  }

  const targetMerc = player.party[mercIndex];
  if (!isCombatantDefeated(targetMerc as any)) {
    sideEffects.push({ type: 'LOG', message: `${targetMerc.name} is not dead.`, logType: 'info' });
    return { player, sideEffects };
  }

  sideEffects.push({
    type: 'LOG',
    message: {
      floatingText: `${targetMerc.name} Revived!`,
      detailedText: `The physician revives ${targetMerc.name} for ${REVIVE_ALLY_COST.toLocaleString()} gold.`,
    },
    logType: 'heal',
  });

  const revivedMerc = reviveCharacter(targetMerc, 100, GAME_DATA) as Mercenary;
  const newParty = [...player.party];
  newParty[mercIndex] = revivedMerc;

  return { player: { ...player, party: newParty, gold: player.gold - REVIVE_ALLY_COST }, sideEffects };
}

export function reviveFallenAlly(player: Player, corpseItem: ItemInstance, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  const sideEffects: GameSideEffect[] = [];
  if (player.gold < REVIVE_ALLY_COST) {
    sideEffects.push({ type: 'LOG', message: 'You cannot afford this service.', logType: 'error' });
    return { player, sideEffects };
  }
  if (player.party.length >= 3) {
    sideEffects.push({ type: 'LOG', message: 'Your party is full.', logType: 'error' });
    return { player, sideEffects };
  }
  const deceasedMercData = corpseItem.deceasedCharacter;
  if (!deceasedMercData) {
    sideEffects.push({ type: 'LOG', message: 'This is not the corpse of a former ally.', logType: 'error' });
    return { player, sideEffects };
  }

  const archetype = GAME_DATA.MERCENARIES[deceasedMercData.mercenaryId];
  if (!archetype) {
    sideEffects.push({ type: 'LOG', message: 'Could not find mercenary archetype data.', logType: 'error' });
    return { player, sideEffects };
  }

  const rebuiltMerc: Mercenary = {
    id: deceasedMercData.id,
    mercenaryId: deceasedMercData.mercenaryId,
    name: deceasedMercData.name,
    race: archetype.race,
    class: archetype.class,
    level: deceasedMercData.level,
    xp: deceasedMercData.xp,
    xpToNextLevel: calculateXpToNextLevel(deceasedMercData.level),
    skills: deceasedMercData.skills,
    baseStats: { ...GAME_DATA.CLASSES[archetype.class].baseStats },
    totalStats: {} as any,
    equipment: {
      head: null,
      chest: null,
      right_armlet: null,
      left_armlet: null,
      right_legging: null,
      left_legging: null,
      right_foot: null,
      left_foot: null,
      weapon: null,
      shield: null,
      amulet1: null,
      amulet2: null,
      left_ring: null,
      right_ring: null,
      groin: null,
      left_glove: null,
      right_glove: null,
    },
    inventory: [],
    body: {},
    statusEffects: [],
    mp: 0,
    maxMp: 0,
    sp: 0,
    maxSp: 0,
    baseWeight: GAME_DATA.RACES[archetype.race].baseWeight,
    currentWeight: 0,
    maxCarryWeight: 0,
    initialCost: archetype.baseCost * deceasedMercData.level,
    dailyCost: archetype.baseDailyCost * deceasedMercData.level,
    happiness: 25,
    gold: 0,
    fleeHealthThreshold: archetype.fleeThreshold,
    vitals: {
      hunger: { current: 100, max: 100 },
      thirst: { current: 100, max: 100 },
      alertness: { current: 100, max: 100 },
      courage: { current: 100, max: 100 },
    },
  };

  rebuiltMerc.baseStats.strength = 10;
  rebuiltMerc.baseStats.constitution = 10;
  rebuiltMerc.baseStats.intelligence = 10;
  rebuiltMerc.baseStats.dexterity = 10;

  for (let i = 1; i < rebuiltMerc.level; i++) {
    rebuiltMerc.baseStats.strength += archetype.statGrowth.strength;
    rebuiltMerc.baseStats.constitution += archetype.statGrowth.constitution;
    rebuiltMerc.baseStats.intelligence += archetype.statGrowth.intelligence;
    rebuiltMerc.baseStats.dexterity += archetype.statGrowth.dexterity;
  }

  const statsRefreshedMerc = calculateCharacterStats(rebuiltMerc, GAME_DATA);
  if (!statsRefreshedMerc) {
    console.error('Failed to recalculate stats for deceased mercenary:', deceasedMercData);
    sideEffects.push({ type: 'LOG', message: 'An error occurred during revival preparations.', logType: 'error' });
    return { player, sideEffects };
  }

  const revivedMerc = reviveCharacter(statsRefreshedMerc, 25, GAME_DATA) as Mercenary;
  sideEffects.push({
    type: 'LOG',
    message: {
      floatingText: `${revivedMerc.name} Revived!`,
      detailedText: `The physician brings ${
        revivedMerc.name
      } back from the dead for ${REVIVE_ALLY_COST.toLocaleString()} gold. Their earthly possessions are lost in the process.`,
    },
    logType: 'heal',
  });

  return {
    player: {
      ...player,
      gold: player.gold - REVIVE_ALLY_COST,
      party: [...player.party, revivedMerc],
      inventory: player.inventory.filter((i) => i.unique_id !== corpseItem.unique_id),
    },
    sideEffects,
  };
}
