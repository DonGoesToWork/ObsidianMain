import {
  ItemInstance,
  LogType,
  Loggable,
  Mercenary,
  Player,
  PlayerContextType,
  GameData,
} from "../../types";

import { isCombatantDefeated } from "utils/combatUtils";
import { reviveCharacter } from "utils/playerUtils";

type SetPlayerFn = PlayerContextType["setPlayer"];
type LogMessageFn = (message: Loggable, type: LogType) => void;

const HEAL_BROKEN_LIMB_COST = 10000;
const REVIVE_ALLY_COST = 50000;

export function healBrokenLimbImpl(
  targetId: string,
  limbId: string,
  setPlayer: SetPlayerFn,
  logMessage: LogMessageFn,
) {
  setPlayer((p: Player | null) => {
    if (!p) return p;
    if (p.gold < HEAL_BROKEN_LIMB_COST) {
      logMessage("You cannot afford this service.", "error");
      return p;
    }

    const isPlayerTarget = targetId === "player";
    const target = isPlayerTarget
      ? p
      : p.party.find((m: Mercenary) => m.id === targetId);
    if (!target) {
      logMessage("Could not find the target.", "error");
      return p;
    }
    const limb = target.body[limbId];
    if (!limb || limb.state !== "Destroyed") {
      logMessage("This limb does not require this service.", "info");
      return p;
    }

    logMessage(
      {
        floatingText: `Healed ${limb.displayName}!`,
        detailedText: `The physician heals ${
          target.name
        }'s ${limb.displayName} for ${HEAL_BROKEN_LIMB_COST.toLocaleString()} gold.`,
      },
      "heal",
    );

    if (isPlayerTarget) {
      return {
        ...p,
        gold: p.gold - HEAL_BROKEN_LIMB_COST,
        body: {
          ...p.body,
          [limbId]: {
            ...limb,
            state: "Healthy",
            currentHp: limb.maxHp,
            statusEffects: [],
          },
        },
      };
    } else {
      return {
        ...p,
        gold: p.gold - HEAL_BROKEN_LIMB_COST,
        party: p.party.map((m) =>
          m.id === targetId
            ? {
                ...m,
                body: {
                  ...m.body,
                  [limbId]: {
                    ...limb,
                    state: "Healthy",
                    currentHp: limb.maxHp,
                    statusEffects: [],
                  },
                },
              }
            : m,
        ),
      };
    }
  });
}

export function reviveDownedAllyImpl(
  mercenaryId: string,
  setPlayer: SetPlayerFn,
  logMessage: LogMessageFn,
) {
  setPlayer((p: Player | null) => {
    if (!p) return p;
    if (p.gold < REVIVE_ALLY_COST) {
      logMessage("You cannot afford this service.", "error");
      return p;
    }

    const mercIndex = p.party.findIndex((m: Mercenary) => m.id === mercenaryId);
    if (mercIndex === -1) {
      logMessage("Could not find the mercenary.", "error");
      return p;
    }

    const targetMerc = p.party[mercIndex];
    if (!isCombatantDefeated(targetMerc as any)) {
      logMessage(`${targetMerc.name} is not dead.`, "info");
      return p;
    }

    logMessage(
      {
        floatingText: `${targetMerc.name} Revived!`,
        detailedText: `The physician revives ${
          targetMerc.name
        } for ${REVIVE_ALLY_COST.toLocaleString()} gold.`,
      },
      "heal",
    );

    const revivedMerc = { ...targetMerc };
    const newBody = { ...revivedMerc.body };
    Object.keys(newBody).forEach((limbId) => {
      newBody[limbId] = {
        ...newBody[limbId],
        state: "Healthy",
        currentHp: newBody[limbId].maxHp,
        statusEffects: [],
      };
    });
    revivedMerc.body = newBody;
    revivedMerc.statusEffects = [];
    revivedMerc.vitals.hunger.current = revivedMerc.vitals.hunger.max;
    revivedMerc.vitals.thirst.current = revivedMerc.vitals.thirst.max;

    const newParty = [...p.party];
    newParty[mercIndex] = revivedMerc;

    return { ...p, party: newParty, gold: p.gold - REVIVE_ALLY_COST };
  });
}

export function reviveFallenAllyImpl(
  corpseItem: ItemInstance,
  setPlayer: SetPlayerFn,
  logMessage: LogMessageFn,
  GAME_DATA: GameData,
) {
  setPlayer((p: Player | null) => {
    if (!p) return p;
    if (p.gold < REVIVE_ALLY_COST) {
      logMessage("You cannot afford this service.", "error");
      return p;
    }
    if (p.party.length >= 3) {
      logMessage("Your party is full.", "error");
      return p;
    }
    const mercToRevive = corpseItem.deceasedCharacter;
    if (!mercToRevive) {
      logMessage("This is not the corpse of a former ally.", "error");
      return p;
    }

    // Revive character
    const revivedMerc = reviveCharacter(mercToRevive, 25, GAME_DATA) as Mercenary;

    logMessage(
      {
        floatingText: `${revivedMerc.name} Revived!`,
        detailedText: `The physician brings ${
          revivedMerc.name
        } back from the dead for ${REVIVE_ALLY_COST.toLocaleString()} gold. Their earthly possessions are lost in the process.`,
      },
      "heal",
    );

    return {
      ...p,
      gold: p.gold - REVIVE_ALLY_COST,
      party: [...p.party, revivedMerc],
      inventory: p.inventory.filter(
        (i) => i.unique_id !== corpseItem.unique_id,
      ),
    };
  });
}