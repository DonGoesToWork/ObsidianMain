import {
  Player,
  ClassId,
  RaceId,
  GameState,
  GameLocation,
  ProfessionId,
  PlayerContextType,
  WorldContextType,
  UIContextType,
  Mercenary,
  LogContextType,
  GameData,
} from "../../types";
import {
  calculateCharacterStats,
  calculateXpToNextLevel,
} from "../../services/statService";
import { createLocationFromZone } from "utils/locationUtils";
import { createItemInstances } from "utils/itemUtils";
import { applyFullHealLogic } from "utils/playerUtils";

export function createPlayerImpl(
  name: string,
  race: RaceId,
  pClass: ClassId,
  setPlayer: (player: Player | null) => void,
  changeGameState: (gameState: GameState) => void,
  logMessage: (message: string, type: any) => void,
  setCurrentLocation: (location: GameLocation | null) => void,
  setGeneratedZones: (zones: Record<string, any>) => void,
  GAME_DATA: GameData,
) {
  const classData = GAME_DATA.CLASSES[pClass];
  const raceData = GAME_DATA.RACES[race];

  const ALL_PROFESSIONS: ProfessionId[] = [
    "smithing",
    "alchemy",
    "jewelcrafting",
    "leatherworking",
    "mining",
    "foraging",
    "appraisal",
    "enchanting",
    "skinning",
    "woodcutting",
    "tailoring",
  ];

  const westhavenZoneData = GAME_DATA.ZONES["zone0"];
  const westhavenLocation = createLocationFromZone("zone0", westhavenZoneData);

  let newPlayer: Omit<Player, "totalStats"> = {
    name,
    class: pClass,
    race,
    level: 1,
    xp: 0,
    xpToNextLevel: calculateXpToNextLevel(1),
    perkPoints: 1 + (raceData.bonus.perkPoints || 0),
    attributePoints: raceData.bonus.attributePoints || 0,
    gold: 50,
    lastAction: null,
    baseStats: {
      strength:
        classData.baseStats.strength + (raceData.bonus.stats?.strength || 0),
      constitution:
        classData.baseStats.constitution +
        (raceData.bonus.stats?.constitution || 0),
      intelligence:
        classData.baseStats.intelligence +
        (raceData.bonus.stats?.intelligence || 0),
      dexterity:
        classData.baseStats.dexterity + (raceData.bonus.stats?.dexterity || 0),
    },
    body: {},
    vitals: {
      hunger: { current: 100, max: 100 },
      thirst: { current: 100, max: 100 },
      alertness: { current: 100, max: 100 },
      courage: { current: 100, max: 100 },
    },
    equipment: {
      head: null,
      chest: null,
      legs: null,
      weapon: null,
      shield: null,
      amulet: null,
      ring1: null,
      ring2: null,
    },
    inventory: [],
    bank: [],
    guildBank: [],
    skills: {},
    statusEffects: [],
    quests: { active: {}, completed: {} },
    knownRecipes: {},
    favoriteAbilities: [],
    professions: Object.fromEntries(
      ALL_PROFESSIONS.map((id) => [
        id,
        { level: 1, xp: 0, xpToNextLevel: 100 },
      ]),
    ) as Player["professions"],
    reputation: { haven_guard: { points: 0, rankIndex: 0 } },
    dailyQuestsCompleted: {},
    pet: null,
    guild: null,
    location: westhavenLocation,
    mp: 0,
    maxMp: 0,
    sp: 0,
    maxSp: 0,
    baseWeight: raceData.baseWeight,
    currentWeight: 0,
    maxWeight: 0,
    party: [],
    lastPayday: new Date().getTime(),
    mercenaryGuildData: { available: [], lastRefreshed: 0 },
    shopInventories: {},
    locationStates: {},
  };
  if (raceData.bonus.professions) {
    for (const prof in raceData.bonus.professions) {
      newPlayer.professions[prof as ProfessionId].level =
        raceData.bonus.professions[
          prof as keyof typeof raceData.bonus.professions
        ]!;
    }
  }
  classData.startEquip.forEach((itemId) => {
    newPlayer.inventory.push(...createItemInstances(itemId, 1, { isUnidentified: false, quality: "Average" }, GAME_DATA));
  });
  classData.startSkills.forEach((abilityId) => {
    if (newPlayer.skills) newPlayer.skills[abilityId] = { rank: 1 };
  });

  const calculatedPlayer = calculateCharacterStats(newPlayer as Player, GAME_DATA);
  if (calculatedPlayer) {
    calculatedPlayer.mp = calculatedPlayer.maxMp;
    calculatedPlayer.sp = calculatedPlayer.maxSp;
    setPlayer(calculatedPlayer);
    changeGameState("town");
    setCurrentLocation(westhavenLocation);
    setGeneratedZones({});
    logMessage(
      `Welcome to ${westhavenLocation.name}, ${calculatedPlayer.name}! Your adventure begins.`,
      "quest",
    );
    logMessage(
      `A path into the Whispering Forest (Lvl 1) has been discovered nearby.`,
      "quest",
    );
  }
}

interface LifecycleActionContext {
  setPlayer: PlayerContextType["setPlayer"];
  logMessage: LogContextType["logMessage"];
  travelTo: WorldContextType["travelTo"];
  setActiveModal: UIContextType["setActiveModal"];
  GAME_DATA: GameData;
}

export function continueFromDeathImpl(context: LifecycleActionContext, payload: {}) {
  const { setPlayer, logMessage, travelTo, setActiveModal, GAME_DATA } = context;
  setPlayer((p) => {
    if (!p) return p;
    let revivedPlayer = applyFullHealLogic(p, GAME_DATA) as Player;
    revivedPlayer.party = revivedPlayer.party.map((merc) => applyFullHealLogic(merc, GAME_DATA) as Mercenary);
    return revivedPlayer;
  });
  logMessage("You revive in town, feeling shaken but whole.", "info");
  travelTo("zone0");
  setActiveModal(null);
}