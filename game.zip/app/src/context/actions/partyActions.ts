import { Player, Mercenary, ItemInstance, LogType, Loggable, GameData } from "../../types";
import { calculateXpToNextLevel, calculateCharacterStats } from "../../services/statService";
import { getItemName } from "utils/itemUtils";
import { generateMercenary } from "../../utils/mercenaryFactory";

type SetPlayerFn = (update: React.SetStateAction<Player | null>) => void;
type LogMessageFn = (message: Loggable, type: LogType) => void;

export function refreshMercenaryGuildImpl(setPlayer: SetPlayerFn, gameTime: Date, GAME_DATA: GameData) {
  setPlayer((p) => {
    if (!p) return p;

    const mercData = p.mercenaryGuildData || {
      available: [],
      lastRefreshed: 0,
    };

    const now = gameTime.getTime();
    const lastRefreshed = mercData.lastRefreshed;
    const oneDay = 24 * 60 * 60 * 1000;

    const needsRefresh = now - lastRefreshed >= oneDay || mercData.available.length === 0;

    if (!needsRefresh) {
      return p;
    }

    const newMercs = Array.from({ length: 3 }, () => generateMercenary(p.level, GAME_DATA));

    return {
      ...p,
      mercenaryGuildData: {
        available: newMercs,
        lastRefreshed: now,
      },
    };
  });
}

export function hireMercenaryImpl(mercenary: Mercenary, setPlayer: SetPlayerFn, logMessage: LogMessageFn) {
  setPlayer((p) => {
    if (!p) return p;
    if (p.party.length >= 3) {
      logMessage("Your party is full.", "error");
      return p;
    }
    if (p.gold < mercenary.initialCost) {
      logMessage("You cannot afford the hiring fee.", "error");
      return p;
    }

    const newParty = [...p.party, mercenary];
    const newGold = p.gold - mercenary.initialCost;

    const newMercenaryGuildData = {
      ...p.mercenaryGuildData,
      available: p.mercenaryGuildData.available.filter((m) => m.id !== mercenary.id),
    };

    logMessage(`${mercenary.name} has joined your party!`, "info");

    return {
      ...p,
      gold: newGold,
      party: newParty,
      mercenaryGuildData: newMercenaryGuildData,
    };
  });
}

export function fireMercenaryImpl(mercenaryId: string, setPlayer: SetPlayerFn, logMessage: LogMessageFn) {
  setPlayer((p) => {
    if (!p) return p;
    const mercToFire = p.party.find((m) => m.id === mercenaryId);
    if (!mercToFire) return p;

    const newParty = p.party.filter((m) => m.id !== mercenaryId);
    logMessage(`${mercToFire.name} has left your party.`, "info");
    return { ...p, party: newParty };
  });
}

export function giftItemToMercenaryImpl(mercenaryId: string, item: ItemInstance, setPlayer: SetPlayerFn, logMessage: LogMessageFn, GAME_DATA: GameData) {
  setPlayer((p) => {
    if (!p) return p;

    const itemIndex = p.inventory.findIndex((i) => i === item);
    if (itemIndex < 0) return p;

    const itemData = GAME_DATA.ITEMS[item.id];
    if (!itemData) return p;

    let newInventory = [...p.inventory];
    newInventory.splice(itemIndex, 1);

    const newParty = p.party.map((merc) => {
      if (merc.id === mercenaryId) {
        const newMerc: Mercenary = {
          ...merc,
          inventory: [...merc.inventory, item],
        };
        const happinessGain = Math.max(1, Math.floor(itemData.value / 10));
        newMerc.happiness = Math.min(100, newMerc.happiness + happinessGain);
        logMessage(`You gifted ${getItemName(item)} to ${merc.name}. Their happiness increased by ${happinessGain}.`, "info");
        return newMerc;
      }
      return merc;
    });

    return { ...p, inventory: newInventory, party: newParty };
  });
}

export function gainMercenaryXpImpl(mercenaryId: string, amount: number, setPlayer: SetPlayerFn, logMessage: LogMessageFn, GAME_DATA: GameData) {
  if (amount <= 0) return;
  setPlayer((p) => {
    if (!p) return p;

    const partyCopy = [...p.party];
    const mercIndex = partyCopy.findIndex((m) => m.id === mercenaryId);

    if (mercIndex === -1) {
      return p;
    }

    let mercToUpdate = { ...partyCopy[mercIndex] };
    mercToUpdate.xp += amount;

    logMessage(`${mercToUpdate.name} gains ${amount} XP.`, "xp");

    while (mercToUpdate.xp >= mercToUpdate.xpToNextLevel) {
      mercToUpdate.xp -= mercToUpdate.xpToNextLevel;
      mercToUpdate.level++;
      mercToUpdate.xpToNextLevel = calculateXpToNextLevel(mercToUpdate.level);
      logMessage(`${mercToUpdate.name} reached level ${mercToUpdate.level}!`, "quest");

      const archetype = GAME_DATA.MERCENARIES[mercToUpdate.mercenaryId];
      if (archetype) {
        mercToUpdate.baseStats.strength += archetype.statGrowth.strength;
        mercToUpdate.baseStats.constitution += archetype.statGrowth.constitution;
        mercToUpdate.baseStats.intelligence += archetype.statGrowth.intelligence;
        mercToUpdate.baseStats.dexterity += archetype.statGrowth.dexterity;
      }

      const calculatedMerc = calculateCharacterStats(mercToUpdate, GAME_DATA);
      if (calculatedMerc) {
        mercToUpdate = calculatedMerc;
        mercToUpdate.mp = mercToUpdate.maxMp;
        mercToUpdate.sp = mercToUpdate.maxSp;
        Object.values(mercToUpdate.body).forEach((limb) => {
          limb.currentHp = limb.maxHp;
        });
      }
    }

    partyCopy[mercIndex] = mercToUpdate;

    return { ...p, party: partyCopy };
  });
}