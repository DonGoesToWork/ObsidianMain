import { calculateItemValue, getItemName, mergeIntoInventory } from 'utils/itemUtils';
import { calculateCharacterStats, calculateXpToNextLevel } from '../../services/statService';
import { GameData, GameSideEffect, ItemInstance, LocationState, Mercenary, Player } from '../../types';
import { generateMercenary } from '../../utils/mercenaryFactory';

export function refreshMercenaryGuildAction(
  currentGuildData: LocationState['mercenaryGuild'],
  locationLevel: number,
  gameTime: Date,
  GAME_DATA: GameData
): LocationState['mercenaryGuild'] {
  const mercData = currentGuildData || {
    available: [],
    lastRefreshed: 0,
  };

  const isFirstStock = mercData.lastRefreshed === 0;

  const lastRefreshDate = new Date(mercData.lastRefreshed);
  const nextRestockTime = new Date(lastRefreshDate);
  nextRestockTime.setHours(6, 0, 0, 0);

  // If the last refresh was on or after 6 AM that day, the next restock is 6 AM the *following* day.
  if (lastRefreshDate.getTime() >= nextRestockTime.getTime()) {
    nextRestockTime.setDate(nextRestockTime.getDate() + 1);
  }

  const needsRefresh = gameTime.getTime() >= nextRestockTime.getTime();

  console.log(`Mercenary Guild Refresh Check -> First Stock: ${isFirstStock}, Needs Refresh: ${needsRefresh}. Last refreshed: ${lastRefreshDate.toLocaleString()}, Next restock at: ${nextRestockTime.toLocaleString()}`);

  if (!needsRefresh && !isFirstStock) {
    console.log('Mercenary Guild Refresh -> No refresh needed.');
    return mercData;
  }

  console.log(`Mercenary Guild Refresh -> Refreshing members. Reason: ${isFirstStock ? 'First Stock' : 'Time to Refresh'}`);

  const newMercs = Array.from({ length: 3 }, () => generateMercenary(locationLevel, GAME_DATA));

  return {
    available: newMercs,
    lastRefreshed: gameTime.getTime(),
  };
}

export function hireMercenaryAction(
  player: Player,
  mercenary: Mercenary,
  currentGuildData: LocationState['mercenaryGuild']
): { updatedPlayer: Player; updatedGuildData: LocationState['mercenaryGuild']; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];
  if (player.party.length >= 3) {
    sideEffects.push({ type: 'LOG', message: 'Your party is full.', logType: 'error' });
    return { updatedPlayer: player, updatedGuildData: currentGuildData, sideEffects };
  }
  if (player.gold < mercenary.initialCost) {
    sideEffects.push({ type: 'LOG', message: 'You cannot afford the hiring fee.', logType: 'error' });
    return { updatedPlayer: player, updatedGuildData: currentGuildData, sideEffects };
  }

  const newParty = [...player.party, mercenary];
  const newGold = player.gold - mercenary.initialCost;

  const newMercenaryGuildData: LocationState['mercenaryGuild'] = {
    ...(currentGuildData || { available: [], lastRefreshed: 0 }),
    available: (currentGuildData?.available || []).filter((m) => m.id !== mercenary.id),
  };

  sideEffects.push({ type: 'LOG', message: `${mercenary.name} has joined your party!`, logType: 'info' });

  return {
    updatedPlayer: {
      ...player,
      gold: newGold,
      party: newParty,
    },
    updatedGuildData: newMercenaryGuildData,
    sideEffects,
  };
}

export function fireMercenary(player: Player, mercenaryId: string): { player: Player; sideEffects: GameSideEffect[] } | null {
  const mercToFire = player.party.find((m) => m.id === mercenaryId);
  if (!mercToFire) return null;

  const newParty = player.party.filter((m) => m.id !== mercenaryId);
  const sideEffects: GameSideEffect[] = [{ type: 'LOG', message: `${mercToFire.name} has left your party.`, logType: 'info' }];

  return { player: { ...player, party: newParty }, sideEffects };
}

export function giftItemToMercenary(player: Player, mercenaryId: string, item: ItemInstance, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  const itemIndex = player.inventory.findIndex((i) => i.unique_id === item.unique_id);
  if (itemIndex < 0) return null;

  const playerInventory = [...player.inventory];
  const stackInPlayerInv = { ...playerInventory[itemIndex] };

  const giftedItem: ItemInstance = { ...stackInPlayerInv, quantity: 1 };

  if (stackInPlayerInv.quantity > 1) {
    playerInventory[itemIndex] = { ...stackInPlayerInv, quantity: stackInPlayerInv.quantity - 1 };
  } else {
    playerInventory.splice(itemIndex, 1);
  }

  const sideEffects: GameSideEffect[] = [];

  const newParty = player.party.map((merc) => {
    if (merc.id === mercenaryId) {
      const { newInventory: newMercInventory, overflow } = mergeIntoInventory(merc.inventory, [giftedItem], GAME_DATA);

      if (overflow.length > 0) {
        sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
        sideEffects.push({
          type: 'LOG',
          message: `${merc.name}'s inventory was full, item dropped on the ground.`,
          logType: 'error',
        });
      }

      const newMerc: Mercenary = {
        ...merc,
        inventory: newMercInventory,
      };

      const happinessGain = Math.max(1, Math.floor(calculateItemValue(giftedItem, GAME_DATA) / 10));
      newMerc.happiness = Math.min(100, newMerc.happiness + happinessGain);
      sideEffects.push({
        type: 'LOG',
        message: `You gifted ${getItemName(item, GAME_DATA)} to ${merc.name}. Their happiness increased by ${happinessGain}.`,
        logType: 'info',
      });
      return newMerc;
    }
    return merc;
  });

  return { player: { ...player, inventory: playerInventory, party: newParty }, sideEffects };
}

export function gainMercenaryXp(player: Player, mercenaryId: string, amount: number, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  if (amount <= 0) return null;

  const partyCopy = [...player.party];
  const mercIndex = partyCopy.findIndex((m) => m.id === mercenaryId);

  if (mercIndex === -1) return null;

  let mercToUpdate = { ...partyCopy[mercIndex] };
  mercToUpdate.xp += amount;

  const sideEffects: GameSideEffect[] = [{ type: 'LOG', message: `${mercToUpdate.name} gains ${amount} XP.`, logType: 'xp' }];

  while (mercToUpdate.xp >= mercToUpdate.xpToNextLevel) {
    mercToUpdate.xp -= mercToUpdate.xpToNextLevel;
    mercToUpdate.level++;
    mercToUpdate.xpToNextLevel = calculateXpToNextLevel(mercToUpdate.level);
    sideEffects.push({ type: 'LOG', message: `${mercToUpdate.name} reached level ${mercToUpdate.level}!`, logType: 'quest' });

    const archetype = GAME_DATA.MERCENARIES[mercToUpdate.mercenaryId];
    if (archetype) {
      mercToUpdate.baseStats.strength += archetype.statGrowth.strength;
      mercToUpdate.baseStats.constitution += archetype.statGrowth.constitution;
      mercToUpdate.baseStats.intelligence += archetype.statGrowth.intelligence;
      mercToUpdate.baseStats.dexterity += archetype.statGrowth.dexterity;
    }

    const calculatedMerc = calculateCharacterStats(mercToUpdate, GAME_DATA);
    if (calculatedMerc) {
      mercToUpdate = calculatedMerc;
      mercToUpdate.mp = mercToUpdate.maxMp;
      mercToUpdate.sp = mercToUpdate.maxSp;
      Object.values(mercToUpdate.body).forEach((limb) => {
        limb.currentHp = limb.maxHp;
      });
    }
  }

  partyCopy[mercIndex] = mercToUpdate;
  return { player: { ...player, party: partyCopy }, sideEffects };
}