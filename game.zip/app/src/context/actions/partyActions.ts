import { calculateItemValue, getItemName, mergeIntoInventory } from 'utils/itemUtils';
import { calculateCharacterStats, calculateXpToNextLevel } from '../../services/statService';
import { GameData, GameSideEffect, ItemInstance, Mercenary, Player, PLAYER_INVENTORY_MAX_UNIQUE_ITEMS, PLAYER_INVENTORY_MAX_STACK_SIZE } from '../../types';
import { generateMercenary } from '../../utils/mercenaryFactory';

export function refreshMercenaryGuild(player: Player, gameTime: Date, GAME_DATA: GameData): { player: Player } {
  const mercData = player.mercenaryGuildData || {
    available: [],
    lastRefreshed: 0,
  };

  const now = gameTime.getTime();
  const lastRefreshed = mercData.lastRefreshed;
  const oneDay = 24 * 60 * 60 * 1000;
  const needsRefresh = now - lastRefreshed >= oneDay || mercData.available.length === 0;

  if (!needsRefresh) {
    return { player };
  }

  const newMercs = Array.from({ length: 3 }, () => generateMercenary(player.level, GAME_DATA));

  return {
    player: {
      ...player,
      mercenaryGuildData: {
        available: newMercs,
        lastRefreshed: now,
      },
    },
  };
}

export function hireMercenary(player: Player, mercenary: Mercenary): { player: Player; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];
  if (player.party.length >= 3) {
    sideEffects.push({ type: 'LOG', message: 'Your party is full.', logType: 'error' });
    return { player, sideEffects };
  }
  if (player.gold < mercenary.initialCost) {
    sideEffects.push({ type: 'LOG', message: 'You cannot afford the hiring fee.', logType: 'error' });
    return { player, sideEffects };
  }

  const newParty = [...player.party, mercenary];
  const newGold = player.gold - mercenary.initialCost;
  const newMercenaryGuildData = {
    ...player.mercenaryGuildData,
    available: player.mercenaryGuildData.available.filter((m) => m.id !== mercenary.id),
  };

  sideEffects.push({ type: 'LOG', message: `${mercenary.name} has joined your party!`, logType: 'info' });

  return {
    player: {
      ...player,
      gold: newGold,
      party: newParty,
      mercenaryGuildData: newMercenaryGuildData,
    },
    sideEffects,
  };
}

export function fireMercenary(player: Player, mercenaryId: string): { player: Player; sideEffects: GameSideEffect[] } | null {
  const mercToFire = player.party.find((m) => m.id === mercenaryId);
  if (!mercToFire) return null;

  const newParty = player.party.filter((m) => m.id !== mercenaryId);
  const sideEffects: GameSideEffect[] = [{ type: 'LOG', message: `${mercToFire.name} has left your party.`, logType: 'info' }];

  return { player: { ...player, party: newParty }, sideEffects };
}

export function giftItemToMercenary(player: Player, mercenaryId: string, item: ItemInstance, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  const itemIndex = player.inventory.findIndex((i) => i.unique_id === item.unique_id);
  if (itemIndex < 0) return null;

  const playerInventory = [...player.inventory];
  const stackInPlayerInv = { ...playerInventory[itemIndex] };

  const giftedItem: ItemInstance = { ...stackInPlayerInv, quantity: 1 };

  if (stackInPlayerInv.quantity > 1) {
    playerInventory[itemIndex] = { ...stackInPlayerInv, quantity: stackInPlayerInv.quantity - 1 };
  } else {
    playerInventory.splice(itemIndex, 1);
  }

  const sideEffects: GameSideEffect[] = [];

  const newParty = player.party.map((merc) => {
    if (merc.id === mercenaryId) {
      const { newInventory: newMercInventory, overflow } = mergeIntoInventory(merc.inventory, [giftedItem], GAME_DATA, {
        maxUniqueItems: PLAYER_INVENTORY_MAX_UNIQUE_ITEMS,
        maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
      });

      if (overflow.length > 0) {
        sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
        sideEffects.push({
          type: 'LOG',
          message: `${merc.name}'s inventory was full, item dropped on the ground.`,
          logType: 'error',
        });
      }

      const newMerc: Mercenary = {
        ...merc,
        inventory: newMercInventory,
      };

      const happinessGain = Math.max(1, Math.floor(calculateItemValue(giftedItem, GAME_DATA) / 10));
      newMerc.happiness = Math.min(100, newMerc.happiness + happinessGain);
      sideEffects.push({
        type: 'LOG',
        message: `You gifted ${getItemName(item, GAME_DATA)} to ${merc.name}. Their happiness increased by ${happinessGain}.`,
        logType: 'info',
      });
      return newMerc;
    }
    return merc;
  });

  return { player: { ...player, inventory: playerInventory, party: newParty }, sideEffects };
}

export function gainMercenaryXp(player: Player, mercenaryId: string, amount: number, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  if (amount <= 0) return null;

  const partyCopy = [...player.party];
  const mercIndex = partyCopy.findIndex((m) => m.id === mercenaryId);

  if (mercIndex === -1) return null;

  let mercToUpdate = { ...partyCopy[mercIndex] };
  mercToUpdate.xp += amount;

  const sideEffects: GameSideEffect[] = [{ type: 'LOG', message: `${mercToUpdate.name} gains ${amount} XP.`, logType: 'xp' }];

  while (mercToUpdate.xp >= mercToUpdate.xpToNextLevel) {
    mercToUpdate.xp -= mercToUpdate.xpToNextLevel;
    mercToUpdate.level++;
    mercToUpdate.xpToNextLevel = calculateXpToNextLevel(mercToUpdate.level);
    sideEffects.push({ type: 'LOG', message: `${mercToUpdate.name} reached level ${mercToUpdate.level}!`, logType: 'quest' });

    const archetype = GAME_DATA.MERCENARIES[mercToUpdate.mercenaryId];
    if (archetype) {
      mercToUpdate.baseStats.strength += archetype.statGrowth.strength;
      mercToUpdate.baseStats.constitution += archetype.statGrowth.constitution;
      mercToUpdate.baseStats.intelligence += archetype.statGrowth.intelligence;
      mercToUpdate.baseStats.dexterity += archetype.statGrowth.dexterity;
    }

    const calculatedMerc = calculateCharacterStats(mercToUpdate, GAME_DATA);
    if (calculatedMerc) {
      mercToUpdate = calculatedMerc;
      mercToUpdate.mp = mercToUpdate.maxMp;
      mercToUpdate.sp = mercToUpdate.maxSp;
      Object.values(mercToUpdate.body).forEach((limb) => {
        limb.currentHp = limb.maxHp;
      });
    }
  }

  partyCopy[mercIndex] = mercToUpdate;
  return { player: { ...player, party: partyCopy }, sideEffects };
}