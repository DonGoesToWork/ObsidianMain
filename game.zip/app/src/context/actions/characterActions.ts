import {
  Player,
  ItemId,
  QuestId,
  ProfessionId,
  QuestProgress,
  BaseStatBlock,
  StatusEffectId,
  StatusEffectInstance,
  AbilityId,
  LogType,
  Loggable,
  GameSideEffect,
  GameData,
} from '../../types';
import { calculateXpToNextLevel } from '../../services/statService';
import { createItemInstances } from 'utils/itemUtils';

export function gainXp(player: Player, amount: number): { player: Player; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];
  if (amount <= 0) return { player, sideEffects };

  const xpBonus = 1 + (player.totalStats.xpGain || 0) / 100;
  const finalAmount = Math.round(amount * xpBonus);

  let newPlayer = { ...player, xp: player.xp + finalAmount };
  sideEffects.push({
    type: 'LOG',
    message: {
      floatingText: `+${finalAmount} XP`,
      detailedText: `You gain ${finalAmount} XP.`,
    },
    logType: 'xp',
  });

  while (newPlayer.xp >= newPlayer.xpToNextLevel) {
    const oldLevel = newPlayer.level;
    newPlayer.xp -= newPlayer.xpToNextLevel;
    newPlayer.level++;
    newPlayer.perkPoints++;
    newPlayer.attributePoints += 5;
    newPlayer.xpToNextLevel = calculateXpToNextLevel(newPlayer.level);
    sideEffects.push({
      type: 'LOG',
      message: `Congratulations! You have reached level ${newPlayer.level}!`,
      logType: 'quest',
    });

    if (newPlayer.level > oldLevel && newPlayer.level % 3 === 1 && newPlayer.level > 1) {
      sideEffects.push({ type: 'GENERATE_ZONE', level: newPlayer.level });
    }
  }
  return { player: newPlayer, sideEffects };
}

export function addGold(player: Player, amount: number): { player: Player; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];
  if (amount === 0) return { player, sideEffects };

  const newPlayer = { ...player, gold: player.gold + amount };

  if (amount > 0) {
    sideEffects.push({
      type: 'LOG',
      message: {
        floatingText: `+${amount} Gold`,
        detailedText: `You gain ${amount} gold.`,
      },
      logType: 'loot',
    });
  } else {
    sideEffects.push({
      type: 'LOG',
      message: {
        floatingText: `${amount} Gold`,
        detailedText: `You lose ${Math.abs(amount)} gold.`,
      },
      logType: 'loot',
    });
  }

  return { player: newPlayer, sideEffects };
}

export function updateQuestProgress(
  player: Player,
  type: 'kill' | 'gather',
  target: string,
  count: number,
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const newActiveQuests = { ...player.quests.active };
  let updated = false;
  const sideEffects: GameSideEffect[] = [];

  for (const questId in newActiveQuests) {
    const quest = newActiveQuests[questId as QuestId];
    if (quest.type === type && quest.target === target && quest.current < quest.count) {
      const newCount = Math.min(quest.count, quest.current + count);
      if (quest.current !== newCount) {
        quest.current = newCount;
        updated = true;
        if (quest.current >= quest.count) {
          const questData = GAME_DATA.QUESTS[questId as QuestId];
          sideEffects.push({
            type: 'LOG',
            message: `Quest objective complete: ${questData.name}`,
            logType: 'quest',
          });
        }
      }
    }
  }

  if (!updated) return null;

  return { player: { ...player, quests: { ...player.quests, active: newActiveQuests } }, sideEffects };
}

export function applyStatusEffect(
  player: Player,
  effectId: StatusEffectId,
  options: {
    turns?: number;
    durationInMinutes?: number;
    limbId?: string;
    stage?: number;
    instanceId?: string;
    linkedToInstanceId?: string;
    isClosed?: boolean;
  },
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } | null {
  const effectData = GAME_DATA.STATUS_EFFECTS[effectId];
  if (!effectData) return null;

  const sideEffects: GameSideEffect[] = [];
  const newEffect: StatusEffectInstance = {
    id: effectId,
    instanceId: options.instanceId || `se_${Date.now()}_${Math.random()}`,
    linkedToInstanceId: options.linkedToInstanceId,
    isClosed: options.isClosed || false,
    turnsRemaining: options.turns || 0,
    durationInMinutes: options.durationInMinutes || 0,
    currentStage: options.stage || 1,
  };

  let newPlayer = { ...player };

  if (options.limbId && newPlayer.body[options.limbId]) {
    const newBody = { ...newPlayer.body };
    const newLimb = { ...newBody[options.limbId] };
    newLimb.statusEffects = [...newLimb.statusEffects, newEffect];
    newBody[options.limbId] = newLimb;
    sideEffects.push({
      type: 'LOG',
      message: `${effectData.name} applied to ${newLimb.displayName}.`,
      logType: 'info',
    });
    newPlayer.body = newBody;
  } else {
    newPlayer.statusEffects = [...player.statusEffects, newEffect];
    sideEffects.push({ type: 'LOG', message: `${effectData.name} applied.`, logType: 'info' });
  }

  return { player: newPlayer, sideEffects };
}

export function spendAttributePoint(player: Player, stat: keyof BaseStatBlock): { player: Player; sideEffects: GameSideEffect[] } | null {
  if (player.attributePoints <= 0) return null;

  const newPlayer = {
    ...player,
    baseStats: { ...player.baseStats, [stat]: player.baseStats[stat] + 1 },
    attributePoints: player.attributePoints - 1,
  };
  const sideEffects: GameSideEffect[] = [{ type: 'LOG', message: `You increased your ${String(stat)}.`, logType: 'info' }];
  return { player: newPlayer, sideEffects };
}

export function learnPerk(player: Player, abilityId: AbilityId, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  if (player.perkPoints <= 0) return null;

  const abilityData = GAME_DATA.SKILLS[abilityId];
  if (!abilityData || abilityData.abilityType !== 'Perk') return null;

  const currentRank = player.skills[abilityId]?.rank || 0;
  if (abilityData.maxRank && currentRank >= abilityData.maxRank) {
    return { player, sideEffects: [{ type: 'LOG', message: 'You have already maxed out this perk.', logType: 'error' }] };
  }

  const newPlayer = {
    ...player,
    skills: { ...player.skills, [abilityId]: { rank: currentRank + 1 } },
    perkPoints: player.perkPoints - 1,
  };
  const sideEffects: GameSideEffect[] = [{ type: 'LOG', message: `You learned ${abilityData.name} (Rank ${currentRank + 1}).`, logType: 'info' }];
  return { player: newPlayer, sideEffects };
}

export function learnAbility(player: Player, abilityId: AbilityId, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  const abilityData = GAME_DATA.SKILLS[abilityId];
  if (!abilityData) return null;

  const currentRank = player.skills[abilityId]?.rank || 0;
  if (currentRank > 0) {
    return { player, sideEffects: [{ type: 'LOG', message: `You already know ${abilityData.name}.`, logType: 'info' }] };
  }

  const newPlayer = {
    ...player,
    skills: { ...player.skills, [abilityId]: { rank: 1 } },
  };
  const sideEffects: GameSideEffect[] = [{ type: 'LOG', message: `You have learned ${abilityData.name}!`, logType: 'skill' }];
  return { player: newPlayer, sideEffects };
}

export function acceptQuest(player: Player, questId: QuestId, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  const questData = GAME_DATA.QUESTS[questId];
  if (!questData) return null;

  const newActiveQuests = { ...player.quests.active };
  newActiveQuests[questId] = { ...questData.objective, current: 0 };

  const newPlayer = {
    ...player,
    quests: { ...player.quests, active: newActiveQuests },
  };

  const sideEffects: GameSideEffect[] = [{ type: 'LOG', message: `Quest accepted: ${questData.name}`, logType: 'quest' }];
  return { player: newPlayer, sideEffects };
}

export function completeQuest(player: Player, questId: QuestId, GAME_DATA: GameData): { player: Player; sideEffects: GameSideEffect[] } | null {
  const questData = GAME_DATA.QUESTS[questId];
  if (!questData || !player.quests.active[questId]) return null;

  let sideEffects: GameSideEffect[] = [];
  let tempPlayer = { ...player };

  const newActive = { ...tempPlayer.quests.active };
  delete newActive[questId];
  const newCompleted = { ...tempPlayer.quests.completed, [questId]: true };
  tempPlayer.quests = { active: newActive, completed: newCompleted };
  sideEffects.push({ type: 'LOG', message: `Quest complete: ${questData.name}`, logType: 'quest' });

  if (questData.reward.gold) {
    const result = addGold(tempPlayer, questData.reward.gold);
    tempPlayer = result.player;
    sideEffects.push(...result.sideEffects);
  }

  if (questData.reward.items) {
    const newInventory = [...tempPlayer.inventory];
    questData.reward.items.forEach((itemId: ItemId) => {
      newInventory.push(...createItemInstances(itemId, 1, { plus_value: 0 }, GAME_DATA));
    });
    tempPlayer.inventory = newInventory;
  }

  if (questData.reward.reputation) {
    const newReputation = { ...tempPlayer.reputation };
    const factionId = questData.reward.reputation.faction;
    const currentRep = newReputation[factionId] || { points: 0, rankIndex: 0 };
    currentRep.points += questData.reward.reputation.points;
    newReputation[factionId] = currentRep;
    tempPlayer.reputation = newReputation;
    sideEffects.push({ type: 'LOG', message: `Gained ${questData.reward.reputation.points} reputation with ${GAME_DATA.FACTIONS[factionId].name}.`, logType: 'rep' });
  }

  tempPlayer.fame = (tempPlayer.fame || 0) + 1;
  sideEffects.push({ type: 'LOG', message: 'Your fame has increased.', logType: 'rep' });

  if (questData.reward.xp) {
    const xpResult = gainXp(tempPlayer, questData.reward.xp);
    tempPlayer = xpResult.player;
    sideEffects.push(...xpResult.sideEffects);
  }

  return { player: tempPlayer, sideEffects };
}

export function toggleFavoriteAbility(player: Player, abilityId: AbilityId): { player: Player } {
  const newFavorites = [...(player.favoriteAbilities || [])];
  const index = newFavorites.indexOf(abilityId);
  if (index > -1) {
    newFavorites.splice(index, 1);
  } else {
    newFavorites.push(abilityId);
  }
  return { player: { ...player, favoriteAbilities: newFavorites } };
}