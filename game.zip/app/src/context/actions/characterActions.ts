import {
  Player,
  ItemId,
  QuestId,
  ProfessionId,
  QuestProgress,
  BaseStatBlock,
  StatusEffectId,
  StatusEffectInstance,
  AbilityId,
  LogType,
  Loggable,
  GameSideEffect,
  GameData,
} from '../../types';
import { calculateXpToNextLevel } from '../../services/statService';
import { createItemInstances } from 'utils/itemUtils';

export function gainXp(player: Player, amount: number): { player: Player; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];
  if (amount <= 0) return { player, sideEffects };

  const xpBonus = 1 + (player.totalStats.xpGain || 0) / 100;
  const finalAmount = Math.round(amount * xpBonus);

  let newPlayer = { ...player, xp: player.xp + finalAmount };
  sideEffects.push({
    type: 'LOG',
    message: {
      floatingText: `+${finalAmount} XP`,
      detailedText: `You gain ${finalAmount} XP.`,
    },
    logType: 'xp',
  });

  while (newPlayer.xp >= newPlayer.xpToNextLevel) {
    const oldLevel = newPlayer.level;
    newPlayer.xp -= newPlayer.xpToNextLevel;
    newPlayer.level++;
    newPlayer.perkPoints++;
    newPlayer.attributePoints += 5;
    newPlayer.xpToNextLevel = calculateXpToNextLevel(newPlayer.level);
    sideEffects.push({
      type: 'LOG',
      message: `Congratulations! You have reached level ${newPlayer.level}!`,
      logType: 'quest',
    });

    if (newPlayer.level > oldLevel && newPlayer.level % 3 === 1 && newPlayer.level > 1) {
      sideEffects.push({ type: 'GENERATE_ZONE', level: newPlayer.level });
    }
  }
  return { player: newPlayer, sideEffects };
}

export function gainProfessionXpImpl(
  professionId: ProfessionId,
  amount: number,
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: Loggable, type: LogType) => void
) {
  setPlayer((p) => {
    if (!p) return p;
    let newPlayer = { ...p };
    const profState = newPlayer.professions[professionId];
    if (!profState) return p;

    profState.xp += amount;

    const percent = ((profState.xp / profState.xpToNextLevel) * 100).toFixed(0);
    logMessage(
      {
        floatingText: `+${amount} ${professionId}`,
        detailedText: `+${amount} ${professionId} Exp - ${percent}% to next level - ${profState.xp}/${profState.xpToNextLevel}`,
      },
      'skill'
    );

    while (profState.xp >= profState.xpToNextLevel) {
      profState.xp -= profState.xpToNextLevel;
      profState.level++;
      profState.xpToNextLevel = calculateXpToNextLevel(profState.level);
      logMessage(`${professionId.charAt(0).toUpperCase() + professionId.slice(1)} skill increased to ${profState.level}!`, 'skill');
    }

    return newPlayer;
  });
}

export function addGold(player: Player, amount: number): { player: Player; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];
  if (amount === 0) return { player, sideEffects };

  const newPlayer = { ...player, gold: player.gold + amount };

  if (amount > 0) {
    sideEffects.push({
      type: 'LOG',
      message: {
        floatingText: `+${amount} Gold`,
        detailedText: `You gain ${amount} gold.`,
      },
      logType: 'loot',
    });
  } else {
    sideEffects.push({
      type: 'LOG',
      message: {
        floatingText: `${amount} Gold`,
        detailedText: `You lose ${Math.abs(amount)} gold.`,
      },
      logType: 'loot',
    });
  }

  return { player: newPlayer, sideEffects };
}

export function updateQuestProgressImpl(
  type: 'kill' | 'gather',
  target: string,
  count: number = 1,
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: Loggable, type: LogType) => void,
  GAME_DATA: GameData
) {
  setPlayer((p) => {
    if (!p) return p;
    const newActiveQuests = { ...p.quests.active };
    let updated = false;
    for (const questId in newActiveQuests) {
      const quest = newActiveQuests[questId as QuestId];
      if (quest.type === type && quest.target === target && quest.current < quest.count) {
        const newCount = Math.min(quest.count, quest.current + count);
        if (quest.current !== newCount) {
          quest.current = newCount;
          updated = true;
          if (quest.current >= quest.count) {
            const questData = GAME_DATA.QUESTS[questId as QuestId];
            logMessage(`Quest objective complete: ${questData.name}`, 'quest');
          }
        }
      }
    }
    if (!updated) return p;
    return { ...p, quests: { ...p.quests, active: newActiveQuests } };
  });
}

export function applyStatusEffectImpl(
  _targetId: 'player',
  effectId: StatusEffectId,
  options: {
    turns?: number;
    durationInMinutes?: number;
    limbId?: string;
    stage?: number;
    instanceId?: string;
    linkedToInstanceId?: string;
    isClosed?: boolean;
  },
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: Loggable, type: LogType) => void,
  GAME_DATA: GameData
) {
  setPlayer((p) => {
    if (!p) return p;
    const effectData = GAME_DATA.STATUS_EFFECTS[effectId];
    if (!effectData) return p;

    const newEffect: StatusEffectInstance = {
      id: effectId,
      instanceId: options.instanceId || `se_${Date.now()}_${Math.random()}`,
      linkedToInstanceId: options.linkedToInstanceId,
      isClosed: options.isClosed || false,
      turnsRemaining: options.turns || 0,
      durationInMinutes: options.durationInMinutes || 0,
      currentStage: options.stage || 1,
    };

    let newPlayer = { ...p };

    if (options.limbId && newPlayer.body[options.limbId]) {
      const newBody = { ...newPlayer.body };
      const newLimb = { ...newBody[options.limbId] };
      newLimb.statusEffects = [...newLimb.statusEffects, newEffect];
      newBody[options.limbId] = newLimb;
      logMessage(`${effectData.name} applied to ${newLimb.displayName}.`, 'info');
    } else {
      newPlayer.statusEffects = [...p.statusEffects, newEffect];
      logMessage(`${effectData.name} applied.`, 'info');
    }

    return newPlayer;
  });
}

export function spendAttributePointImpl(
  stat: keyof BaseStatBlock,
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: Loggable, type: LogType) => void
) {
  setPlayer((p) => {
    if (!p || p.attributePoints <= 0) return p;
    const newBaseStats = { ...p.baseStats, [stat]: p.baseStats[stat] + 1 };
    logMessage(`You increased your ${String(stat)}.`, 'info');
    return {
      ...p,
      baseStats: newBaseStats,
      attributePoints: p.attributePoints - 1,
    };
  });
}

export function learnPerkImpl(
  abilityId: AbilityId,
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: Loggable, type: LogType) => void,
  GAME_DATA: GameData
) {
  setPlayer((p) => {
    if (!p || p.perkPoints <= 0) return p;
    const abilityData = GAME_DATA.SKILLS[abilityId];
    if (!abilityData || abilityData.abilityType !== 'Perk') return p;

    const currentRank = p.skills[abilityId]?.rank || 0;
    if (abilityData.maxRank && currentRank >= abilityData.maxRank) {
      logMessage('You have already maxed out this perk.', 'error');
      return p;
    }

    logMessage(`You learned ${abilityData.name} (Rank ${currentRank + 1}).`, 'info');
    const newSkills = { ...p.skills, [abilityId]: { rank: currentRank + 1 } };
    return { ...p, skills: newSkills, perkPoints: p.perkPoints - 1 };
  });
}

export function learnAbilityImpl(
  abilityId: AbilityId,
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: Loggable, type: LogType) => void,
  GAME_DATA: GameData
) {
  setPlayer((p) => {
    if (!p) return p;
    const abilityData = GAME_DATA.SKILLS[abilityId];
    if (!abilityData) return p;

    const currentRank = p.skills[abilityId]?.rank || 0;
    if (currentRank > 0) {
      logMessage(`You already know ${abilityData.name}.`, 'info');
      return p;
    }

    const newSkills = { ...p.skills, [abilityId]: { rank: 1 } };
    logMessage(`You have learned ${abilityData.name}!`, 'skill');
    return { ...p, skills: newSkills };
  });
}

export function acceptQuestImpl(
  questId: QuestId,
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: Loggable, type: LogType) => void,
  GAME_DATA: GameData
) {
  setPlayer((p) => {
    if (!p) return p;
    const questData = GAME_DATA.QUESTS[questId];
    if (!questData) return p;

    const newActiveQuests = { ...p.quests.active };
    const newQuestProgress: QuestProgress = {
      ...questData.objective,
      current: 0,
    };
    newActiveQuests[questId] = newQuestProgress;
    logMessage(`Quest accepted: ${questData.name}`, 'quest');
    return { ...p, quests: { ...p.quests, active: newActiveQuests } };
  });
}

export function completeQuestImpl(
  questId: QuestId,
  setPlayer: (update: React.SetStateAction<Player | null>) => void,
  logMessage: (message: Loggable, type: LogType) => void,
  gainXp: (amount: number) => void,
  GAME_DATA: GameData
) {
  setPlayer((p: Player | null) => {
    if (!p) return p;
    const questData = GAME_DATA.QUESTS[questId];
    if (!questData || !p.quests.active[questId]) return p;

    let tempPlayer = {
      ...p,
      quests: {
        active: { ...p.quests.active },
        completed: { ...p.quests.completed },
      },
      inventory: [...p.inventory],
      reputation: { ...p.reputation },
    };
    delete tempPlayer.quests.active[questId];
    tempPlayer.quests.completed[questId] = true;

    logMessage(`Quest complete: ${questData.name}`, 'quest');

    if (questData.reward.gold) tempPlayer.gold += questData.reward.gold;
    if (questData.reward.items) {
      questData.reward.items.forEach((itemId: ItemId) => {
        tempPlayer.inventory.push(...createItemInstances(itemId, 1, { quality: 'Good' }, GAME_DATA));
      });
    }
    if (questData.reward.reputation) {
      const factionId = questData.reward.reputation.faction;
      const rep = tempPlayer.reputation[factionId];
      rep.points += questData.reward.reputation.points;
      logMessage(`Gained ${questData.reward.reputation.points} reputation with ${GAME_DATA.FACTIONS[factionId].name}.`, 'rep');
    }

    tempPlayer.fame = (tempPlayer.fame || 0) + 1;
    logMessage('Your fame has increased.', 'rep');

    if (questData.reward.xp) {
      gainXp(questData.reward.xp);
    }

    return tempPlayer;
  });
}

export function toggleFavoriteAbilityImpl(abilityId: AbilityId, setPlayer: (update: React.SetStateAction<Player | null>) => void) {
  setPlayer((p) => {
    if (!p) return p;
    const newFavorites = [...(p.favoriteAbilities || [])];
    const index = newFavorites.indexOf(abilityId);
    if (index > -1) {
      newFavorites.splice(index, 1);
    } else {
      newFavorites.push(abilityId);
    }
    return { ...p, favoriteAbilities: newFavorites };
  });
}