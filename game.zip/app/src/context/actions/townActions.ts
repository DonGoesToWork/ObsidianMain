import { VitalId, RestOptions, Player, LogType, Loggable, AppraiseOptions, GameSideEffect } from '../../types';

export function performInnAction(player: Player, action: 'eat' | 'rest', cost: number): { player: Player; sideEffects: GameSideEffect[] } | null {
  const sideEffects: GameSideEffect[] = [];

  if (player.gold < cost) {
    sideEffects.push({ type: 'LOG', message: `You need ${cost} gold.`, logType: 'error' });
    return { player, sideEffects };
  }

  let newPlayer = { ...player };
  let timeToPass = 0;

  switch (action) {
    case 'eat':
      newPlayer.vitals.hunger.current = newPlayer.vitals.hunger.max;
      newPlayer.vitals.thirst.current = newPlayer.vitals.thirst.max;
      break;
    case 'rest':
      Object.values(newPlayer.body).forEach((limb: any) => {
        limb.currentHp = limb.maxHp;
      });
      newPlayer.mp = newPlayer.maxMp;
      newPlayer.sp = newPlayer.maxSp;
      newPlayer.vitals.alertness.current = newPlayer.vitals.alertness.max;
      timeToPass = 8 * 60;
      break;
  }

  newPlayer.gold -= cost;
  sideEffects.push({ type: 'LOG', message: `You pay ${cost} gold and use the inn's services.`, logType: 'info' });

  if (timeToPass > 0) {
    sideEffects.push({ type: 'PASS_TIME', minutes: timeToPass } as GameSideEffect);
  }

  return { player: newPlayer, sideEffects };
}

export function cureAilment(player: Player, vitalId: VitalId, cost: number): { player: Player; sideEffects: GameSideEffect[] } | null {
  const sideEffects: GameSideEffect[] = [];

  if (player.vitals[vitalId].current === 0) {
    sideEffects.push({ type: 'LOG', message: `You are not afflicted with ${vitalId}.`, logType: 'info' });
    return { player, sideEffects };
  }
  if (player.gold < cost) {
    sideEffects.push({ type: 'LOG', message: `You need ${cost} gold.`, logType: 'error' });
    return { player, sideEffects };
  }

  const newPlayer = { ...player, gold: player.gold - cost };
  newPlayer.vitals[vitalId].current = 0;
  sideEffects.push({
    type: 'LOG',
    message: {
      floatingText: `Cured ${vitalId}`,
      detailedText: `The physician cures your ${vitalId}.`,
    },
    logType: 'heal',
  });

  return { player: newPlayer, sideEffects };
}