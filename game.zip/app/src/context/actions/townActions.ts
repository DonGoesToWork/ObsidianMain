import { VitalId, RestOptions, Player, LogType, Loggable } from "../../types";

interface TownActionContext {
  setPlayer: (update: React.SetStateAction<Player | null>) => void;
  logMessage: (message: Loggable, type: LogType) => void;
  passTime: (minutes: number, options?: RestOptions) => void;
}

export function performInnActionImpl(context: TownActionContext, payload: { action: "eat" | "rest"; cost: number }) {
  const { setPlayer, logMessage, passTime } = context;
  const { action, cost } = payload;

  setPlayer((p: Player | null) => {
    if (!p || p.gold < cost) {
      logMessage(`You need ${cost} gold.`, "error");
      return p;
    }

    let newPlayer = { ...p };
    switch (action) {
      case "eat":
        newPlayer.vitals.hunger.current = newPlayer.vitals.hunger.max;
        newPlayer.vitals.thirst.current = newPlayer.vitals.thirst.max;
        break;
      case "rest":
        Object.values(newPlayer.body).forEach((limb: any) => {
          limb.currentHp = limb.maxHp;
        });
        newPlayer.mp = newPlayer.maxMp;
        newPlayer.sp = newPlayer.maxSp;
        newPlayer.vitals.alertness.current = newPlayer.vitals.alertness.max;
        passTime(8 * 60);
        break;
    }
    newPlayer.gold -= cost;
    logMessage(`You pay ${cost} gold and use the inn's services.`, "info");
    return newPlayer;
  });
}

export function cureAilmentImpl(context: Pick<TownActionContext, "setPlayer" | "logMessage">, payload: { vitalId: VitalId; cost: number }) {
  const { setPlayer, logMessage } = context;
  const { vitalId, cost } = payload;
  setPlayer((p: Player | null) => {
    if (!p || p.vitals[vitalId].current === 0) {
      logMessage(`You are not afflicted with ${vitalId}.`, "info");
      return p;
    }
    if (p.gold < cost) {
      logMessage(`You need ${cost} gold.`, "error");
      return p;
    }

    const newPlayer = { ...p, gold: p.gold - cost };
    newPlayer.vitals[vitalId].current = 0;
    logMessage(
      {
        floatingText: `Cured ${vitalId}`,
        detailedText: `The physician cures your ${vitalId}.`,
      },
      "heal",
    );
    return newPlayer;
  });
}