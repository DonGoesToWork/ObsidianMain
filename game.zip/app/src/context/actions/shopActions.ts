import { GameData, GameSideEffect, ItemId, ItemInstance, Player, PLAYER_INVENTORY_MAX_STACK_SIZE, PLAYER_INVENTORY_MAX_UNIQUE_ITEMS } from '../../types';

import { calculateItemValue, groupItems, mergeIntoInventory } from 'utils/itemUtils';

export function refreshShopInventory(
  player: Player,
  locationId: string,
  locationLevel: number,
  gameTime: Date,
  GAME_DATA: GameData,
  force: boolean
): { player: Player; sideEffects: GameSideEffect[] } {
  const shopData = player.shopInventories[locationId] || {
    stock: {},
    uniqueStock: [],
    lastRefreshed: 0,
  };
  const now = gameTime.getTime();
  const oneDay = 24 * 60 * 60 * 1000;

  if (!force && now - shopData.lastRefreshed < oneDay && Object.keys(shopData.stock).length > 0) {
    return { player, sideEffects: [] };
  }

  const townLevel = locationLevel;
  const minLevel = Math.max(1, Math.round(townLevel * 0.85) - 5);
  const maxLevel = Math.round(townLevel * 1.15) + 5;

  const levelAppropriateItems = GAME_DATA.SHOP_INVENTORY.filter((id) => {
    const itemData = GAME_DATA.ITEMS[id];
    if (!itemData) return false;
    const isEquipment = itemData.type.includes('equipment');
    if (!isEquipment) {
      return itemData.itemLevel <= maxLevel;
    }
    return itemData.itemLevel >= minLevel && itemData.itemLevel <= maxLevel;
  });

  const newStock: Record<ItemId, number> = {};
  [...new Set(levelAppropriateItems)].forEach((id) => {
    const itemData = GAME_DATA.ITEMS[id];
    if (itemData.stackable) {
      newStock[id] = 100;
    } else {
      newStock[id] = Math.max(1, Math.floor(Math.random() * 5));
    }
  });

  const newShopInventories = {
    ...player.shopInventories,
    [locationId]: {
      stock: newStock,
      uniqueStock: [],
      lastRefreshed: now,
    },
  };

  const newPlayer = { ...player, shopInventories: newShopInventories };
  const sideEffects: GameSideEffect[] = force ? [{ type: 'LOG', message: 'The shopkeeper has restocked their wares.', logType: 'info' }] : [];

  return { player: newPlayer, sideEffects };
}

export function getShopStockImpl(player: Player | null, locationId: string) {
  if (!player || !player.shopInventories[locationId]) {
    return { stock: {}, uniqueStock: [], lastRefreshed: 0 };
  }
  const shopData = player.shopInventories[locationId];
  if (!shopData.uniqueStock) {
    shopData.uniqueStock = [];
  }
  return shopData;
}

export function executeTrade(
  player: Player,
  locationId: string,
  playerOfferItems: ItemInstance[],
  merchantOfferItems: ItemInstance[],
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];

  const playerItemsValue = playerOfferItems.reduce((sum, item) => sum + (Math.floor(calculateItemValue(item, GAME_DATA) / 4) || 1) * item.quantity, 0);
  const merchantItemsValue = merchantOfferItems.reduce((sum, item) => sum + calculateItemValue(item, GAME_DATA) * item.quantity, 0);

  const playerGoldChange = playerItemsValue - merchantItemsValue;
  if (player.gold + playerGoldChange < 0) {
    return { player, sideEffects: [{ type: 'LOG', message: "You don't have enough gold for this trade.", logType: 'error' }] };
  }

  // 1. Remove offered items from player inventory
  let tempInventory = [...player.inventory];
  const groupedPlayerOffer = groupItems(playerOfferItems, GAME_DATA);

  for (const key in groupedPlayerOffer) {
    const { item: offeredItem, count } = groupedPlayerOffer[key];
    let removedCount = 0;

    for (let i = tempInventory.length - 1; i >= 0 && removedCount < count; i--) {
      const invItem = tempInventory[i];
      if (invItem.unique_id === offeredItem.unique_id || (GAME_DATA.ITEMS[offeredItem.id].stackable && invItem.id === offeredItem.id)) {
        const amountToRemove = Math.min(invItem.quantity, count - removedCount);
        invItem.quantity -= amountToRemove;
        removedCount += amountToRemove;
        if (invItem.quantity <= 0) {
          tempInventory.splice(i, 1);
        }
      }
    }
  }

  // 2. Add merchant items to player inventory
  const { newInventory, overflow } = mergeIntoInventory(tempInventory, merchantOfferItems, GAME_DATA, {
    maxUniqueItems: PLAYER_INVENTORY_MAX_UNIQUE_ITEMS,
    maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE,
  });

  if (overflow.length > 0) {
    sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
  }

  merchantOfferItems.forEach((item) => {
    if (GAME_DATA.ITEMS[item.id].type.includes('material')) {
      sideEffects.push({ type: 'UPDATE_QUEST_PROGRESS', questType: 'gather', target: item.id, count: item.quantity });
    }
  });

  // 3. Update shop stock
  const shopData = player.shopInventories[locationId] || { stock: {}, uniqueStock: [], lastRefreshed: 0 };
  const newShopStock = { ...shopData.stock };
  const { newInventory: newUniqueStock } = mergeIntoInventory(shopData.uniqueStock || [], playerOfferItems, GAME_DATA, { maxStackSize: PLAYER_INVENTORY_MAX_STACK_SIZE });

  merchantOfferItems.forEach((item) => {
    if (item.unique_id.startsWith('shop_base_')) {
      newShopStock[item.id] = (newShopStock[item.id] || 0) - item.quantity;
      if (newShopStock[item.id] <= 0) delete newShopStock[item.id];
    }
  });

  const merchantUniqueIdsToMove = new Set(merchantOfferItems.map((i) => i.unique_id));
  const remainingUniqueStock = newUniqueStock.filter((item) => !merchantUniqueIdsToMove.has(item.unique_id));

  // 4. Construct final player object
  const newPlayer = {
    ...player,
    inventory: newInventory,
    gold: player.gold + playerGoldChange,
    shopInventories: {
      ...player.shopInventories,
      [locationId]: {
        ...(player.shopInventories[locationId] || { lastRefreshed: 0 }),
        stock: newShopStock,
        uniqueStock: remainingUniqueStock,
      },
    },
  };

  // 5. Generate final log message
  sideEffects.push({ type: 'LOG', message: 'Trade successful!', logType: 'info' });
  return { player: newPlayer, sideEffects };
}