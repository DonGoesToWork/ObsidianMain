import { GameData, GameSideEffect, ItemId, ItemInstance, LocationState, Player } from '../../types';

import { calculateItemTier, calculateItemValue, groupItems, mergeIntoInventory } from 'utils/itemUtils';

export function refreshShopInventoryAction(
  currentShopData: LocationState['shopInventory'],
  locationLevel: number,
  gameTime: Date,
  GAME_DATA: GameData,
  force: boolean
): { updatedShopData: LocationState['shopInventory']; sideEffects: GameSideEffect[] } {
  console.log('shopActions.ts: refreshShopInventoryAction called. force:', force, 'gameTime:', gameTime.toLocaleString());
  const shopData = currentShopData || {
    stock: {},
    uniqueStock: [],
    lastRefreshed: 0,
  };

  const isFirstStock = shopData.lastRefreshed === 0;

  const lastRefreshDate = new Date(shopData.lastRefreshed);
  const nextRestockTime = new Date(lastRefreshDate);
  nextRestockTime.setHours(6, 0, 0, 0);

  // If the last refresh was on or after 6 AM that day, the next restock is 6 AM the *following* day.
  if (lastRefreshDate.getTime() >= nextRestockTime.getTime()) {
    nextRestockTime.setDate(nextRestockTime.getDate() + 1);
  }

  const isTimeToRefresh = gameTime.getTime() >= nextRestockTime.getTime();

  console.log(
    `Shop Refresh Check -> First Stock: ${isFirstStock}, Time to Refresh: ${isTimeToRefresh}. Last refreshed: ${lastRefreshDate.toLocaleString()}, Next restock at: ${nextRestockTime.toLocaleString()}`
  );

  if (!force && !isTimeToRefresh && !isFirstStock) {
    console.log('Shop Refresh -> No refresh needed.');
    return { updatedShopData: shopData, sideEffects: [] };
  }

  console.log(`Shop Refresh -> Refreshing stock. Reason: ${force ? 'Forced' : isFirstStock ? 'First Stock' : 'Time to Refresh'}`);

  const townTier = calculateItemTier(locationLevel);

  // Get all items that are of the town's tier
  const tierAppropriateItems = GAME_DATA.SHOP_INVENTORY.filter((id) => {
    const itemData = GAME_DATA.ITEMS[id];
    if (!itemData) return false;
    const itemTier = calculateItemTier(itemData.itemLevel);
    return itemTier === townTier;
  });

  const lowerLevelItemsToAdd: ItemId[] = [];
  if (townTier > 1) {
    // Get all items from tiers lower than the town's tier
    const lowerTierItemsPool = GAME_DATA.SHOP_INVENTORY.filter((id) => {
      const itemData = GAME_DATA.ITEMS[id];
      if (!itemData) return false;
      const itemTier = calculateItemTier(itemData.itemLevel);
      return itemTier < townTier;
    });

    // Add a random number of lower level items (e.g., 5 to 10 items)
    if (lowerTierItemsPool.length > 0) {
      const numberOfLowerLevelItems = Math.floor(Math.random() * 6) + 5; // 5 to 10 items
      for (let i = 0; i < numberOfLowerLevelItems; i++) {
        const randomIndex = Math.floor(Math.random() * lowerTierItemsPool.length);
        lowerLevelItemsToAdd.push(lowerTierItemsPool[randomIndex]);
      }
    }
  }

  const finalStockPool = [...tierAppropriateItems, ...lowerLevelItemsToAdd];

  const newStock: Record<ItemId, number> = {};
  [...new Set(finalStockPool)].forEach((id) => {
    const itemData = GAME_DATA.ITEMS[id];
    if (itemData.stackable) {
      newStock[id] = 100;
    } else {
      newStock[id] = Math.max(1, Math.floor(Math.random() * 5));
    }
  });

  const updatedShopData: LocationState['shopInventory'] = {
    stock: newStock,
    uniqueStock: [], // unique stock is player-sold items, should be cleared on restock.
    lastRefreshed: gameTime.getTime(),
  };

  const sideEffects: GameSideEffect[] = isFirstStock ? [] : [{ type: 'LOG', message: 'The shopkeeper has restocked their wares.', logType: 'info' }];
  return { updatedShopData, sideEffects };
}

export function getShopStockImpl(locationState: LocationState | undefined) {
  const shopData = locationState?.shopInventory;
  if (!shopData) {
    return { stock: {}, uniqueStock: [], lastRefreshed: 0 };
  }
  if (!shopData.uniqueStock) {
    shopData.uniqueStock = [];
  }
  return shopData;
}

export function executeTrade(
  player: Player,
  currentShopData: LocationState['shopInventory'],
  playerOfferItems: ItemInstance[],
  merchantOfferItems: ItemInstance[],
  GAME_DATA: GameData
): { updatedPlayer: Player; updatedShopData: LocationState['shopInventory']; sideEffects: GameSideEffect[] } {
  const sideEffects: GameSideEffect[] = [];

  const playerItemsValue = playerOfferItems.reduce((sum, item) => sum + (Math.floor(calculateItemValue(item, GAME_DATA) / 4) || 1) * item.quantity, 0);
  const merchantItemsValue = merchantOfferItems.reduce((sum, item) => sum + calculateItemValue(item, GAME_DATA) * item.quantity, 0);

  const playerGoldChange = playerItemsValue - merchantItemsValue;
  if (player.gold + playerGoldChange < 0) {
    sideEffects.push({ type: 'LOG', message: "You don't have enough gold for this trade.", logType: 'error' });
    return { updatedPlayer: player, updatedShopData: currentShopData, sideEffects };
  }

  // 1. Remove offered items from player inventory
  let tempInventory = [...player.inventory];
  const groupedPlayerOffer = groupItems(playerOfferItems, GAME_DATA);

  for (const key in groupedPlayerOffer) {
    const { item: offeredItem, count } = groupedPlayerOffer[key];
    let removedCount = 0;

    for (let i = tempInventory.length - 1; i >= 0 && removedCount < count; i--) {
      const invItem = tempInventory[i];
      if (invItem.unique_id === offeredItem.unique_id || (GAME_DATA.ITEMS[offeredItem.id].stackable && invItem.id === offeredItem.id)) {
        const amountToRemove = Math.min(invItem.quantity, count - removedCount);
        invItem.quantity -= amountToRemove;
        removedCount += amountToRemove;
        if (invItem.quantity <= 0) {
          tempInventory.splice(i, 1);
        }
      }
    }
  }

  // 2. Add merchant items to player inventory
  const { newInventory, overflow } = mergeIntoInventory(tempInventory, merchantOfferItems, GAME_DATA);

  if (overflow.length > 0) {
    sideEffects.push({ type: 'DROP_ITEMS', items: overflow });
  }

  merchantOfferItems.forEach((item) => {
    if (GAME_DATA.ITEMS[item.id].type.includes('material')) {
      sideEffects.push({ type: 'UPDATE_QUEST_PROGRESS', questType: 'gather', target: item.id, count: item.quantity });
    }
  });

  // 3. Update shop stock
  const shopData = currentShopData || { stock: {}, uniqueStock: [], lastRefreshed: 0 };
  const newShopStock = { ...shopData.stock };
  const { newInventory: newUniqueStock } = mergeIntoInventory(shopData.uniqueStock || [], playerOfferItems, GAME_DATA);

  merchantOfferItems.forEach((item) => {
    if (item.unique_id.startsWith('shop_base_')) {
      newShopStock[item.id] = (newShopStock[item.id] || 0) - item.quantity;
      if (newShopStock[item.id] <= 0) delete newShopStock[item.id];
    }
  });

  const merchantUniqueIdsToMove = new Set(merchantOfferItems.map((i) => i.unique_id));
  const remainingUniqueStock = newUniqueStock.filter((item) => !merchantUniqueIdsToMove.has(item.unique_id));

  const updatedShopData: LocationState['shopInventory'] = {
    ...(currentShopData || { lastRefreshed: 0 }),
    stock: newShopStock,
    uniqueStock: remainingUniqueStock,
  };

  // 4. Construct final player object
  const updatedPlayer = {
    ...player,
    inventory: newInventory,
    gold: player.gold + playerGoldChange,
  };

  // 5. Generate final log message
  sideEffects.push({ type: 'LOG', message: 'Trade successful!', logType: 'info' });
  return { updatedPlayer, updatedShopData, sideEffects };
}
