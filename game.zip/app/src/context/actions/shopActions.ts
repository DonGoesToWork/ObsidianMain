import { ItemId, ItemInstance, Player, GameData, GameSideEffect } from '../../types';

import { calculateItemValue, createItemInstances } from 'utils/itemUtils';

export function refreshShopInventory(player: Player, locationId: string, locationLevel: number, gameTime: Date, GAME_DATA: GameData, force: boolean): { player: Player; sideEffects: GameSideEffect[] } {
  const shopData = player.shopInventories[locationId] || {
    stock: {},
    uniqueStock: [],
    lastRefreshed: 0,
  };
  const now = gameTime.getTime();
  const oneDay = 24 * 60 * 60 * 1000;

  if (!force && now - shopData.lastRefreshed < oneDay && Object.keys(shopData.stock).length > 0) {
    return { player, sideEffects: [] };
  }

  const townLevel = locationLevel;
  const minLevel = Math.max(1, Math.round(townLevel * 0.85) - 5);
  const maxLevel = Math.round(townLevel * 1.15) + 5;

  const levelAppropriateItems = GAME_DATA.SHOP_INVENTORY.filter((id) => {
    const itemData = GAME_DATA.ITEMS[id];
    if (!itemData) return false;
    const isEquipment = itemData.type.includes('equipment');
    if (!isEquipment) {
      return itemData.itemLevel <= maxLevel;
    }
    return itemData.itemLevel >= minLevel && itemData.itemLevel <= maxLevel;
  });

  const newStock: Record<ItemId, number> = {};
  [...new Set(levelAppropriateItems)].forEach((id) => {
    const itemData = GAME_DATA.ITEMS[id];
    if (itemData.stackable) {
      newStock[id] = 100;
    } else {
      newStock[id] = Math.max(1, Math.floor(Math.random() * 5));
    }
  });

  const newShopInventories = {
    ...player.shopInventories,
    [locationId]: {
      stock: newStock,
      uniqueStock: [],
      lastRefreshed: now,
    },
  };

  const newPlayer = { ...player, shopInventories: newShopInventories };
  const sideEffects: GameSideEffect[] = force ? [{ type: 'LOG', message: 'The shopkeeper has restocked their wares.', logType: 'info' }] : [];

  return { player: newPlayer, sideEffects };
}

export function getShopStockImpl(player: Player | null, locationId: string) {
  if (!player || !player.shopInventories[locationId]) {
    return { stock: {}, uniqueStock: [], lastRefreshed: 0 };
  }
  const shopData = player.shopInventories[locationId];
  if (!shopData.uniqueStock) {
    shopData.uniqueStock = [];
  }
  return shopData;
}

export function executeTrade(
  player: Player,
  locationId: string,
  playerOfferItems: ItemInstance[],
  merchantOfferItems: ItemInstance[],
  GAME_DATA: GameData
): { player: Player; sideEffects: GameSideEffect[] } {
  const playerItemsValue = playerOfferItems.reduce((sum, item) => sum + (Math.floor(calculateItemValue(item, GAME_DATA) / 4) || 1), 0);
  const merchantItemsValue = merchantOfferItems.reduce((sum, item) => sum + calculateItemValue(item, GAME_DATA), 0);

  const playerGoldChange = playerItemsValue - merchantItemsValue;
  if (player.gold + playerGoldChange < 0) {
    return { player, sideEffects: [{ type: 'LOG', message: "You don't have enough gold for this trade.", logType: 'error' }] };
  }

  const playerOfferIds = new Set(playerOfferItems.map((i) => i.unique_id));
  const remainingPlayerItems = player.inventory.filter((item) => !playerOfferIds.has(item.unique_id));
  const finalPlayerInventory = [...remainingPlayerItems, ...merchantOfferItems];

  const shopData = player.shopInventories[locationId] || { stock: {}, uniqueStock: [], lastRefreshed: 0 };
  const newShopStock = { ...shopData.stock };
  const newUniqueStock = [...(shopData.uniqueStock || [])];

  playerOfferItems.forEach((item) => {
    const itemDef = GAME_DATA.ITEMS[item.id];
    const hasInstanceData =
      (item.enchantments && Object.keys(item.enchantments).length > 0) ||
      (item.plus_value && item.plus_value !== 0) ||
      item.currentDurability !== undefined ||
      (item.containerState && item.containerState.items.length > 0) ||
      item.deceasedCharacter;
    const isStackable = itemDef.stackable && !hasInstanceData;
    if (isStackable) {
      newShopStock[item.id] = (newShopStock[item.id] || 0) + 1;
    } else {
      newUniqueStock.push(item);
    }
  });

  merchantOfferItems.forEach((item) => {
    if (item.unique_id.startsWith('shop_base_')) {
      newShopStock[item.id] = (newShopStock[item.id] || 0) - 1;
      if (newShopStock[item.id] <= 0) delete newShopStock[item.id];
    }
  });

  const merchantUniqueIdsToMove = new Set(merchantOfferItems.map((i) => i.unique_id));
  const remainingUniqueStock = newUniqueStock.filter((item) => !merchantUniqueIdsToMove.has(item.unique_id));

  const newPlayer = {
    ...player,
    gold: player.gold + playerGoldChange,
    inventory: finalPlayerInventory,
    shopInventories: {
      ...player.shopInventories,
      [locationId]: {
        ...(player.shopInventories[locationId] || { lastRefreshed: 0 }),
        stock: newShopStock,
        uniqueStock: remainingUniqueStock,
      },
    },
  };
  return { player: newPlayer, sideEffects: [{ type: 'LOG', message: 'Trade successful!', logType: 'info' }] };
}