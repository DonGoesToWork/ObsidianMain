import React from "react";
import { Player, AbilityId, LogType, Mercenary, WorldContextType, LogContextType, CharacterContextType, Limb, Loggable, Ability, GameData } from "../../types";
import { ContextMenuOption } from "context/ContextMenuContext";
import { isCombatantDefeated } from "utils/combatUtils";
import { reviveCharacter } from "utils/playerUtils";

function healBody(player: Player | Mercenary, healAmount: number): Player | Mercenary {
  let totalMissingHp = 0;
  Object.values(player.body).forEach((limb) => {
    totalMissingHp += limb.maxHp - limb.currentHp;
  });

  if (totalMissingHp > 0) {
    Object.values(player.body).forEach((limb) => {
      const limbMissingHp = limb.maxHp - limb.currentHp;
      if (limbMissingHp > 0) {
        const healForLimb = healAmount * (limbMissingHp / totalMissingHp);
        limb.currentHp = Math.min(limb.maxHp, limb.currentHp + healForLimb);
      }
    });
  }
  return player;
}

const handleDamageEffect = (target: Player | Mercenary, limbId: string | null, ability: Ability, power: number, rankBonus: number) => {
  const logs: Loggable[] = [];
  if (!limbId || !target.body[limbId]) {
    logs.push("Invalid target for damage.");
    return { updatedTarget: target, logs };
  }
  const targetLimb = target.body[limbId] as Limb;
  const finalMultiplier = (ability.effect.multiplier || 0) + (ability.effect.scaling?.multiplier || 0) * rankBonus;
  const damageAmount = Math.round(power * finalMultiplier);

  const oldHp = targetLimb.currentHp;
  targetLimb.currentHp = Math.max(0, targetLimb.currentHp - damageAmount);
  if (targetLimb.currentHp === 0) {
    targetLimb.state = "Destroyed";
  }
  const actualDamage = oldHp - targetLimb.currentHp;

  logs.push({
    floatingText: `-${actualDamage.toFixed(0)} HP to ${targetLimb.displayName}`,
    detailedText: `You use ${ability.name} on ${target.name}, dealing ${actualDamage.toFixed(0)} damage to their ${targetLimb.displayName}.`,
  });

  return { updatedTarget: target, logs };
};

const handleBuffEffect = (
  targetId: "player",
  ability: Ability,
  rankBonus: number,
  applyStatusEffect: CharacterContextType["applyStatusEffect"],
) => {
  const logs: Loggable[] = [];
  const effectsToApply = ability.effect.applyStatusEffect;
  if (!effectsToApply) return { logs };

  if (Array.isArray(effectsToApply)) {
    effectsToApply.forEach((effect) => {
      const finalTurns = (effect.turns || 0) + Math.floor((ability.effect.scaling?.turns || 0) * rankBonus);
      const durationInMinutes = finalTurns * 0.1;
      applyStatusEffect(targetId, effect.id, { durationInMinutes });
    });
  } else {
    const finalTurns = (effectsToApply.turns || 0) + Math.floor((ability.effect.scaling?.turns || 0) * rankBonus);
    const durationInMinutes = finalTurns * 0.1;
    applyStatusEffect(targetId, effectsToApply.id, { durationInMinutes });
  }

  logs.push(`You cast ${ability.name} on yourself.`);
  return { logs };
};

const handleHealBodyEffect = (target: Player | Mercenary, ability: Ability, power: number, rankBonus: number) => {
  const finalMultiplier = (ability.effect.multiplier || 0) + (ability.effect.scaling?.multiplier || 0) * rankBonus;
  const healAmount = power * finalMultiplier;
  const healedTarget = healBody(target, healAmount);
  const logs: Loggable[] = [
    {
      floatingText: `Healed body`,
      detailedText: `You cast ${ability.name}, restoring health across ${target.name}'s body.`,
    },
  ];
  return { updatedTarget: healedTarget, logs };
};

const handleHealLimbEffect = (target: Player | Mercenary, limbId: string | null, ability: Ability, power: number, rankBonus: number) => {
  const logs: Loggable[] = [];
  if (!limbId || !target.body[limbId]) {
    logs.push("Invalid limb target.");
    return { updatedTarget: target, logs };
  }
  const targetLimb = target.body[limbId] as Limb;
  if (targetLimb.state === "Destroyed") {
    logs.push(`${targetLimb.displayName} is destroyed and cannot be healed.`);
    return { updatedTarget: target, logs };
  }
  const finalMultiplier = (ability.effect.multiplier || 0) + (ability.effect.scaling?.multiplier || 0) * rankBonus;
  const healAmount = power * finalMultiplier;
  const oldHp = targetLimb.currentHp;
  targetLimb.currentHp = Math.min(targetLimb.maxHp, targetLimb.currentHp + healAmount);
  const actualHeal = targetLimb.currentHp - oldHp;
  logs.push({
    floatingText: `+${actualHeal.toFixed(0)} HP to ${targetLimb.displayName}`,
    detailedText: `You cast ${ability.name}, restoring ${actualHeal.toFixed(0)} health to ${target.name}'s ${targetLimb.displayName}.`,
  });
  return { updatedTarget: target, logs };
};

const handleReviveEffect = (target: Player | Mercenary, ability: Ability, GAME_DATA: GameData) => {
  const logs: Loggable[] = [];
  if (!isCombatantDefeated(target as any)) {
    logs.push(`${target.name} is not dead.`);
    return { updatedTarget: target, logs };
  }
  const percentHealth = ability.effect.percentHealth || 10;
  const revivedTarget = reviveCharacter(target, percentHealth, GAME_DATA);
  logs.push(`${target.name} has been revived!`);
  return { updatedTarget: revivedTarget, logs };
};

export function applySkillOutOfCombatImpl(
  abilityId: AbilityId,
  targetId: string,
  limbId: string | null,
  setPlayer: (p: React.SetStateAction<Player | null>) => void,
  logMessage: LogContextType["logMessage"],
  passTime: WorldContextType["passTime"],
  applyStatusEffect: CharacterContextType["applyStatusEffect"],
  GAME_DATA: GameData,
) {
  setPlayer((p) => {
    if (!p) return p;

    const abilityData = GAME_DATA.SKILLS[abilityId];
    if (!abilityData) {
      logMessage("Unknown ability.", "error");
      return p;
    }

    const resourceCost = abilityData.resourceCost || 0;
    const resourcePool = abilityData.resourceType.toLowerCase() as "mp" | "sp";

    if (abilityData.resourceType !== "None" && p[resourcePool] < resourceCost) {
      logMessage("Not enough resources.", "error");
      return p;
    }

    let logs: Loggable[] = [];
    const isPlayerTarget = targetId === "player";
    let newPlayerState = {
      ...p,
      party: [...p.party.map((m) => ({ ...m }))],
    };

    if (abilityData.resourceType !== "None") {
      (newPlayerState[resourcePool] as number) -= resourceCost;
    }

    const rank = newPlayerState.skills[abilityId]?.rank || 1;
    const rankBonus = rank - 1;
    const power =
      abilityData.effect.scalesWith === "spellPower" ? newPlayerState.totalStats.spellPower : newPlayerState.totalStats.attackPower;

    let target = isPlayerTarget ? newPlayerState : newPlayerState.party.find((m) => m.id === targetId);

    if (!target) {
      logMessage("Invalid target.", "error");
      return p;
    }

    switch (abilityData.effect.type) {
      case "damage": {
        const result = handleDamageEffect(target, limbId, abilityData, power, rankBonus);
        target = result.updatedTarget;
        logs.push(...result.logs);
        break;
      }
      case "buff": {
        if (!isPlayerTarget) {
          logMessage("This can only be cast on yourself.", "error");
          return p;
        }
        const result = handleBuffEffect("player", abilityData, rankBonus, applyStatusEffect);
        logs.push(...result.logs);
        break;
      }
      case "heal_body": {
        const result = handleHealBodyEffect(target, abilityData, power, rankBonus);
        target = result.updatedTarget;
        logs.push(...result.logs);
        break;
      }
      case "heal_limb": {
        const result = handleHealLimbEffect(target, limbId, abilityData, power, rankBonus);
        target = result.updatedTarget;
        logs.push(...result.logs);
        break;
      }
      case "revive": {
        const result = handleReviveEffect(target, abilityData, GAME_DATA);
        target = result.updatedTarget;
        logs.push(...result.logs);
        break;
      }
      default: {
        logMessage("This ability has no effect out of combat.", "info");
        return p;
      }
    }

    logs.forEach((log) => logMessage(log, "info"));
    if (abilityData.timeToUse) passTime(abilityData.timeToUse);

    if (isPlayerTarget) {
      return target as Player;
    } else {
      newPlayerState.party = newPlayerState.party.map((m) => (m.id === targetId ? (target as Mercenary) : m));
      return newPlayerState;
    }
  });
}

export function castAbilityOutOfCombatImpl(
  abilityId: AbilityId,
  e: React.MouseEvent,
  player: Player | null,
  showContextMenu: (x: number, y: number, options: ContextMenuOption[]) => void,
  applySkillOutOfCombat: (abilityId: AbilityId, targetId: string, limbId: string | null) => void,
  logMessage: (message: string, type?: LogType) => void,
  GAME_DATA: GameData,
) {
  if (!player) return;
  const abilityData = GAME_DATA.SKILLS[abilityId];
  if (!abilityData) return;

  const targetRule = abilityData.targetRule;
  const validTargets = abilityData.validTargets || [];

  const targets: (Player | Mercenary)[] = [player, ...player.party];
  const targetOptions: ContextMenuOption[] = [];

  targets.forEach((target) => {
    const isSelf = target === player;
    const targetId = isSelf ? "player" : (target as Mercenary).id;
    const targetIsDefeated = isCombatantDefeated(target as any);

    if (isSelf && !validTargets.includes("self")) return;
    if (!isSelf && !validTargets.includes("ally")) return;

    if (abilityData.effect.type === "revive" && !targetIsDefeated) return;
    if (abilityData.effect.type !== "revive" && targetIsDefeated) return;

    if (targetRule === "AnyBody" || targetRule === "Self") {
      targetOptions.push({
        label: target.name,
        onClick: () => applySkillOutOfCombat(abilityId, targetId, null),
      });
    } else if (targetRule === "SingleLimb") {
      const limbSubMenu = Object.values(target.body).map((limb: Limb) => {
        const limbIsDestroyed = limb.state === "Destroyed";
        const canBeTargeted = abilityData.effect.type === "damage" ? !limbIsDestroyed : !limbIsDestroyed;

        return {
          label: `${limb.displayName} (${limb.currentHp.toFixed(0)}/${limb.maxHp})`,
          onClick: () => applySkillOutOfCombat(abilityId, targetId, limb.id),
          disabled: !canBeTargeted,
        };
      });
      targetOptions.push({ label: target.name, subMenu: limbSubMenu });
    }
  });

  if (targetOptions.length > 0) {
    if (targetOptions.length === 1 && !targetOptions[0].subMenu) {
      targetOptions[0].onClick?.();
    } else {
      showContextMenu(e.clientX, e.clientY, targetOptions);
    }
  } else {
    logMessage("This ability has no valid targets right now.", "info");
  }
}