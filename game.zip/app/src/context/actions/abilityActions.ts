import { ContextMenuOption } from 'context/ContextMenuContext';
import React from 'react';
import { isCombatantDefeated } from 'utils/combatUtils';
import { reviveCharacter } from 'utils/playerUtils';
import {
  Ability,
  AbilityId,
  CharacterContextType,
  GameData,
  Limb,
  LogContextType,
  Loggable,
  LogType,
  Mercenary,
  Player,
  SkillEffectType,
  WorldContextType,
} from '../../types';

function healBody(player: Player | Mercenary, healAmount: number): Player | Mercenary {
  let totalMissingHp = 0;
  Object.values(player.body).forEach((limb) => {
    totalMissingHp += limb.maxHp - limb.currentHp;
  });

  if (totalMissingHp > 0) {
    Object.values(player.body).forEach((limb) => {
      const limbMissingHp = limb.maxHp - limb.currentHp;
      if (limbMissingHp > 0) {
        const healForLimb = healAmount * (limbMissingHp / totalMissingHp);
        limb.currentHp = Math.min(limb.maxHp, limb.currentHp + healForLimb);
        if (limb.currentHp >= limb.maxHp) {
          limb.state = 'Healthy';
        }
      }
    });
  }
  return player;
}

type OutOfCombatEffectHandler = (
  target: Player | Mercenary,
  limbId: string | null,
  ability: Ability,
  power: number,
  rankBonus: number,
  context: { applyStatusEffect: CharacterContextType['applyStatusEffect']; GAME_DATA: GameData }
) => { updatedTarget: Player | Mercenary; logs: Loggable[] };

const handleDamageEffect: OutOfCombatEffectHandler = (target, limbId, ability, power, rankBonus) => {
  const logs: Loggable[] = [];
  if (!limbId || !target.body[limbId]) {
    logs.push('Invalid target for damage.');
    return { updatedTarget: target, logs };
  }
  const targetLimb = target.body[limbId] as Limb;
  const finalMultiplier = (ability.effect.multiplier || 0) + (ability.effect.scaling?.multiplier || 0) * rankBonus;
  const damageAmount = Math.round(power * finalMultiplier);

  const oldHp = targetLimb.currentHp;
  targetLimb.currentHp = Math.max(0, targetLimb.currentHp - damageAmount);
  if (targetLimb.currentHp === 0) {
    targetLimb.state = 'Destroyed';
  }
  const actualDamage = oldHp - targetLimb.currentHp;

  logs.push({
    floatingText: `-${actualDamage.toFixed(0)} HP to ${targetLimb.displayName}`,
    detailedText: `You use ${ability.name} on ${target.name}, dealing ${actualDamage.toFixed(0)} damage to their ${targetLimb.displayName}.`,
  });

  return { updatedTarget: target, logs };
};

const handleBuffEffect: OutOfCombatEffectHandler = (target, limbId, ability, power, rankBonus, { applyStatusEffect }) => {
  const logs: Loggable[] = [];
  if (!('professions' in target)) {
    logs.push('This can only be cast on yourself.');
    return { updatedTarget: target, logs };
  }

  const effectsToApply = ability.effect.applyStatusEffect;
  if (!effectsToApply) return { updatedTarget: target, logs };

  if (Array.isArray(effectsToApply)) {
    effectsToApply.forEach((effect) => {
      const finalTurns = (effect.turns || 0) + Math.floor((ability.effect.scaling?.turns || 0) * rankBonus);
      const durationInMinutes = finalTurns * 0.1;
      applyStatusEffect('player', effect.id, { durationInMinutes });
    });
  } else {
    const finalTurns = (effectsToApply.turns || 0) + Math.floor((ability.effect.scaling?.turns || 0) * rankBonus);
    const durationInMinutes = finalTurns * 0.1;
    applyStatusEffect('player', effectsToApply.id, { durationInMinutes });
  }

  logs.push(`You cast ${ability.name} on yourself.`);
  return { updatedTarget: target, logs };
};

const handleHealBodyEffect: OutOfCombatEffectHandler = (target, limbId, ability, power, rankBonus) => {
  const finalMultiplier = (ability.effect.multiplier || 0) + (ability.effect.scaling?.multiplier || 0) * rankBonus;
  const healAmount = power * finalMultiplier;
  const healedTarget = healBody(target, healAmount);
  const logs: Loggable[] = [
    {
      floatingText: `Healed body`,
      detailedText: `You cast ${ability.name}, restoring health across ${target.name}'s body.`,
    },
  ];
  return { updatedTarget: healedTarget, logs };
};

const handleHealLimbEffect: OutOfCombatEffectHandler = (target, limbId, ability, power, rankBonus) => {
  const logs: Loggable[] = [];
  if (!limbId || !target.body[limbId]) {
    logs.push('Invalid limb target.');
    return { updatedTarget: target, logs };
  }
  const targetLimb = target.body[limbId] as Limb;
  if (targetLimb.state === 'Destroyed') {
    logs.push(`${targetLimb.displayName} is destroyed and cannot be healed.`);
    return { updatedTarget: target, logs };
  }
  const finalMultiplier = (ability.effect.multiplier || 0) + (ability.effect.scaling?.multiplier || 0) * rankBonus;
  const healAmount = power * finalMultiplier;
  const oldHp = targetLimb.currentHp;
  targetLimb.currentHp = Math.min(targetLimb.maxHp, targetLimb.currentHp + healAmount);
  if (targetLimb.currentHp >= targetLimb.maxHp) {
    targetLimb.state = 'Healthy';
  }
  const actualHeal = targetLimb.currentHp - oldHp;
  logs.push({
    floatingText: `+${actualHeal.toFixed(0)} HP to ${targetLimb.displayName}`,
    detailedText: `You cast ${ability.name}, restoring ${actualHeal.toFixed(0)} health to ${target.name}'s ${targetLimb.displayName}.`,
  });
  return { updatedTarget: target, logs };
};

const handleReviveEffect: OutOfCombatEffectHandler = (target, limbId, ability, power, rankBonus, { GAME_DATA }) => {
  const logs: Loggable[] = [];
  if (!isCombatantDefeated(target as any)) {
    logs.push(`${target.name} is not dead.`);
    return { updatedTarget: target, logs };
  }
  const percentHealth = ability.effect.percentHealth || 10;
  const revivedTarget = reviveCharacter(target, percentHealth, GAME_DATA);
  logs.push(`${target.name} has been revived!`);
  return { updatedTarget: revivedTarget, logs };
};

const outOfCombatEffectHandlers: Partial<Record<SkillEffectType, OutOfCombatEffectHandler>> = {
  damage: handleDamageEffect,
  buff: handleBuffEffect,
  heal_body: handleHealBodyEffect,
  heal_limb: handleHealLimbEffect,
  revive: handleReviveEffect,
};

export function applySkillOutOfCombatImpl(
  abilityId: AbilityId,
  targetId: string,
  limbId: string | null,
  setPlayer: (p: React.SetStateAction<Player | null>) => void,
  logMessage: LogContextType['logMessage'],
  passTime: WorldContextType['passTime'],
  applyStatusEffect: CharacterContextType['applyStatusEffect'],
  GAME_DATA: GameData
) {
  setPlayer((p) => {
    if (!p) return p;

    const abilityData = GAME_DATA.SKILLS[abilityId];
    if (!abilityData) {
      logMessage('Unknown ability.', 'error');
      return p;
    }

    const resourceCost = abilityData.resourceCost || 0;
    const resourcePool = abilityData.resourceType.toLowerCase() as 'mp' | 'sp';

    if (abilityData.resourceType !== 'None' && p[resourcePool] < resourceCost) {
      logMessage('Not enough resources.', 'error');
      return p;
    }

    const isPlayerTarget = targetId === 'player';
    let newPlayerState = {
      ...p,
      party: [...p.party.map((m) => ({ ...m }))],
    };

    if (abilityData.resourceType !== 'None') {
      (newPlayerState[resourcePool] as number) -= resourceCost;
    }

    const rank = newPlayerState.skills[abilityId]?.rank || 1;
    const rankBonus = rank - 1;
    const power = abilityData.effect.scalesWith === 'spellPower' ? newPlayerState.totalStats.spellPower : newPlayerState.totalStats.attackPower;

    let target = isPlayerTarget ? newPlayerState : newPlayerState.party.find((m) => m.id === targetId);
    if (!target) {
      logMessage('Invalid target.', 'error');
      return p;
    }

    const handler = outOfCombatEffectHandlers[abilityData.effect.type];

    if (handler) {
      const result = handler(target, limbId, abilityData, power, rankBonus, { applyStatusEffect, GAME_DATA });
      target = result.updatedTarget;
      result.logs.forEach((log) => logMessage(log, 'info'));
      if (abilityData.timeToUse) passTime(abilityData.timeToUse);
    } else {
      logMessage('This ability has no effect out of combat.', 'info');
      return p;
    }

    if (isPlayerTarget) {
      return target as Player;
    } else {
      newPlayerState.party = newPlayerState.party.map((m) => (m.id === targetId ? (target as Mercenary) : m));
      return newPlayerState;
    }
  });
}

export function castAbilityOutOfCombatImpl(
  abilityId: AbilityId,
  e: React.MouseEvent,
  player: Player | null,
  showContextMenu: (x: number, y: number, options: ContextMenuOption[]) => void,
  applySkillOutOfCombat: (abilityId: AbilityId, targetId: string, limbId: string | null) => void,
  logMessage: (message: string, type?: LogType) => void,
  GAME_DATA: GameData
) {
  if (!player) return;
  const abilityData = GAME_DATA.SKILLS[abilityId];
  if (!abilityData) return;

  const targetRule = abilityData.targetRule;
  const validTargets = abilityData.validTargets || [];

  const targets: (Player | Mercenary)[] = [player, ...player.party];
  const targetOptions: ContextMenuOption[] = [];

  targets.forEach((target) => {
    const isSelf = 'professions' in target;
    const targetId = isSelf ? 'player' : (target as Mercenary).id;
    const targetIsDefeated = isCombatantDefeated(target as any);

    if (isSelf && !validTargets.includes('self')) return;
    if (!isSelf && !validTargets.includes('ally')) return;

    if (abilityData.effect.type === 'revive' && !targetIsDefeated) return;
    if (abilityData.effect.type !== 'revive' && targetIsDefeated) return;

    if (targetRule === 'AnyBody' || targetRule === 'Self') {
      targetOptions.push({
        label: target.name,
        onClick: () => applySkillOutOfCombat(abilityId, targetId, null),
      });
    } else if (targetRule === 'SingleLimb') {
      const limbSubMenu = Object.values(target.body).map((limb: Limb) => {
        const limbIsDestroyed = limb.state === 'Destroyed';
        const canBeTargeted = abilityData.effect.type === 'damage' ? !limbIsDestroyed : !limbIsDestroyed;

        return {
          label: `${limb.displayName} (${limb.currentHp.toFixed(0)}/${limb.maxHp})`,
          onClick: () => applySkillOutOfCombat(abilityId, targetId, limb.id),
          disabled: !canBeTargeted,
        };
      });
      targetOptions.push({ label: target.name, subMenu: limbSubMenu });
    }
  });

  if (targetOptions.length > 0) {
    if (targetOptions.length === 1 && !targetOptions[0].subMenu) {
      targetOptions[0].onClick?.();
    } else {
      showContextMenu(e.clientX, e.clientY, targetOptions);
    }
  } else {
    logMessage('This ability has no valid targets right now.', 'info');
  }
}
