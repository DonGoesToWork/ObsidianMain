import {
  CharacterContextType,
  CombatContextType,
  Combatant,
  GameData,
  InventoryContextType,
  ItemId,
  ItemInstance,
  LogContextType,
  Mercenary,
  MonsterId,
  MonsterData,
  PartyContextType,
  Player,
  PlayerContextType,
  StatusEffectInstance,
  UIContextType,
  WorldContextType,
} from "../../types";
import { createMonsterCombatant, createPlayerCombatant, createMercenaryCombatant } from "utils/combatantFactory";
import { createItemInstances } from "utils/itemUtils";
import { isCombatantDefeated } from "utils/combatUtils";

type CombatActionContext = Pick<CombatContextType, "currentCombat" | "setCurrentCombat"> &
  Pick<WorldContextType, "changeGameState" | "currentLocation" | "travelTo"> &
  PlayerContextType &
  Pick<CharacterContextType, "gainXp" | "addGold" | "updateQuestProgress"> &
  Pick<InventoryContextType, "removeItem"> &
  Pick<PartyContextType, "gainMercenaryXp"> &
  Pick<UIContextType, "setActiveModal"> &
  Pick<LogContextType, "logMessage"> & {
    addItemsToGround: (items: ItemInstance[]) => void;
    GAME_DATA: GameData;
  };

export function startCombatImpl(
  context: Pick<CombatContextType, "setCurrentCombat"> &
    Pick<WorldContextType, "changeGameState"> &
    Pick<PlayerContextType, "player"> &
    Pick<LogContextType, "logMessage"> & { GAME_DATA: GameData },
  payload: {
    monsterPack: MonsterId[];
    options?: { zoneId?: string; source?: "rest" | "wilds" };
  },
) {
  const { player, logMessage, changeGameState, setCurrentCombat, GAME_DATA } = context;
  const { monsterPack, options } = payload;
  if (!player) return;

  const combatants: Record<string, Combatant> = {};
  combatants["player"] = createPlayerCombatant(player);
  player.party.forEach((merc) => {
    combatants[merc.id] = createMercenaryCombatant(merc);
  });
  monsterPack.forEach((monsterId, i) => {
    const monster = createMonsterCombatant(monsterId, i, GAME_DATA);
    combatants[monster.id] = monster;
  });

  const getTurnOrderValue = (c: Combatant) => {
    if (c.type === "player") return 0;
    if (c.type === "mercenary") return 1;
    return 2;
  };
  const turnOrder = Object.values(combatants)
    .sort((a, b) => getTurnOrderValue(a) - getTurnOrderValue(b))
    .map((c) => c.id);

  const ambushMsg = `You are ambushed by ${monsterPack.map((id) => GAME_DATA.MONSTERS[id as keyof typeof GAME_DATA.MONSTERS].name).join(", ")}!`;
  logMessage({ floatingText: "Ambush!", detailedText: ambushMsg }, "combat");

  changeGameState("combat");
  setCurrentCombat({
    isActive: true,
    combatants,
    turnOrder,
    turnIndex: 0,
    playerTargetId: turnOrder.find((id) => combatants[id].type === "enemy") || null,
    playerSelectedLimbId: null,
    petTargetId: null,
    isPlayerTurn: true,
    source: options?.source || "wilds",
    fieldEffects: [],
    selectedAction: null,
  });
}

function filterPersistentEffects(character: Player | Mercenary, GAME_DATA: GameData, logMessage: LogContextType["logMessage"]): Player | Mercenary {
  const newChar = { ...character };

  const persistentFilter = (effect: StatusEffectInstance) => {
    if (effect.durationInMinutes === Infinity || effect.turnsRemaining === Infinity) return true;
    const isCombatOnly = effect.turnsRemaining > 0 && (!effect.durationInMinutes || effect.durationInMinutes === 0);
    const effectData = GAME_DATA.STATUS_EFFECTS[effect.id];
    if (isCombatOnly) {
      logMessage(`${effectData.name} fades.`, "info");
      return false;
    }
    return true;
  };

  newChar.statusEffects = newChar.statusEffects.filter(persistentFilter);
  Object.values(newChar.body).forEach((limb) => {
    limb.statusEffects = limb.statusEffects.filter(persistentFilter);
  });

  return newChar;
}

export function endCombatImpl(context: CombatActionContext, payload: { victory: boolean }) {
  const {
    currentCombat,
    player,
    logMessage,
    gainXp,
    gainMercenaryXp,
    addGold,
    addItemsToGround,
    updateQuestProgress,
    changeGameState,
    currentLocation,
    setPlayer,
    setCurrentCombat,
    setActiveModal,
    GAME_DATA,
  } = context;
  const { victory } = payload;
  if (!currentCombat || !player) return;

  setPlayer((p) => (p ? { ...p, lastAction: null } : p));

  if (victory) {
    logMessage({ floatingText: "Victory!", detailedText: "Victory!" }, "combat");
    let totalXp = 0;
    let totalGold = 0;

    const survivingMercs = Object.values(currentCombat.combatants).filter(
      (c: Combatant) => c.type === "mercenary" && c.body.torso.currentHp > 0,
    );

    Object.values(currentCombat.combatants).forEach((c: Combatant) => {
      if (c.type === "enemy" && c.monsterId) {
        const monsterData = GAME_DATA.MONSTERS[c.monsterId];
        if (monsterData) {
          totalXp += monsterData.xp;
          totalGold += monsterData.gold;
          const lootItems: ItemInstance[] = [];
          Object.keys(monsterData.lootTable).forEach((itemId) => {
            if (Math.random() < monsterData.lootTable[itemId as ItemId]) {
              lootItems.push(...createItemInstances(itemId as ItemId, 1, undefined, GAME_DATA));
            }
          });
          if (monsterData.equipment) {
            Object.values(monsterData.equipment).forEach((item) => {
              if (item) lootItems.push(...createItemInstances(item, 1, { isUnidentified: true }, GAME_DATA));
            });
          }
          if (lootItems.length > 0) {
            addItemsToGround(lootItems);
          }
          updateQuestProgress("kill", c.monsterId);
        }
      }
    });
    if (totalXp > 0) {
      gainXp(totalXp);
      const mercXpShare = Math.round(totalXp / (survivingMercs.length + 1));
      if (mercXpShare > 0) {
        survivingMercs.forEach((merc) => gainMercenaryXp(merc.id, mercXpShare));
      }
    }

    if (totalGold > 0) {
      const goldBonus = 1 + (player.totalStats.goldFind || 0) / 100;
      const finalGold = Math.round(totalGold * goldBonus);
      addGold(finalGold);
    }
    changeGameState(currentLocation?.type === "town" ? "town" : "wilds");
  } else {
    logMessage(
      {
        floatingText: "Defeated...",
        detailedText: "You have been defeated...",
      },
      "error",
    );
    setActiveModal("death-modal");
  }

  setPlayer((p) => {
    if (!p) return p;
    const combatPlayer = currentCombat.combatants.player;
    let newPlayer = { ...p, body: combatPlayer.body };

    newPlayer = filterPersistentEffects(newPlayer, GAME_DATA, logMessage) as Player;

    const deadMercs: Mercenary[] = [];
    const newParty = newPlayer.party
      .map((merc) => {
        const combatMerc = currentCombat.combatants[merc.id];
        if (!combatMerc) return merc;

        if (isCombatantDefeated(combatMerc)) {
          deadMercs.push(merc);
          return null;
        }

        let updatedMerc: Mercenary = {
          ...merc,
          body: combatMerc.body,
          mp: combatMerc.mp,
          sp: combatMerc.sp,
          statusEffects: combatMerc.statusEffects,
        };

        updatedMerc = filterPersistentEffects(updatedMerc, GAME_DATA, logMessage) as Mercenary;

        return updatedMerc;
      })
      .filter((m): m is Mercenary => m !== null);
    newPlayer.party = newParty;

    if (deadMercs.length > 0) {
      const corpsesToDrop: ItemInstance[] = deadMercs.map((deadMerc) => {
        const combatantData = currentCombat.combatants[deadMerc.id];
        const equipmentItems = Object.values(combatantData.equipment).filter((item): item is ItemInstance => !!item && !item.isUnarmed);
        const mercItems: ItemInstance[] = [...combatantData.inventory, ...equipmentItems];

        const corpseItem: ItemInstance = {
          id: "item_corpse",
          unique_id: `corpse_${deadMerc.id}_${Date.now()}_${Math.random()}`,
          name: `Corpse of ${deadMerc.name}`,
          weight: deadMerc.baseWeight,
          deceasedCharacter: deadMerc,
          enchantments: {},
          containerState: {
            items: mercItems,
            capacity: combatantData.maxWeight || 200,
          },
        };
        logMessage(`${deadMerc.name}'s body falls to the ground.`, "combat");
        return corpseItem;
      });
      addItemsToGround(corpsesToDrop);
    }

    const playerIsDead = isCombatantDefeated(newPlayer);
    if (victory && playerIsDead) {
      const reviverIndex = newPlayer.party.findIndex(
        (merc) =>
          merc.happiness >= 50 &&
          !isCombatantDefeated(merc as any) &&
          (merc.skills["sp_cleric_t7_revive"] || merc.inventory.some((i) => i.id === "item_phoenix_feather")),
      );

      if (reviverIndex > -1) {
        const reviver = { ...newPlayer.party[reviverIndex] };
        let usedRevive = false;

        const reviveSpell = GAME_DATA.SKILLS["sp_cleric_t7_revive"];
        if (reviver.skills["sp_cleric_t7_revive"] && reviver.mp >= reviveSpell.resourceCost) {
          reviver.mp -= reviveSpell.resourceCost;
          logMessage(`${reviver.name} uses ${reviveSpell.name} to revive you!`, "heal");
          usedRevive = true;
        } else {
          const featherIndex = reviver.inventory.findIndex((i) => i.id === "item_phoenix_feather");
          if (featherIndex > -1) {
            const feather = GAME_DATA.ITEMS["item_phoenix_feather"];
            reviver.inventory.splice(featherIndex, 1);
            logMessage(`${reviver.name} uses a ${feather.name} to revive you!`, "heal");
            usedRevive = true;
          }
        }

        if (usedRevive) {
          newPlayer.party[reviverIndex] = reviver;
          Object.values(newPlayer.body).forEach((limb) => {
            limb.state = "Healthy";
            limb.currentHp = limb.maxHp * 0.1;
            limb.statusEffects = [];
          });
          newPlayer.statusEffects = [];
        }
      }
    }

    return newPlayer;
  });

  setCurrentCombat(null);
}

export function fleeCombatImpl(
  context: Pick<CombatActionContext, "currentCombat" | "player" | "logMessage" | "removeItem" | "setCurrentCombat" | "changeGameState" | "currentLocation" | "GAME_DATA">,
  payload: {},
) {
  const { currentCombat, player, logMessage, removeItem, setCurrentCombat, changeGameState, currentLocation, GAME_DATA } = context;
  if (!currentCombat) return;

  if (currentCombat.source === "rest") {
    const tent = player?.inventory.find((i: ItemInstance) => GAME_DATA.ITEMS[i.id]?.restAid?.lostOnFlee);
    if (tent) {
      logMessage(`In your haste to flee, you abandon your ${GAME_DATA.ITEMS[tent.id].name}!`, "error");
      removeItem(tent.id, 1);
    }
  }

  logMessage(
    {
      floatingText: "Fled!",
      detailedText: "You successfully fled from combat.",
    },
    "info",
  );
  setCurrentCombat(null);
  changeGameState(currentLocation?.type === "wilds" ? "wilds" : "town");
}