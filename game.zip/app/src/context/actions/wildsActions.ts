import { LogContextType, PlayerContextType, WorldContextType } from 'types';
import { calculateDifficultyBonus } from 'utils/gameMechanics';
import { createItemInstances, getEquippedToolBonus } from 'utils/itemUtils';
import { GameData, ItemInstance, ProfessionId, ProfessionsContextType } from '../../types';

type WildsActionContext = Pick<WorldContextType, 'passTime' | 'currentLocation' | 'addItemsToGround'> &
  Pick<PlayerContextType, 'player'> &
  Pick<ProfessionsContextType, 'gainProfessionXp'> &
  Pick<LogContextType, 'logMessage'> & { GAME_DATA: GameData };

export function performWildsActionImpl(context: WildsActionContext, payload: { actionType: ProfessionId }) {
  const { passTime, player, currentLocation, logMessage, gainProfessionXp, addItemsToGround, GAME_DATA } = context;
  const { actionType } = payload;
  passTime(30);
  const currentPlayer = player;
  if (!currentPlayer || currentPlayer.currentWeight >= currentPlayer.maxCarryWeight) {
    logMessage('You are over-encumbered and cannot gather more items.', 'error');
    return;
  }

  const zone = currentLocation;
  if (!zone) return;

  const actionNodes = zone.gather.filter((node) => node.type === actionType);
  if (actionNodes.length === 0) {
    logMessage(`You find nothing of interest to ${actionType}.`, 'info');
    return;
  }

  const highestDifficulty = Math.max(1, ...actionNodes.map((n) => n.skillReq));
  gainProfessionXp(actionType, 2 * highestDifficulty + 1);

  logMessage(`You attempt to ${actionType}...`, 'info');
  let totalSkill = currentPlayer.professions[actionType].level + getEquippedToolBonus(currentPlayer, actionType);

  let foundItems: ItemInstance[] = [];
  actionNodes.forEach((node) => {
    const bonus = calculateDifficultyBonus(totalSkill, node.skillReq);
    if (Math.random() < node.chance * bonus) {
      const numFound = bonus > 1.5 && Math.random() > 0.5 ? 2 : 1;
      const itemData = GAME_DATA.ITEMS[node.item];
      const newItems = createItemInstances(
        node.item,
        numFound,
        {
          isUnidentified: itemData.type.includes('equipment'),
        },
        GAME_DATA
      );
      foundItems.push(...newItems);
    }
  });

  if (foundItems.length > 0) {
    addItemsToGround(foundItems);
  } else {
    logMessage(`You failed to find anything.`, 'info');
  }
}
