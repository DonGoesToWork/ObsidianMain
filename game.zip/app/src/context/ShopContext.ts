import { createContext } from "react";
import { ShopContextType } from "../types";

export const ShopContext = createContext<ShopContextType | null>(null);