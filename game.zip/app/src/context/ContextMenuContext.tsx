import React, {
  createContext,
  useState,
  useCallback,
  ReactNode,
  useContext,
  useRef,
  useEffect,
} from "react";
import ReactDOM from "react-dom";

export interface ContextMenuOption {
  label: string;
  onClick?: () => void;
  disabled?: boolean;
  subMenu?: ContextMenuOption[];
}

interface ContextMenuContextType {
  showContextMenu: (x: number, y: number, options: ContextMenuOption[]) => void;
  hideContextMenu: () => void;
}

const ContextMenuContext = createContext<ContextMenuContextType | null>(null);

export const useContextMenu = () => {
  const context = useContext(ContextMenuContext);
  if (!context) {
    throw new Error("useContextMenu must be used within a ContextMenuProvider");
  }
  return context;
};

interface ContextMenuProps {
  options: ContextMenuOption[];
  position?: { x: number; y: number };
  anchorEl?: HTMLElement;
  hideRootMenu: () => void;
}

const ContextMenuComponent: React.FC<ContextMenuProps> = ({
  options,
  position,
  anchorEl,
  hideRootMenu,
}) => {
  const menuRef = useRef<HTMLDivElement>(null);
  const [adjustedPosition, setAdjustedPosition] = useState({
    x: -9999,
    y: -9999,
  });
  const [activeSubMenu, setActiveSubMenu] = useState<{
    anchor: HTMLElement;
    options: ContextMenuOption[];
  } | null>(null);
  const hideTimer = useRef<NodeJS.Timeout>();

  const clearHideTimer = () => {
    if (hideTimer.current) {
      clearTimeout(hideTimer.current);
    }
  };

  const handleMouseEnterItem = (
    e: React.MouseEvent<HTMLDivElement>,
    subMenuOptions?: ContextMenuOption[],
  ) => {
    clearHideTimer();
    if (subMenuOptions) {
      setActiveSubMenu({ anchor: e.currentTarget, options: subMenuOptions });
    } else {
      setActiveSubMenu(null); // Hide submenu if hovering over an item without one
    }
  };

  const handleMouseLeaveMenu = () => {
    hideTimer.current = setTimeout(() => {
      setActiveSubMenu(null);
    }, 200);
  };

  useEffect(() => {
    if (menuRef.current) {
      const menuRect = menuRef.current.getBoundingClientRect();
      let x, y;
      if (anchorEl) {
        // Is a submenu
        const anchorRect = anchorEl.getBoundingClientRect();
        x = anchorRect.right;
        y = anchorRect.top;
        if (x + menuRect.width > window.innerWidth) {
          x = anchorRect.left - menuRect.width;
        }
      } else if (position) {
        // Is a root menu
        x = position.x;
        y = position.y;
        if (x + menuRect.width > window.innerWidth) {
          x = window.innerWidth - menuRect.width - 5;
        }
      } else {
        return;
      }

      if (y + menuRect.height > window.innerHeight) {
        y = window.innerHeight - menuRect.height - 5;
      }
      if (y < 0) y = 5;
      if (x < 0) x = 5;

      setAdjustedPosition({ x, y });
    }
  }, [options, position, anchorEl]);

  return (
    <div
      ref={menuRef}
      className="context-menu"
      style={{
        top: `${adjustedPosition.y}px`,
        left: `${adjustedPosition.x}px`,
      }}
      onMouseLeave={handleMouseLeaveMenu}
      onMouseEnter={clearHideTimer}
    >
      {options.map((option, index) => (
        <div
          key={index}
          className={`context-menu-item ${option.disabled ? "disabled" : ""} ${
            option.subMenu ? "has-submenu" : ""
          }`}
          onClick={(e) => {
            if (option.disabled) return;
            if (option.onClick) {
              option.onClick();
              hideRootMenu(); // Close all menus on click
            }
          }}
          onMouseEnter={(e) => handleMouseEnterItem(e, option.subMenu)}
        >
          {option.label}
        </div>
      ))}
      {activeSubMenu && (
        <ContextMenuComponent
          options={activeSubMenu.options}
          anchorEl={activeSubMenu.anchor}
          hideRootMenu={hideRootMenu}
        />
      )}
    </div>
  );
};

export const ContextMenuProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [menuState, setMenuState] = useState<{
    isVisible: boolean;
    position: { x: number; y: number };
    options: ContextMenuOption[];
  }>({
    isVisible: false,
    position: { x: 0, y: 0 },
    options: [],
  });

  const hideContextMenu = useCallback(() => {
    setMenuState((prev) => ({ ...prev, isVisible: false }));
  }, []);

  const showContextMenu = useCallback(
    (x: number, y: number, options: ContextMenuOption[]) => {
      setMenuState({
        isVisible: true,
        position: { x, y },
        options,
      });
    },
    [],
  );

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuState.isVisible) {
        const target = event.target as HTMLElement;
        if (!target.closest(".context-menu")) {
          hideContextMenu();
        }
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!menuState.isVisible) return;

      const menuRootEl = document.getElementById("context-menu-root");
      if (!menuRootEl) return;

      const menus = menuRootEl.querySelectorAll(".context-menu");
      if (menus.length === 0) return;

      const margin = 30;
      const isOver = Array.from(menus).some((menu) => {
        const rect = menu.getBoundingClientRect();
        return (
          e.clientX >= rect.left - margin &&
          e.clientX <= rect.right + margin &&
          e.clientY >= rect.top - margin &&
          e.clientY <= rect.bottom + margin
        );
      });

      if (!isOver) {
        hideContextMenu();
      }
    };

    if (menuState.isVisible) {
      document.addEventListener("click", handleClickOutside, true);
      document.addEventListener("mousemove", handleMouseMove, true);
    }
    return () => {
      document.removeEventListener("click", handleClickOutside, true);
      document.removeEventListener("mousemove", handleMouseMove, true);
    };
  }, [menuState.isVisible, hideContextMenu]);

  const contextValue: ContextMenuContextType = {
    showContextMenu,
    hideContextMenu,
  };

  const menuRoot = document.getElementById("context-menu-root");

  return (
    <ContextMenuContext.Provider value={contextValue}>
      {children}
      {menuState.isVisible &&
        menuRoot &&
        ReactDOM.createPortal(
          <ContextMenuComponent
            options={menuState.options}
            position={menuState.position}
            hideRootMenu={hideContextMenu}
          />,
          menuRoot,
        )}
    </ContextMenuContext.Provider>
  );
};