import { HeldItem } from 'components/shared/HeldItem';
import { UIContext } from 'context/UIContext';
import { usePlayer } from 'hooks/usePlayer';
import React, { useContext } from 'react';
import { CharacterVitalsPanel } from './components/character/CharacterVitalsPanel';
import { FloatingTextDisplay } from './components/shared/FloatingTextDisplay';
import { MainPanel } from './components/layout/MainPanel';
import { ModalManager } from './components/layout/ModalManager';
import { RightSidebarPanel } from './components/layout/RightSidebarPanel';
import { useGameHotkeys } from './hooks/useGameHotkeys';

const GameUI: React.FC = () => {
  const player = usePlayer();
  const { heldItem, setHeldItem } = useContext(UIContext)!;
  useGameHotkeys();

  if (!player) return null;

  const handleWrapperClick = () => {
    if (heldItem) {
      setHeldItem(null);
    }
  };

  return (
    <div id="game-wrapper" onClick={handleWrapperClick}>
      <div id="game-layout">
        <div id="player-panel" className="panel">
          <CharacterVitalsPanel character={player} contextualLinks={true} />
        </div>
        <MainPanel />
        <RightSidebarPanel />
      </div>
      <div className="footer-note">
        <p>Game auto-saves periodically.</p>
      </div>
      <FloatingTextDisplay />
      <ModalManager />
      <HeldItem />
    </div>
  );
};

export default GameUI;