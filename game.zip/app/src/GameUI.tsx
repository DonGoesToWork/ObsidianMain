import React from "react";
import { MainPanel } from "./components/layout/MainPanel";
import { FloatingTextDisplay } from "./components/shared/FloatingTextDisplay";
import { useGameHotkeys } from "./hooks/useGameHotkeys";
import { ModalManager } from "./components/layout/ModalManager";
import { RightSidebarPanel } from "./components/layout/RightSidebarPanel";
import { CharacterVitalsPanel } from "./components/character/CharacterVitalsPanel";
import { usePlayer } from "hooks/usePlayer";

const GameUI: React.FC = () => {
  const player = usePlayer();
  useGameHotkeys();

  if (!player) return null;

  return (
    <div id="game-wrapper">
      <div id="game-layout">
        <div id="player-panel" className="panel">
          <CharacterVitalsPanel character={player} contextualLinks={true} />
        </div>
        <MainPanel />
        <RightSidebarPanel />
      </div>
      <div className="footer-note">
        <p>Game auto-saves periodically.</p>
      </div>
      <FloatingTextDisplay />
      <ModalManager />
    </div>
  );
};

export default GameUI;