const prefixes = ['Brave', 'Still', 'Green', 'Fair', 'High', 'Low', 'East', 'West', 'North', 'South', 'Old', 'New', 'Silver', 'Gold', 'Iron', 'Stone'];
const suffixes = ['wood', 'water', 'fen', 'dell', 'garde', 'port', 'haven', 'field', 'run', 'fall', 'crest', 'mire', 'brook', 'bridge', 'rock'];
const wildPrefixes = ['Whispering', 'Silent', 'Howling', 'Forgotten', 'Sunken', 'Verdant', 'Shattered', 'Bleak', 'Murky', 'Twisted'];
const wildSuffixes = ['Woods', 'Forest', 'Expanse', 'Wastes', 'Wilds', 'Hills', 'Plains', 'Mire', 'Marsh', 'Cliffs', 'Caverns'];

export function generateTownName(): string {
  const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
  return `${prefix}${suffix}`;
}

export function generateWildsName(): string {
  const prefix = wildPrefixes[Math.floor(Math.random() * wildPrefixes.length)];
  const suffix = wildSuffixes[Math.floor(Math.random() * wildSuffixes.length)];
  return `${prefix} ${suffix}`;
}
