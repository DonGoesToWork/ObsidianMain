import { GameData, StatusEffect, StatusEffectInstance } from 'types';

type EffectDefinition = StatusEffect['effects'];

export function getEffectsFromInstance(effectInst: StatusEffectInstance, GAME_DATA: GameData): EffectDefinition {
  const effectData = GAME_DATA.STATUS_EFFECTS[effectInst.id];
  let effectsToApply = effectData?.effects;

  if (effectData?.stages && effectInst.currentStage) {
    const stageData = effectData.stages[effectInst.currentStage - 1];
    if (stageData?.effects) {
      effectsToApply = stageData.effects;
    }
  }

  return effectsToApply;
}