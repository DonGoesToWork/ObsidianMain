import { BodyPlan, Limb } from 'types';

export function instantiateBodyPlan(template: BodyPlan<Limb>, baseHp: number, existingBody?: BodyPlan<Limb>): BodyPlan<Limb> {
  const newBody: BodyPlan<Limb> = JSON.parse(JSON.stringify(template));
  for (const limbId in newBody) {
    if (!newBody.hasOwnProperty(limbId)) continue;
    const limb = newBody[limbId];
    limb.maxHp = baseHp;

    if (existingBody && existingBody[limbId]) {
      const oldLimb = existingBody[limbId];
      // Preserve raw currentHP and clamp to new maxHP, instead of using percentages.
      // This prevents health changes when maxHP changes due to buffs/debuffs wearing off.
      limb.currentHp = oldLimb.currentHp;
      limb.currentHp = Math.min(limb.currentHp, limb.maxHp);

      limb.state = oldLimb.state;
      limb.statusEffects = oldLimb.statusEffects;
    } else {
      limb.currentHp = limb.maxHp;
    }
  }
  return newBody;
}