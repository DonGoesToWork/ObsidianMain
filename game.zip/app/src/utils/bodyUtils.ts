import { BodyPlan, Limb } from "types";

export function instantiateBodyPlan(
  template: BodyPlan<Limb>,
  baseHp: number,
  existingBody?: BodyPlan<Limb>,
): BodyPlan<Limb> {
  const newBody: BodyPlan<Limb> = JSON.parse(JSON.stringify(template));
  for (const limbId in newBody) {
    const limb = newBody[limbId];
    limb.maxHp = baseHp;

    if (existingBody && existingBody[limbId]) {
      const oldLimb = existingBody[limbId];
      const hpPercent =
        oldLimb.maxHp > 0 ? oldLimb.currentHp / oldLimb.maxHp : 1;
      limb.currentHp = limb.maxHp * hpPercent;
      limb.state = oldLimb.state;
      limb.statusEffects = oldLimb.statusEffects;
    } else {
      limb.currentHp = limb.maxHp;
    }
  }
  return newBody;
}
