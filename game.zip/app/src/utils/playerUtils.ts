import { Player, AlertnessLevel, Mercenary, PlayerVitals, StatusEffectInstance, GameData, Combatant } from 'types';
import { formatDuration } from './formatUtils';
import { deepCloneWithInfinity } from './mathUtils';

export const calculateTimeToFullHeal = (player: Player, alertness: AlertnessLevel) => {
  if (!player.body || (player.totalStats?.worldHpRegen ?? 0) <= 0) {
    return { minutes: 0, formatted: '0s' };
  }

  const totalMissingHp = Object.values(player.body).reduce((sum, limb) => {
    if (limb.state !== 'Destroyed') {
      return sum + (limb.maxHp - limb.currentHp);
    }
    return sum;
  }, 0);

  if (totalMissingHp <= 0) {
    return { minutes: 0, formatted: '0s' };
  }

  let qualityMultiplier = 1.0;
  switch (alertness) {
    case 'half-awake':
      qualityMultiplier = 2;
      break;
    case 'fully-alert':
      qualityMultiplier = 1;
      break;
    case 'passive':
    default:
      qualityMultiplier = 3;
      break;
  }

  const baseRegenPerMin = player.totalStats.worldHpRegen;
  const effectiveRegenPerMin = baseRegenPerMin * 3 * qualityMultiplier;

  if (effectiveRegenPerMin <= 0) {
    return { minutes: Infinity, formatted: 'Never' };
  }

  const minutes = totalMissingHp / effectiveRegenPerMin;

  return { minutes, formatted: formatDuration(minutes) };
};

export function reviveCharacter(character: Player | Mercenary, percentHealth: number, GAME_DATA: GameData): Player | Mercenary {
  const revivedChar = deepCloneWithInfinity(character);
  Object.values(revivedChar.body).forEach((limb: any) => {
    limb.currentHp = limb.maxHp * (percentHealth / 100);
    limb.state = 'Healthy';
    limb.statusEffects = [];
  });
  revivedChar.statusEffects = [];
  if (revivedChar.vitals) {
    revivedChar.vitals.hunger.current = revivedChar.vitals.hunger.max;
    revivedChar.vitals.thirst.current = revivedChar.vitals.thirst.max;
  }
  return revivedChar;
}

export function applyRestoreResourcesLogic(char: Player | Mercenary | Combatant): Player | Mercenary | Combatant {
  const newChar = { ...char };
  const newBody = deepCloneWithInfinity(char.body);
  Object.values(newBody).forEach((limb: any) => {
    limb.currentHp = limb.maxHp;
  });
  newChar.body = newBody;
  newChar.mp = newChar.maxMp;
  newChar.sp = newChar.maxSp;
  return newChar;
}

export function applyClearDebuffsLogic(char: Player | Mercenary | Combatant, GAME_DATA: GameData): Player | Mercenary | Combatant {
  const newChar = { ...char };
  const newBody = deepCloneWithInfinity(char.body);
  Object.values(newBody).forEach((limb: any) => {
    limb.statusEffects = limb.statusEffects.filter((e: StatusEffectInstance) => GAME_DATA.STATUS_EFFECTS[e.id]?.isBeneficial);
  });
  newChar.statusEffects = char.statusEffects.filter((e: StatusEffectInstance) => GAME_DATA.STATUS_EFFECTS[e.id]?.isBeneficial);
  return newChar;
}

export function applyFullHealLogic(char: Player | Mercenary | Combatant, GAME_DATA: GameData): Player | Mercenary | Combatant {
  const newChar: any = applyRestoreResourcesLogic(char);

  if ('vitals' in newChar && newChar.vitals) {
    const newVitals = { ...newChar.vitals };
    (Object.keys(newVitals) as Array<keyof PlayerVitals>).forEach((key) => {
      newVitals[key].current = newVitals[key].max;
    });
    newChar.vitals = newVitals;
  }

  const newBody = deepCloneWithInfinity(newChar.body);
  Object.values(newBody).forEach((limb: any) => {
    limb.state = 'Healthy';
    limb.statusEffects = limb.statusEffects.filter((e: StatusEffectInstance) => GAME_DATA.STATUS_EFFECTS[e.id]?.isBeneficial);
  });
  newChar.body = newBody;

  newChar.statusEffects = char.statusEffects.filter((e: StatusEffectInstance) => GAME_DATA.STATUS_EFFECTS[e.id]?.isBeneficial);

  return newChar;
}