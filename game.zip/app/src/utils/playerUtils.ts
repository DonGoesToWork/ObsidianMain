import { AlertnessLevel, BodyPlan, Combatant, GameData, ItemId, Limb, Mercenary, Player, PlayerVitals, StatusEffectInstance } from 'types';
import { formatDuration } from './formatUtils';
import { deepCloneWithInfinity } from './mathUtils';

export const calculateTimeToFullHeal = (character: Player | Mercenary, alertness: AlertnessLevel, aids: ItemId[], GAME_DATA: GameData) => {
  if (!character.body) {
    return { minutes: 0, formatted: '0s' };
  }

  const totalMissingHp = Object.values(character.body).reduce((sum, limb) => {
    if (limb.state !== 'Destroyed') {
      return sum + (limb.maxHp - limb.currentHp);
    }
    return sum;
  }, 0);

  const totalMissingMp = character.maxMp - character.mp;
  const totalMissingSp = character.maxSp - character.sp;

  if (totalMissingHp <= 0 && totalMissingMp <= 0 && totalMissingSp <= 0) {
    return { minutes: 0, formatted: '0s' };
  }

  let qualityMultiplier = 1.0;
  switch (alertness) {
    case 'passive':
      qualityMultiplier = 1.5;
      break;
    case 'half-awake':
      qualityMultiplier = 1.25;
      break;
    case 'fully-alert':
    default:
      qualityMultiplier = 1.0;
      break;
  }

  aids.forEach((aidId) => {
    const restAid = GAME_DATA.ITEMS[aidId]?.restAid;
    if (restAid?.type === 'quality_bonus') {
      qualityMultiplier += restAid.value;
    }
  });

  const effectiveHpRegenPerMin = (character.totalStats.worldHpRegen || 0) * 3 * qualityMultiplier;
  const effectiveMpRegenPerMin = (character.totalStats.worldMpRegen || 0) * 3 * qualityMultiplier;
  const effectiveSpRegenPerMin = (character.totalStats.worldSpRegen || 0) * 3 * qualityMultiplier;

  const minutesForHp = effectiveHpRegenPerMin > 0 ? totalMissingHp / effectiveHpRegenPerMin : Infinity;
  const minutesForMp = effectiveMpRegenPerMin > 0 ? totalMissingMp / effectiveMpRegenPerMin : Infinity;
  const minutesForSp = effectiveSpRegenPerMin > 0 ? totalMissingSp / effectiveSpRegenPerMin : Infinity;

  const minutes = Math.max(minutesForHp, minutesForMp, minutesForSp);

  if (minutes === Infinity) {
    return { minutes: Infinity, formatted: 'Never' };
  }
  return { minutes, formatted: formatDuration(minutes) };
};

export const calculateTimeToFullHealForParty = (player: Player, alertness: AlertnessLevel, aids: ItemId[], GAME_DATA: GameData) => {
  const partyMembers = [player, ...player.party];
  let maxMinutes = 0;

  for (const member of partyMembers) {
    const { minutes } = calculateTimeToFullHeal(member, alertness, aids, GAME_DATA);
    if (minutes === Infinity) {
      return { minutes: Infinity, formatted: 'Never' };
    }
    if (minutes > maxMinutes) {
      maxMinutes = minutes;
    }
  }

  return { minutes: maxMinutes, formatted: formatDuration(maxMinutes) };
};

export function reviveCharacter(character: Player | Mercenary, percentHealth: number, GAME_DATA: GameData): Player | Mercenary {
  const revivedChar = deepCloneWithInfinity(character);
  Object.values(revivedChar.body as BodyPlan<Limb>).forEach((limb: Limb) => {
    limb.currentHp = limb.maxHp * (percentHealth / 100);
    limb.state = 'Healthy';
    limb.statusEffects = [];
  });
  revivedChar.statusEffects = [];
  if (revivedChar.vitals) {
    const newVitals = { ...revivedChar.vitals };
    (Object.keys(newVitals) as Array<keyof PlayerVitals>).forEach((key) => {
      newVitals[key].current = newVitals[key].max;
    });
    revivedChar.vitals = newVitals;
  }
  return revivedChar;
}

export function applyRestoreResourcesLogic(char: Player | Mercenary | Combatant): Player | Mercenary | Combatant {
  const newChar = { ...char };
  const newBody = deepCloneWithInfinity(char.body);
  Object.values(newBody as BodyPlan<Limb>).forEach((limb: Limb) => {
    limb.currentHp = limb.maxHp;
  });
  newChar.body = newBody;
  newChar.mp = newChar.maxMp;
  newChar.sp = newChar.maxSp;
  return newChar;
}

export function applyClearDebuffsLogic(char: Player | Mercenary | Combatant, GAME_DATA: GameData): Player | Mercenary | Combatant {
  const newChar = { ...char };
  const newBody = deepCloneWithInfinity(char.body);
  Object.values(newBody as BodyPlan<Limb>).forEach((limb: Limb) => {
    limb.statusEffects = limb.statusEffects.filter((e: StatusEffectInstance) => GAME_DATA.STATUS_EFFECTS[e.id]?.isBeneficial);
  });
  newChar.statusEffects = char.statusEffects.filter((e: StatusEffectInstance) => GAME_DATA.STATUS_EFFECTS[e.id]?.isBeneficial);
  return newChar;
}

export function applyFullHealLogic(char: Player | Mercenary | Combatant, GAME_DATA: GameData): Player | Mercenary | Combatant {
  const newChar: any = applyRestoreResourcesLogic(char);

  if ('vitals' in newChar && newChar.vitals) {
    const newVitals = { ...newChar.vitals };
    (Object.keys(newVitals) as Array<keyof PlayerVitals>).forEach((key) => {
      newVitals[key].current = newVitals[key].max;
    });
    newChar.vitals = newVitals;
  }

  const newBody = deepCloneWithInfinity(newChar.body);
  Object.values(newBody as BodyPlan<Limb>).forEach((limb: Limb) => {
    limb.state = 'Healthy';
    limb.statusEffects = limb.statusEffects.filter((e: StatusEffectInstance) => GAME_DATA.STATUS_EFFECTS[e.id]?.isBeneficial);
  });
  newChar.body = newBody;

  newChar.statusEffects = char.statusEffects.filter((e: StatusEffectInstance) => GAME_DATA.STATUS_EFFECTS[e.id]?.isBeneficial);

  return newChar;
}