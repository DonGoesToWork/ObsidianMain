import { Player, AlertnessLevel, Mercenary, PlayerVitals, StatusEffectInstance, GameData } from "types";
import { formatDuration } from "./formatUtils";

export const calculateTimeToFullHeal = (
  player: Player,
  alertness: AlertnessLevel,
) => {
  if (!player.body || (player.totalStats?.worldHpRegen ?? 0) <= 0) {
    return { minutes: 0, formatted: "0s" };
  }

  const totalMissingHp = Object.values(player.body).reduce((sum, limb) => {
    if (limb.state !== "Destroyed") {
      return sum + (limb.maxHp - limb.currentHp);
    }
    return sum;
  }, 0);

  if (totalMissingHp <= 0) {
    return { minutes: 0, formatted: "0s" };
  }

  let qualityMultiplier = 1.0;
  switch (alertness) {
    case "half-awake":
      qualityMultiplier = 2;
      break;
    case "fully-alert":
      qualityMultiplier = 1;
      break;
    case "passive":
    default:
      qualityMultiplier = 3;
      break;
  }

  const baseRegenPerMin = player.totalStats.worldHpRegen;
  const effectiveRegenPerMin = baseRegenPerMin * 3 * qualityMultiplier;

  if (effectiveRegenPerMin <= 0) {
    return { minutes: Infinity, formatted: "Never" };
  }

  const minutes = totalMissingHp / effectiveRegenPerMin;

  return { minutes, formatted: formatDuration(minutes) };
};

export function reviveCharacter(
  character: Player | Mercenary,
  percentHealth: number,
  GAME_DATA: GameData,
): Player | Mercenary {
  const revivedChar = JSON.parse(JSON.stringify(character)); // deep copy to avoid mutation issues
  Object.values(revivedChar.body).forEach((limb: any) => {
    limb.currentHp = limb.maxHp * (percentHealth / 100);
    limb.state = "Healthy";
    limb.statusEffects = [];
  });
  revivedChar.statusEffects = [];
  if (revivedChar.vitals) {
    revivedChar.vitals.hunger.current = revivedChar.vitals.hunger.max;
    revivedChar.vitals.thirst.current = revivedChar.vitals.thirst.max;
  }
  return revivedChar;
}

export function applyFullHealLogic(char: Player | Mercenary, GAME_DATA: GameData): Player | Mercenary {
  const newVitals = { ...char.vitals };
  (Object.keys(newVitals) as Array<keyof PlayerVitals>).forEach((key) => {
    newVitals[key].current = newVitals[key].max;
  });

  const newBody = JSON.parse(JSON.stringify(char.body));
  Object.values(newBody).forEach((limb: any) => {
    limb.currentHp = limb.maxHp;
    limb.state = "Healthy";
    limb.statusEffects = limb.statusEffects.filter((e: StatusEffectInstance) => GAME_DATA.STATUS_EFFECTS[e.id]?.isBeneficial);
  });

  const statusEffects = char.statusEffects.filter((e: StatusEffectInstance) => GAME_DATA.STATUS_EFFECTS[e.id]?.isBeneficial);

  return {
    ...char,
    body: newBody,
    mp: char.maxMp,
    sp: char.maxSp,
    vitals: newVitals,
    statusEffects,
  };
}