export function formatDuration(minutes: number): string {
  if (minutes <= 0) return '0s';

  const totalSeconds = Math.floor(minutes * 60);

  if (totalSeconds < 1) return '< 1s';

  const hours = Math.floor(totalSeconds / 3600);
  const mins = Math.floor((totalSeconds % 3600) / 60);
  const secs = totalSeconds % 60;

  let parts = [];
  if (hours > 0) parts.push(`${hours}h`);
  if (mins > 0) parts.push(`${mins}m`);
  if (secs > 0 && hours === 0) parts.push(`${secs}s`);

  if (parts.length === 0) {
    return '0s';
  }

  return parts.join(' ');
}

export const formatTravelTime = (distance: number): string => {
  const timeInMinutes = Math.round(distance * 30); // 30 minutes per distance unit
  if (timeInMinutes < 1) return '< 1 min';
  if (timeInMinutes < 60) {
    return `${timeInMinutes} mins`;
  }
  const hours = Math.floor(timeInMinutes / 60);
  const days = Math.floor(hours / 24);
  const remainingHours = hours % 24;

  if (days > 0) {
    return `${days}d ${remainingHours}h`;
  }
  return `${hours}h`;
};
