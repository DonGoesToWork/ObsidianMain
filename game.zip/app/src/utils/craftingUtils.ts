import {
  Player,
  Recipe,
  ItemInstance,
  GameLocation,
  RequirementCheck,
  GameData,
} from "types";

export function getCraftingChecks(
  player: Player,
  recipe: Recipe | null,
  tools: ItemInstance[],
  currentLocation: GameLocation | null,
  checkKnown: boolean,
  GAME_DATA: GameData,
): Record<string, RequirementCheck> {
  const checks: Record<string, RequirementCheck> = {};
  if (!recipe) return checks;

  if (checkKnown) {
    checks.recipeKnown = {
      ok: !!player.knownRecipes[recipe.id],
      text: `Recipe Known ${player.knownRecipes[recipe.id] ? "✔" : "❌"}`,
    };
  }

  const toolIds = new Set(tools.map((t) => t.id));
  if (recipe.tools) {
    for (const toolId of recipe.tools) {
      const toolData = GAME_DATA.ITEMS[toolId];
      const hasTool = toolIds.has(toolId);
      if (!toolData) {
        checks[toolId] = { ok: false, text: `Unknown Tool (${toolId}) ❌` };
      } else {
        checks[toolId] = {
          ok: hasTool,
          text: `${toolData.name} ${hasTool ? "✔" : "❌"}`,
        };
      }
    }
  }

  if (recipe.requiresForge) {
    const hasForge =
      currentLocation?.type === "town" ||
      !!player.inventory.find((i) => i.id === "item_forge");
    checks.forge = {
      ok: hasForge,
      text: `Forge Nearby ${hasForge ? "✔" : "❌"}`,
    };
  }

  checks.level = {
    ok: player.professions[recipe.profession].level >= recipe.levelReq,
    text: `Lvl ${recipe.levelReq} ${recipe.profession} ${
      player.professions[recipe.profession].level >= recipe.levelReq ? "✔" : "❌"
    }`,
  };

  return checks;
}

export function calculateEnchantSuccessChance(
  playerSkill: number,
  enchantRank: number,
): number {
  const successChanceRaw = 100 - (enchantRank + 1) * 5 + playerSkill / 2;
  return Math.max(0, Math.min(100, successChanceRaw));
}

export function calculateUpgradeSuccessChance(
  itemGrade: number,
  playerSkill: number,
): number {
  const successChanceRaw = 50 - itemGrade * 10 + playerSkill / 2;
  return Math.max(0, successChanceRaw);
}