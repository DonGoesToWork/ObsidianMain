import { EnchantmentRecipeId, GameData, GameLocation, ItemId, ItemInstance, Player, Recipe, RecipeId, RequirementCheck, RequirementStatus } from 'types';
import { calculateItemLevel, calculateItemTier, countItems } from './itemUtils';

import { calculateDifficultyBonus } from './gameMechanics';

export function getRequirementStatus(checks: Record<string, RequirementCheck>): RequirementStatus {
  const allChecks = Object.values(checks);

  if (allChecks.length === 0) {
    return 'full';
  }

  if (allChecks.every((c) => c.ok)) {
    return 'full';
  }

  if (allChecks.some((c) => !c.ok && c.isHardRequirement)) {
    return 'none';
  }

  return 'partial';
}

export function getCraftingChecks(
  player: Player,
  recipe: Recipe | null,
  tools: ItemInstance[],
  currentLocation: GameLocation | null,
  checkKnown: boolean,
  GAME_DATA: GameData,
  options: {
    checkInventoryForTools?: boolean;
    materialSource?: ItemInstance[];
  } = {}
): Record<string, RequirementCheck> {
  const { checkInventoryForTools = false, materialSource } = options;
  const checks: Record<string, RequirementCheck> = {};
  if (!recipe) return checks;

  if (checkKnown) {
    checks.recipeKnown = {
      ok: !!player.knownRecipes[recipe.id],
      text: `Recipe Known: ${player.knownRecipes[recipe.id] ? '✔' : '❌'}`,
      isHardRequirement: true,
    };
  }

  const toolSource = checkInventoryForTools ? player.inventory : tools;
  const toolIds = new Set(toolSource.map((t) => t.id));

  if (recipe.tools) {
    for (const toolId of recipe.tools) {
      const toolData = GAME_DATA.ITEMS[toolId];
      const hasTool = toolIds.has(toolId);
      checks[toolId] = {
        ok: hasTool,
        text: `${toolData.name}: ${hasTool ? '✔' : '❌'}`,
      };
    }
  }

  if (recipe.requiresForge) {
    const hasForge = currentLocation?.type === 'town' || !!player.inventory.find((i) => i.id === 'item_forge');
    checks.forge = {
      ok: hasForge,
      text: `Forge Nearby: ${hasForge ? '✔' : '❌'}`,
    };
  }

  const sourceOfMaterials = materialSource ?? player.inventory;
  const inventoryCounts = sourceOfMaterials.reduce((acc: Record<string, number>, item: ItemInstance) => {
    if (!item.isUnidentified) {
      acc[item.id] = (acc[item.id] || 0) + item.quantity;
    }
    return acc;
  }, {});

  for (const [matId, requiredCount] of Object.entries(recipe.materials)) {
    const hasCount = inventoryCounts[matId as ItemId] || 0;
    const matData = GAME_DATA.ITEMS[matId as ItemId];
    checks[`mat_${matId}`] = {
      ok: hasCount >= requiredCount,
      text: matData.name,
      provided: hasCount,
      required: requiredCount,
    };
  }

  return checks;
}

export function getRepairChecks(
  player: Player,
  recipe: Recipe | null,
  materials: ItemInstance[],
  tools: ItemInstance[],
  currentLocation: GameLocation | null,
  GAME_DATA: GameData,
  checkInventoryForTools: boolean = false
): Record<string, RequirementCheck> {
  const checks = getCraftingChecks(player, recipe, tools, currentLocation, true, GAME_DATA, {
    checkInventoryForTools,
    materialSource: materials,
  });
  if (!recipe) return checks;

  return checks;
}

export function getUpgradeChecks(player: Player, targetItem: ItemInstance, GAME_DATA: GameData): Record<string, RequirementCheck> {
  const checks: Record<string, RequirementCheck> = {};
  const itemData = GAME_DATA.ITEMS[targetItem.id];
  const currentPlus = targetItem.plus_value || 0;

  const itemLevel = calculateItemLevel(targetItem, GAME_DATA);
  const itemTier = calculateItemTier(itemLevel);

  if (!itemData.recipeId || currentPlus >= itemTier) {
    checks.upgradeable = { ok: false, text: 'Item cannot be upgraded further.', isHardRequirement: true };
    return checks;
  }

  checks.recipeKnown = {
    ok: !!player.knownRecipes[itemData.recipeId],
    text: `Knows original recipe: ${player.knownRecipes[itemData.recipeId] ? '✔' : '❌'}`,
    isHardRequirement: true,
  };

  const emberId = `mat_reforge_ember_t${itemTier}` as ItemId;
  const emberData = GAME_DATA.ITEMS[emberId];
  if (!emberData) {
    checks.materials = { ok: false, text: 'Missing Reforging Ember ' + itemTier + '.', isHardRequirement: true };
    return checks;
  }

  const materialCost = itemTier;
  const hasCount = countItems(player.inventory, emberId);
  const hasMaterials = hasCount >= materialCost;

  checks.materials = {
    ok: hasMaterials,
    text: emberData.name,
    provided: hasCount,
    required: materialCost,
  };

  return checks;
}

export function calculateEnchantSuccessChance(playerSkill: number, dr: number): number {
  // A skill level equal to DR gives a 50% chance.
  // Every point of skill above DR adds 5% chance.
  // Every point of skill below DR subtracts 5% chance.
  // Chance is capped at 0% and 100%.
  // A 10 point difference results in 0% or 100% chance.
  return Math.max(0, Math.min(100, 50 + (playerSkill - dr) * 5));
}

export function calculateCraftSuccessChance(playerSkill: number, recipeLevel: number): number {
  const bonus = calculateDifficultyBonus(playerSkill, recipeLevel);
  return Math.max(0, Math.min(100, (bonus / 2) * 100));
}

export function calculateRepairSuccessChance(playerSkill: number, recipeLevel: number): number {
  const effectiveness = calculateDifficultyBonus(playerSkill, recipeLevel);
  // Based on repairItemImpl logic, success is capped at 95%
  return Math.min(95, effectiveness * 100);
}

export function findDiscoveredRecipe(
  ingredients: ItemInstance[],
  tools: ItemInstance[],
  currentLocation: GameLocation | null,
  allRecipes: Record<RecipeId, Recipe>
): Recipe | undefined {
  if (ingredients.length === 0 && tools.length === 0) return undefined;

  const ingredientCounts: Record<string, number> = {};
  for (const ing of ingredients) {
    ingredientCounts[ing.id] = (ingredientCounts[ing.id] || 0) + ing.quantity;
  }
  const providedToolIds = new Set(tools.map((t) => t.id));

  return Object.values(allRecipes).find((r) => {
    const recipeMatKeys = Object.keys(r.materials);
    const providedIngKeys = Object.keys(ingredientCounts);
    if (recipeMatKeys.length !== providedIngKeys.length) return false;

    const ingredientsMatch = recipeMatKeys.every((key) => ingredientCounts[key] === r.materials[key as ItemId]);
    if (!ingredientsMatch) return false;

    const requiredToolIds = new Set(r.tools || []);
    if (r.requiresForge) {
      requiredToolIds.add('item_forge');
    }

    const providedWithForge = new Set(providedToolIds);
    if (r.requiresForge && currentLocation?.type === 'town') {
      providedWithForge.add('item_forge');
    }

    if (requiredToolIds.size !== providedWithForge.size) return false;

    const toolsMatch = Array.from(requiredToolIds).every((toolId) => providedWithForge.has(toolId as ItemId));
    return toolsMatch;
  });
}

export function calculateEnchantmentDetails(
  player: Player,
  selectedItem: ItemInstance,
  selectedEnchantment: { enchantId: string; tier: number },
  itemTier: number,
  GAME_DATA: GameData
) {
  const enchantDef = GAME_DATA.ENCHANTS.find((e) => e.id === selectedEnchantment.enchantId);
  if (!enchantDef) return null;

  const currentTier = selectedItem.enchantments[enchantDef.id] || 0;
  const selectedTier = selectedEnchantment.tier;
  const rank = selectedTier - 1;

  if (rank < 0 || rank >= enchantDef.scaling.length) return null;

  const isHigherTier = selectedTier > currentTier;

  const materialCost = enchantDef.cost[rank];
  const crystalId = Object.keys(materialCost)[0] as ItemId;
  const crystalCostCount = materialCost[crystalId];
  const hasCrystals = countItems(player.inventory, crystalId) >= crystalCostCount;

  const numExistingEnchants = Object.keys(selectedItem.enchantments).length;
  const isNewEnchantType = !selectedItem.enchantments[enchantDef.id];
  const maxEnchantsReached = isNewEnchantType && numExistingEnchants >= Object.keys(GAME_DATA.ITEM_RARITY_TIERS).length - 1;
  const enchantTierIsTooHigh = selectedTier > itemTier;

  const recipeId = `${enchantDef.id}_t${selectedTier}`;
  const isKnown = !!player.knownEnchantments[recipeId as EnchantmentRecipeId];

  const canEnchant = isKnown && isHigherTier && hasCrystals && !enchantTierIsTooHigh && !maxEnchantsReached;
  const playerSkill = player.professions.enchanting.level;

  const baseDr = (rank + 1) * 10;
  const finalDr = baseDr + numExistingEnchants;
  const successChance = calculateEnchantSuccessChance(playerSkill, finalDr);

  return {
    enchantDef,
    currentTier,
    selectedTier,
    isHigherTier,
    enchantTierIsTooHigh,
    maxEnchantsReached,
    crystalId,
    crystalName: GAME_DATA.ITEMS[crystalId]?.name || 'Unknown Crystal',
    crystalCost: crystalCostCount,
    hasCrystals,
    successChance,
    canEnchant,
    dr: finalDr,
    playerSkill,
    isKnown,
  };
}