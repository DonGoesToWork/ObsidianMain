import { GameData, GameLocation, ItemId, ItemInstance, Player, Recipe, RequirementCheck, RequirementStatus } from 'types';
import { calculateItemLevel, countItems } from './itemUtils';

import { calculateDifficultyBonus } from './gameMechanics';

export function getRequirementStatus(checks: Record<string, RequirementCheck>): RequirementStatus {
  const allChecks = Object.values(checks);

  if (allChecks.length === 0) {
    return 'full';
  }

  if (allChecks.every((c) => c.ok)) {
    return 'full';
  }

  if (allChecks.some((c) => !c.ok && c.isHardRequirement)) {
    return 'none';
  }

  return 'partial';
}

export function getCraftingChecks(
  player: Player,
  recipe: Recipe | null,
  tools: ItemInstance[],
  currentLocation: GameLocation | null,
  checkKnown: boolean,
  GAME_DATA: GameData,
  options: {
    checkInventoryForTools?: boolean;
    materialSource?: ItemInstance[];
  } = {}
): Record<string, RequirementCheck> {
  const { checkInventoryForTools = false, materialSource } = options;
  const checks: Record<string, RequirementCheck> = {};
  if (!recipe) return checks;

  if (checkKnown) {
    checks.recipeKnown = {
      ok: !!player.knownRecipes[recipe.id],
      text: `Recipe Known: ${player.knownRecipes[recipe.id] ? '✔' : '❌'}`,
      isHardRequirement: true,
    };
  }

  const toolSource = checkInventoryForTools ? player.inventory : tools;
  const toolIds = new Set(toolSource.map((t) => t.id));

  if (recipe.tools) {
    for (const toolId of recipe.tools) {
      const toolData = GAME_DATA.ITEMS[toolId];
      const hasTool = toolIds.has(toolId);
      checks[toolId] = {
        ok: hasTool,
        text: `${toolData.name}: ${hasTool ? '✔' : '❌'}`,
      };
    }
  }

  if (recipe.requiresForge) {
    const hasForge = currentLocation?.type === 'town' || !!player.inventory.find((i) => i.id === 'item_forge');
    checks.forge = {
      ok: hasForge,
      text: `Forge Nearby: ${hasForge ? '✔' : '❌'}`,
    };
  }

  const sourceOfMaterials = materialSource ?? player.inventory;
  const inventoryCounts = sourceOfMaterials.reduce((acc: Record<string, number>, item: ItemInstance) => {
    if (!item.isUnidentified) {
      acc[item.id] = (acc[item.id] || 0) + 1;
    }
    return acc;
  }, {});

  for (const [matId, requiredCount] of Object.entries(recipe.materials)) {
    const hasCount = inventoryCounts[matId as ItemId] || 0;
    const matData = GAME_DATA.ITEMS[matId as ItemId];
    checks[`mat_${matId}`] = {
      ok: hasCount >= requiredCount,
      text: matData.name,
      provided: hasCount,
      required: requiredCount,
    };
  }

  return checks;
}

export function getRepairChecks(
  player: Player,
  recipe: Recipe | null,
  materials: ItemInstance[],
  tools: ItemInstance[],
  currentLocation: GameLocation | null,
  GAME_DATA: GameData,
  checkInventoryForTools: boolean = false
): Record<string, RequirementCheck> {
  const checks = getCraftingChecks(player, recipe, tools, currentLocation, true, GAME_DATA, {
    checkInventoryForTools,
    materialSource: materials,
  });
  if (!recipe) return checks;

  return checks;
}

export function getUpgradeChecks(player: Player, targetItem: ItemInstance, GAME_DATA: GameData): Record<string, RequirementCheck> {
  const checks: Record<string, RequirementCheck> = {};
  const itemData = GAME_DATA.ITEMS[targetItem.id];
  const currentPlus = targetItem.plus_value || 0;

  const itemLevel = calculateItemLevel(targetItem, GAME_DATA);
  const itemTier = Math.max(1, Math.floor(itemLevel / 10) + 1);

  if (!itemData.recipeId || currentPlus >= itemTier) {
    checks.upgradeable = { ok: false, text: 'Item cannot be upgraded further.', isHardRequirement: true };
    return checks;
  }

  checks.recipeKnown = {
    ok: !!player.knownRecipes[itemData.recipeId],
    text: `Knows original recipe: ${player.knownRecipes[itemData.recipeId] ? '✔' : '❌'}`,
    isHardRequirement: true,
  };

  const emberId = `mat_reforge_ember_t${itemTier}` as ItemId;
  const emberData = GAME_DATA.ITEMS[emberId];
  if (!emberData) {
    checks.materials = { ok: false, text: 'Cannot find appropriate Reforging Ember.', isHardRequirement: true };
    return checks;
  }

  const materialCost = Math.abs(currentPlus) + 1;
  const hasCount = countItems(player.inventory, emberId);
  const hasMaterials = hasCount >= materialCost;

  checks.materials = {
    ok: hasMaterials,
    text: emberData.name,
    provided: hasCount,
    required: materialCost,
  };

  return checks;
}

export function calculateEnchantSuccessChance(playerSkill: number, dr: number): number {
  // A skill level equal to DR gives a 50% chance.
  // Every point of skill above DR adds 5% chance.
  // Every point of skill below DR subtracts 5% chance.
  // Chance is capped at 0% and 100%.
  // A 10 point difference results in 0% or 100% chance.
  return Math.max(0, Math.min(100, 50 + (playerSkill - dr) * 5));
}

export function calculateCraftSuccessChance(playerSkill: number, recipeLevel: number): number {
  const bonus = calculateDifficultyBonus(playerSkill, recipeLevel);
  return Math.max(0, Math.min(100, (bonus / 2) * 100));
}

export function calculateRepairSuccessChance(playerSkill: number, recipeLevel: number): number {
  const effectiveness = calculateDifficultyBonus(playerSkill, recipeLevel);
  // Based on repairItemImpl logic, success is capped at 95%
  return Math.min(95, effectiveness * 100);
}