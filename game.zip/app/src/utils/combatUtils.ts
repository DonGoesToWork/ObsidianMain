import {
  Combatant,
  StatBlock,
  StatusEffectInstance,
  Limb,
  Loggable,
  AbilityId,
  CombatState,
  FieldEffect,
  BodyPlan,
  Player,
  Mercenary,
  ClassId,
  RaceId,
  GameData,
} from 'types';
import { getEffectsFromInstance } from './statusEffectUtils';

export function createDamageMessage(sourceName: string, targetName: string, limbName: string, amount: number, isCrit: boolean) {
  const critClass = isCrit ? 'crit' : 'damage';
  const critText = isCrit ? 'CRITICAL! ' : '';
  return `<span class="${critClass}">${sourceName} hits ${targetName}'s ${limbName} for ${critText}${amount} damage.</span>`;
}

function handleWoundReopening(limb: Limb, ownerName: string): { updatedLimb: Limb; logMessages: Loggable[] } {
  const logMessages: Loggable[] = [];
  const closedCut = limb.statusEffects.find((se) => se.id === 'cut' && se.isClosed);
  if (!closedCut || Math.random() >= 0.2) {
    return { updatedLimb: limb, logMessages };
  }

  logMessages.push({
    floatingText: 'Wound reopened!',
    detailedText: `The patch on ${ownerName}'s ${limb.displayName} bursts open.`,
  });
  const originalCut = limb.statusEffects.find((se) => se.instanceId === closedCut.instanceId);
  if (!originalCut) return { updatedLimb: limb, logMessages };

  originalCut.isClosed = false;

  if (Math.random() < 0.2 && originalCut.currentStage! < 5) {
    originalCut.currentStage!++;
    logMessages.push({
      floatingText: 'Wound Worsened!',
      detailedText: `The wound has worsened!`,
    });
  }

  const bleedStage = originalCut.currentStage! - 1;
  if (bleedStage > 0) {
    const newBleed: StatusEffectInstance = {
      id: 'external_bleed',
      instanceId: `se_${Date.now()}_${Math.random()}`,
      turnsRemaining: Infinity,
      durationInMinutes: Infinity,
      currentStage: bleedStage,
      linkedToInstanceId: originalCut.instanceId,
    };
    limb.statusEffects.push(newBleed);
  }

  return { updatedLimb: limb, logMessages };
}

function applySlashingDamageEffect(limb: Limb, damage: number, ownerName: string, GAME_DATA: GameData): { updatedLimb: Limb; logMessages: Loggable[] } {
  const logMessages: Loggable[] = [];
  const healDurations = { 1: 30, 2: 24 * 60, 3: 24 * 60, 4: 24 * 60, 5: Infinity };
  const damagePercent = damage / limb.maxHp;
  let stageToApply = 0;

  if (damagePercent >= 0.1 && damagePercent < 0.2) stageToApply = 1;
  else if (damagePercent >= 0.2 && damagePercent < 0.3) stageToApply = 2;
  else if (damagePercent >= 0.3 && damagePercent < 0.4) stageToApply = 3;
  else if (damagePercent >= 0.4 && damagePercent < 1.0) stageToApply = 4;
  else if (damagePercent >= 1.0) stageToApply = 5;

  if (stageToApply === 0) {
    return { updatedLimb: limb, logMessages };
  }

  const existingCut = limb.statusEffects.find((se) => se.id === 'cut');
  if (existingCut) {
    if (stageToApply > existingCut.currentStage!) {
      existingCut.currentStage = Math.min(5, stageToApply);
      existingCut.durationInMinutes = healDurations[existingCut.currentStage as keyof typeof healDurations];
      logMessages.push({ detailedText: `The wound on ${limb.displayName} has worsened!` });
      const oldBleed = limb.statusEffects.find((se) => se.linkedToInstanceId === existingCut.instanceId);
      const newBleedStage = existingCut.currentStage! - 1;
      if (oldBleed) {
        if (newBleedStage > 0) {
          oldBleed.currentStage = newBleedStage;
        } else {
          limb.statusEffects = limb.statusEffects.filter((se) => se.instanceId !== oldBleed.instanceId);
        }
      } else if (newBleedStage > 0) {
        const newBleed: StatusEffectInstance = {
          id: 'external_bleed',
          instanceId: `se_${Date.now()}_${Math.random()}`,
          turnsRemaining: Infinity,
          durationInMinutes: Infinity,
          currentStage: newBleedStage,
          linkedToInstanceId: existingCut.instanceId,
        };
        limb.statusEffects.push(newBleed);
      }
    }
  } else {
    const cutInstanceId = `se_${Date.now()}_${Math.random()}`;
    const newCut: StatusEffectInstance = {
      id: 'cut',
      instanceId: cutInstanceId,
      turnsRemaining: 0,
      durationInMinutes: healDurations[stageToApply as keyof typeof healDurations],
      currentStage: stageToApply,
    };
    limb.statusEffects.push(newCut);
    const cutName = GAME_DATA.STATUS_EFFECTS.cut.stages![stageToApply - 1].name;
    logMessages.push({ detailedText: `A ${cutName} appears on ${ownerName}'s ${limb.displayName}!` });
    const bleedStage = newCut.currentStage! - 1;
    if (bleedStage > 0) {
      const newBleed: StatusEffectInstance = {
        id: 'external_bleed',
        instanceId: `se_${Date.now()}_${Math.random()}`,
        turnsRemaining: Infinity,
        durationInMinutes: Infinity,
        currentStage: bleedStage,
        linkedToInstanceId: cutInstanceId,
      };
      limb.statusEffects.push(newBleed);
    }
  }
  return { updatedLimb: limb, logMessages };
}

function handleLimbDestruction(limb: Limb, ownerName: string): { updatedLimb: Limb; logMessages: Loggable[] } {
  const logMessages: Loggable[] = [];

  limb.state = 'Destroyed';
  logMessages.push({
    floatingText: `${limb.displayName} Destroyed!`,
    detailedText: `${ownerName}'s ${limb.displayName} has been destroyed!`,
  });

  limb.statusEffects = [];

  const cutInstanceId = `se_${Date.now()}_${Math.random()}`;
  const newCut: StatusEffectInstance = { id: 'cut', instanceId: cutInstanceId, turnsRemaining: 0, durationInMinutes: Infinity, currentStage: 5 };
  const newBleed: StatusEffectInstance = {
    id: 'external_bleed',
    instanceId: `se_${Date.now()}_${Math.random()}`,
    turnsRemaining: Infinity,
    durationInMinutes: Infinity,
    currentStage: 4,
    linkedToInstanceId: cutInstanceId,
  };
  limb.statusEffects.push(newCut, newBleed);

  return { updatedLimb: limb, logMessages };
}

export function processLimbDamage(
  targetLimb: Limb,
  damage: number,
  damageTypes: string[],
  ownerName: string,
  GAME_DATA: GameData
): { updatedLimb: Limb; logMessages: Loggable[] } {
  let limb = JSON.parse(JSON.stringify(targetLimb));
  let allLogMessages: Loggable[] = [];

  const { updatedLimb: limbAfterReopen, logMessages: reopenLogs } = handleWoundReopening(limb, ownerName);
  limb = limbAfterReopen;
  allLogMessages.push(...reopenLogs);

  limb.currentHp = Math.max(0, limb.currentHp - damage);

  if (limb.currentHp <= 0 && limb.state !== 'Destroyed') {
    const { updatedLimb: limbAfterDestruction, logMessages: destructionLogs } = handleLimbDestruction(limb, ownerName);
    limb = limbAfterDestruction;
    allLogMessages.push(...destructionLogs);
  } else {
    if (damageTypes.includes('Slashing') || damageTypes.includes('Pierce')) {
      const { updatedLimb: limbAfterSlashing, logMessages: slashingLogs } = applySlashingDamageEffect(limb, damage, ownerName, GAME_DATA);
      limb = limbAfterSlashing;
      allLogMessages.push(...slashingLogs);
    }
    if (limb.state !== 'Destroyed' && limb.currentHp < limb.maxHp) {
      limb.state = 'Injured';
    } else if (limb.state === 'Injured' && limb.currentHp === limb.maxHp) {
      limb.state = 'Healthy';
    }
  }

  return { updatedLimb: limb, logMessages: allLogMessages };
}

export function recalculateCombatantStats(combatant: Combatant, GAME_DATA: GameData): Combatant {
  const newTotalStats = { ...combatant.baseStats };
  const allEffects: StatusEffectInstance[] = [...combatant.statusEffects];
  Object.values(combatant.body).forEach((limb) => allEffects.push(...limb.statusEffects));

  allEffects.forEach((effectInst) => {
    const effectsToApply = getEffectsFromInstance(effectInst, GAME_DATA);

    if (effectsToApply?.stats) {
      for (const stat in effectsToApply.stats) {
        const key = stat as keyof StatBlock;
        (newTotalStats[key] as number) += effectsToApply.stats[key]!;
      }
    }
    if (effectsToApply?.levelScaledStats) {
      for (const stat in effectsToApply.levelScaledStats) {
        const key = stat as keyof StatBlock;
        (newTotalStats[key] as number) += effectsToApply.levelScaledStats[key]! * combatant.level;
      }
    }
  });

  allEffects.forEach((effectInst) => {
    const effectsToApply = getEffectsFromInstance(effectInst, GAME_DATA);

    if (effectsToApply?.statMods) {
      for (const stat in effectsToApply.statMods) {
        const key = stat as keyof StatBlock;
        (newTotalStats[key] as number) *= effectsToApply.statMods[key]!;
      }
    }
  });

  return { ...combatant, totalStats: newTotalStats };
}

export const isCombatantDefeated = (c: { body: BodyPlan<Limb> } | null | undefined): boolean => {
  if (!c || !c.body) return true;
  const head = c.body.head;
  const torso = c.body.torso || c.body.body;
  return (head && head.currentHp <= 0) || (torso && torso.currentHp <= 0);
};

export function calculateHitChance(
  attacker: Combatant,
  target: Combatant,
  limb: Limb,
  selectedAction: { type: string; skillId: AbilityId | null } | null,
  GAME_DATA: GameData
): number {
  if (!selectedAction || selectedAction.type === 'inspect') {
    return -1; // Indicates no calculation
  }

  let abilityAccuracyMod = 1.0;
  if (selectedAction.type === 'skill' && selectedAction.skillId) {
    const ability = GAME_DATA.SKILLS[selectedAction.skillId];
    abilityAccuracyMod = ability.effect.accuracyMod || 1.0;
  }

  const finalAttackerAccuracy = attacker.totalStats.accuracy * abilityAccuracyMod;
  const limbAccuracyMod = limb.accuracyModifier || 1.0;
  const finalLimbAccuracy = finalAttackerAccuracy * limbAccuracyMod;

  return Math.max(0, Math.min(100, 100 * (finalLimbAccuracy / (finalLimbAccuracy + target.totalStats.evasion))));
}

export function processFieldEffectsForState(fieldEffects: FieldEffect[]): FieldEffect[] {
  return fieldEffects.map((fe) => ({ ...fe, turnsRemaining: fe.turnsRemaining - 1 })).filter((fe) => fe.turnsRemaining > 0);
}

export function isCombatEndForState(cs: CombatState): boolean {
  const livingEnemies = Object.values(cs.combatants).filter((c) => c.team === 'enemy' && !isCombatantDefeated(c));
  const livingPlayers = Object.values(cs.combatants).filter((c) => c.team === 'player' && !isCombatantDefeated(c));
  return livingEnemies.length === 0 || livingPlayers.length === 0;
}