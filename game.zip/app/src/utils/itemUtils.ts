import { GameData, ItemId, ItemInstance, Player, ProfessionId, StatBlock } from 'types';

export const ITEM_RARITY_TIERS: Record<number, { name: string; color: string; className: string }> = {
  0: { name: 'Common', color: '#ffffff', className: 'tier-0' },
  1: { name: 'Magic', color: '#57cfff', className: 'tier-1' },
  2: { name: 'Rare', color: '#0070dd', className: 'tier-2' },
  3: { name: 'Very Rare', color: '#1aff00', className: 'tier-3' },
  4: { name: 'Epic', color: '#ff8000', className: 'tier-4' },
  5: { name: 'Legendary', color: '#ff0000', className: 'tier-5' },
  6: { name: 'Mythic', color: '#e71aeb', className: 'tier-6' },
  7: { name: 'Ancient', color: '#8a8a8a', className: 'tier-7' },
  8: { name: 'Divine', color: '#ffd700', className: 'tier-8' },
};

export function getItemTier(item: ItemInstance, GAME_DATA: GameData) {
  if (item.isUnidentified) return ITEM_RARITY_TIERS[0];
  const enchantCount = Object.keys(item.enchantments || {}).length;
  return ITEM_RARITY_TIERS[Math.min(enchantCount, Object.keys(GAME_DATA.ENCHANTS).length)] || ITEM_RARITY_TIERS[0];
}

export function getItemName(itemInstance: ItemInstance, GAME_DATA: GameData): string {
  const baseName = itemInstance.name || GAME_DATA.ITEMS[itemInstance.id]?.name || 'Unknown Item';
  if (itemInstance.plus_value && itemInstance.plus_value !== 0) {
    const sign = itemInstance.plus_value > 0 ? '+' : '';
    return `${baseName} [${sign}${itemInstance.plus_value}]`;
  }
  return baseName;
}

export function getFullItemName(itemInstance: ItemInstance, GAME_DATA: GameData): string {
  const baseName = getItemName(itemInstance, GAME_DATA);

  const tier = getItemTier(itemInstance, GAME_DATA);
  const prefix = tier.name === 'Common' || itemInstance.isUnidentified ? '' : tier.name + ' ';

  return `${prefix}${baseName}`;
}

export function getItemWeight(itemInstance: ItemInstance, GAME_DATA: GameData): number {
  const itemData = GAME_DATA.ITEMS[itemInstance.id];
  const baseWeight = itemInstance.weight !== undefined ? itemInstance.weight : itemData?.weight || 0;

  const hasAntiGravity = !!itemInstance.enchantments?.['univ_anti_gravity'];

  if (itemInstance.containerState) {
    const contentsWeight = itemInstance.containerState.items.reduce((sum, item) => sum + getItemWeight(item, GAME_DATA), 0);
    if (hasAntiGravity) {
      return 0;
    }
    return baseWeight + contentsWeight;
  }

  if (hasAntiGravity) {
    return 0;
  }

  return baseWeight;
}

export interface GroupedItem {
  item: ItemInstance;
  count: number;
  indices: number[];
}

export function groupItems(itemList: ItemInstance[] | undefined, GAME_DATA: GameData): Record<string, GroupedItem> {
  if (!itemList) return {};
  return itemList.reduce((acc, itemInstance, index) => {
    const itemDef = GAME_DATA.ITEMS[itemInstance.id];
    if (!itemDef) {
      console.warn(`Item with ID ${itemInstance.id} not found in GAME_DATA. Skipping.`);
      return acc;
    }

    const hasInstanceData =
      (itemInstance.enchantments && Object.keys(itemInstance.enchantments).length > 0) ||
      (itemInstance.plus_value && itemInstance.plus_value !== 0) ||
      itemInstance.currentDurability !== undefined ||
      (itemInstance.containerState && itemInstance.containerState.items.length > 0) ||
      itemInstance.deceasedCharacter;

    const isStackable = itemDef.stackable && !hasInstanceData;

    const key = isStackable ? `${itemInstance.id}-${itemInstance.isUnidentified}` : itemInstance.unique_id;

    if (!acc[key]) {
      acc[key] = { item: itemInstance, count: 0, indices: [] };
    }
    acc[key].count++;
    acc[key].indices.push(index);
    return acc;
  }, {} as Record<string, GroupedItem>);
}

export function calculateItemValue(item: ItemInstance, GAME_DATA: GameData): number {
  const baseData = GAME_DATA.ITEMS[item.id];
  if (!baseData) return 0;

  let value = baseData.value;

  if (baseData.sellValue !== undefined) {
    return baseData.sellValue;
  }

  value *= 1 + (item.plus_value || 0) * 0.1;

  const enchantCount = Object.keys(item.enchantments || {}).length;
  value += enchantCount * (baseData.itemLevel * 2);

  if (item.isUnidentified) {
    return Math.floor(value / 10) || 1;
  }

  return Math.floor(value);
}

export function calculateItemLevel(item: ItemInstance, GAME_DATA: GameData): number {
  const baseData = GAME_DATA.ITEMS[item.id];
  if (!baseData) return 0;

  let level = baseData.itemLevel;

  level += (item.plus_value || 0) * 2;

  const enchantCount = Object.keys(item.enchantments || {}).length;
  level += enchantCount * 2;

  return level;
}

export function countItems(inventory: ItemInstance[], itemId: ItemId): number {
  return inventory.reduce((count, item) => (item.id === itemId ? count + 1 : count), 0);
}

export function getEquippedToolBonus(player: Player, skill: ProfessionId): number {
  let bonus = 0;
  // This function is simple and doesn't need GAME_DATA passed in yet, as it inspects instances.
  // If it were to need base item data, it would need GAME_DATA.
  // For now, it's okay as is, but it's a candidate for future refactoring if logic expands.
  return bonus;
}

export function createItemInstances(
  itemId: ItemId,
  quantity: number,
  options?: {
    isUnidentified?: boolean;
    plus_value?: number;
    initialDurabilityPercent?: number;
    addRandomEnchantments?: boolean;
  },
  GAME_DATA?: GameData // Optional for calls that might not have it yet
): ItemInstance[] {
  if (!GAME_DATA) {
    console.error(`GAME_DATA not provided to createItemInstances for item: ${itemId}`);
    return [];
  }

  const itemData = GAME_DATA.ITEMS[itemId];
  if (!itemData) {
    console.error(`Attempted to create non-existent item: ${itemId}`);
    return [];
  }

  const isEquipment = itemData.type.includes('equipment');
  const isContainer = itemData.type.includes('container');
  const isUnidentified = options?.isUnidentified !== undefined ? options.isUnidentified : isEquipment;

  const newItems: ItemInstance[] = Array.from({ length: quantity }, () => {
    const newItem: ItemInstance = {
      id: itemId,
      unique_id: `item_${Date.now()}_${Math.random()}`,
      enchantments: {},
      isUnidentified: isUnidentified,
      plus_value: options?.plus_value || 0,
    };

    if (options?.addRandomEnchantments && isEquipment && itemData.slot && GAME_DATA.ENCHANTS) {
      const possibleEnchants = GAME_DATA.ENCHANTS.filter((e) => {
        if (e.type === 'global') return true;
        if (e.type === 'local') {
          if (!e.appliesTo) return true;
          const { hasStat, hasItemType } = e.appliesTo;
          if ((!hasStat || hasStat.length === 0) && (!hasItemType || hasItemType.length === 0)) return true;

          const itemStats = itemData.stats || {};
          const itemTypes = itemData.type || [];

          const statMatch = hasStat && hasStat.some((s) => itemStats[s] !== undefined);
          const typeMatch = hasItemType && hasItemType.some((t) => itemTypes.includes(t));
          return !!(statMatch || typeMatch);
        }
        return false;
      });

      if (possibleEnchants && possibleEnchants.length > 0) {
        const enchantDef = possibleEnchants[Math.floor(Math.random() * possibleEnchants.length)];
        if (enchantDef.scaling && enchantDef.scaling.length > 0) {
          const tier = Math.floor(Math.random() * 3) + 1; // Randomly give a tier 1-3 enchantment
          newItem.enchantments[enchantDef.id] = tier;
        }
      }
    }

    if (itemData.charges) newItem.charges = itemData.charges;
    if (itemData.maxCharges) newItem.maxCharges = itemData.maxCharges;

    if (isContainer) {
      newItem.containerState = {
        items: [],
        capacity: itemData.capacity || 50,
      };
    }

    if (isEquipment && !itemData.isUnarmed) {
      if (itemData.baseDurability) {
        const baseDurability = itemData.baseDurability;
        newItem.maxDurability = baseDurability;

        if (options?.initialDurabilityPercent !== undefined) {
          newItem.currentDurability = Math.max(0, Math.floor(newItem.maxDurability * options.initialDurabilityPercent));
        } else {
          newItem.currentDurability = newItem.maxDurability;
        }
      }

      newItem.isBroken = newItem.currentDurability !== undefined && newItem.currentDurability <= 0;
      newItem.isUnrepairable = false;
    }

    return newItem;
  });

  return newItems;
}