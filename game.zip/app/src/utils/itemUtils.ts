import { PLAYER_INVENTORY_MAX_STACK_SIZE, PLAYER_INVENTORY_MAX_UNIQUE_ITEMS } from 'config/GLOBAL_QUICK_DEV_CONFIGURATION';
import { GameData, GameItem, ItemId, ItemInstance, Player, ProfessionId } from 'types';

export const ITEM_RARITY_TIERS: Record<number, { name: string; color: string; className: string }> = {
  0: { name: 'Common', color: '#ffffff', className: 'tier-0' },
  1: { name: 'Magic', color: '#57cfff', className: 'tier-1' },
  2: { name: 'Rare', color: '#0070dd', className: 'tier-2' },
  3: { name: 'Very Rare', color: '#1aff00', className: 'tier-3' },
  4: { name: 'Epic', color: '#ff8000', className: 'tier-4' },
  5: { name: 'Legendary', color: '#ff0000', className: 'tier-5' },
  6: { name: 'Mythic', color: '#e71aeb', className: 'tier-6' },
  7: { name: 'Ancient', color: '#8a8a8a', className: 'tier-7' },
  8: { name: 'Divine', color: '#ffd700', className: 'tier-8' },
};

export function areEffectivelyEqual(a: ItemInstance, b: ItemInstance): boolean {
  if (a.id !== b.id) return false;
  if ((a.plus_value || 0) !== (b.plus_value || 0)) return false;
  if ((a.isUnidentified || false) !== (b.isUnidentified || false)) return false;
  if ((a.isBroken || false) !== (b.isBroken || false)) return false;

  // Handle undefined cases correctly for durability and charges
  const durA = a.currentDurability;
  const durB = b.currentDurability;
  if ((durA === undefined) !== (durB === undefined)) return false;
  if (durA !== undefined && durB !== undefined && durA.toPrecision(5) !== durB.toPrecision(5)) return false;
  if ((a.maxDurability === undefined) !== (b.maxDurability === undefined)) return false;
  if (a.maxDurability !== undefined && b.maxDurability !== undefined && a.maxDurability !== b.maxDurability) return false;

  const chargesA = a.charges;
  const chargesB = b.charges;
  if ((chargesA === undefined) !== (chargesB === undefined)) return false;
  if (chargesA !== undefined && chargesB !== undefined && chargesA.toPrecision(5) !== chargesB.toPrecision(5)) return false;
  if ((a.maxCharges === undefined) !== (b.maxCharges === undefined)) return false;
  if (a.maxCharges !== undefined && b.maxCharges !== undefined && a.maxCharges !== b.maxCharges) return false;

  // Compare enchantments
  const enchantsA = a.enchantments || {};
  const enchantsB = b.enchantments || {};
  const keysA = Object.keys(enchantsA).sort();
  const keysB = Object.keys(enchantsB).sort();
  if (keysA.length !== keysB.length) return false;
  for (let i = 0; i < keysA.length; i++) {
    if (keysA[i] !== keysB[i] || enchantsA[keysA[i]] !== enchantsB[keysB[i]]) {
      return false;
    }
  }

  // Containers and corpses are special cases that don't stack if they have contents/data
  if (a.containerState?.items?.length || b.containerState?.items?.length) return false;
  if (a.deceasedCharacter || b.deceasedCharacter) return false;

  return true;
}

export function mergeIntoInventory(
  inventory: (ItemInstance | null)[],
  itemsToMerge: ItemInstance[],
  GAME_DATA: GameData,
  options: {
    maxUniqueItems?: number;
    maxStackSize?: number;
  } = {}
): { newInventory: ItemInstance[]; overflow: ItemInstance[] } {
  const { maxUniqueItems = PLAYER_INVENTORY_MAX_UNIQUE_ITEMS, maxStackSize = PLAYER_INVENTORY_MAX_STACK_SIZE } = options;
  let newInventory: (ItemInstance | null)[] = JSON.parse(JSON.stringify(inventory));
  const overflow: ItemInstance[] = [];

  console.log(`[mergeIntoInventory] START. Items to merge: ${itemsToMerge.length}. Options:`, options);

  for (const itemToMerge of itemsToMerge) {
    const itemData = GAME_DATA.ITEMS[itemToMerge.id];
    let quantityToPlace = itemToMerge.quantity;

    console.log(`[mergeIntoInventory] Processing: ${itemData.name} (x${quantityToPlace})`, itemToMerge);

    if (!itemData.stackable) {
      console.log(`[mergeIntoInventory] Item is not stackable.`);
      for (let i = 0; i < quantityToPlace; i++) {
        const firstEmptyIndex = newInventory.indexOf(null);
        if (firstEmptyIndex !== -1 && firstEmptyIndex < maxUniqueItems) {
          newInventory[firstEmptyIndex] = { ...itemToMerge, quantity: 1, unique_id: `item_${Date.now()}_${Math.random()}` };
        } else if (newInventory.filter(Boolean).length < maxUniqueItems) {
          newInventory.push({ ...itemToMerge, quantity: 1, unique_id: `item_${Date.now()}_${Math.random()}` });
        } else {
          overflow.push({ ...itemToMerge, quantity: 1, unique_id: `item_${Date.now()}_${Math.random()}` });
        }
      }
      continue;
    }

    // Phase 1: Fill existing, non-full stacks
    console.log(`[mergeIntoInventory] Phase 1: Filling existing stacks.`);
    for (let i = 0; i < newInventory.length; i++) {
      if (quantityToPlace === 0) break;
      const invItem = newInventory[i];
      if (!invItem) continue;

      const isEqual = areEffectivelyEqual(invItem, itemToMerge);
      const isNotFull = invItem.quantity < maxStackSize;

      if (isEqual && isNotFull) {
        const spaceInStack = maxStackSize - invItem.quantity;
        const amountToAdd = Math.min(quantityToPlace, spaceInStack);
        newInventory[i] = { ...invItem, quantity: invItem.quantity + amountToAdd };
        quantityToPlace -= amountToAdd;
      }
    }

    // Phase 2: Create new stacks if space is available
    console.log(`[mergeIntoInventory] Phase 2: Creating new stacks. Quantity remaining: ${quantityToPlace}`);
    while (quantityToPlace > 0) {
      const firstEmptyIndex = newInventory.indexOf(null);
      const nonNullItems = newInventory.filter(Boolean).length;

      if (firstEmptyIndex === -1 && nonNullItems >= maxUniqueItems) {
        console.warn(`[mergeIntoInventory] Inventory full (${nonNullItems}/${maxUniqueItems}). Overflowing.`);
        const existingOverflowStack = overflow.find((o) => areEffectivelyEqual(o, itemToMerge));
        if (existingOverflowStack) {
          existingOverflowStack.quantity += quantityToPlace;
        } else {
          overflow.push({ ...itemToMerge, quantity: quantityToPlace });
        }
        break; // All remaining quantity is overflowed
      }

      const newStackQuantity = Math.min(quantityToPlace, maxStackSize);
      const newItem = {
        ...itemToMerge,
        quantity: newStackQuantity,
        unique_id: `item_${Date.now()}_${Math.random()}`,
      };

      if (firstEmptyIndex !== -1) {
        newInventory[firstEmptyIndex] = newItem;
      } else {
        newInventory.push(newItem);
      }
      quantityToPlace -= newStackQuantity;
    }
  }
  console.log(`[mergeIntoInventory] END. Final inventory size: ${newInventory.length}. Overflow: ${overflow.length}`);
  return { newInventory: newInventory.filter((i): i is ItemInstance => i !== null), overflow };
}

export function getItemTier(item: ItemInstance, GAME_DATA: GameData) {
  if (item.isUnidentified) return ITEM_RARITY_TIERS[0];
  const enchantCount = Object.keys(item.enchantments || {}).length;
  return ITEM_RARITY_TIERS[Math.min(enchantCount, Object.keys(ITEM_RARITY_TIERS).length - 1)] || ITEM_RARITY_TIERS[0];
}

export function getItemName(itemInstance: ItemInstance, GAME_DATA: GameData): string {
  const baseName = itemInstance.name || GAME_DATA.ITEMS[itemInstance.id]?.name || 'Unknown Item';
  if (itemInstance.plus_value && itemInstance.plus_value !== 0) {
    const sign = itemInstance.plus_value > 0 ? '+' : '';
    return `${baseName} [${sign}${itemInstance.plus_value}]`;
  }
  return baseName;
}

export function getFullItemName(itemInstance: ItemInstance, GAME_DATA: GameData): string {
  const baseName = getItemName(itemInstance, GAME_DATA);

  const tier = getItemTier(itemInstance, GAME_DATA);
  const prefix = tier.name === 'Common' || itemInstance.isUnidentified ? '' : tier.name + ' ';

  return `${prefix}${baseName}`;
}

export function getItemWeight(itemInstance: ItemInstance | null, GAME_DATA: GameData): number {
  if (!itemInstance) {
    return 0;
  }
  const itemData = GAME_DATA.ITEMS[itemInstance.id];
  const baseWeight = itemInstance.weight !== undefined ? itemInstance.weight : itemData?.weight || 0;
  const quantity = itemInstance.quantity || 1;

  const hasAntiGravity = !!itemInstance.enchantments?.['univ_anti_gravity'];

  if (itemInstance.containerState) {
    const contentsWeight = itemInstance.containerState.items.reduce((sum, item) => sum + getItemWeight(item, GAME_DATA), 0);
    if (hasAntiGravity) {
      return 0;
    }
    // Container quantity is always 1 if it has items
    return baseWeight + contentsWeight;
  }

  if (hasAntiGravity) {
    return 0;
  }

  return baseWeight * quantity;
}

export function getWeaponDisplayStat(weapon: ItemInstance, GAME_DATA: GameData): { text: string; value: number; icon: string } | null {
  const weaponData = GAME_DATA.ITEMS[weapon.id];
  let displayValue = 0;
  let baseValue = 0;
  let icon = '⚔️';

  if (weaponData?.stats?.attackPower) {
    baseValue = weaponData.stats.attackPower;
    icon = '⚔️';
  } else if (weaponData?.stats?.spellPower) {
    baseValue = weaponData.stats.spellPower;
    icon = '🥍';
  }

  if (baseValue > 0) {
    displayValue = baseValue;
    const plusValue = weapon.plus_value || 0;
    if (plusValue > 0) {
      displayValue += Math.ceil(baseValue * plusValue * 0.1);
    }
    return { text: `, ${icon}:${displayValue}`, value: displayValue, icon };
  }
  return null;
}

export interface GroupedItem {
  item: ItemInstance;
  count: number;
  indices: number[];
}

function getStackingKey(item: ItemInstance, itemData: GameItem): string {
  if (!itemData.stackable) return item.unique_id;

  if (item.containerState?.items?.length) return item.unique_id;
  if (item.deceasedCharacter) return item.unique_id;

  const parts: (string | number | boolean | undefined)[] = [
    item.id,
    item.plus_value || 0,
    item.isUnidentified || false,
    item.isBroken || false,
    item.currentDurability?.toPrecision(5),
    item.maxDurability,
    item.charges?.toPrecision(5),
    item.maxCharges,
  ];

  const enchantsA = item.enchantments || {};
  const keysA = Object.keys(enchantsA).sort();
  for (const key of keysA) {
    parts.push(key);
    parts.push(enchantsA[key]);
  }

  return parts.join('|');
}

export function groupItems(itemList: (ItemInstance | null)[] | undefined, GAME_DATA: GameData): Record<string, GroupedItem> {
  if (!itemList) return {};
  return itemList.reduce((acc, itemInstance, index) => {
    if (!itemInstance) return acc;

    const itemDef = GAME_DATA.ITEMS[itemInstance.id];
    if (!itemDef) {
      console.warn(`Item with ID ${itemInstance.id} not found in GAME_DATA. Skipping.`);
      return acc;
    }

    const key = getStackingKey(itemInstance, itemDef);

    if (!acc[key]) {
      acc[key] = { item: itemInstance, count: 0, indices: [] };
    }
    acc[key].count += itemInstance.quantity;
    acc[key].indices.push(index);
    return acc;
  }, {} as Record<string, GroupedItem>);
}

export function calculateItemValue(item: ItemInstance, GAME_DATA: GameData): number {
  const baseData = GAME_DATA.ITEMS[item.id];
  if (!baseData) return 0;

  let value = baseData.value;

  if (baseData.sellValue !== undefined) {
    return baseData.sellValue * item.quantity;
  }

  value *= 1 + (item.plus_value || 0) * 0.1;

  const enchantCount = Object.keys(item.enchantments || {}).length;
  value += enchantCount * (baseData.itemLevel * 2);

  if (item.isUnidentified) {
    value = Math.floor(value / 10) || 1;
  }

  return Math.floor(value) * item.quantity;
}

export function calculateItemLevel(item: ItemInstance, GAME_DATA: GameData): number {
  const baseData = GAME_DATA.ITEMS[item.id];
  if (!baseData) return 0;
  return baseData.itemLevel;
}

export function calculateItemTier(itemLevel: number): number {
  return Math.floor(itemLevel / 10) + 1;
}

export function countItems(inventory: (ItemInstance | null)[], itemId: ItemId): number {
  return inventory.reduce((count, item) => (item && item.id === itemId ? count + item.quantity : count), 0);
}

export function getEquippedToolBonus(player: Player, skill: ProfessionId): number {
  let bonus = 0;
  // This function is simple and doesn't need GAME_DATA passed in yet, as it inspects instances.
  // If it were to need base item data, it would need GAME_DATA.
  // For now, it's okay as is, but it's a candidate for future refactoring if logic expands.
  return bonus;
}

export function createItemInstances(
  itemId: ItemId,
  quantity: number,
  options?: {
    isUnidentified?: boolean;
    plus_value?: number;
    initialDurabilityPercent?: number;
    addRandomEnchantments?: boolean;
  },
  GAME_DATA?: GameData // Optional for calls that might not have it yet
): ItemInstance[] {
  if (!GAME_DATA) {
    console.error(`GAME_DATA not provided to createItemInstances for item: ${itemId}`);
    return [];
  }

  const itemData = GAME_DATA.ITEMS[itemId];
  if (!itemData) {
    console.error(`Attempted to create non-existent item: ${itemId}`);
    return [];
  }

  const createSingleInstance = (q: number): ItemInstance => {
    const isEquipment = itemData.type.includes('equipment');
    const isUnidentified = options?.isUnidentified !== undefined ? options.isUnidentified : isEquipment;

    const newItem: ItemInstance = {
      id: itemId,
      unique_id: `item_${Date.now()}_${Math.random()}`,
      quantity: q,
      enchantments: {},
      isUnidentified: isUnidentified,
      plus_value: options?.plus_value || 0,
    };

    if (itemData.charges) newItem.charges = itemData.charges;
    if (itemData.maxCharges) newItem.maxCharges = itemData.maxCharges;

    if (itemData.type.includes('container')) {
      newItem.containerState = {
        items: [],
        capacity: itemData.capacity || 50,
      };
    }

    if (isEquipment && !itemData.isUnarmed) {
      if (itemData.baseDurability) {
        newItem.maxDurability = itemData.baseDurability;
        if (options?.initialDurabilityPercent !== undefined) {
          newItem.currentDurability = Math.max(0, Math.floor(newItem.maxDurability * options.initialDurabilityPercent));
        } else {
          newItem.currentDurability = newItem.maxDurability;
        }
        newItem.isBroken = newItem.currentDurability <= 0;
      }
      newItem.isUnrepairable = false;
    }

    return newItem;
  };

  if (!itemData.stackable) {
    const newItems: ItemInstance[] = [];
    for (let i = 0; i < quantity; i++) {
      newItems.push(createSingleInstance(1));
    }
    return newItems;
  }

  // If we are adding random enchantments, each item must be unique.
  if (options?.addRandomEnchantments) {
    const newItems: ItemInstance[] = [];
    for (let i = 0; i < quantity; i++) {
      const newItem = createSingleInstance(1);
      const isEquipment = itemData.type.includes('equipment');
      if (isEquipment && itemData.slot && GAME_DATA.ENCHANTS) {
        const possibleEnchants = GAME_DATA.ENCHANTS.filter((e) => {
          if (e.type === 'global') return true;
          if (e.type === 'local') {
            if (!e.appliesTo) return true;
            const { hasStat, hasItemType } = e.appliesTo;
            if ((!hasStat || hasStat.length === 0) && (!hasItemType || hasItemType.length === 0)) return true;
            const itemStats = itemData.stats || {};
            const itemTypes = itemData.type || [];
            const statMatch = hasStat && hasStat.some((s) => itemStats[s] !== undefined);
            const typeMatch = hasItemType && hasItemType.some((t) => itemTypes.includes(t));
            return !!(statMatch || typeMatch);
          }
          return false;
        });

        if (possibleEnchants.length > 0) {
          const enchantDef = possibleEnchants[Math.floor(Math.random() * possibleEnchants.length)];
          if (enchantDef.scaling && enchantDef.scaling.length > 0) {
            const tier = Math.floor(Math.random() * 3) + 1; // Randomly give a tier 1-3 enchantment
            newItem.enchantments[enchantDef.id] = tier;
          }
        }
      }
      newItems.push(newItem);
    }
    return newItems;
  }

  const newItems: ItemInstance[] = [];
  let remainingQuantity = quantity;
  while (remainingQuantity > 0) {
    const stackQuantity = Math.min(remainingQuantity, PLAYER_INVENTORY_MAX_STACK_SIZE);
    newItems.push(createSingleInstance(stackQuantity));
    remainingQuantity -= stackQuantity;
  }
  return newItems;
}