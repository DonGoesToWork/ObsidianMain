import { Player, ItemInstance, ItemId, ProfessionId, PlayerEquipmentSlot, ItemQuality, GameData } from 'types';
import { generateRandomQuality } from './gameMechanics';

export const ITEM_TIERS: Record<number, { name: string; color: string; className: string }> = {
  0: { name: 'Common', color: '#ffffff', className: 'tier-0' },
  1: { name: 'Enchanted', color: '#87ceeb', className: 'tier-1' },
  2: { name: 'Rare', color: '#0070dd', className: 'tier-2' },
  3: { name: 'Very Rare', color: '#1eff00', className: 'tier-3' },
  4: { name: 'Epic', color: '#ff8000', className: 'tier-4' },
  5: { name: 'Legendary', color: '#ff4500', className: 'tier-5' },
  6: { name: 'Artifact', color: '#a335ee', className: 'tier-6' },
  7: { name: 'Divine', color: '#ffd700', className: 'tier-7' },
};

export const ITEM_QUALITY_ORDER: ItemQuality[] = ['Poor', 'Average', 'Good', 'Great', 'Exceptional', 'Masterwork', 'One-of-a-kind'];

export function getQualityGrade(quality: ItemQuality | undefined): number {
  if (!quality) return ITEM_QUALITY_ORDER.indexOf('Average');
  return ITEM_QUALITY_ORDER.indexOf(quality);
}

export function getItemTier(item: ItemInstance, GAME_DATA: GameData) {
  if (item.isUnidentified) return ITEM_TIERS[0];
  const enchantCount = Object.keys(item.enchantments || {}).length;
  return ITEM_TIERS[Math.min(enchantCount, 7)] || ITEM_TIERS[0];
}

export function getItemName(itemInstance: ItemInstance, GAME_DATA: GameData): string {
  if (itemInstance.name) return itemInstance.name;
  if (itemInstance.isUnidentified) return 'Unidentified Item';
  const itemData = GAME_DATA.ITEMS[itemInstance.id];
  if (itemData) {
    return itemData.name;
  }
  return 'Unknown Item';
}

export function getItemWeight(itemInstance: ItemInstance, GAME_DATA: GameData): number {
  const itemData = GAME_DATA.ITEMS[itemInstance.id];
  let totalWeight = itemInstance.weight !== undefined ? itemInstance.weight : itemData?.weight || 0;

  if (itemInstance.containerState) {
    totalWeight += itemInstance.containerState.items.reduce((sum, item) => sum + getItemWeight(item, GAME_DATA), 0);
  }
  return totalWeight;
}

export interface GroupedItem {
  item: ItemInstance;
  count: number;
  indices: number[];
}

export function groupItems(itemList: ItemInstance[] | undefined, GAME_DATA: GameData): Record<string, GroupedItem> {
  if (!itemList) return {};
  return itemList.reduce((acc, itemInstance, index) => {
    const itemDef = GAME_DATA.ITEMS[itemInstance.id];
    if (!itemDef) {
      console.warn(`Item with ID ${itemInstance.id} not found in GAME_DATA. Skipping.`);
      return acc;
    }

    const hasInstanceData =
      (itemInstance.enchantments && Object.keys(itemInstance.enchantments).length > 0) ||
      (itemInstance.quality && itemDef.type.includes('equipment')) ||
      itemInstance.currentDurability !== undefined ||
      (itemInstance.containerState && itemInstance.containerState.items.length > 0) ||
      itemInstance.deceasedCharacter;

    const isStackable = itemDef.stackable && !hasInstanceData;

    const key = isStackable ? `${itemInstance.id}-${itemInstance.isUnidentified}` : itemInstance.unique_id;

    if (!acc[key]) {
      acc[key] = { item: itemInstance, count: 0, indices: [] };
    }
    acc[key].count++;
    acc[key].indices.push(index);
    return acc;
  }, {} as Record<string, GroupedItem>);
}

export function calculateItemValue(item: ItemInstance, GAME_DATA: GameData): number {
  const baseData = GAME_DATA.ITEMS[item.id];
  if (!baseData) return 0;

  let value = baseData.value;

  if (baseData.sellValue !== undefined) {
    return baseData.sellValue;
  }

  if (item.quality) {
    const qualityMultiplier = GAME_DATA.ITEM_QUALITIES[item.quality]?.multiplier || 1.0;
    value *= qualityMultiplier;
  }

  const enchantCount = Object.keys(item.enchantments || {}).length;
  value += enchantCount * (baseData.itemLevel * 2);

  if (item.isUnidentified) {
    return Math.floor(value / 10) || 1;
  }

  return Math.floor(value);
}

export function calculateItemLevel(item: ItemInstance, GAME_DATA: GameData): number {
  const baseData = GAME_DATA.ITEMS[item.id];
  if (!baseData) return 0;

  let level = baseData.itemLevel;

  if (item.quality) {
    const qualityMultiplier = GAME_DATA.ITEM_QUALITIES[item.quality]?.multiplier || 1.0;
    level += Math.floor(baseData.itemLevel * (qualityMultiplier - 1.0));
  }

  const enchantCount = Object.keys(item.enchantments || {}).length;
  level += enchantCount * 2;

  return level;
}

export function countItems(inventory: ItemInstance[], itemId: ItemId): number {
  return inventory.reduce((count, item) => (item.id === itemId ? count + 1 : count), 0);
}

export function getEquippedToolBonus(player: Player, skill: ProfessionId): number {
  let bonus = 0;
  // This function is simple and doesn't need GAME_DATA passed in yet, as it inspects instances.
  // If it were to need base item data, it would need GAME_DATA.
  // For now, it's okay as is, but it's a candidate for future refactoring if logic expands.
  return bonus;
}

export function createItemInstances(
  itemId: ItemId,
  quantity: number,
  options?: {
    isUnidentified?: boolean;
    quality?: ItemQuality;
    initialDurabilityPercent?: number;
  },
  GAME_DATA?: GameData // Optional for calls that might not have it yet
): ItemInstance[] {
  if (!GAME_DATA) {
    console.error(`GAME_DATA not provided to createItemInstances for item: ${itemId}`);
    return [];
  }

  const itemData = GAME_DATA.ITEMS[itemId];
  if (!itemData) {
    console.error(`Attempted to create non-existent item: ${itemId}`);
    return [];
  }

  const isEquipment = itemData.type.includes('equipment');
  const isContainer = itemData.type.includes('container');
  const isUnidentified = options?.isUnidentified !== undefined ? options.isUnidentified : isEquipment;

  const newItems: ItemInstance[] = Array.from({ length: quantity }, () => {
    const quality = isEquipment ? options?.quality || generateRandomQuality() : undefined;
    const newItem: ItemInstance = {
      id: itemId,
      unique_id: `item_${Date.now()}_${Math.random()}`,
      enchantments: {},
      isUnidentified: isUnidentified,
      quality: quality,
    };
    if (itemData.charges) newItem.charges = itemData.charges;
    if (itemData.maxCharges) newItem.maxCharges = itemData.maxCharges;

    if (isContainer) {
      newItem.containerState = {
        items: [],
        capacity: itemData.capacity || 50,
      };
    }

    if (isEquipment && !itemData.isUnarmed) {
      if (itemData.baseDurability) {
        const baseDurability = itemData.baseDurability;
        const qualityMultiplier = quality ? GAME_DATA.ITEM_QUALITIES[quality].multiplier : 1.0;
        newItem.maxDurability = Math.round(baseDurability * qualityMultiplier);

        if (options?.initialDurabilityPercent !== undefined) {
          newItem.currentDurability = Math.max(0, Math.floor(newItem.maxDurability * options.initialDurabilityPercent));
        } else {
          newItem.currentDurability = newItem.maxDurability;
        }
      }

      newItem.isBroken = newItem.currentDurability !== undefined && newItem.currentDurability <= 0;
      newItem.isUnrepairable = false;
    }

    return newItem;
  });

  return newItems;
}