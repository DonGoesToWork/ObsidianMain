import { calculateCharacterStats, calculateXpToNextLevel } from '../services/statService';
import { GameData, Mercenary, MercenaryArchetypeId, PlayerEquipmentSlot } from '../types';

export function generateMercenary(locationLevel: number, GAME_DATA: GameData): Mercenary {
  const archetypes = Object.keys(GAME_DATA.MERCENARIES) as MercenaryArchetypeId[];
  const archetypeId = archetypes[Math.floor(Math.random() * archetypes.length)];
  const archetype = GAME_DATA.MERCENARIES[archetypeId];

  const level = Math.max(1, locationLevel + Math.floor(Math.random() * 5) - 2); // +/- 2 levels from location
  console.log(`Generating mercenary for location level ${locationLevel}. Final level: ${level}`);

  const merc: Mercenary = {
    id: `merc_${Date.now()}_${Math.random()}`,
    mercenaryId: archetypeId,
    name: archetype.name,
    race: archetype.race,
    class: archetype.class,
    level: level,
    xp: 0,
    xpToNextLevel: calculateXpToNextLevel(level),
    baseStats: { ...GAME_DATA.CLASSES[archetype.class].baseStats },
    totalStats: {} as any, // will be calculated
    equipment: {
      head: null,
      chest: null,
      groin: null,
      right_armlet: null,
      left_armlet: null,
      right_glove: null,
      left_glove: null,
      right_legging: null,
      left_legging: null,
      right_foot: null,
      left_foot: null,
      weapon: null,
      shield: null,
      amulet1: null,
      amulet2: null,
      left_ring: null,
      right_ring: null,
    },
    inventory: [],
    body: {} as any, // will be calculated
    statusEffects: [],
    skills: {},
    mp: 0,
    maxMp: 0,
    sp: 0,
    maxSp: 0,
    baseWeight: GAME_DATA.RACES[archetype.race].baseWeight,
    currentWeight: 0,
    maxCarryWeight: 0,
    initialCost: archetype.baseCost * level,
    dailyCost: archetype.baseDailyCost * level,
    happiness: 50,
    gold: 0,
    fleeHealthThreshold: archetype.fleeThreshold,
    vitals: {
      hunger: { current: 100, max: 100 },
      thirst: { current: 100, max: 100 },
      alertness: { current: 100, max: 100 },
      courage: { current: 100, max: 100 },
    },
  };

  archetype.skillPool.forEach((skillId) => {
    merc.skills[skillId] = { rank: 1 };
  });

  merc.baseStats.strength = 10;
  merc.baseStats.constitution = 10;
  merc.baseStats.intelligence = 10;
  merc.baseStats.dexterity = 10;

  for (let i = 1; i < level; i++) {
    merc.baseStats.strength += archetype.statGrowth.strength;
    merc.baseStats.constitution += archetype.statGrowth.constitution;
    merc.baseStats.intelligence += archetype.statGrowth.intelligence;
    merc.baseStats.dexterity += archetype.statGrowth.dexterity;
  }

  for (const slot in archetype.equipmentPool) {
    const itemPool = archetype.equipmentPool[slot as PlayerEquipmentSlot];
    if (itemPool && itemPool.length > 0) {
      const itemId = itemPool[Math.floor(Math.random() * itemPool.length)];
      merc.equipment[slot as PlayerEquipmentSlot] = {
        id: itemId,
        unique_id: `item_${Date.now()}_${Math.random()}`,
        quantity: 1,
        enchantments: {},
        plus_value: 0,
      };
    }
  }

  const calculatedMerc = calculateCharacterStats(merc, GAME_DATA)!;
  calculatedMerc.mp = calculatedMerc.maxMp;
  calculatedMerc.sp = calculatedMerc.maxSp;
  Object.values(calculatedMerc.body).forEach((limb) => {
    limb.currentHp = limb.maxHp;
  });

  return calculatedMerc;
}