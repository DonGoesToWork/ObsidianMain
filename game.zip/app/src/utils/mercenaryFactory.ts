import { Mercenary, MercenaryArchetypeId, PlayerEquipmentSlot, GameData } from "../types";
import { calculateXpToNextLevel, calculateCharacterStats } from "../services/statService";

export function generateMercenary(playerLevel: number, GAME_DATA: GameData): Mercenary {
  const archetypes = Object.keys(GAME_DATA.MERCENARIES) as MercenaryArchetypeId[];
  const archetypeId = archetypes[Math.floor(Math.random() * archetypes.length)];
  const archetype = GAME_DATA.MERCENARIES[archetypeId];

  const level = Math.max(1, playerLevel + Math.floor(Math.random() * 5) - 2); // +/- 2 levels from player

  const merc: Mercenary = {
    id: `merc_${Date.now()}_${Math.random()}`,
    mercenaryId: archetypeId,
    name: archetype.name,
    race: archetype.race,
    class: archetype.class,
    level: level,
    xp: 0,
    xpToNextLevel: calculateXpToNextLevel(level),
    baseStats: { ...GAME_DATA.CLASSES[archetype.class].baseStats },
    totalStats: {} as any, // will be calculated
    equipment: {
      head: null,
      chest: null,
      legs: null,
      weapon: null,
      shield: null,
      amulet: null,
      ring1: null,
      ring2: null,
    },
    inventory: [],
    body: {} as any, // will be calculated
    statusEffects: [],
    skills: {},
    mp: 0,
    maxMp: 0,
    sp: 0,
    maxSp: 0,
    baseWeight: GAME_DATA.RACES[archetype.race].baseWeight,
    currentWeight: 0,
    maxWeight: 0,
    initialCost: archetype.baseCost * level,
    dailyCost: archetype.baseDailyCost * level,
    happiness: 50,
    gold: 0,
    fleeHealthThreshold: archetype.fleeThreshold,
    vitals: {
      hunger: { current: 100, max: 100 },
      thirst: { current: 100, max: 100 },
      alertness: { current: 100, max: 100 },
      courage: { current: 100, max: 100 },
    },
  };

  archetype.skillPool.forEach((skillId) => {
    merc.skills[skillId] = { rank: 1 };
  });

  for (let i = 1; i < level; i++) {
    merc.baseStats.strength += archetype.statGrowth.strength;
    merc.baseStats.constitution += archetype.statGrowth.constitution;
    merc.baseStats.intelligence += archetype.statGrowth.intelligence;
    merc.baseStats.dexterity += archetype.statGrowth.dexterity;
  }

  for (const slot in archetype.equipmentPool) {
    const itemPool = archetype.equipmentPool[slot as PlayerEquipmentSlot];
    if (itemPool && itemPool.length > 0) {
      const itemId = itemPool[Math.floor(Math.random() * itemPool.length)];
      merc.equipment[slot as PlayerEquipmentSlot] = {
        id: itemId,
        unique_id: `item_${Date.now()}_${Math.random()}`,
        enchantments: {},
        quality: "Average",
      };
    }
  }

  const calculatedMerc = calculateCharacterStats(merc, GAME_DATA)!;
  calculatedMerc.mp = calculatedMerc.maxMp;
  calculatedMerc.sp = calculatedMerc.maxSp;
  Object.values(calculatedMerc.body).forEach((limb) => {
    limb.currentHp = limb.maxHp;
  });

  return calculatedMerc;
}