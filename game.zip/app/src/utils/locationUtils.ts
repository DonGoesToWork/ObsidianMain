import { GameLocation, Zone } from 'types';

export function mapZoneTypeToLocationType(zoneType: Zone['type']): GameLocation['type'] {
  if (zoneType === 'dungeon') return 'dungeon';
  if (zoneType === 'town') return 'town';
  return 'wilds'; // Default for 'wilderness' and undefined
}

export function createLocationFromZone(zoneId: string, zoneData: Zone): GameLocation {
  return {
    id: zoneId,
    name: zoneData.name,
    type: mapZoneTypeToLocationType(zoneData.type),
    pos: zoneData.pos,
    levelReq: zoneData.levelReq,
    dangerLevel: zoneData.dangerLevel ?? 0,
    gather: zoneData.gather || [],
    monsterPacks: zoneData.monsterPacks,
    stages: zoneData.stages,
    monsters: zoneData.monsters,
    boss: zoneData.boss,
    groundLoot: [],
  };
}