export function calculateDistance(
  pos1: { x: number; y: number },
  pos2: { x: number; y: number },
) {
  return Math.sqrt(Math.pow(pos2.x - pos1.x, 2) + Math.pow(pos2.y - pos1.y, 2));
}
