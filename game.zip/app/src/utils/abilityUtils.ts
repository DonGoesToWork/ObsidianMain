import { Player, Ability, AbilityId, GameData } from 'types';

export function getAbilityDescription(ability: Ability, rank: number): string {
  let desc = ability.desc;

  const placeholderRegex = /(\d*\.?\d+%?)\s*(\[\+(\d*\.?\d+%?)\s*per rank\])/g;

  desc = desc.replace(placeholderRegex, (match: string, baseValue: string, scalingText: string, perRankValue: string) => {
    const isPercent = baseValue.includes('%');
    const baseNum = parseFloat(baseValue);
    const perRankNum = parseFloat(perRankValue);

    const effectiveRank = Math.max(1, rank);
    const totalValue = baseNum + perRankNum * (effectiveRank - 1);

    const displayedValue = isPercent ? totalValue.toFixed(0) + '%' : totalValue;
    return `${displayedValue} ${scalingText}`;
  });

  const simplePlaceholderRegex = /(\d+)\s*(\w+)\s*\[\+(\d+)\s*\w*\s*per rank\]/g;
  desc = desc.replace(simplePlaceholderRegex, (match: string, baseValue: string, unit: string, perRankValue: string) => {
    const baseNum = parseInt(baseValue, 10);
    const perRankNum = parseInt(perRankValue, 10);
    const effectiveRank = Math.max(1, rank);
    const totalValue = baseNum + perRankNum * (effectiveRank - 1);
    return `${totalValue} ${unit}`;
  });

  const passiveRegex = /by (\d*\.?\d+%?) per rank/g;
  desc = desc.replace(passiveRegex, (match: string, perRankValue: string) => {
    const isPercent = perRankValue.includes('%');
    const perRankNum = parseFloat(perRankValue);
    const totalValue = perRankNum * rank;
    return `by ${isPercent ? totalValue.toFixed(0) + '%' : totalValue}`;
  });

  return desc;
}

export function canLearnAbility(player: Player, abilityId: AbilityId, GAME_DATA: GameData) {
  const ability = GAME_DATA.SKILLS[abilityId];
  if (!ability) return { can: false, reason: 'Ability not found.' };
  if (ability.abilityType === 'Perk' && player.perkPoints <= 0) return { can: false, reason: 'No perk points.' };
  const currentRank = player.skills[abilityId]?.rank || 0;
  if (ability.maxRank && currentRank >= ability.maxRank) return { can: false, reason: 'Max rank.' };
  if (ability.levelReq && player.level < ability.levelReq) return { can: false, reason: `Requires level ${ability.levelReq}.` };
  if (ability.reqSkill && !player.skills[ability.reqSkill])
    return {
      can: false,
      reason: `Requires ${GAME_DATA.SKILLS[ability.reqSkill].name}.`,
    };
  return { can: true, reason: '' };
}

export function getUnlearnedAbilities(player: Player | null, GAME_DATA: GameData) {
  if (!player) return [];
  const allAbilityIds = Object.keys(GAME_DATA.SKILLS) as AbilityId[];
  return allAbilityIds.filter((id) => !player.skills[id]);
}

export function groupAbilitiesByTypeAndCategory(abilityIds: AbilityId[], GAME_DATA: GameData): Record<'active' | 'passive', Record<string, [AbilityId, Ability][]>> {
  return abilityIds.reduce((acc, abilityId) => {
    const ability = GAME_DATA.SKILLS[abilityId];
    if (!ability) return acc;

    const typeKey = ability.abilityType === 'Perk' ? 'passive' : 'active';
    const category = ability.category || 'General';

    if (!acc[typeKey]) acc[typeKey] = {};
    if (!acc[typeKey][category]) acc[typeKey][category] = [];
    acc[typeKey][category].push([abilityId, ability]);
    return acc;
  }, {} as Record<'active' | 'passive', Record<string, [AbilityId, Ability][]>>);
}
