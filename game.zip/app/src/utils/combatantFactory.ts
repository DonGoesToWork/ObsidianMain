import { Player, Mercenary, Combatant, MonsterId, Equipment, ItemId, TotalPlayerStats, StatBlock, GameData } from "types";
import { instantiateBodyPlan } from "./bodyUtils";
import { createItemInstances } from "./itemUtils";

export function createPlayerCombatant(player: Player): Combatant {
  return {
    id: "player",
    type: "player",
    name: player.name,
    race: player.race,
    class: player.class,
    level: player.level,
    mp: player.mp,
    maxMp: player.maxMp,
    sp: player.sp,
    maxSp: player.maxSp,
    baseStats: { ...player.totalStats },
    stats: { ...player.totalStats },
    statusEffects: player.statusEffects.filter((e) => e.turnsRemaining > 0),
    skills: player.skills,
    equipment: player.equipment,
    inventory: player.inventory,
    team: "player",
    body: JSON.parse(JSON.stringify(player.body)),
    lastAction: player.lastAction,
    baseWeight: player.baseWeight,
    currentWeight: player.currentWeight,
    maxWeight: player.maxWeight,
  };
}

export function createMercenaryCombatant(merc: Mercenary): Combatant {
  return {
    id: merc.id,
    type: "mercenary",
    name: merc.name,
    race: merc.race,
    class: merc.class,
    level: merc.level,
    mp: merc.mp,
    maxMp: merc.maxMp,
    sp: merc.sp,
    maxSp: merc.maxSp,
    baseStats: { ...merc.totalStats },
    stats: { ...merc.totalStats },
    statusEffects: merc.statusEffects.filter((e) => e.turnsRemaining > 0),
    skills: merc.skills,
    equipment: merc.equipment,
    inventory: merc.inventory,
    team: "player",
    body: JSON.parse(JSON.stringify(merc.body)),
    lastAction: merc.lastAction,
    mercenaryInstanceId: merc.id,
    baseWeight: merc.baseWeight,
    currentWeight: merc.currentWeight,
    maxWeight: merc.maxWeight,
  };
}

export function createMonsterCombatant(monsterId: MonsterId, index: number, GAME_DATA: GameData): Combatant {
  const monsterData = GAME_DATA.MONSTERS[monsterId];
  const inferredConstitution = monsterData.hp / 10;
  const monsterTotalHp = 50 + inferredConstitution * 10;

  const monsterTemplate = GAME_DATA.BODY_PLANS.getMonsterTemplate(monsterData);
  const monsterBody = instantiateBodyPlan(monsterTemplate, monsterTotalHp, undefined);
  const id = `monster-${index}`;

  const combatantEquipment: Equipment = {
    head: null,
    chest: null,
    legs: null,
    weapon: null,
    shield: null,
    amulet: null,
    ring1: null,
    ring2: null,
  };

  if (monsterData.equipment) {
    for (const slot in monsterData.equipment) {
      const itemId = monsterData.equipment[slot as keyof Equipment];
      if (itemId) {
        const [newItem] = createItemInstances(itemId, 1, { quality: "Average", isUnidentified: false }, GAME_DATA);
        combatantEquipment[slot as keyof Equipment] = newItem;
      }
    }
  }

  if (!combatantEquipment.weapon && monsterData.unarmedWeapon) {
    const [unarmed] = createItemInstances(monsterData.unarmedWeapon, 1, undefined, GAME_DATA);
    combatantEquipment.weapon = unarmed;
  }

  const baseStats: TotalPlayerStats = {
    strength: monsterData.attack,
    constitution: inferredConstitution,
    intelligence: 0,
    dexterity: monsterData.level,
    luck: 0,
    attackPower: monsterData.attack,
    spellPower: 0,
    armor: monsterData.armor,
    critChance: 5,
    goldFind: 0,
    xpGain: 0,
    worldHpRegen: 0,
    worldMpRegen: 0,
    worldSpRegen: 0,
    onHitEffects: [],
    accuracy: 100 + monsterData.level,
    evasion: 50 + monsterData.level,
    attackSpeed: 1,
    maxHp: monsterTotalHp,
    maxMp: 0,
    maxSp: 100,
  };

  const weapon = combatantEquipment.weapon;
  if (weapon) {
    const weaponData = GAME_DATA.ITEMS[weapon.id];
    if (weaponData && weaponData.stats) {
      for (const stat in weaponData.stats) {
        const key = stat as keyof StatBlock;
        (baseStats[key] as number) = ((baseStats[key] as number) || 0) + weaponData.stats[key]!;
      }
    }
  }

  const inventoryWeight = monsterData.lootTable
    ? Object.keys(monsterData.lootTable).reduce((acc, itemId) => {
        const item = GAME_DATA.ITEMS[itemId as ItemId];
        return acc + (item?.weight || 0);
      }, 0)
    : 0;

  const baseWeight = GAME_DATA.RACES[monsterData.race].baseWeight;

  return {
    id,
    monsterId,
    type: "enemy",
    name: monsterData.name,
    race: monsterData.race,
    class: monsterData.class,
    level: monsterData.level,
    mp: 0,
    maxMp: 0,
    sp: 100,
    maxSp: 100,
    body: monsterBody,
    inventory: [],
    statusEffects: [],
    team: "enemy",
    behavior: monsterData.behavior,
    abilities: monsterData.abilities,
    equipment: combatantEquipment,
    baseStats: baseStats,
    stats: { ...baseStats },
    skills: {},
    lastAction: null,
    gold: monsterData.gold,
    baseWeight: baseWeight,
    currentWeight: baseWeight + inventoryWeight,
    maxWeight: monsterData.level * 5 + 50,
  };
}

export function createCombatantFromCharacter(char: Player | Mercenary): Combatant {
  const isPlayer = "professions" in char;
  if (isPlayer) {
    return createPlayerCombatant(char as Player);
  } else {
    return createMercenaryCombatant(char as Mercenary);
  }
}