import { GameData, GameItem, ItemInstance } from "types";
import { formatDuration } from "./formatUtils";

export function getPotionEffectDescription(
  item: ItemInstance,
  itemData: GameItem,
  GAME_DATA: GameData,
): string | null {
  if (!itemData.type.includes("potion")) return null;

  if (itemData.effect?.applyStatusEffect) {
    const {
      id: effectId,
      durationInMinutes,
      turns,
    } = itemData.effect.applyStatusEffect;
    const effectData = GAME_DATA.STATUS_EFFECTS[effectId];

    if (!effectData) return null;
    if (!durationInMinutes && !turns) return effectData.desc; // For instant effects without duration

    let parts: string[] = [];

    const stats = effectData.effects?.stats;
    if (stats) {
      if (stats.worldHpRegen) {
        parts.push(`+${(stats.worldHpRegen * 60).toFixed(1)} HP/hr`);
      }
      if (stats.worldMpRegen) {
        parts.push(`+${(stats.worldMpRegen * 60).toFixed(1)} MP/hr`);
      }
      if (stats.worldSpRegen) {
        parts.push(`+${(stats.worldSpRegen * 60).toFixed(1)} SP/hr`);
      }
    }

    if (parts.length === 0) {
      parts.push(effectData.name);
    }

    if (durationInMinutes) {
      const durationHours = durationInMinutes / 60;
      parts.push(`for ${durationHours} hour(s)`);
    } else if (turns) {
      parts.push(`for ${turns} turn(s)`);
    }

    return parts.join(" ");
  }

  if (itemData.effect?.cureStatusEffect) {
    const effectId = itemData.effect.cureStatusEffect;
    const effectName = GAME_DATA.STATUS_EFFECTS[effectId]?.name || "an ailment";
    return `Cures ${effectName}.`;
  }

  if (itemData.effect?.revive) {
    return `Revives a fallen ally, restoring them to ${itemData.effect.revive.percentHealth}% health.`;
  }

  if (itemData.effect?.closesCutOfStage) {
    return `Closes an open wound up to Stage ${itemData.effect.closesCutOfStage}.`;
  }

  return null;
}