import { ItemId } from 'types';

export function getLoot(lootTable: Record<ItemId, number>): ItemId[] {
  const loot: ItemId[] = [];
  for (const itemId in lootTable) {
    if (Math.random() < lootTable[itemId as ItemId]) {
      loot.push(itemId as ItemId);
    }
  }
  return loot;
}

/**
 * Calculates a bonus multiplier based on skill difference.
 * @param skillLevel The player's current skill level.
 * @param difficultyLevel The difficulty level of the activity.
 * @returns A multiplier, typically between 0 (huge disadvantage) and 2.0 (huge advantage).
 */
export function calculateDifficultyBonus(skillLevel: number, difficultyLevel: number): number {
  const diff = skillLevel - difficultyLevel;
  const clampedDiff = Math.max(-10, Math.min(10, diff));

  // This creates a curve where being 10 levels below is near 0% success/bonus,
  // and 10 levels above gives a 100% bonus (2.0 multiplier).
  // Level match (diff 0) gives a 1.0 multiplier.
  return 1 + clampedDiff / 10;
}