import { instantiateBodyPlan } from 'utils/bodyUtils';
import { getItemWeight } from 'utils/itemUtils';
import { GameData, Mercenary, Player } from '../../types';

type CalculableCharacter = Player | Mercenary;

function isPlayer(char: CalculableCharacter): char is Player {
  return 'professions' in char;
}

export function calculateBodyPlanAndArmor<T extends CalculableCharacter>(character: T, GAME_DATA: GameData): T {
  const charWithBody = { ...character };
  const baseHp = character.totalStats.maxHp;

  // Players and Mercenaries are both humanoid and use the player template.
  // Monsters have their body plans assigned at creation time in the combatant factory.
  const template = GAME_DATA.BODY_PLANS.getPlayerTemplate();

  charWithBody.body = instantiateBodyPlan(template, baseHp, character.body);

  let totalArmor = charWithBody.totalStats.armor;
  for (const limbId in charWithBody.body) {
    const limb = charWithBody.body[limbId];
    limb.armorValue = 0;
    for (const slotId of limb.equipmentSlots) {
      const item = charWithBody.equipment[slotId];
      if (item && !item.isBroken) {
        const itemData = GAME_DATA.ITEMS[item.id];
        if (itemData?.stats?.armor) {
          const baseArmor = itemData.stats.armor;
          let totalArmorOnItem = baseArmor;
          const plusValue = item.plus_value || 0;
          if (plusValue > 0) {
            totalArmorOnItem += Math.ceil(baseArmor * plusValue * 0.1);
          }
          limb.armorValue += totalArmorOnItem;
        }

        if (item.enchantments) {
          for (const enchantId in item.enchantments) {
            const tier = item.enchantments[enchantId];
            if (tier === undefined) continue;
            const enchantDef = GAME_DATA.ENCHANTS.find((e) => e.id === enchantId);
            if (!enchantDef || enchantDef.stat !== 'armor') continue;
            const value = enchantDef.scaling[tier - 1];
            if (value !== undefined) {
              limb.armorValue += value;
            }
          }
        }
      }
    }
    limb.armorValue = Math.round(limb.armorValue);
    totalArmor += limb.armorValue;
  }
  charWithBody.totalStats.armor = totalArmor;
  return charWithBody;
}

export function calculateWeightAndEncumbrance<T extends CalculableCharacter>(character: T, GAME_DATA: GameData): T {
  let p = { ...character };
  p.currentWeight =
    (p.baseWeight || 0) +
    p.inventory.filter(Boolean).reduce((sum, i) => sum + getItemWeight(i!, GAME_DATA), 0) +
    Object.values(p.equipment).reduce((sum, i) => (i ? sum + getItemWeight(i, GAME_DATA) : sum), 0);

  if (isPlayer(p)) {
    const player = p as Player;
    const isOverweight = player.currentWeight > player.maxCarryWeight;
    const hasDebuff = player.statusEffects.some((e) => e.id === 'encumbered');

    if (isOverweight && !hasDebuff) {
      player.statusEffects.push({
        id: 'encumbered',
        instanceId: 'encumbered_status',
        turnsRemaining: Infinity,
        durationInMinutes: Infinity,
        source: 'system',
      });
    } else if (!isOverweight && hasDebuff) {
      player.statusEffects = player.statusEffects.filter((e) => e.id !== 'encumbered');
    }
    return player as T;
  }

  return p;
}

export function roundStats<T extends CalculableCharacter>(character: T): T {
  const roundedChar = { ...character, totalStats: { ...character.totalStats } };
  const stats = roundedChar.totalStats;
  for (const key in stats) {
    if (key === 'onHitEffects') continue;
    const statKey = key as keyof Omit<typeof stats, 'onHitEffects'>;
    if (statKey === 'worldHpRegen' || statKey === 'worldMpRegen' || statKey === 'worldSpRegen') {
      (stats[statKey] as number) = parseFloat(((stats[statKey] as number) || 0).toPrecision(4));
    } else if (typeof stats[statKey] === 'number') {
      (stats[statKey] as number) = Math.round(((stats[statKey] as number) || 0) * 100) / 100;
    }
  }
  return roundedChar;
}