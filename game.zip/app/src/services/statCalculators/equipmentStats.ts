import { GameData, ItemSetId, Mercenary, OnHitEffect, Player, StatBlock } from '../../types';

type CalculableCharacter = Player | Mercenary;

export function applyEquipmentStats<T extends CalculableCharacter>(character: T, GAME_DATA: GameData): T {
  const charWithStats = { ...character, totalStats: { ...character.totalStats } };

  for (const slot in charWithStats.equipment) {
    const itemInstance = charWithStats.equipment[slot as keyof typeof charWithStats.equipment];
    if (!itemInstance || itemInstance.isBroken) continue;

    const itemData = GAME_DATA.ITEMS[itemInstance.id];
    if (!itemData || !itemData.type.includes('equipment')) continue;

    if (itemData.stats) {
      const plusValue = itemInstance.plus_value || 0;
      for (const stat in itemData.stats) {
        const key = stat as keyof StatBlock;
        if (key === 'armor') continue;

        let value = itemData.stats[key]!;

        if (plusValue > 0 && (key === 'attackPower' || key === 'spellPower')) {
          const bonus = Math.ceil(value * plusValue * 0.1);
          value += bonus;
        }

        (charWithStats.totalStats[key] as number) = ((charWithStats.totalStats[key] as number) || 0) + value;
      }
    }

    if (itemInstance.enchantments) {
      for (const enchantId in itemInstance.enchantments) {
        const tier = itemInstance.enchantments[enchantId];
        if (tier === undefined) continue;

        const enchantDef = GAME_DATA.ENCHANTS.find((e) => e.id === enchantId);
        if (!enchantDef || !enchantDef.stat) continue;

        const statKey = enchantDef.stat as keyof StatBlock;
        const value = enchantDef.scaling[tier - 1];
        if (value !== undefined) {
          (charWithStats.totalStats[statKey] as number) = ((charWithStats.totalStats[statKey] as number) || 0) + value;
        }
      }
    }
  }
  return charWithStats;
}

export function applySetBonuses<T extends CalculableCharacter>(character: T, GAME_DATA: GameData): T {
  const charWithBonuses = {
    ...character,
    totalStats: { ...character.totalStats, onHitEffects: [...(character.totalStats.onHitEffects || [])] as OnHitEffect[] },
  };
  const equippedSets: Partial<Record<string, number>> = {};

  for (const slot in charWithBonuses.equipment) {
    const itemInstance = charWithBonuses.equipment[slot as keyof typeof charWithBonuses.equipment];
    const itemData = itemInstance ? GAME_DATA.ITEMS[itemInstance.id] : null;
    if (itemInstance && !itemInstance.isBroken && itemData?.type.includes('equipment') && itemData.set) {
      equippedSets[itemData.set] = (equippedSets[itemData.set] || 0) + 1;
    }
  }

  for (const setId in equippedSets) {
    const count = equippedSets[setId]!;
    const setData = GAME_DATA.ITEM_SETS[setId as ItemSetId];
    for (const reqCount in setData.bonuses) {
      if (count >= Number(reqCount)) {
        const bonus = setData.bonuses[reqCount as any];
        if (bonus.stats) {
          for (const stat in bonus.stats) {
            const key = stat as keyof StatBlock;
            (charWithBonuses.totalStats[key] as number) = ((charWithBonuses.totalStats[key] as number) || 0) + bonus.stats[key]!;
          }
        }
        if (bonus.special === 'serpent_reflexes') {
          charWithBonuses.totalStats.onHitEffects.push({
            applyStatusEffect: { id: 'cut', chance: 0.15, stage: 2 },
          });
        }
      }
    }
  }
  return charWithBonuses;
}