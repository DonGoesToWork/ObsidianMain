import { GameData, Mercenary, Player } from '../../types';

type CalculableCharacter = Player | Mercenary;

function isPlayer(char: CalculableCharacter): char is Player {
  return 'professions' in char;
}

export function calculateDerivativeStats<T extends CalculableCharacter>(character: T, GAME_DATA: GameData): T {
  const charWithDerivatives = { ...character, totalStats: { ...character.totalStats } };
  const stats = charWithDerivatives.totalStats;

  stats.maxHp = stats.constitution * 10;
  charWithDerivatives.maxMp = stats.intelligence * 5;
  charWithDerivatives.maxSp = stats.dexterity * 5;

  charWithDerivatives.maxCarryWeight = character.baseWeight + stats.strength * 10;

  if (isPlayer(charWithDerivatives) && charWithDerivatives.guild) {
    const guildLevel = charWithDerivatives.guild.level - 1;
    const guildBonus = GAME_DATA.GUILD_DATA.levels[guildLevel]?.bonus.effect;
    if (guildBonus?.maxHp_mod) stats.maxHp = Math.round(stats.maxHp * guildBonus.maxHp_mod);
  }

  stats.worldHpRegen = Math.max(0.01, stats.constitution / 66.666 + (stats.worldHpRegen || 0));
  stats.worldMpRegen = stats.intelligence / 6.666 + (stats.worldMpRegen || 0);
  stats.worldSpRegen = Math.max(1, stats.dexterity / 0.666 + (stats.worldSpRegen || 0));

  charWithDerivatives.mp = Math.min(charWithDerivatives.mp, charWithDerivatives.maxMp);
  charWithDerivatives.sp = Math.min(charWithDerivatives.sp, charWithDerivatives.maxSp);

  stats.attackPower += stats.strength * 2;
  stats.spellPower += stats.intelligence * 2;
  stats.critChance += stats.dexterity * 0.5;
  stats.accuracy += stats.dexterity * 0.5 + (isPlayer(character) ? stats.luck : 0) * 0.2;
  stats.evasion += stats.dexterity * 0.25 + (isPlayer(character) ? stats.luck : 0) * 0.2;

  return charWithDerivatives;
}