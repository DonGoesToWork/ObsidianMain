import { GameData, Player, Mercenary, StatusEffectInstance, StatBlock } from '../../types';
import { getEffectsFromInstance } from 'utils/statusEffectUtils';

type CalculableCharacter = Player | Mercenary;

function isPlayer(char: CalculableCharacter): char is Player {
  return 'professions' in char;
}

export function applyPassiveSkillBonuses<T extends CalculableCharacter>(character: T, GAME_DATA: GameData): T {
  if (!isPlayer(character)) {
    return character;
  }
  const charWithBonuses = { ...character, totalStats: { ...character.totalStats } };
  for (const skillId in charWithBonuses.skills) {
    const skill = GAME_DATA.SKILLS[skillId as keyof typeof charWithBonuses.skills];
    const pSkill = charWithBonuses.skills[skillId as keyof typeof charWithBonuses.skills]!;
    if (skill.abilityType === 'Perk' && skill.effect.type === 'stat') {
      const key = skill.effect.stat as keyof StatBlock;
      (charWithBonuses.totalStats[key] as number) = ((charWithBonuses.totalStats[key] as number) || 0) + skill.effect.value * pSkill.rank;
    }
  }
  return charWithBonuses;
}

export function applyStatusEffectFlatBonuses<T extends CalculableCharacter>(character: T, GAME_DATA: GameData): T {
  const charWithMods = { ...character, totalStats: { ...character.totalStats } };
  const allEffects: StatusEffectInstance[] = [...character.statusEffects, ...Object.values(character.body).flatMap((limb) => limb.statusEffects || [])];

  allEffects.forEach((effectInst) => {
    const effectsToApply = getEffectsFromInstance(effectInst, GAME_DATA);
    if (effectsToApply?.stats) {
      for (const stat in effectsToApply.stats) {
        const key = stat as keyof StatBlock;
        (charWithMods.totalStats[key] as number) = ((charWithMods.totalStats[key] as number) || 0) + effectsToApply.stats[key]!;
      }
    }
    if (effectsToApply?.levelScaledStats) {
      for (const stat in effectsToApply.levelScaledStats) {
        const key = stat as keyof StatBlock;
        (charWithMods.totalStats[key] as number) = ((charWithMods.totalStats[key] as number) || 0) + effectsToApply.levelScaledStats[key]! * character.level;
      }
    }
  });

  return charWithMods;
}

export function applyPercentageAndMultiplicativeMods<T extends CalculableCharacter>(character: T, GAME_DATA: GameData): T {
  const charWithMods = { ...character, totalStats: { ...character.totalStats } };
  const stats = charWithMods.totalStats;

  if (stats.attackPowerPercent) stats.attackPower *= 1 + stats.attackPowerPercent / 100;
  if (stats.spellPowerPercent) stats.spellPower *= 1 + stats.spellPowerPercent / 100;
  if (stats.armorPercent) stats.armor *= 1 + stats.armorPercent / 100;

  const allEffects: StatusEffectInstance[] = [...character.statusEffects, ...Object.values(character.body).flatMap((limb) => limb.statusEffects || [])];
  allEffects.forEach((effectInst) => {
    const effectsToApply = getEffectsFromInstance(effectInst, GAME_DATA);
    if (effectsToApply?.statMods) {
      for (const stat in effectsToApply.statMods) {
        const key = stat as keyof StatBlock;
        (stats[key] as number) *= effectsToApply.statMods[key]!;
      }
    }
  });

  return charWithMods;
}