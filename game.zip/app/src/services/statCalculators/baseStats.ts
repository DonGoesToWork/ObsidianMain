import { GameData, Mercenary, OnHitEffect, Player } from '../../types';

export function initializeTotalStats<T extends Player | Mercenary>(character: T, GAME_DATA: GameData): T {
  let p: T = { ...character };

  p.totalStats = {
    ...p.baseStats,
    luck: 0,
    attackPower: 0,
    spellPower: 0,
    armor: 0,
    critChance: 0,
    goldFind: 0,
    xpGain: 0,
    worldHpRegen: 0,
    worldMpRegen: 0,
    worldSpRegen: 0,
    accuracy: 100,
    evasion: 50,
    attackSpeed: 1,
    maxHp: 0,
    maxMp: 0,
    maxSp: 0,
    lifeLeechPercent: 0,
    damageRetaliation: 0,
    attackPowerPercent: 0,
    spellPowerPercent: 0,
    armorPercent: 0,
    onHitEffects: [] as OnHitEffect[],
  };

  if (!p.equipment.weapon) {
    p = { ...p, equipment: { ...p.equipment } };
    const raceData = GAME_DATA.RACES[p.race];
    if (raceData.unarmedWeapon) {
      p.equipment.weapon = {
        id: raceData.unarmedWeapon,
        unique_id: `item_unarmed_${p.name}_${Math.random()}`,
        quantity: 1,
        enchantments: {},
        isUnarmed: true,
        plus_value: 0,
        isBroken: false,
      };
    }
  }

  return p;
}