import { GameData, GameLocation, ItemId, ItemInstance, Player, RequirementStatus } from 'types';
import { calculateItemLevel, calculateItemTier, countItems } from 'utils/itemUtils';

import { getCraftingChecks, getRepairChecks, getRequirementStatus, getUpgradeChecks } from '../utils/craftingUtils';

export function calculateCraftingTabStatuses(player: Player, currentLocation: GameLocation | null, GAME_DATA: GameData): Record<string, RequirementStatus> {
  const getListStatus = (items: any[]): RequirementStatus => {
    if (items.length === 0) return 'none';
    const statuses = items.map((item) => item.requirementStatus);
    if (statuses.some((s) => s === 'full')) return 'full';
    if (statuses.some((s) => s === 'partial')) return 'partial';
    return 'none';
  };

  const createList = Object.values(GAME_DATA.ALL_RECIPES)
    .filter((r) => player.knownRecipes[r.id])
    .map((r) => ({ requirementStatus: getRequirementStatus(getCraftingChecks(player, r, [], currentLocation, true, GAME_DATA, { checkInventoryForTools: true })) }));

  const repairableItems = [...player.inventory, ...Object.values(player.equipment).filter((i): i is ItemInstance => !!i)]
    .filter((item: ItemInstance) => {
      if (!item?.id || !GAME_DATA.ITEMS[item.id]) {
        if (item) console.warn('Item data not found in GAME_DATA for repair check:', item.id);
        return false;
      }
      const data = GAME_DATA.ITEMS[item.id];
      return (
        data.type.includes('equipment') &&
        item.currentDurability !== undefined &&
        item.maxDurability !== undefined &&
        item.currentDurability < item.maxDurability &&
        !item.isUnrepairable &&
        !item.isUnidentified &&
        data.recipeId &&
        player.knownRecipes[data.recipeId]
      );
    })
    .map((item) => {
      const itemData = GAME_DATA.ITEMS[item.id];
      const recipe = itemData.recipeId ? GAME_DATA.ALL_RECIPES[itemData.recipeId] : null;
      return { requirementStatus: getRequirementStatus(getRepairChecks(player, recipe, player.inventory, player.inventory, currentLocation, GAME_DATA, true)) };
    });

  const upgradeableItems = [...player.inventory, ...Object.values(player.equipment).filter((i): i is ItemInstance => !!i)]
    .filter((item: ItemInstance) => {
      if (!item?.id || !GAME_DATA.ITEMS[item.id]) {
        if (item) console.warn('Item data not found in GAME_DATA for upgrade check:', item.id);
        return false;
      }
      const data = GAME_DATA.ITEMS[item.id];
      const itemLevel = calculateItemLevel(item, GAME_DATA);
      const itemTier = calculateItemTier(itemLevel);
      const currentPlus = item.plus_value || 0;
      return data.type.includes('equipment') && data.recipeId && currentPlus < itemTier && !item.isUnidentified && player.knownRecipes[data.recipeId!];
    })
    .map((item) => ({ requirementStatus: getRequirementStatus(getUpgradeChecks(player, item, GAME_DATA)) }));

  const enchantingItems =
    player?.inventory.filter((item: ItemInstance) => {
      const itemData = GAME_DATA.ITEMS[item.id];
      return itemData.type.includes('equipment') && !item.isUnidentified && !itemData.isUnarmed;
    }) || [];

  let canEnchantSomething = false;
  if (enchantingItems.length > 0) {
    for (const item of enchantingItems) {
      const itemData = GAME_DATA.ITEMS[item.id];
      const availableEnchants = GAME_DATA.ENCHANTS.filter((enchant) => {
        if (enchant.type === 'global') {
          return true;
        }
        if (enchant.type === 'local') {
          if (!enchant.appliesTo) {
            return true; // Universal local enchant
          }
          const { hasStat, hasItemType } = enchant.appliesTo;

          if ((!hasStat || hasStat.length === 0) && (!hasItemType || hasItemType.length === 0)) return true;

          const itemStats = itemData.stats || {};
          const itemTypes = itemData.type || [];

          const statMatch = hasStat && hasStat.some((s) => itemStats[s] !== undefined);
          const typeMatch = hasItemType && hasItemType.some((t) => itemTypes.includes(t));

          return !!(statMatch || typeMatch);
        }
        return false;
      });

      for (const enchantDef of availableEnchants) {
        const currentTier = item.enchantments[enchantDef.id] || 0;
        if (currentTier >= enchantDef.scaling.length) continue;

        const nextRank = currentTier;
        const cost = enchantDef.cost[nextRank];
        if (!cost) continue;

        const crystalId = Object.keys(cost)[0] as ItemId;
        const crystalCostCount = cost[crystalId];
        if (countItems(player.inventory, crystalId) >= crystalCostCount) {
          canEnchantSomething = true;
          break;
        }
      }
      if (canEnchantSomething) break;
    }
  }

  return {
    Create: getListStatus(createList),
    Repair: getListStatus(repairableItems),
    Upgrade: getListStatus(upgradeableItems),
    Enchanting: canEnchantSomething ? 'full' : 'none',
  };
}