import { GameData, ItemInstance, Mercenary, Player } from 'types';
import { isCombatantDefeated } from 'utils/combatUtils';
import { deepCloneWithInfinity } from 'utils/mathUtils';

/**
 * Processes global game rules based on the player state.
 * This is a pure function that returns a new player object if any changes were made,
 * along with any resulting items that should be dropped (e.g., mercenary corpses).
 * It does not dispatch state changes or log messages directly.
 * @param player The current player state.
 * @param GAME_DATA The static game data.
 * @returns An object containing the new player state (or null if no changes), and any resulting items to be dropped.
 */
export function processGameRules(
  player: Player,
  GAME_DATA: GameData
): { newPlayer: Player | null; corpsesToDrop: ItemInstance[]; deadMercs: Mercenary[]; starvation: string[]; thirst: string[] } {
  let modified = false;
  let playerForUpdate = deepCloneWithInfinity(player);
  const corpsesToDrop: ItemInstance[] = [];
  const deadMercs: Mercenary[] = [];
  const deadMercIds = new Set<string>();

  const starvation: string[] = [];
  const thirst: string[] = [];

  const allChars = [playerForUpdate, ...playerForUpdate.party];

  for (const char of allChars) {
    if (('professions' in char && isCombatantDefeated(char)) || ('mercenaryId' in char && deadMercIds.has((char as Mercenary).id))) {
      continue;
    }

    let deathReason: string | null = null;
    if (char.vitals.hunger.current <= 0) {
      deathReason = 'starvation';
      starvation.push(char.name);
    } else if (char.vitals.thirst.current <= 0) {
      deathReason = 'thirst';
      thirst.push(char.name);
    }

    if (deathReason) {
      if (char.body.torso) char.body.torso.currentHp = 0;
      if (char.body.body) char.body.body.currentHp = 0; // For non-humanoids
      modified = true;
    }

    // Now, regardless of the cause, if the character is defeated, process their death.
    if (isCombatantDefeated(char)) {
      if (!('professions' in char)) {
        // It's a mercenary
        const merc = char as Mercenary;
        if (!deadMercIds.has(merc.id)) {
          deadMercs.push(merc);
          deadMercIds.add(merc.id);
          modified = true;
        }
      }
    }
  }

  // Process dead mercenaries if any were found
  if (deadMercIds.size > 0) {
    deadMercIds.forEach((deadMercId) => {
      const mercIndex = playerForUpdate.party.findIndex((m: Mercenary) => m.id === deadMercId);
      if (mercIndex > -1) {
        const deadMerc = playerForUpdate.party[mercIndex];
        const equipmentItems = (Object.values(deadMerc.equipment) as (ItemInstance | null)[]).filter((item): item is ItemInstance => !!item && !item.isUnarmed);
        const mercItems: ItemInstance[] = [...deadMerc.inventory, ...equipmentItems];

        const corpseItem: ItemInstance = {
          id: 'item_corpse',
          unique_id: `corpse_${deadMerc.id}_${Date.now()}_${Math.random()}`,
          quantity: 1,
          name: `Corpse of ${deadMerc.name}`,
          weight: deadMerc.baseWeight,
          deceasedCharacter: deadMerc,
          enchantments: {},
          containerState: { items: mercItems, capacity: deadMerc.maxCarryWeight || 200 },
        };
        corpsesToDrop.push(corpseItem);
      }
    });
    playerForUpdate.party = playerForUpdate.party.filter((m: Mercenary) => !deadMercIds.has(m.id));
  }

  // Handle encumbrance status effect
  const isOverweight = playerForUpdate.currentWeight > playerForUpdate.maxCarryWeight;
  const hasEncumberedDebuff = playerForUpdate.statusEffects.some((e) => e.id === 'encumbered');
  if (isOverweight && !hasEncumberedDebuff) {
    playerForUpdate.statusEffects.push({ id: 'encumbered', instanceId: 'encumbered_status', turnsRemaining: Infinity, durationInMinutes: Infinity, source: 'system' });
    modified = true;
  } else if (!isOverweight && hasEncumberedDebuff) {
    playerForUpdate.statusEffects = playerForUpdate.statusEffects.filter((e) => e.id !== 'encumbered');
    modified = true;
  }

  return { newPlayer: modified ? playerForUpdate : null, corpsesToDrop, deadMercs, starvation, thirst };
}