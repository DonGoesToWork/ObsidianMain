import { Mercenary, Player, StatBlock, StatusEffectInstance, OnHitEffect, GameData } from '../types';

import { getEffectsFromInstance } from '../utils/statusEffectUtils';
import { getItemWeight } from 'utils/itemUtils';
import { instantiateBodyPlan } from 'utils/bodyUtils';

type CalculableCharacter = Player | Mercenary;

function isPlayer(char: CalculableCharacter): char is Player {
  return 'professions' in char;
}

function applyEquipmentStats(p: CalculableCharacter, GAME_DATA: GameData): CalculableCharacter {
  const pWithStats = { ...p, totalStats: { ...p.totalStats } };

  for (const slot in pWithStats.equipment) {
    const itemInstance = pWithStats.equipment[slot as keyof typeof pWithStats.equipment];
    if (!itemInstance || itemInstance.isBroken) continue;

    const itemData = GAME_DATA.ITEMS[itemInstance.id];
    if (!itemData || !itemData.type.includes('equipment')) continue;

    if (itemData.stats) {
      const qualityMultiplier = itemInstance.quality ? GAME_DATA.ITEM_QUALITIES[itemInstance.quality]?.multiplier || 1.0 : 1.0;
      for (const stat in itemData.stats) {
        const key = stat as keyof StatBlock;
        let value = itemData.stats[key]!;

        if (key !== 'attackSpeed') {
          value *= qualityMultiplier;
        }
        pWithStats.totalStats[key] = (pWithStats.totalStats[key] || 0) + value;
      }
    }

    if (itemInstance.enchantments) {
      for (const stat in itemInstance.enchantments) {
        const key = stat as keyof StatBlock;
        pWithStats.totalStats[key] = (pWithStats.totalStats[key] || 0) + itemInstance.enchantments[key]!;
      }
    }
  }
  return pWithStats;
}

function applySetBonuses(p: CalculableCharacter, GAME_DATA: GameData): CalculableCharacter {
  const pWithBonuses = {
    ...p,
    totalStats: { ...p.totalStats, onHitEffects: [] as OnHitEffect[] },
  };
  const equippedSets: Partial<Record<string, number>> = {};

  for (const slot in pWithBonuses.equipment) {
    const itemInstance = pWithBonuses.equipment[slot as keyof typeof pWithBonuses.equipment];
    const itemData = itemInstance ? GAME_DATA.ITEMS[itemInstance.id] : null;
    if (itemInstance && !itemInstance.isBroken && itemData?.type.includes('equipment') && itemData.set) {
      equippedSets[itemData.set] = (equippedSets[itemData.set] || 0) + 1;
    }
  }

  for (const setId in equippedSets) {
    const count = equippedSets[setId]!;
    const setData = GAME_DATA.ITEM_SETS[setId as keyof typeof GAME_DATA.ITEM_SETS];
    for (const reqCount in setData.bonuses) {
      if (count >= Number(reqCount)) {
        const bonus = setData.bonuses[reqCount as any];
        if (bonus.stats) {
          for (const stat in bonus.stats) {
            const key = stat as keyof StatBlock;
            pWithBonuses.totalStats[key] = (pWithBonuses.totalStats[key] || 0) + bonus.stats[key]!;
          }
        }
        if (bonus.special === 'serpent_reflexes') {
          pWithBonuses.totalStats.onHitEffects.push({
            applyStatusEffect: { id: 'cut', chance: 0.15, stage: 2 },
          });
        }
      }
    }
  }
  return pWithBonuses;
}

function applyPassiveSkillBonuses(p: Player, GAME_DATA: GameData): Player {
  const pWithBonuses = { ...p, totalStats: { ...p.totalStats } };
  for (const skillId in pWithBonuses.skills) {
    const skill = GAME_DATA.SKILLS[skillId as keyof typeof pWithBonuses.skills];
    const pSkill = pWithBonuses.skills[skillId as keyof typeof pWithBonuses.skills]!;
    if (skill.abilityType === 'Perk' && skill.effect.type === 'stat') {
      const key = skill.effect.stat as keyof StatBlock;
      pWithBonuses.totalStats[key] = (pWithBonuses.totalStats[key] || 0) + skill.effect.value * pSkill.rank;
    }
  }
  return pWithBonuses;
}

function applyStatusEffectBonuses(p: CalculableCharacter, GAME_DATA: GameData): CalculableCharacter {
  let pWithMods = { ...p, totalStats: { ...p.totalStats } };
  const allEffects: StatusEffectInstance[] = [...p.statusEffects, ...Object.values(p.body).flatMap((limb) => limb.statusEffects || [])];

  allEffects.forEach((effectInst) => {
    const effectsToApply = getEffectsFromInstance(effectInst, GAME_DATA);
    if (effectsToApply?.stats) {
      for (const stat in effectsToApply.stats) {
        const key = stat as keyof StatBlock;
        (pWithMods.totalStats[key] as number) += effectsToApply.stats[key]!;
      }
    }
    if (effectsToApply?.levelScaledStats) {
      for (const stat in effectsToApply.levelScaledStats) {
        const key = stat as keyof StatBlock;
        (pWithMods.totalStats[key] as number) += effectsToApply.levelScaledStats[key]! * p.level;
      }
    }
  });

  allEffects.forEach((effectInst) => {
    const effectsToApply = getEffectsFromInstance(effectInst, GAME_DATA);
    if (effectsToApply?.statMods) {
      for (const stat in effectsToApply.statMods) {
        const key = stat as keyof StatBlock;
        (pWithMods.totalStats[key] as number) *= effectsToApply.statMods[key]!;
      }
    }
  });
  return pWithMods;
}

function calculateDerivativeStats(p: CalculableCharacter, GAME_DATA: GameData): CalculableCharacter {
  const pWithDerivatives = { ...p, totalStats: { ...p.totalStats } };
  const stats = pWithDerivatives.totalStats;

  stats.maxHp = stats.constitution * 10;
  pWithDerivatives.maxMp = stats.intelligence * 5;
  pWithDerivatives.maxSp = stats.dexterity * 5;

  pWithDerivatives.maxCarryWeight = p.baseWeight + stats.strength * 10;

  if (isPlayer(pWithDerivatives) && pWithDerivatives.guild) {
    const guildLevel = pWithDerivatives.guild.level - 1;
    const guildBonus = GAME_DATA.GUILD_DATA.levels[guildLevel]?.bonus.effect;
    if (guildBonus?.maxHp_mod) stats.maxHp = Math.round(stats.maxHp * guildBonus.maxHp_mod);
  }

  stats.worldHpRegen = Math.max(0.01, stats.constitution / 66.666 + (stats.worldHpRegen || 0));
  stats.worldMpRegen = stats.intelligence / 6.666 + (stats.worldMpRegen || 0);
  stats.worldSpRegen = Math.max(1, stats.dexterity / 0.666 + (stats.worldSpRegen || 0));

  pWithDerivatives.mp = Math.min(pWithDerivatives.mp, pWithDerivatives.maxMp);
  pWithDerivatives.sp = Math.min(pWithDerivatives.sp, pWithDerivatives.maxSp);

  stats.attackPower += stats.strength * 2;
  stats.spellPower += stats.intelligence * 2;
  stats.critChance += stats.dexterity * 0.5;
  stats.accuracy += stats.dexterity * 0.5 + (isPlayer(p) ? stats.luck : 0) * 0.2;
  stats.evasion += stats.dexterity * 0.25 + (isPlayer(p) ? stats.luck : 0) * 0.2;

  return pWithDerivatives;
}

function calculateBodyPlanAndArmor(p: CalculableCharacter, GAME_DATA: GameData): CalculableCharacter {
  const pWithBody = { ...p };
  const baseHp = p.totalStats.maxHp;
  const template = isPlayer(p) ? GAME_DATA.BODY_PLANS.getPlayerTemplate() : GAME_DATA.BODY_PLANS.getMonsterTemplate({ bodyPlan: 'default' } as any);
  pWithBody.body = instantiateBodyPlan(template, baseHp, p.body);

  let totalArmor = p.totalStats.armor;
  for (const limbId in pWithBody.body) {
    const limb = pWithBody.body[limbId];
    limb.armorValue = 0;
    for (const slotId of limb.equipmentSlots) {
      const item = pWithBody.equipment[slotId];
      if (item && !item.isBroken) {
        const itemData = GAME_DATA.ITEMS[item.id];
        const qualityMultiplier = item.quality ? GAME_DATA.ITEM_QUALITIES[item.quality]?.multiplier || 1.0 : 1.0;
        if (itemData?.stats?.armor) {
          limb.armorValue += itemData.stats.armor * qualityMultiplier;
        }
        if (item.enchantments?.armor) {
          limb.armorValue += item.enchantments.armor;
        }
      }
    }
    limb.armorValue = Math.round(limb.armorValue);
    totalArmor += limb.armorValue;
  }
  pWithBody.totalStats.armor = totalArmor;
  return pWithBody;
}

function roundStats(p: CalculableCharacter): CalculableCharacter {
  const roundedChar = { ...p, totalStats: { ...p.totalStats } };
  const stats = roundedChar.totalStats;
  for (const key in stats) {
    if (key === 'onHitEffects') continue;
    const statKey = key as keyof Omit<typeof stats, 'onHitEffects'>;
    if (statKey === 'worldHpRegen' || statKey === 'worldMpRegen' || statKey === 'worldSpRegen') {
      stats[statKey] = parseFloat(stats[statKey].toPrecision(4));
    } else if (typeof stats[statKey] === 'number') {
      stats[statKey] = Math.round(stats[statKey] * 100) / 100;
    }
  }
  return roundedChar;
}

export function calculateXpToNextLevel(level: number): number {
  return Math.floor(100 * Math.pow(level, 1.5));
}

export function calculateCharacterStats<T extends CalculableCharacter>(character: T | null, GAME_DATA: GameData): T | null {
  if (!character) return null;

  let p: CalculableCharacter = { ...character };

  p.totalStats = {
    ...p.baseStats,
    luck: 0,
    attackPower: 0,
    spellPower: 0,
    armor: 0,
    critChance: 0,
    goldFind: 0,
    xpGain: 0,
    worldHpRegen: 0,
    worldMpRegen: 0,
    worldSpRegen: 0,
    onHitEffects: [] as OnHitEffect[],
    accuracy: 100,
    evasion: 50,
    attackSpeed: 1,
    maxHp: 0,
    maxMp: 0,
    maxSp: 0,
  };

  if (!p.equipment.weapon) {
    p = { ...p, equipment: { ...p.equipment } };
    const raceData = GAME_DATA.RACES[p.race];
    if (raceData.unarmedWeapon) {
      p.equipment.weapon = {
        id: raceData.unarmedWeapon,
        unique_id: `item_unarmed_${p.name}_${Math.random()}`,
        enchantments: {},
        isUnarmed: true,
        quality: 'Average',
        isBroken: false,
      };
    }
  }

  p = applyEquipmentStats(p, GAME_DATA);
  p = applySetBonuses(p, GAME_DATA);
  if (isPlayer(p)) p = applyPassiveSkillBonuses(p, GAME_DATA);
  p = calculateDerivativeStats(p, GAME_DATA);
  p = applyStatusEffectBonuses(p, GAME_DATA);
  p = calculateBodyPlanAndArmor(p, GAME_DATA);
  p = roundStats(p);

  p.currentWeight =
    (p.baseWeight || 0) +
    p.inventory.reduce((sum, i) => sum + getItemWeight(i, GAME_DATA), 0) +
    Object.values(p.equipment).reduce((sum, i) => (i ? sum + getItemWeight(i, GAME_DATA) : sum), 0);

  if (isPlayer(p)) {
    const player = p as Player;
    const isOverweight = player.currentWeight > player.maxCarryWeight;
    const hasDebuff = player.statusEffects.some((e) => e.id === 'encumbered');

    if (isOverweight && !hasDebuff) {
      player.statusEffects = [
        ...player.statusEffects,
        {
          id: 'encumbered',
          instanceId: 'encumbered',
          turnsRemaining: Infinity,
          durationInMinutes: Infinity,
          source: 'system',
        },
      ];
    } else if (!isOverweight && hasDebuff) {
      player.statusEffects = player.statusEffects.filter((e) => e.id !== 'encumbered');
    }
  }

  return p as T;
}
