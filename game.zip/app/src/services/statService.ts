import { Mercenary, Player, GameData } from '../types';
import {
  initializeTotalStats,
  applyEquipmentStats,
  applySetBonuses,
  applyPassiveSkillBonuses,
  applyStatusEffectFlatBonuses,
  applyPercentageAndMultiplicativeMods,
  calculateDerivativeStats,
  calculateBodyPlanAndArmor,
  calculateWeightAndEncumbrance,
  roundStats,
} from './statCalculators';

type CalculableCharacter = Player | Mercenary;

export function calculateXpToNextLevel(level: number): number {
  return Math.floor(100 * Math.pow(level, 1.5));
}

export function calculateCharacterStats<T extends CalculableCharacter>(character: T | null, GAME_DATA: GameData): T | null {
  if (!character) return null;

  let p: T;

  // The pipeline composition
  p = initializeTotalStats(character, GAME_DATA);

  // 1. Accumulate all flat bonuses
  p = applyEquipmentStats(p, GAME_DATA);
  p = applySetBonuses(p, GAME_DATA);
  p = applyPassiveSkillBonuses(p, GAME_DATA);
  p = applyStatusEffectFlatBonuses(p, GAME_DATA);

  // 2. Calculate derivative stats from primary attributes
  p = calculateDerivativeStats(p, GAME_DATA);

  // 3. Apply all percentage/multiplicative mods
  p = applyPercentageAndMultiplicativeMods(p, GAME_DATA);

  // 4. Final calculations based on modified stats
  p = calculateBodyPlanAndArmor(p, GAME_DATA);
  p = calculateWeightAndEncumbrance(p, GAME_DATA);
  p = roundStats(p);

  return p;
}