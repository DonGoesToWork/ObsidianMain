import { Combatant, CombatState, GameData, Loggable, LogType, StatusEffectInstance } from 'types';
import { createDamageMessage, isCombatantDefeated, processLimbDamage, recalculateCombatantStats } from 'utils/combatUtils';

type TurnLog = { message: Loggable; type: LogType };
type CombatAction = { type: 'attack'; targetId: string; limbId: string } | { type: 'idle' };

function selectNpcAction(cs: CombatState, npc: Combatant): CombatAction {
  const isConfused = npc.statusEffects.some((e) => e.id === 'confused') && Math.random() < 0.5;

  let potentialTargets: Combatant[];
  if (isConfused) {
    potentialTargets = Object.values(cs.combatants).filter((c) => !isCombatantDefeated(c));
  } else {
    potentialTargets = Object.values(cs.combatants).filter((c) => c.team === 'player' && !isCombatantDefeated(c));
  }

  if (potentialTargets.length === 0) {
    return { type: 'idle' };
  }

  const target = potentialTargets[Math.floor(Math.random() * potentialTargets.length)];
  const validLimbs = Object.values(target.body).filter((l) => l.state !== 'Destroyed');

  if (validLimbs.length > 0) {
    const randomLimb = validLimbs[Math.floor(Math.random() * validLimbs.length)];
    return { type: 'attack', targetId: target.id, limbId: randomLimb.id };
  }

  return { type: 'idle' };
}

function executeNpcAttack(cs: CombatState, npc: Combatant, targetId: string, limbId: string, GAME_DATA: GameData): { newState: CombatState; logs: TurnLog[] } {
  const logs: TurnLog[] = [];
  const target = cs.combatants[targetId];
  const limb = target.body[limbId];
  if (!target || !limb) return { newState: cs, logs };

  const weaponItem = npc.equipment?.weapon ? GAME_DATA.ITEMS[npc.equipment.weapon.id] : null;
  const damageTags = weaponItem?.defaultAttack?.tags || ['Blunt'];

  const hitChance = Math.max(0.05, Math.min(0.95, npc.totalStats.accuracy / target.totalStats.evasion));

  if (Math.random() > hitChance) {
    logs.push({
      message: `${npc.name} attacks ${target.name}'s ${limb.displayName} but misses!`,
      type: 'info',
    });
    return { newState: cs, logs };
  }

  const isCrit = Math.random() < npc.totalStats.critChance / 100;
  const baseDamage = npc.totalStats.attackPower * (isCrit ? 1.5 : 1);
  const mitigation = (limb.armorValue || 0) / 2;
  const damage = Math.max(1, Math.round(baseDamage - mitigation));

  let currentTarget = { ...cs.combatants[target.id] };
  const { updatedLimb, logMessages } = processLimbDamage(currentTarget.body[limb.id], damage, damageTags, currentTarget.name, GAME_DATA);
  logMessages.forEach((msg) => logs.push({ message: msg, type: 'combat' }));

  currentTarget = { ...currentTarget, body: { ...currentTarget.body, [limb.id]: updatedLimb } };

  npc.totalStats.onHitEffects?.forEach((onHit: any) => {
    if (Math.random() < onHit.applyStatusEffect.chance) {
      const newEffect: StatusEffectInstance = {
        id: onHit.applyStatusEffect.id,
        instanceId: `se_${Date.now()}_${Math.random()}`,
        turnsRemaining: onHit.applyStatusEffect.turns || Infinity,
        durationInMinutes: 0,
        currentStage: onHit.applyStatusEffect.stage || 1,
      };
      const buffData = GAME_DATA.STATUS_EFFECTS[newEffect.id];
      if (buffData) {
        let effectsArray = [...currentTarget.body[limb.id].statusEffects];
        effectsArray.push(newEffect);
        currentTarget.body[limb.id].statusEffects = effectsArray;
        logs.push({ message: `${buffData.name} on ${target.name} has been applied.`, type: 'combat' });
      }
    }
  });

  const updatedTarget = recalculateCombatantStats(currentTarget, GAME_DATA);
  const newCombatants = { ...cs.combatants, [target.id]: updatedTarget };

  logs.push({
    message: createDamageMessage(npc.name, target.name, limb.displayName, damage, isCrit),
    type: 'combat',
  });

  return { newState: { ...cs, combatants: newCombatants }, logs };
}

export function processNpcTurnLogic(cs: CombatState, npcId: string, GAME_DATA: GameData): { newState: CombatState; logs: TurnLog[]; isStunned: boolean } {
  const npc = cs.combatants[npcId];
  if (isCombatantDefeated(npc)) {
    return { newState: cs, logs: [], isStunned: false };
  }

  const action = selectNpcAction(cs, npc);

  if (action.type === 'attack') {
    return { ...executeNpcAttack(cs, npc, action.targetId, action.limbId, GAME_DATA), isStunned: false };
  }

  return { newState: cs, logs: [], isStunned: false };
}
