import {
  ClassId,
  RaceId,
  ItemId,
  AbilityId,
  FactionId,
  PetId,
  ProfessionId,
  MonsterId,
  QuestId,
  BaseStatBlock,
  RecipeId,
  TotalPlayerStats,
  BodyPlan,
  Limb,
  StatusEffectInstance,
  PlayerEquipmentSlot,
  ItemInstance,
  MercenaryArchetypeId,
  Equipment,
  ShopData,
} from './gameData';
import { GameLocation, ModalUiSettings } from './game';

export interface Combatant {
  id: string;
  type: 'player' | 'pet' | 'enemy' | 'mercenary';
  name: string;
  race: RaceId;
  class: ClassId | 'none';
  level: number;
  mp: number;
  maxMp: number;
  sp: number;
  maxSp: number;
  body: BodyPlan<Limb>;
  baseStats: TotalPlayerStats;
  totalStats: TotalPlayerStats;
  statusEffects: StatusEffectInstance[];
  inventory: ItemInstance[];
  monsterId?: MonsterId;
  mercenaryInstanceId?: string;
  behavior?: any[];
  abilities?: Record<string, any>;
  skills: Partial<Record<AbilityId, { rank: number }>>;
  equipment: Equipment;
  team: 'player' | 'enemy';
  gold?: number;
  currentWeight?: number;
  maxWeight?: number;
  baseWeight: number;
  currentAction?: {
    skillId: AbilityId;
    targetId: string;
  };
  lastAction?: {
    type: 'attack' | 'skill';
    skillId: AbilityId | null;
    targetId: string;
    limbId: string | null;
    isRandom?: boolean;
  } | null;
}

export interface ProfessionState {
  level: number;
  xp: number;
  xpToNextLevel: number;
}

export type Professions = Record<ProfessionId, ProfessionState>;

export interface KillObjectiveProgress {
  type: 'kill';
  target: MonsterId;
  count: number;
  current: number;
}

export interface GatherObjectiveProgress {
  type: 'gather';
  target: ItemId;
  count: number;
  current: number;
}

export type QuestProgress = KillObjectiveProgress | GatherObjectiveProgress;

export interface PlayerVital {
  current: number;
  max: number;
}

export interface PlayerVitals {
  hunger: PlayerVital;
  thirst: PlayerVital;
  alertness: PlayerVital;
  courage: PlayerVital;
}

export interface Mercenary {
  id: string; // unique instance ID
  mercenaryId: MercenaryArchetypeId;
  name: string;
  race: RaceId;
  class: ClassId;
  level: number;
  xp: number;
  xpToNextLevel: number;

  baseStats: BaseStatBlock;
  totalStats: TotalPlayerStats;

  equipment: Equipment;
  inventory: ItemInstance[];

  body: BodyPlan<Limb>;
  statusEffects: StatusEffectInstance[];
  skills: Partial<Record<AbilityId, { rank: number }>>;

  mp: number;
  maxMp: number;
  sp: number;
  maxSp: number;

  vitals: PlayerVitals;
  currentWeight: number;
  maxCarryWeight: number;
  baseWeight: number;

  initialCost: number;
  dailyCost: number;
  happiness: number;
  gold: number;
  fleeHealthThreshold: number;

  lastAction?: Combatant['lastAction'];
}

export interface Player {
  name: string;
  class: ClassId;
  race: RaceId;
  level: number;
  xp: number;
  xpToNextLevel: number;
  perkPoints: number;
  attributePoints: number;
  gold: number;
  baseStats: BaseStatBlock;
  totalStats: TotalPlayerStats;
  equipment: Equipment;
  body: BodyPlan<Limb>;
  inventory: ItemInstance[];
  bank: ItemInstance[];
  guildBank: ItemInstance[];
  skills: Partial<Record<AbilityId, { rank: number }>>;
  statusEffects: StatusEffectInstance[];
  quests: {
    active: Record<string, QuestProgress>;
    completed: Record<string, boolean>;
  };
  professions: Professions;
  reputation: Record<FactionId, { points: number; rankIndex: number }>;
  dailyQuestsCompleted: Record<string, number>; // quest_id: timestamp
  pet: {
    id: PetId;
    name: string;
    level: number;
  } | null;
  party: Mercenary[];
  guild: {
    name: string;
    level: number;
  } | null;
  mp: number;
  maxMp: number;
  sp: number;
  maxSp: number;
  vitals: PlayerVitals;
  location: GameLocation;
  currentWeight: number;
  maxCarryWeight: number;
  baseWeight: number;
  knownRecipes: Partial<Record<RecipeId, boolean>>;
  favoriteAbilities: AbilityId[];
  lastAction?: {
    type: 'attack' | 'skill';
    skillId: AbilityId | null;
    targetId: string;
    limbId: string | null;
    isRandom?: boolean;
  } | null;
  fame: number;
  lastPayday: number;
  mercenaryGuildData: {
    available: Mercenary[];
    lastRefreshed: number;
  };
  shopInventories: Record<string, ShopData>;
  locationStates?: Record<string, { groundLoot?: ItemInstance[]; groundLootTimestamp?: number }>;
}