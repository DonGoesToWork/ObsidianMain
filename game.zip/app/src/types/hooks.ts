import { Player } from "./player";
import {
  ItemInstance,
  ProfessionId,
  Recipe,
  RequirementCheck,
} from "./gameData";
import { GroupedItem } from "../utils/itemUtils";
import React from "react";

export type UseCraftingReturn = {
  player: Player | null;
  tools: ItemInstance[];
  setTools: React.Dispatch<React.SetStateAction<ItemInstance[]>>;
  ingredients: ItemInstance[];
  setIngredients: React.Dispatch<React.SetStateAction<ItemInstance[]>>;
  selectedRecipe: Recipe | null;
  recipeProfession: ProfessionId;
  setRecipeProfession: React.Dispatch<React.SetStateAction<ProfessionId>>;
  playerInventoryForDisplay: ItemInstance[];
  playerInventoryMap: number[];
  groupedIngredients: Record<string, GroupedItem>;
  knownRecipes: Recipe[];
  craftableRecipes: Recipe[];
  uncraftableRecipes: Recipe[];
  discoveredRecipe: Recipe | undefined;
  requirementChecks: Record<string, RequirementCheck>;
  canCraftSingle: boolean;
  canCraftMultiple: (quantity: number) => boolean;
  handleAddItemToCraft: (itemsToAdd: ItemInstance[]) => void;
  handleSelectRecipe: (recipe: Recipe) => void;
  handleCraft: (quantity: number) => void;
  handleRemoveItem: (
    item: ItemInstance,
    setFn: React.Dispatch<React.SetStateAction<ItemInstance[]>>,
    transferAmount: number,
  ) => void;
};