import {
  AbilityId,
  BaseStatBlock,
  ClassId,
  DungeonState,
  EnchantDef,
  EnchantmentRecipeId,
  GatherNode,
  ItemId,
  ItemInstance,
  MonsterId,
  PlayerEquipmentSlot,
  ProfessionId,
  QuestId,
  RaceId,
  Recipe,
  RecipeId,
  ShopData,
  StatusEffectId,
  Zone,
} from './gameData';
import { Combatant, Mercenary, Player } from './player';

import { MutableRefObject } from 'react';

export type GameState = 'character-creation' | 'town' | 'wilds' | 'world-map' | 'combat' | 'dungeon' | 'combat-sim';

export type LogType = 'info' | 'error' | 'combat' | 'damage' | 'crit' | 'heal' | 'loot' | 'xp' | 'rep' | 'quest' | 'time' | 'skill';

export type LogMessageObject = {
  floatingText?: string;
  detailedText: string;
};
export type Loggable = string | LogMessageObject;

export interface LogEntry {
  id: number;
  message: string;
  type: LogType;
}
export interface FieldEffect {
  id: string; // unique id for the effect instance
  sourceAbilityId: AbilityId;
  casterId: string;
  turnsRemaining: number;
}
export interface CombatState {
  isActive: boolean;
  combatants: Record<string, Combatant>;
  turnOrder: string[];
  turnIndex: number;
  playerTargetId: string | null;
  playerSelectedLimbId: string | null;
  petTargetId: string | null;
  isPlayerTurn: boolean;
  source?: 'rest' | 'wilds';
  fieldEffects: FieldEffect[];
  selectedAction: {
    type: 'attack' | 'skill' | 'inspect';
    skillId: AbilityId | null;
  } | null;
}

export interface GameLocation {
  id: string; // zoneId
  name: string;
  type: 'town' | 'wilds' | 'dungeon';
  pos: { x: number; y: number };
  levelReq: number;
  dangerLevel: number;
  gather: GatherNode[];
  monsterPacks?: MonsterId[][];
  stages?: number;
  monsters?: MonsterId[];
  boss?: MonsterId;
  groundLoot?: ItemInstance[];
  groundLootTimestamp?: number;
}

export interface LocationState {
  id: string;
  mercenaryGuild?: {
    available: Mercenary[];
    lastRefreshed: number;
  };
  shopInventory?: ShopData;
  groundLoot?: ItemInstance[];
  groundLootTimestamp?: number;
}

export type VitalId = 'hunger' | 'thirst' | 'alertness' | 'courage';

export type AlertnessLevel = 'passive' | 'half-awake' | 'fully-alert';

export type RestOptions = {
  isResting: true;
  alertnessLevel: AlertnessLevel;
  aids: ItemId[];
};

export type AppraiseOptions = {
  isAppraising: true;
};

export type GameSideEffect =
  | { type: 'LOG'; message: Loggable; logType: LogType }
  | { type: 'GENERATE_ZONE'; level: number }
  | { type: 'PASS_TIME'; minutes: number; options?: RestOptions | AppraiseOptions }
  | { type: 'GAIN_PROFESSION_XP'; professionId: ProfessionId; amount: number }
  | { type: 'UPDATE_QUEST_PROGRESS'; questType: 'kill' | 'gather'; target: string; count: number }
  | { type: 'LEARN_RECIPE'; recipeId: RecipeId }
  | { type: 'LEARN_ENCHANTMENT'; enchantmentRecipeId: EnchantmentRecipeId }
  | { type: 'LEARN_ABILITY'; abilityId: AbilityId }
  | { type: 'DROP_ITEMS'; items: ItemInstance[] }
  | {
      type: 'APPLY_STATUS_EFFECT';
      effectId: StatusEffectId;
      options: {
        turns?: number;
        durationInMinutes?: number;
        limbId?: string;
        stage?: number;
        instanceId?: string;
        linkedToInstanceId?: string;
        isClosed?: boolean;
      };
    }
  | { type: 'UPDATE_MODAL_REFERENCE'; modalId: string; newUniqueId: string };

export type ViewMode = 'simple' | 'detailed';
export type SortKey = 'name' | 'value' | 'type' | 'weight' | 'itemLevel' | 'stock' | 'requirementStatus' | 'durability';
export type SortDirection = 'asc' | 'desc';

export interface ModalUiSettings {
  [inventoryIdentifier: string]: {
    viewMode?: ViewMode;
    transferAmount?: number;
    sortConfig?: { key: SortKey; direction: SortDirection } | null;
  };
}

export type ModalConfig = {
  history?: boolean;
  nested?: boolean;
  replace?: boolean;
};

export interface ModalState {
  id: string;
  options: any;
  config: ModalConfig;
}

export interface UIContextType {
  modalStack: ModalState[];
  setActiveModal: (modal: string | null, options?: any, config?: ModalConfig) => void;
  floatingTexts: { id: number; text: string }[];
  setFloatingTexts: React.Dispatch<React.SetStateAction<{ id: number; text: string }[]>>;
  modalUiSettings: Record<string, ModalUiSettings>;
  setModalUiSettings: React.Dispatch<React.SetStateAction<Record<string, ModalUiSettings>>>;
  heldItem: ItemInstance | null;
  setHeldItem: React.Dispatch<React.SetStateAction<ItemInstance | null>>;
}

export interface LogContextType {
  logs: LogEntry[];
  addLogEntry: (entry: Omit<LogEntry, 'id'>) => void;
  logMessage: (message: Loggable, type?: LogType) => void;
}

export interface ProfessionsContextType {
  player: Player | null; // For convenience
  craftItem: (recipe: Recipe | null, quantity: number, tools: ItemInstance[], ingredients: ItemInstance[]) => void;
  repairItem: (targetItem: ItemInstance, materials: ItemInstance[], tools: ItemInstance[]) => void;
  repairAllItems: () => void;
  upgradeItem: (targetItem: ItemInstance) => void;
  enchantItem: (itemUniqueId: string, enchantDef: EnchantDef, enchantRank: number, onComplete?: (newItem: ItemInstance | null) => void) => void;
  identifyAllItems: (cost: number) => void;
  gainProfessionXp: (id: ProfessionId, amount: number) => void;
  learnRecipe: (recipeId: RecipeId) => void;
  learnEnchantment: (enchantmentRecipeId: EnchantmentRecipeId) => void;
}

export interface PlayerContextType {
  player: Player | null;
  setPlayer: (update: React.SetStateAction<Player | null>) => void;
}

export interface CharacterContextType {
  gainXp: (amount: number) => void;
  addGold: (amount: number) => void;
  updateQuestProgress: (type: 'kill' | 'gather', target: string, count?: number) => void;
  applyStatusEffect: (
    targetId: 'player',
    effectId: StatusEffectId,
    options: {
      turns?: number;
      durationInMinutes?: number;
      limbId?: string;
      stage?: number;
      instanceId?: string;
      linkedToInstanceId?: string;
      isClosed?: boolean;
    }
  ) => void;
  acceptQuest: (questId: QuestId) => void;
  completeQuest: (questId: QuestId) => void;
  spendAttributePoint: (stat: keyof BaseStatBlock) => void;
  learnPerk: (abilityId: AbilityId) => void;
  learnAbility: (abilityId: AbilityId) => void;
  toggleFavoriteAbility: (abilityId: AbilityId) => void;
}
export interface InventoryContextType {
  addItem: (
    itemId: ItemId,
    quantity?: number,
    options?: {
      isUnidentified?: boolean;
      plus_value?: number;
      initialDurabilityPercent?: number;
      addRandomEnchantments?: boolean;
    }
  ) => ItemInstance[];
  removeItem: (itemId: ItemId, quantity?: number) => void;
  removeItemByInstance: (itemToRemove: ItemInstance) => void;
  equipItem: (itemUniqueId: string, slot?: PlayerEquipmentSlot) => void;
  unequipItem: (slot: PlayerEquipmentSlot) => void;
  dropItems: (itemsToDrop: { unique_id: string; quantity?: number }[]) => void;
  reorderInventory: (draggedItemUniqueId: string, targetIndex: number) => void;
  sortInventory: (config: { key: SortKey; direction: SortDirection } | null) => void;
  consumeItem: (itemUniqueId: string, targetId?: string) => void;
  damageItemDurability: (slot: PlayerEquipmentSlot, amount: number) => void;
  moveItemToBank: (itemUniqueId: string, quantity?: number) => void;
  moveItemsToBank: (itemsToMove: { unique_id: string; quantity: number }[]) => void;
  moveItemFromBank: (itemUniqueId: string, quantity?: number) => void;
  moveItemsFromBank: (itemsToMove: { unique_id: string; quantity: number }[]) => void;
  moveItemToContainer: (itemUniqueId: string, quantity: number, containerUniqueId: string) => void;
  moveItemFromContainer: (itemUniqueIdInContainer: string, quantity: number, containerUniqueId: string) => void;
  giftItemToMercenary: (mercenaryId: string, item: ItemInstance) => void;
  doUseItemOnItem: (heldItemUniqueId: string, targetItemUniqueId: string) => void;
}

export interface PartyContextType {
  hireMercenary: (mercenary: Mercenary) => void;
  fireMercenary: (mercenaryId: string) => void;
  refreshMercenaryGuild: (locationLevel: number) => void;
  gainMercenaryXp: (mercId: string, amount: number) => void;
  healBrokenLimb: (targetId: string, limbId: string) => void;
  reviveDownedAlly: (mercenaryId: string) => void;
  reviveFallenAlly: (corpseItem: ItemInstance) => void;
}

export interface ShopContextType {
  getShopStock: (locationId: string) => ShopData;
  refreshShopInventory: (locationId: string, locationLevel: number, force?: boolean) => void;
  executeTrade: (locationId: string, playerOfferItems: ItemInstance[], merchantOfferItems: ItemInstance[]) => void;
}

export interface DebugContextType {
  debugTargets: string[];
  setDebugTargets: React.Dispatch<React.SetStateAction<string[]>>;
  debug_addGold: (amount: number) => void;
  debug_setGold: (amount: number) => void;
  debug_fullHeal: () => void;
  debug_fullHealAll: () => void;
  debug_restoreResources: () => void;
  debug_clearDebuffs: () => void;
  debug_addPoints: (type: 'perk' | 'stat', amount: number) => void;
  debug_setStatPoints: (amount: number) => void;
  debug_setPerkPoints: (amount: number) => void;
  debug_addXP: (amount: number) => void;
  debug_setXP: (xp: number) => void;
  debug_addLevel: (levels: number) => void;
  debug_setLevel: (level: number) => void;
  debug_addAttributes: (amount: number) => void;
  debug_setAttributes: (amount: number) => void;
  debug_duplicateItems: () => void;
  debug_maxProfessions: () => void;
  debug_setProfessionLevel: (level: number) => void;
  debug_learnAllRecipes: () => void;
  debug_learnAllEnchantmentRecipes: () => void;
  debug_learnAllSkills: () => void;
  debug_learnAllSpells: () => void;
  debug_unlockAll: () => void;
  debug_lockAll: () => void;
  debug_giveRandomItems: (count: number, options?: { unidentifiedWithEnchantments?: boolean }) => void;
  debug_giveAllRecipeItems: () => void;
  debug_giveDamagedItem: (count: number) => void;
  debug_giveAntiGravityChest: (count: number) => void;
  debug_giveUnmodifiableItem: () => void;
  debug_test_all: () => void;
  debug_clearInventory: () => void;
  debug_applyDirectDamage: (targetId: string, limbId: string, damage: number, damageTypes: string[]) => void;
  debug_modifyVitals: (vital: VitalId, amount: number) => void;
  debug_setVital: (vital: VitalId, amount: number) => void;
  debug_setLimbHp: (limbId: string, value: number, isPercent: boolean) => void;
  debug_setGameTimeToStartOfDay: () => void;
  debug_craftGod: () => void;
}

export interface WorldContextType {
  gameState: GameState;
  changeGameState: (gameState: GameState, options?: any) => void;
  gameTime: Date;
  setGameTime: React.Dispatch<React.SetStateAction<Date>>;
  currentLocation: GameLocation | null;
  setCurrentLocation: React.Dispatch<React.SetStateAction<GameLocation | null>>;
  generatedZones: Record<string, Zone>;
  setGeneratedZones: React.Dispatch<React.SetStateAction<Record<string, Zone>>>;
  worldLocationsState: Record<string, LocationState>;
  setWorldLocationsState: React.Dispatch<React.SetStateAction<Record<string, LocationState>>>;
  currentDungeon: DungeonState | null;
  setCurrentDungeon: React.Dispatch<React.SetStateAction<DungeonState | null>>;
  saveGame: () => void;
  resetGame: () => void;
  createPlayer: (name: string, race: RaceId, pClass: ClassId) => void;
  continueFromDeath: () => void;
  performInnAction: (action: 'eat' | 'rest', cost: number) => void;
  cureAilment: (vitalId: VitalId, cost: number) => void;
  passTime: (minutes: number, options?: RestOptions | AppraiseOptions) => void;
  performWildsAction: (actionType: ProfessionId) => void;
  travelTo: (locationId: string) => void;
  getZoneData: (zoneId: string) => Zone | undefined;
  addItemsToGround: (items: ItemInstance[]) => void;
  grabItemsFromGround: (itemsToGrab: { representativeUniqueId: string; quantity: number }[]) => void;
  abandonAllLoot: () => void;
  castAbilityOutOfCombat: (abilityId: AbilityId, e: React.MouseEvent) => void;
  debug_teleportToTown: () => void;
  updateQuestProgress: (type: 'kill' | 'gather', target: string, count?: number) => void;
  generateNewZone: (level: number) => void;
  isActionLocked: boolean;
  withActionLock: <T>(action: () => T, options?: { silent?: boolean }) => T | undefined;
}

export interface CombatContextType {
  currentCombat: CombatState | null;
  setCurrentCombat: React.Dispatch<React.SetStateAction<CombatState | null>>;
  startCombat: (monsterPack: MonsterId[], options?: { zoneId?: string; source?: 'rest' | 'wilds' }) => void;
  endCombat: (victory: boolean) => void;
  fleeCombat: () => void;
  playerActionTaken: () => void;
  endTurnCallbackRef: MutableRefObject<(() => void) | null>;
  enemies: Combatant[];
  selectedTargetId: string | null;
  setSelectedTargetId: React.Dispatch<React.SetStateAction<string | null>>;
  selectedLimbId: string | null;
  setSelectedLimbId: React.Dispatch<React.SetStateAction<string | null>>;
  playerAttack: (targetId: string, limbId: string, isRandom: boolean) => void;
  playerUseSkill: (abilityId: AbilityId, targetId: string | null, limbId: string | null, isRandom: boolean) => void;
  endPlayerTurn: (lastAction?: Player['lastAction']) => void;
  playerFlee: () => void;
  playerTargetRandomLimb: (targetId: string, actionType: 'attack' | 'skill', abilityId: AbilityId | null) => void;
  playerRepeatLastAction: () => void;
  setSelectedAction: (action: CombatState['selectedAction']) => void;
  selectedAction: CombatState['selectedAction'];
}