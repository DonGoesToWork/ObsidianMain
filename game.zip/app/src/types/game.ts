import { Player, Combatant, Mercenary } from "./player";
import {
  MonsterId,
  AbilityId,
  RaceId,
  ClassId,
  ItemId,
  ItemQuality,
  QuestId,
  ProfessionId,
  BaseStatBlock,
  StatusEffectId,
  Recipe,
  RecipeId,
  PlayerEquipmentSlot,
  ItemInstance,
  GatherNode,
  ShopData,
  Zone,
  DungeonState,
} from "./gameData";
import { MutableRefObject } from "react";

export type GameState =
  | "character-creation"
  | "town"
  | "wilds"
  | "world-map"
  | "combat"
  | "dungeon"
  | "combat-sim";

export type LogType =
  | "info"
  | "error"
  | "combat"
  | "damage"
  | "crit"
  | "heal"
  | "loot"
  | "xp"
  | "rep"
  | "quest"
  | "time"
  | "skill";

export type LogMessageObject = {
  floatingText?: string;
  detailedText: string;
};
export type Loggable = string | LogMessageObject;

export interface LogEntry {
  id: number;
  message: string;
  type: LogType;
}
export interface FieldEffect {
  id: string; // unique id for the effect instance
  sourceAbilityId: AbilityId;
  casterId: string;
  turnsRemaining: number;
}
export interface CombatState {
  isActive: boolean;
  combatants: Record<string, Combatant>;
  turnOrder: string[];
  turnIndex: number;
  playerTargetId: string | null;
  playerSelectedLimbId: string | null;
  petTargetId: string | null;
  isPlayerTurn: boolean;
  source?: "rest" | "wilds";
  fieldEffects: FieldEffect[];
  selectedAction: {
    type: "attack" | "skill" | "inspect";
    skillId: AbilityId | null;
  } | null;
}

export interface GameLocation {
  id: string; // zoneId
  name: string;
  type: "town" | "wilds" | "dungeon";
  pos: { x: number; y: number };
  levelReq: number;
  dangerLevel: number;
  gather: GatherNode[];
  monsterPacks?: MonsterId[][];
  stages?: number;
  monsters?: MonsterId[];
  boss?: MonsterId;
  groundLoot?: ItemInstance[];
  groundLootTimestamp?: number;
}

export type VitalId = "hunger" | "thirst" | "alertness" | "courage";

export type AlertnessLevel = "passive" | "half-awake" | "fully-alert";

export type RestOptions = {
  isResting: true;
  alertnessLevel: AlertnessLevel;
  aids: ItemId[];
};

export type GameSideEffect =
  | { type: "LOG"; message: Loggable; logType: LogType }
  | { type: "GENERATE_ZONE"; level: number };

export type ViewMode = "simple" | "detailed";

export interface ModalUiSettings {
  [inventoryIdentifier: string]: {
    viewMode?: ViewMode;
    transferAmount?: number;
  };
}

export type ModalConfig = {
  history?: boolean;
  nested?: boolean;
};

export interface ModalState {
  id: string;
  options: any;
  config: ModalConfig;
}

export interface UIContextType {
  modalStack: ModalState[];
  setActiveModal: (modal: string | null, options?: any, config?: ModalConfig) => void;
  floatingTexts: { id: number; text: string }[];
  setFloatingTexts: React.Dispatch<React.SetStateAction<{ id: number; text: string }[]>>;
  zoomLevel: number;
  setZoomLevel: React.Dispatch<React.SetStateAction<number>>;
  modalUiSettings: Record<string, ModalUiSettings>;
  setModalUiSettings: React.Dispatch<React.SetStateAction<Record<string, ModalUiSettings>>>;
}

export interface LogContextType {
  logs: LogEntry[];
  addLogEntry: (entry: Omit<LogEntry, "id">) => void;
  logMessage: (message: Loggable, type?: LogType) => void;
}

export interface ProfessionsContextType {
  player: Player | null; // For convenience
  craftItem: (
    recipe: Recipe,
    quantity: number,
    tools: ItemInstance[],
    ingredients: ItemInstance[],
  ) => void;
  repairItem: (
    targetItem: ItemInstance,
    materials: ItemInstance[],
    tools: ItemInstance[],
  ) => void;
  upgradeItem: (targetItem: ItemInstance) => void;
  enchantItem: (
    itemUniqueId: string,
    enchantDef: any,
    enchantRank: number,
  ) => void;
  identifyItem: (itemUniqueId: string) => void;
  identifyAllItems: (cost: number) => void;
  gainProfessionXp: (id: ProfessionId, amount: number) => void;
  learnRecipe: (recipeId: RecipeId) => void;
}

export interface PlayerContextType {
  player: Player | null;
  setPlayer: (update: React.SetStateAction<Player | null>) => void;
}

export interface CharacterContextType {
  gainXp: (amount: number) => void;
  addGold: (amount: number) => void;
  updateQuestProgress: (
    type: "kill" | "gather",
    target: string,
    count?: number,
  ) => void;
  applyStatusEffect: (
    targetId: "player",
    effectId: StatusEffectId,
    options: {
      turns?: number;
      durationInMinutes?: number;
      limbId?: string;
      stage?: number;
      instanceId?: string;
      linkedToInstanceId?: string;
      isClosed?: boolean;
    },
  ) => void;
  acceptQuest: (questId: QuestId) => void;
  completeQuest: (questId: QuestId) => void;
  spendAttributePoint: (stat: keyof BaseStatBlock) => void;
  learnPerk: (abilityId: AbilityId) => void;
  learnAbility: (abilityId: AbilityId) => void;
  toggleFavoriteAbility: (abilityId: AbilityId) => void;
}
export interface InventoryContextType {
  addItem: (
    itemId: ItemId,
    quantity?: number,
    options?: {
      isUnidentified?: boolean;
      quality?: ItemQuality;
      initialDurabilityPercent?: number;
    },
  ) => ItemInstance[];
  removeItem: (itemId: ItemId, quantity?: number) => void;
  removeItemByInstance: (itemToRemove: ItemInstance) => void;
  equipItem: (itemUniqueId: string) => void;
  unequipItem: (slot: PlayerEquipmentSlot) => void;
  dropItem: (itemUniqueId: string) => void;
  dropItems: (itemUniqueIds: string[]) => void;
  consumeItem: (itemUniqueId: string, targetId?: string) => void;
  damageItemDurability: (slot: PlayerEquipmentSlot, amount: number) => void;
  moveItemToBank: (itemUniqueId: string) => void;
  moveItemsToBank: (itemUniqueIds: string[]) => void;
  moveItemFromBank: (itemUniqueId: string) => void;
  moveItemsFromBank: (itemUniqueIds: string[]) => void;
  moveItemToContainer: (
    itemUniqueId: string,
    containerUniqueId: string,
  ) => void;
  moveItemFromContainer: (
    itemUniqueIdInContainer: string,
    containerUniqueId: string,
  ) => void;
  giftItemToMercenary: (mercenaryId: string, item: ItemInstance) => void;
}

export interface PartyContextType {
  hireMercenary: (mercenary: Mercenary) => void;
  fireMercenary: (mercenaryId: string) => void;
  refreshMercenaryGuild: () => void;
  gainMercenaryXp: (mercId: string, amount: number) => void;
  healBrokenLimb: (targetId: string, limbId: string) => void;
  reviveDownedAlly: (mercenaryId: string) => void;
  reviveFallenAlly: (corpseItem: ItemInstance) => void;
}

export interface ShopContextType {
  getShopStock: (locationId: string) => ShopData;
  refreshShopInventory: (locationId: string, locationLevel: number) => void;
  executeTrade: (locationId: string, playerOfferItems: ItemInstance[], merchantOfferItems: ItemInstance[]) => void;
}

export interface DebugContextType {
  debug_addGold: (amount: number) => void;
  debug_fullHeal: (targetId: string) => void;
  debug_fullHealAll: () => void;
  debug_restoreResources: (targetId: string) => void;
  debug_clearDebuffs: (targetId: string) => void;
  debug_addPoints: (type: "perk" | "stat", amount: number) => void;
  debug_addXP: (amount: number) => void;
  debug_addLevel: (levels: number) => void;
  debug_addAttributes: (amount: number) => void;
  debug_duplicateItems: () => void;
  debug_maxProfessions: () => void;
  debug_learnAllRecipes: () => void;
  debug_learnAllSkills: () => void;
  debug_learnAllSpells: () => void;
  debug_unlockAll: () => void;
  debug_giveRandomItems: (count: number) => void;
  debug_giveDamagedItem: () => void;
  debug_test_all: () => void;
  debug_clearInventory: () => void;
  debug_applyDirectDamage: (
    targetId: string,
    limbId: string,
    damage: number,
    damageTypes: string[],
  ) => void;
}

export interface WorldContextType {
  gameState: GameState;
  changeGameState: (gameState: GameState, options?: any) => void;
  gameTime: Date;
  setGameTime: React.Dispatch<React.SetStateAction<Date>>;
  currentLocation: GameLocation | null;
  setCurrentLocation: React.Dispatch<React.SetStateAction<GameLocation | null>>;
  generatedZones: Record<string, Zone>;
  setGeneratedZones: React.Dispatch<React.SetStateAction<Record<string, Zone>>>;
  currentDungeon: DungeonState | null;
  setCurrentDungeon: React.Dispatch<React.SetStateAction<DungeonState | null>>;
  saveGame: () => void;
  resetGame: () => void;
  createPlayer: (name: string, race: RaceId, pClass: ClassId) => void;
  continueFromDeath: () => void;
  performInnAction: (action: "eat" | "rest", cost: number) => void;
  cureAilment: (vitalId: VitalId, cost: number) => void;
  passTime: (minutes: number, options?: RestOptions) => void;
  performWildsAction: (actionType: ProfessionId) => void;
  travelTo: (locationId: string) => void;
  getZoneData: (zoneId: string) => Zone | undefined;
  addItemsToGround: (items: ItemInstance[]) => void;
  grabItemsFromGround: (itemIndices: number[]) => void;
  identifyGroundItem: (groundLootIndex: number) => void;
  castAbilityOutOfCombat: (abilityId: AbilityId, e: React.MouseEvent) => void;
  debug_teleportToTown: () => void;
}

export interface CombatContextType {
  currentCombat: CombatState | null;
  setCurrentCombat: React.Dispatch<React.SetStateAction<CombatState | null>>;
  startCombat: (
    monsterPack: MonsterId[],
    options?: { zoneId?: string; source?: "rest" | "wilds" },
  ) => void;
  endCombat: (victory: boolean) => void;
  fleeCombat: () => void;
  playerActionTaken: () => void;
  endTurnCallbackRef: MutableRefObject<(() => void) | null>;
  enemies: Combatant[];
  selectedTargetId: string | null;
  setSelectedTargetId: React.Dispatch<React.SetStateAction<string | null>>;
  selectedLimbId: string | null;
  setSelectedLimbId: React.Dispatch<React.SetStateAction<string | null>>;
  playerAttack: (targetId: string, limbId: string, isRandom: boolean) => void;
  playerUseSkill: (
    abilityId: AbilityId,
    targetId: string | null,
    limbId: string | null,
    isRandom: boolean,
  ) => void;
  endPlayerTurn: (lastAction?: Player["lastAction"]) => void;
  playerFlee: () => void;
  playerTargetRandomLimb: (
    targetId: string,
    actionType: "attack" | "skill",
    abilityId: AbilityId | null,
  ) => void;
  playerRepeatLastAction: () => void;
  setSelectedAction: (action: CombatState["selectedAction"]) => void;
  selectedAction: CombatState["selectedAction"];
}