// By defining ID types as string literals, we break the circular dependency
// where types were trying to infer themselves from the data object that implemented them.
// This makes the type definitions the single source of truth.

import { Mercenary, Player } from './player';

export type ClassId = 'warrior' | 'mage' | 'rogue' | 'cleric' | 'ranger' | 'none';
export type RaceId = 'human' | 'elf' | 'dwarf' | 'orc' | 'rat' | 'goblin' | 'wolf' | 'crawler' | 'undead' | 'elemental' | 'yeti' | 'serpent' | 'naga' | 'beast';
export type ItemId = string;
export type RecipeId = string;
export type ItemSetId = 'valiant' | 'serpent_scale';
export type AbilityId = string;

export type StatusEffectId =
  | 'burning'
  | 'poisoned'
  | 'stunned'
  | 'fortified'
  | 'frozen'
  | 'regeneration'
  | 'sundered'
  | 'pet_empower'
  | 'hasted'
  | 'enraged'
  | 'chilled'
  | 'weakened'
  | 'arcane_brilliance'
  | 'earthen_ward'
  | 'shadow_veil'
  | 'cursed'
  | 'blessed'
  | 'focused'
  | 'hp_regen_potion_minor'
  | 'mp_regen_potion_minor'
  | 'sp_regen_potion_minor'
  | 'hp_regen_potion'
  | 'mp_regen_potion'
  | 'blinded'
  | 'silenced'
  | 'confused'
  | 'cut'
  | 'external_bleed'
  | 'infection'
  | 'immobilized'
  | 'lightning_dot'
  | 'encumbered'
  | 'guarding';

export type MonsterId = 'm001' | 'm002' | 'm003' | 'm004' | 'm005_boss' | 'm006' | 'm007' | 'm008_boss' | 'm009' | 'm010' | 'm011' | 'm012_boss' | 'm_hatchling';
export type ZoneId = 'zone0' | 'zone1' | 'zone2' | 'zone3' | 'zone4' | 'zone5' | 'zone6' | 'zone19' | 'zone20' | 'wilderness_transit';
export type NPCId = 'innkeeper' | 'shopkeeper' | 'banker' | 'guildmaster' | 'captain' | 'clinic' | 'mercenary_guild' | 'appraiser';
export type QuestId = 'q001_main' | 'q002_main' | 'q003_main' | 'q004_main' | 'q101_side' | 'q_daily_haven_guard';
export type FactionId = 'haven_guard';
export type PetId = 'wolf';
export type ProfessionId =
  | 'smithing'
  | 'alchemy'
  | 'jewelcrafting'
  | 'leatherworking'
  | 'mining'
  | 'foraging'
  | 'appraisal'
  | 'enchanting'
  | 'skinning'
  | 'woodcutting'
  | 'tailoring';
export type ItemQuality = 'Poor' | 'Average' | 'Good' | 'Great' | 'Exceptional' | 'Masterwork' | 'One-of-a-kind';
export type ItemType = 'equipment' | 'potion' | 'material' | 'tool' | 'note' | 'container' | 'corpse';
export type PlayerEquipmentSlot = 'head' | 'chest' | 'legs' | 'weapon' | 'shield' | 'amulet' | 'ring1' | 'ring2';
export type EquipmentSlot = PlayerEquipmentSlot | 'ring';
export type LimbState = 'Healthy' | 'Injured' | 'Destroyed';

export type MercenaryArchetypeId = 'westhaven_warrior' | 'westhaven_mage' | 'westhaven_cleric';

export interface ShopData {
  stock: Record<ItemId, number>;
  uniqueStock: ItemInstance[];
  lastRefreshed: number;
}

export interface DungeonState {
  id: string;
  currentStage: number;
  totalStages: number;
}

export interface MercenaryArchetype {
  name: string;
  class: ClassId;
  race: RaceId;
  baseCost: number;
  baseDailyCost: number;
  fleeThreshold: number; // e.g., 0.2 for 20% health
  statGrowth: BaseStatBlock;
  skillPool: AbilityId[];
  equipmentPool: Partial<Record<PlayerEquipmentSlot, ItemId[]>>;
}

export interface BaseStatBlock {
  strength: number;
  constitution: number;
  intelligence: number;
  dexterity: number;
}

export interface StatBlock extends BaseStatBlock {
  luck: number;
  attackPower: number;
  spellPower: number;
  armor: number;
  critChance: number;
  goldFind: number;
  xpGain: number;
  worldHpRegen: number;
  worldMpRegen: number;
  worldSpRegen: number;
  accuracy: number;
  evasion: number;
  attackSpeed: number;
  maxHp: number;
  maxMp: number;
  maxSp: number;
}

export interface OnHitEffect {
  applyStatusEffect: {
    id: StatusEffectId;
    chance: number;
    turns?: number;
    stage?: number;
  };
}

export interface TotalPlayerStats extends StatBlock {
  onHitEffects: OnHitEffect[];
}

export interface ItemInstance {
  id: ItemId;
  unique_id: string;
  name?: string; // For dynamic names, e.g. corpses
  weight?: number; // For dynamic weights, e.g. corpses
  enchantments: Partial<Record<keyof StatBlock, number>>;
  isUnidentified?: boolean;
  quality?: ItemQuality;
  charges?: number;
  maxCharges?: number;
  currentDurability?: number;
  maxDurability?: number;
  isBroken?: boolean;
  isUnrepairable?: boolean;
  isUnarmed?: boolean;
  containerState?: {
    items: ItemInstance[];
    capacity: number;
  };
  deceasedCharacter?: Mercenary;
}

export type Equipment = Record<PlayerEquipmentSlot, ItemInstance | null>;

export interface StatusEffectInstance {
  id: StatusEffectId;
  instanceId: string;
  linkedToInstanceId?: string;
  isClosed?: boolean;
  turnsRemaining: number;
  durationInMinutes: number;
  source?: string;
  currentStage?: number;
}

export interface Limb {
  id: string;
  displayName: string;
  maxHp: number;
  currentHp: number;
  armorValue: number;
  equipmentSlots: PlayerEquipmentSlot[];
  state: LimbState;
  statusEffects: StatusEffectInstance[];
  accuracyModifier?: number;
}

export type BodyPlan<T> = Record<string, T extends Limb ? T : Limb>;

export interface GameRace {
  name: string;
  desc: string;
  unarmedWeapon: ItemId;
  baseWeight: number;
  bonus: {
    stats?: Partial<BaseStatBlock>;
    perkPoints?: number;
    attributePoints?: number;
    professions?: Partial<Record<ProfessionId, number>>;
  };
}

export interface GameClass {
  name: string;
  desc: string;
  baseStats: BaseStatBlock;
  startEquip: ItemId[];
  startSkills: AbilityId[];
}

export type RestAid = {
  type: 'quality_bonus' | 'encounter_reduction';
  value: number;
  reusable?: boolean;
  lostOnFlee?: boolean;
};

export interface BaseItem {
  name: string;
  type: ItemType[];
  icon?: string;
  itemLevel: number;
  weight: number;
  value: number;
  desc?: string;
  stackable?: boolean;
  charges?: number;
  maxCharges?: number;
  chargeUnit?: string;
  destroyOnEmpty?: boolean;
  restAid?: RestAid;
}

export interface GameItem extends BaseItem {
  // from EquipmentItem
  slot?: EquipmentSlot;
  twoHanded?: boolean;
  stats?: Partial<StatBlock>;
  skillBonuses?: Partial<Record<ProfessionId, number>>;
  set?: ItemSetId;
  repReq?: { faction: FactionId; rank: number };
  onHit?: OnHitEffect;
  baseDurability?: number;
  recipeId?: RecipeId;
  defaultAttack?: { name: string; tags: string[] };
  isUnarmed?: boolean;
  // from PotionItem
  effect?: {
    applyStatusEffect?: {
      id: StatusEffectId;
      turns?: number;
      durationInMinutes?: number;
    };
    cureStatusEffect?: StatusEffectId;
    cureStage?: number;
    closesCutOfStage?: number;
    revive?: { percentHealth: number };
  };
  // from ContainerItem
  capacity?: number;
  // from ToolItem
  moldFor?: string;
  // from NoteItem
  teachesRecipe?: RecipeId;
  teachesAbility?: AbilityId;
  sellValue?: number;
  // Common property
  material?: ItemId;
  hardness?: number; // For materials
  durabilityMod?: number; // For materials
}

export interface Recipe {
  id: RecipeId;
  name: string;
  profession: ProfessionId;
  levelReq: number;
  xp: number;
  creates: ItemId;
  quantity: number;
  materials: Record<ItemId, number>;
  tools?: ItemId[];
  requiresMold?: boolean; // For smithing, signifies any appropriate mold is needed
  requiresForge?: boolean;
}

export interface ItemSet {
  name: string;
  bonuses: Record<
    number,
    {
      stats?: Partial<StatBlock>;
      special?: string;
      desc: string;
    }
  >;
}

export type SkillCategory = 'Weapon' | 'Armor' | 'Crafting' | 'Gathering' | 'Utility' | 'Passive';

export type SkillEffectType = 'damage' | 'buff' | 'tame' | 'pet_command' | 'stat' | 'auto_id_chance' | 'enable_pet' | 'heal_limb' | 'heal_body' | 'field' | 'revive';
export type SkillTargetType = 'self' | 'enemy' | 'all_enemies' | 'ally' | 'all_allies' | 'any';
export type AITag =
  | 'Single Target Consistent Damage'
  | 'Multi-Target Consistent Damage'
  | 'Execute'
  | 'Buff'
  | 'Debuff'
  | 'Recover Health'
  | 'Recovery Mana'
  | 'Recovery Stamina'
  | 'Field Effect';

export interface Ability {
  name: string;
  desc: string;

  abilityType: 'Skill' | 'Spell' | 'Perk';
  resourceType: 'MP' | 'SP' | 'None';
  resourceCost: number;
  damageTypeTags: string[];
  targetRule: 'SingleLimb' | 'MultiLimb' | 'AllLimbs' | 'Field' | 'Self' | 'AllEnemies' | 'AnyBody';
  range: 'Close' | 'Medium' | 'Long' | 'Fullscreen' | 'N/A';
  aiTags: AITag[];

  category: SkillCategory;

  maxRank?: number;
  reqSkill?: AbilityId;
  levelReq?: number;
  timeToUse?: number;
  validTargets?: ('self' | 'ally' | 'enemy' | 'any')[];

  effect: {
    type: SkillEffectType;
    target?: SkillTargetType;
    percentHealth?: number;

    scalesWith?: 'attackPower' | 'spellPower';
    multiplier?: number;
    accuracyMod?: number;

    chains?: number;
    chainDamageFalloff?: number;

    fieldDuration?: number;

    applyStatusEffect?:
      | {
          id: StatusEffectId;
          chance?: number;
          turns?: number;
          chanceCap?: number;
          stage?: number;
        }
      | { id: StatusEffectId; turns: number; stage?: number }[];

    scaling?: {
      multiplier?: number;
      chance?: number;
      turns?: number;
    };
    [key: string]: any;
  };
}

export interface StatusEffectStage {
  name: string;
  desc: string;
  effects?: StatusEffect['effects'];
  progression?: {
    type: 'TIME' | 'DAMAGE_TYPE';
    turns?: number;
    value?: ('slash' | 'pierce')[];
  };
}

export interface StatusEffect {
  name: string;
  desc: string;
  icon: string;
  isBeneficial: boolean;
  maxStacks?: number;
  maxStages?: number;
  effects?: {
    stats?: Partial<StatBlock>;
    statMods?: Partial<Record<keyof StatBlock, number>>;
    levelScaledStats?: Partial<Record<keyof StatBlock, number>>;
    costModifier?: { mp?: number; sp?: number };
    onTurn?:
      | {
          type: 'damage' | 'heal';
          base: number;
          scalesWith: 'attackPower' | 'spellPower';
          multiplier: number;
        }
      | { type: 'damage_percent_max_hp'; percent: number };
    onApply?: {
      type: 'skipTurn' | 'apply_status' | 'bleed_out';
      id?: StatusEffectId;
      turns?: number;
    };
    onDamageTaken?: {
      chance: number;
      effect: { id: StatusEffectId; turns: number };
      damageType?: 'physical' | 'magical';
    };
  };
  stages?: StatusEffectStage[];
}

export type NPCService =
  | {
      type: 'modal';
      id:
        | 'shop-modal'
        | 'bank-modal'
        | 'guild-modal'
        | 'faction-modal'
        | 'clinic-modal'
        | 'inn-modal'
        | 'crafting-modal'
        | 'mercenary-guild-modal'
        | 'appraiser-modal'
        | 'not-implemented';
      props?: Record<string, any>;
    }
  | { type: 'modal'; id: 'quest-modal'; quests: QuestId[] };

export interface TownNPC {
  name: string;
  services: NPCService[];
}

export interface GatherNode {
  type: ProfessionId;
  name: string;
  item: ItemId;
  chance: number;
  skillReq: number;
}

export interface Zone {
  name: string;
  levelReq: number;
  pos: { x: number; y: number };
  monsterPacks?: MonsterId[][];
  gather: GatherNode[];
  type?: 'town' | 'wilderness' | 'dungeon';
  stages?: number;
  monsters?: MonsterId[];
  boss?: MonsterId;
  dangerLevel?: number; // Base encounter chance
}

export interface MonsterData {
  name: string;
  race: RaceId;
  class: ClassId | 'none';
  level: number;
  hp: number; // Base HP, will be distributed among limbs
  attack: number;
  armor: number;
  xp: number;
  gold: number;
  lootTable: Record<ItemId, number>;
  skinnable?: ItemId;
  tamable?: PetId;
  bodyPlan?: string;
  unarmedWeapon?: ItemId;
  equipment?: Partial<Record<PlayerEquipmentSlot, ItemId>>;
  behavior?: any[];
  abilities?: any;
}

export interface Quest {
  name: string;
  giver: string;
  type: 'main' | 'side' | 'daily';
  startDesc: string;
  objective: { type: 'kill'; target: MonsterId; count: number } | { type: 'gather'; target: ItemId; count: number };
  reward: {
    xp?: number;
    gold?: number;
    items?: ItemId[];
    reputation?: { faction: FactionId; points: number };
    professions?: Partial<Record<ProfessionId, number>>;
  };
  prereq?: QuestId;
  levelReq?: number;
}

export interface RequirementCheck {
  ok: boolean;
  text: string;
}

export interface GameData {
  CLASSES: Record<ClassId, GameClass>;
  RACES: Record<RaceId, GameRace>;
  ITEMS: Record<ItemId, GameItem>;
  ITEM_SETS: Record<ItemSetId, ItemSet>;
  SKILLS: Record<AbilityId, Ability>;
  STATUS_EFFECTS: Record<StatusEffectId, StatusEffect>;
  MONSTERS: Record<MonsterId, MonsterData>;
  ZONES: Record<ZoneId, Zone>;
  TOWN_NPCS: Record<NPCId, TownNPC>;
  SHOP_INVENTORY: ItemId[];
  RECIPES: Record<ProfessionId, Recipe[]>;
  ALL_RECIPES: Record<RecipeId, Recipe>;
  ENCHANTS: Record<string, any[]>;
  QUESTS: Record<QuestId, Quest>;
  FACTIONS: Record<FactionId, any>;
  PETS: Record<PetId, any>;
  GUILD_DATA: any;
  ITEM_QUALITIES: Record<ItemQuality, { color: string; multiplier: number }>;
  BODY_PLANS: any;
  MERCENARIES: Record<MercenaryArchetypeId, MercenaryArchetype>;
}
