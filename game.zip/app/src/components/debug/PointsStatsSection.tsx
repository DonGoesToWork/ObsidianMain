import React from "react";
import { DebugContextType } from "types";

type PointsStatsSectionProps = Pick<
  DebugContextType,
  "debug_addPoints" | "debug_addAttributes"
>;

export const PointsStatsSection: React.FC<PointsStatsSectionProps> = ({
  debug_addPoints,
  debug_addAttributes,
}) => (
  <>
    <button
      onClick={() => debug_addPoints("stat", 10)}
      className="btn btn-secondary"
    >
      +10 Stat Points
    </button>
    <button
      onClick={() => debug_addPoints("perk", 10)}
      className="btn btn-secondary"
    >
      +10 Perk Points
    </button>
    <button
      onClick={() => debug_addAttributes(10)}
      className="btn btn-secondary"
    >
      +10 All Stats
    </button>
  </>
);