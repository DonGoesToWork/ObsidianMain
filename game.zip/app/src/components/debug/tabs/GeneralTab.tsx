import React from 'react';
import { MaxDebugSection } from '../sections/MaxDebugSection';

export const GeneralTab: React.FC = () => {
  return (
    <>
      <MaxDebugSection />
    </>
  );
};