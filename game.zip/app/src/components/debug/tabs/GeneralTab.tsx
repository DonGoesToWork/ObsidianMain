import React from 'react';
import { CharacterStateSection } from '../sections/CharacterStateSection';
import { CurrencySection } from '../sections/CurrencySection';
import { ExperienceLevelsSection } from '../sections/ExperienceLevelsSection';
import { ItemsSection } from '../sections/ItemsSection';
import { LimbStateSection } from '../sections/LimbStateSection';
import { MaxDebugSection } from '../sections/MaxDebugSection';
import { PointsStatsSection } from '../sections/PointsStatsSection';
import { StatSection } from '../sections/StatSection';
import { UnlocksSection } from '../sections/UnlocksSection';
import { VitalsSection } from '../sections/VitalsSection';

type DebugTab = 'Player' | 'Party' | 'Enemy' | 'All';

interface GeneralTabProps {
  tab: DebugTab;
}

export const GeneralTab: React.FC<GeneralTabProps> = ({ tab }) => {
  const isPlayerTab = tab === 'Player';
  const showCurrency = tab === 'Player' || tab === 'Party';
  const showVitals = tab === 'Player' || tab === 'Party';

  return (
    <>
      {isPlayerTab && <MaxDebugSection />}
      <CharacterStateSection />
      {showCurrency && <CurrencySection />}
      <ItemsSection />
      <ExperienceLevelsSection />
      {isPlayerTab && <PointsStatsSection />}
      <UnlocksSection showPlayerOnlyUnlocks={isPlayerTab} />
      <StatSection />
      {showVitals && <VitalsSection />}
      <LimbStateSection />
    </>
  );
};