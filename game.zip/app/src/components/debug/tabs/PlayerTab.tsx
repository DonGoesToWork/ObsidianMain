import React from 'react';
import { CharacterStateSection } from '../sections/CharacterStateSection';
import { CurrencySection } from '../sections/CurrencySection';
import { ItemsSection } from '../sections/ItemsSection';
import { ExperienceLevelsSection } from '../sections/ExperienceLevelsSection';
import { PointsStatsSection } from '../sections/PointsStatsSection';
import { UnlocksSection } from '../sections/UnlocksSection';
import { StatSection } from '../sections/StatSection';
import { VitalsSection } from '../sections/VitalsSection';
import { LimbStateSection } from '../sections/LimbStateSection';

export const PlayerTab: React.FC = () => {
  return (
    <>
      <CharacterStateSection />
      <CurrencySection />
      <ItemsSection />
      <ExperienceLevelsSection />
      <PointsStatsSection />
      <StatSection />
      <UnlocksSection showPlayerOnlyUnlocks={true} />
      <VitalsSection />
      <LimbStateSection />
    </>
  );
};