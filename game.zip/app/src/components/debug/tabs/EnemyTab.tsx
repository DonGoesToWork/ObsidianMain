import React from 'react';
import { CharacterStateSection } from '../sections/CharacterStateSection';
import { StatSection } from '../sections/StatSection';
import { LimbStateSection } from '../sections/LimbStateSection';
import { UnlocksSection } from '../sections/UnlocksSection';
import { ItemsSection } from '../sections/ItemsSection';
import { ExperienceLevelsSection } from '../sections/ExperienceLevelsSection';

export const EnemyTab: React.FC = () => {
  return (
    <>
      <CharacterStateSection />
      <ItemsSection />
      <ExperienceLevelsSection />
      <UnlocksSection showPlayerOnlyUnlocks={false} />
      <StatSection />
      <LimbStateSection />
    </>
  );
};