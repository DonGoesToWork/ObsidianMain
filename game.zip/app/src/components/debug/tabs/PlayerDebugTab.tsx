import React from 'react';
import { CharacterStateSection } from '../sections/CharacterStateSection';
import { CurrencySection } from '../sections/CurrencySection';
import { ExperienceLevelsSection } from '../sections/ExperienceLevelsSection';
import { ItemsISection } from '../sections/ItemsISection';
import { ItemsIISection } from '../sections/ItemsIISection';
import { LimbStateSection } from '../sections/LimbStateSection';
import { MaxDebugSection } from '../sections/MaxDebugSection';
import { PointsStatsSection } from '../sections/PointsStatsSection';
import { StatSection } from '../sections/StatSection';
import { UnlocksSection } from '../sections/UnlocksSection';
import { VitalsSection } from '../sections/VitalsSection';

export const PlayerDebugTab: React.FC = () => (
  <>
    <MaxDebugSection />
    <CharacterStateSection />
    <CurrencySection />
    <ItemsISection />
    <ItemsIISection />
    <ExperienceLevelsSection />
    <PointsStatsSection />
    <UnlocksSection showPlayerOnlyUnlocks={true} />
    <StatSection />
    <VitalsSection />
    <LimbStateSection />
  </>
);