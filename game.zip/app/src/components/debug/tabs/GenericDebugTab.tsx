import React from 'react';
import { CharacterStateSection } from '../sections/CharacterStateSection';
import { ExperienceLevelsSection } from '../sections/ExperienceLevelsSection';
import { ItemsISection } from '../sections/ItemsISection';
import { ItemsIISection } from '../sections/ItemsIISection';
import { LimbStateSection } from '../sections/LimbStateSection';
import { StatSection } from '../sections/StatSection';
import { UnlocksSection } from '../sections/UnlocksSection';

export const GenericDebugTab: React.FC = () => (
  <>
    <CharacterStateSection />
    <ItemsISection />
    <ItemsIISection />
    <ExperienceLevelsSection />
    <UnlocksSection showPlayerOnlyUnlocks={false} />
    <StatSection />
    <LimbStateSection />
  </>
);