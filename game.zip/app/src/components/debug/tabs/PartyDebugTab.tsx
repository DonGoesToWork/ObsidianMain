import React from 'react';
import { CharacterStateSection } from '../sections/CharacterStateSection';
import { CurrencySection } from '../sections/CurrencySection';
import { ExperienceLevelsSection } from '../sections/ExperienceLevelsSection';
import { ItemsISection } from '../sections/ItemsISection';
import { ItemsIISection } from '../sections/ItemsIISection';
import { LimbStateSection } from '../sections/LimbStateSection';
import { StatSection } from '../sections/StatSection';
import { UnlocksSection } from '../sections/UnlocksSection';
import { VitalsSection } from '../sections/VitalsSection';

export const PartyDebugTab: React.FC = () => (
  <>
    <CharacterStateSection />
    <CurrencySection />
    <ItemsISection />
    <ItemsIISection />
    <ExperienceLevelsSection />
    <UnlocksSection showPlayerOnlyUnlocks={false} />
    <StatSection />
    <VitalsSection />
    <LimbStateSection />
  </>
);