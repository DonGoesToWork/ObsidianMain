import React from 'react';
import { CharacterStateSection } from '../sections/CharacterStateSection';
import { StatSection } from '../sections/StatSection';
import { VitalsSection } from '../sections/VitalsSection';
import { LimbStateSection } from '../sections/LimbStateSection';
import { UnlocksSection } from '../sections/UnlocksSection';
import { ItemsSection } from '../sections/ItemsSection';
import { CurrencySection } from '../sections/CurrencySection';
import { ExperienceLevelsSection } from '../sections/ExperienceLevelsSection';

export const PartyTab: React.FC = () => {
  return (
    <>
      <CharacterStateSection />
      <CurrencySection />
      <ItemsSection />
      <ExperienceLevelsSection />
      <UnlocksSection showPlayerOnlyUnlocks={false} />
      <StatSection />
      <VitalsSection />
      <LimbStateSection />
    </>
  );
};