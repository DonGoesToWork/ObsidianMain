import React from "react";
import { DebugContextType } from "types";

type PlayerStateSectionProps = Pick<
  DebugContextType,
  | "debug_fullHeal"
  | "debug_fullHealAll"
  | "debug_restoreResources"
  | "debug_clearDebuffs"
>;

export const PlayerStateSection: React.FC<PlayerStateSectionProps> = ({
  debug_fullHeal,
  debug_fullHealAll,
  debug_restoreResources,
  debug_clearDebuffs,
}) => (
  <>
    <button
      onClick={() => debug_fullHeal("player")}
      className="btn btn-secondary"
    >
      Full Heal Self
    </button>
    <button onClick={() => debug_fullHealAll()} className="btn btn-secondary">
      Full Heal All
    </button>
    <button
      onClick={() => debug_restoreResources("player")}
      className="btn btn-secondary"
    >
      Restore HP/MP/SP
    </button>
    <button
      onClick={() => debug_clearDebuffs("player")}
      className="btn btn-secondary"
    >
      Clear Debuffs
    </button>
  </>
);