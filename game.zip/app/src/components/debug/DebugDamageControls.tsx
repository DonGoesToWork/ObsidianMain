import { Limb, Mercenary, Player } from "types";
import React, { useContext, useState } from "react";
import { DebugContext } from "context/DebugContext";
import { usePlayer } from "hooks/usePlayer";

const DAMAGE_TYPES = ["Slashing", "Pierce", "Blunt", "Fire", "Ice", "Lightning", "Holy", "Poison"];

const getCharId = (c: Player | Mercenary) => ("professions" in c ? "player" : (c as Mercenary).id);

export const DebugDamageControls: React.FC<{
  character: Player | Mercenary | undefined;
}> = ({ character }) => {
  const { debug_applyDirectDamage } = useContext(DebugContext)!;

  const [damageMode, setDamageMode] = useState<"percent" | "exact">("percent");
  const [damageValue, setDamageValue] = useState<number>(10);
  const [selectedLimbIds, setSelectedLimbIds] = useState<string[]>([]);
  const [selectedDamageTypes, setSelectedDamageTypes] = useState<string[]>(["Slashing"]);

  const characterId = character ? getCharId(character) : undefined;

  React.useEffect(() => {
    setSelectedLimbIds([]);
  }, [characterId]);

  if (!character) return null;

  const handleLimbSelectionChange = (limbId: string) => {
    setSelectedLimbIds((prev) => (prev.includes(limbId) ? prev.filter((id) => id !== limbId) : [...prev, limbId]));
  };

  const handleDamageTypeChange = (type: string) => {
    setSelectedDamageTypes((prev) => (prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]));
  };

  const handleHit = () => {
    if (selectedLimbIds.length === 0 || damageValue <= 0 || !characterId) {
      return;
    }
    const targetId = characterId;

    selectedLimbIds.forEach((limbId) => {
      const limb = character.body[limbId as keyof typeof character.body] as Limb;
      if (!limb) return;

      let finalDamage = damageValue;
      if (damageMode === "percent") {
        finalDamage = Math.round(limb.maxHp * (damageValue / 100));
      }

      debug_applyDirectDamage(targetId, limbId, finalDamage, selectedDamageTypes);
    });
  };

  return (
    <div className="debug-combat-simulator">
      <div className="sim-control-group">
        <h4>Damage Amount</h4>
        <div className="radio-group">
          <label>
            <input type="radio" value="percent" checked={damageMode === "percent"} onChange={() => setDamageMode("percent")} />
            Damage by % of Max HP
          </label>
          <label>
            <input type="radio" value="exact" checked={damageMode === "exact"} onChange={() => setDamageMode("exact")} />
            Exact Damage Value
          </label>
        </div>
        <input type="number" value={damageValue} onChange={(e) => setDamageValue(Number(e.target.value))} className="sim-input" />
      </div>

      <div className="sim-control-group">
        <h4>Target Limbs</h4>
        <div className="checkbox-group">
          {Object.values(character.body).map((limb) => (
            <label key={limb.id}>
              <input type="checkbox" value={limb.id} checked={selectedLimbIds.includes(limb.id)} onChange={() => handleLimbSelectionChange(limb.id)} />
              {limb.displayName} ({limb.currentHp.toFixed(0)}/{limb.maxHp})
            </label>
          ))}
        </div>
      </div>

      <div className="sim-control-group">
        <h4>Damage Types</h4>
        <div className="checkbox-group">
          {DAMAGE_TYPES.map((type) => (
            <label key={type}>
              <input type="checkbox" value={type} checked={selectedDamageTypes.includes(type)} onChange={() => handleDamageTypeChange(type)} />
              {type}
            </label>
          ))}
        </div>
      </div>

      <div className="sim-control-group">
        <button className="btn" onClick={handleHit}>
          Hit {character.name}
        </button>
      </div>
    </div>
  );
};