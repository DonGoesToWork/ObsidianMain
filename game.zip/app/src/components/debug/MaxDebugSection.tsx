import React from "react";
import { DebugContextType, WorldContextType } from "types";

type MaxDebugSectionProps = Pick<DebugContextType, "debug_test_all"> &
  Pick<WorldContextType, "changeGameState" | "debug_teleportToTown"> & {
    closeModal: () => void;
  };

export const MaxDebugSection: React.FC<MaxDebugSectionProps> = ({
  debug_test_all,
  closeModal,
  changeGameState,
  debug_teleportToTown,
}) => (
  <>
    <button onClick={() => debug_test_all()} className="btn btn-secondary">
      Do It All
    </button>
    <button
      onClick={() => {
        closeModal();
        changeGameState("combat-sim");
      }}
      className="btn btn-secondary"
    >
      Open Combat Sim
    </button>
    <button onClick={() => debug_teleportToTown()} className="btn btn-secondary">
      To Starter Town
    </button>
  </>
);