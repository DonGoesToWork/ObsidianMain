import { Combatant, Mercenary, Player } from 'types';
import { createContext } from 'react';

export interface DebugTargetContextType {
  primaryTarget: Player | Mercenary | Combatant | null;
}

export const DebugTargetContext = createContext<DebugTargetContextType | null>(null);