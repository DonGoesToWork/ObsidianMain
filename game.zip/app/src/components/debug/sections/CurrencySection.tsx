import React, { useContext } from 'react';
import { DebugContext } from 'context/DebugContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h4 className="debug-section-header">{title}</h4>
    {children}
  </div>
);

export const CurrencySection: React.FC = () => {
  const { debug_addGold } = useContext(DebugContext)!;
  return (
    <DebugSection title="Currency">
      <button onClick={() => debug_addGold(1000)} className="btn btn-secondary">
        +1k Gold
      </button>
      <button onClick={() => debug_addGold(10000)} className="btn btn-secondary">
        +10k Gold
      </button>
      <button onClick={() => debug_addGold(1000000)} className="btn btn-secondary">
        +1m Gold
      </button>
    </DebugSection>
  );
};