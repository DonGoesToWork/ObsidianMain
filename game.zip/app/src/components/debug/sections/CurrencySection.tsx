import React, { useContext } from 'react';

import { DebugContext } from 'context/DebugContext';
import { DebugSetter } from '../shared/DebugSetter';
import { DebugTargetContext } from '../DebugTargetContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h3 className="debug-section-header">{title}</h3>
    {children}
  </div>
);

export const CurrencySection: React.FC = () => {
  const { debug_addGold, debug_setGold } = useContext(DebugContext)!;
  const { primaryTarget } = useContext(DebugTargetContext)!;

  const currentGold = primaryTarget && 'gold' in primaryTarget ? primaryTarget.gold : 0;

  return (
    <DebugSection title="Currency">
      <DebugSetter
        title={`Add Gold (${currentGold?.toLocaleString()})`}
        onSet={debug_addGold}
        quickSets={[
          { label: '+1k', value: 1000 },
          { label: '+10k', value: 10000 },
          { label: '+100k', value: 100000 },
        ]}
      />
      <DebugSetter
        title={`Set Gold (${currentGold?.toLocaleString()})`}
        onSet={debug_setGold}
        quickSets={[
          { label: 'Set 0', value: 0 },
          { label: 'Set 10k', value: 10000 },
          { label: 'Set 1m', value: 1000000 },
        ]}
      />
    </DebugSection>
  );
};
