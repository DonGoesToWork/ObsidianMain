import React, { useContext } from 'react';

import { DebugContext } from 'context/DebugContext';
import { DebugSetter } from '../shared/DebugSetter';
import { DebugTargetContext } from '../DebugTargetContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h3 className="debug-section-header">{title}</h3>
    {children}
  </div>
);

export const VitalsSection: React.FC = () => {
  const { debug_modifyVitals, debug_setVital } = useContext(DebugContext)!;
  const { primaryTarget } = useContext(DebugTargetContext)!;

  const currentHunger = primaryTarget && 'vitals' in primaryTarget ? primaryTarget.vitals.hunger.current.toFixed(0) : 'N/A';
  const currentThirst = primaryTarget && 'vitals' in primaryTarget ? primaryTarget.vitals.thirst.current.toFixed(0) : 'N/A';

  return (
    <DebugSection title="Vitals">
      <DebugSetter
        title={`Add Hunger (${currentHunger})`}
        onSet={(val) => debug_modifyVitals('hunger', val)}
        quickSets={[
          { label: '+10', value: 10 },
          { label: '-10', value: -10 },
          { label: '+100', value: 100 },
        ]}
      />
      <DebugSetter
        title={`Set Hunger (${currentHunger})`}
        onSet={(val) => debug_setVital('hunger', val)}
        quickSets={[
          { label: 'Set 0', value: 0 },
          { label: 'Set 100', value: 100 },
        ]}
      />

      <hr style={{ border: 'none', borderTop: '1px solid #444', margin: '10px 0' }} />

      <DebugSetter
        title={`Add Thirst (${currentThirst})`}
        onSet={(val) => debug_modifyVitals('thirst', val)}
        quickSets={[
          { label: '+10', value: 10 },
          { label: '-10', value: -10 },
          { label: '+100', value: 100 },
        ]}
      />
      <DebugSetter
        title={`Set Thirst (${currentThirst})`}
        onSet={(val) => debug_setVital('thirst', val)}
        quickSets={[
          { label: 'Set 0', value: 0 },
          { label: 'Set 100', value: 100 },
        ]}
      />
    </DebugSection>
  );
};
