import React, { useContext } from 'react';
import { DebugContext } from 'context/DebugContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h4 className="debug-section-header">{title}</h4>
    {children}
  </div>
);

export const VitalsSection: React.FC = () => {
  const { debug_modifyVitals } = useContext(DebugContext)!;
  return (
    <DebugSection title="Vitals">
      <button onClick={() => debug_modifyVitals('hunger', 100)} className="btn btn-secondary">
        Restore Hunger
      </button>
      <button onClick={() => debug_modifyVitals('hunger', -50)} className="btn btn-secondary">
        -50 Hunger
      </button>
      <button onClick={() => debug_modifyVitals('thirst', 100)} className="btn btn-secondary">
        Restore Thirst
      </button>
      <button onClick={() => debug_modifyVitals('thirst', -50)} className="btn btn-secondary">
        -50 Thirst
      </button>
    </DebugSection>
  );
};