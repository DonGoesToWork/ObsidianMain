import React, { useContext } from 'react';
import { DebugContext } from 'context/DebugContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h4 className="debug-section-header">{title}</h4>
    {children}
  </div>
);

export const StatSection: React.FC = () => {
  const { debug_addAttributes } = useContext(DebugContext)!;
  return (
    <DebugSection title="Stats">
      <button onClick={() => debug_addAttributes(10)} className="btn btn-secondary">
        +10 All Stats
      </button>
    </DebugSection>
  );
};