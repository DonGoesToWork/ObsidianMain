import React, { useContext } from 'react';

import { DebugContext } from 'context/DebugContext';
import { DebugSetter } from '../shared/DebugSetter';
import { DebugTargetContext } from '../DebugTargetContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h3 className="debug-section-header">{title}</h3>
    {children}
  </div>
);

export const StatSection: React.FC = () => {
  const { debug_addAttributes, debug_setAttributes } = useContext(DebugContext)!;
  const { primaryTarget } = useContext(DebugTargetContext)!;

  const currentStr = primaryTarget?.baseStats.strength || 0;
  const currentCon = primaryTarget?.baseStats.constitution || 0;
  const currentInt = primaryTarget?.baseStats.intelligence || 0;
  const currentDex = primaryTarget?.baseStats.dexterity || 0;
  const displayValue = `(S:${currentStr} C:${currentCon} I:${currentInt} D:${currentDex})`;

  return (
    <DebugSection title={`Base Attributes ${displayValue}`}>
      <DebugSetter
        title="Add to All Stats"
        onSet={debug_addAttributes}
        quickSets={[
          { label: '+1', value: 1 },
          { label: '+10', value: 10 },
          { label: '+100', value: 100 },
        ]}
      />
      <DebugSetter
        title="Set All Stats"
        onSet={debug_setAttributes}
        quickSets={[
          { label: 'Set 10', value: 10 },
          { label: 'Set 50', value: 50 },
          { label: 'Set 100', value: 100 },
        ]}
      />
    </DebugSection>
  );
};
