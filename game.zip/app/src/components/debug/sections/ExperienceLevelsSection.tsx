import React, { useContext } from 'react';
import { DebugContext } from 'context/DebugContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h4 className="debug-section-header">{title}</h4>
    {children}
  </div>
);

export const ExperienceLevelsSection: React.FC = () => {
  const { debug_addXP, debug_addLevel } = useContext(DebugContext)!;
  return (
    <DebugSection title="Experience & Levels">
      <button onClick={() => debug_addXP(100)} className="btn btn-secondary">
        +100 XP
      </button>
      <button onClick={() => debug_addXP(1000)} className="btn btn-secondary">
        +1k XP
      </button>
      <button onClick={() => debug_addLevel(1)} className="btn btn-secondary">
        +1 Level
      </button>
      <button onClick={() => debug_addLevel(5)} className="btn btn-secondary">
        +5 Levels
      </button>
    </DebugSection>
  );
};