import React, { useContext } from 'react';

import { DebugContext } from 'context/DebugContext';
import { DebugTargetContext } from '../DebugTargetContext';
import { DebugSetter } from '../shared/DebugSetter';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h3 className="debug-section-header">{title}</h3>
    {children}
  </div>
);

export const ExperienceLevelsSection: React.FC = () => {
  const { debug_addXP, debug_setXP, debug_addLevel, debug_setLevel } = useContext(DebugContext)!;
  const { primaryTarget } = useContext(DebugTargetContext)!;

  const currentXP = primaryTarget && 'xp' in primaryTarget ? primaryTarget.xp : 0;
  const currentLevel = primaryTarget ? primaryTarget.level : 0;

  return (
    <DebugSection title="Experience & Levels">
      <DebugSetter
        title={`Add XP (${currentXP})`}
        onSet={debug_addXP}
        quickSets={[
          { label: '+100', value: 100 },
          { label: '+1k', value: 1000 },
          { label: '+10k', value: 10000 },
        ]}
      />
      <DebugSetter
        title={`Set XP (${currentXP})`}
        onSet={debug_setXP}
        quickSets={[
          { label: 'Set 0', value: 0 },
          { label: 'Set 50', value: 50 },
          { label: 'Set 500', value: 500 },
        ]}
      />
      <hr style={{ border: 'none', borderTop: '1px solid #444', margin: '10px 0' }} />
      <DebugSetter
        title={`Add Level(s) (${currentLevel})`}
        onSet={debug_addLevel}
        quickSets={[
          { label: '+1', value: 1 },
          { label: '+5', value: 5 },
          { label: '+10', value: 10 },
        ]}
      />
      <DebugSetter
        title={`Set Level (${currentLevel})`}
        onSet={debug_setLevel}
        quickSets={[
          { label: 'Set 1', value: 1 },
          { label: 'Set 50', value: 50 },
          { label: 'Set 100', value: 100 },
        ]}
      />
    </DebugSection>
  );
};
