import React, { useContext } from 'react';

import { DebugContext } from 'context/DebugContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h3 className="debug-section-header">{title}</h3>
    {children}
  </div>
);

export const ItemsIISection: React.FC = () => {
  const { debug_giveAllRecipeItems } = useContext(DebugContext)!;
  return (
    <DebugSection title="Items II">
      <button onClick={() => debug_giveAllRecipeItems?.()} className="btn btn-secondary">
        Give Recipes
      </button>
    </DebugSection>
  );
};