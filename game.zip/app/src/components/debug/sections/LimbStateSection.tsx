import { Mercenary, Player } from 'types';
import React, { useContext, useState } from 'react';

import { DebugContext } from 'context/DebugContext';
import { DebugSetter } from '../shared/DebugSetter';
import { DebugTargetContext } from '../DebugTargetContext';
import { usePlayer } from 'hooks/usePlayer';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h3 className="debug-section-header">{title}</h3>
    {children}
  </div>
);

export const LimbStateSection: React.FC = () => {
  const player = usePlayer(); // Used for limb list template
  const { primaryTarget } = useContext(DebugTargetContext)!;
  const { debug_setLimbHp } = useContext(DebugContext)!;
  const [selectedLimbId, setSelectedLimbId] = useState<string>('head');
  const [mode, setMode] = useState<'percent' | 'exact'>('percent');

  const allLimbs = React.useMemo(() => {
    if (!primaryTarget) return [];
    return Object.values(primaryTarget.body).map((limb) => ({ id: limb.id, name: limb.displayName }));
  }, [primaryTarget]);

  const handleSetHp = (value: number) => {
    if (!selectedLimbId) return;
    debug_setLimbHp(selectedLimbId, value, mode === 'percent');
  };

  const quickSets =
    mode === 'percent'
      ? [
          { label: '0%', value: 0 },
          { label: '100%', value: 100 },
        ]
      : [];

  const limbData = primaryTarget?.body[selectedLimbId];
  const currentHpDisplay = limbData ? `(${limbData.currentHp.toFixed(0)}/${limbData.maxHp.toFixed(0)})` : '';

  return (
    <DebugSection title={`Limb HP ${currentHpDisplay}`}>
      <div>
        <h3>Limb</h3>
        <div className="debug-radio-group">
          {allLimbs.map((limb) => (
            <label key={limb.id}>
              <input type="radio" name="limb-select" value={limb.id} checked={selectedLimbId === limb.id} onChange={(e) => setSelectedLimbId(e.target.value)} />
              {limb.name}
            </label>
          ))}
        </div>
      </div>
      <div>
        <h3>Mode</h3>
        <div className="debug-radio-group">
          <label>
            <input type="radio" name="hp-mode" value="percent" checked={mode === 'percent'} onChange={() => setMode('percent')} />
            Percent
          </label>
          <label>
            <input type="radio" name="hp-mode" value="exact" checked={mode === 'exact'} onChange={() => setMode('exact')} />
            Exact
          </label>
        </div>
      </div>
      <DebugSetter title={`Set HP ${mode === 'percent' ? '(%)' : ''}`} onSet={handleSetHp} quickSets={quickSets} inputDefault={mode === 'percent' ? 100 : 10} />
    </DebugSection>
  );
};