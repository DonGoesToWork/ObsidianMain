import React, { useContext, useState } from 'react';
import { DebugContext } from 'context/DebugContext';
import { usePlayer } from 'hooks/usePlayer';
import { LimbState } from 'types';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h4 className="debug-section-header">{title}</h4>
    {children}
  </div>
);

export const LimbStateSection: React.FC = () => {
  const player = usePlayer();
  const { debug_setLimbState } = useContext(DebugContext)!;
  const [selectedLimbId, setSelectedLimbId] = useState<string>('head');

  const allLimbs = React.useMemo(() => {
    if (!player) return [];
    // Just use player's body plan as a template for all humanoids
    return Object.keys(player.body);
  }, [player]);

  return (
    <DebugSection title="Limb State">
      <select value={selectedLimbId} onChange={(e) => setSelectedLimbId(e.target.value)} style={{ padding: '8px', marginBottom: '10px' }}>
        {allLimbs.map((limbId) => (
          <option key={limbId} value={limbId}>
            {limbId}
          </option>
        ))}
      </select>
      <button onClick={() => debug_setLimbState(selectedLimbId, 'Healthy')} className="btn btn-secondary">
        Set Healthy
      </button>
      <button onClick={() => debug_setLimbState(selectedLimbId, 'Injured')} className="btn btn-secondary">
        Set Injured
      </button>
      <button onClick={() => debug_setLimbState(selectedLimbId, 'Destroyed')} className="btn btn-secondary">
        Set Destroyed
      </button>
    </DebugSection>
  );
};