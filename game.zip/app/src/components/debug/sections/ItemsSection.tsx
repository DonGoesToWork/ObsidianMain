import React, { useContext } from 'react';

import { DebugContext } from 'context/DebugContext';
import { DebugSetter } from '../shared/DebugSetter';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h3 className="debug-section-header">{title}</h3>
    {children}
  </div>
);

export const ItemsSection: React.FC = () => {
  const { debug_duplicateItems, debug_giveRandomItems, debug_giveDamagedItem, debug_clearInventory, debug_giveAntiGravityChest } = useContext(DebugContext)!;

  return (
    <DebugSection title="Items">
      <DebugSetter
        title="Give Random Items"
        onSet={(count) => debug_giveRandomItems(count)}
        quickSets={[
          { label: '1x', value: 1 },
          { label: '5x', value: 5 },
        ]}
      />
      <DebugSetter
        title="Give Random Unidentified Items"
        onSet={(count) => debug_giveRandomItems(count, { unidentifiedWithEnchantments: true })}
        quickSets={[
          { label: '1x', value: 1 },
          { label: '5x', value: 5 },
        ]}
      />
      <DebugSetter
        title="Give Damaged Item"
        onSet={(count) => debug_giveDamagedItem(count)}
        quickSets={[
          { label: '1x', value: 1 },
          { label: '5x', value: 5 },
        ]}
      />
      <DebugSetter
        title="Give Anti-Gravity Chest"
        onSet={(count) => debug_giveAntiGravityChest(count)}
        quickSets={[
          { label: '1x', value: 1 },
          { label: '5x', value: 5 },
        ]}
      />
      <hr style={{ border: 0, borderTop: '1px solid #444', margin: '10px 0' }} />
      <button onClick={() => debug_duplicateItems()} className="btn btn-secondary">
        Duplicate Items
      </button>
      <button onClick={() => debug_clearInventory()} className="btn btn-secondary">
        Clear Inventory
      </button>
    </DebugSection>
  );
};
