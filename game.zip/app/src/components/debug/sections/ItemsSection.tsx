import React, { useContext } from 'react';
import { DebugContext } from 'context/DebugContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h4 className="debug-section-header">{title}</h4>
    {children}
  </div>
);

export const ItemsSection: React.FC = () => {
  const { debug_duplicateItems, debug_giveRandomItems, debug_giveDamagedItem, debug_clearInventory } = useContext(DebugContext)!;

  return (
    <DebugSection title="Items">
      <button onClick={() => debug_duplicateItems()} className="btn btn-secondary">
        Duplicate Items
      </button>
      <button onClick={() => debug_giveRandomItems(5)} className="btn btn-secondary">
        Give 5x Random Item
      </button>
      <button onClick={() => debug_giveDamagedItem()} className="btn btn-secondary">
        Give Damaged Item
      </button>
      <button onClick={() => debug_clearInventory()} className="btn btn-secondary">
        Clear Inventory
      </button>
    </DebugSection>
  );
};