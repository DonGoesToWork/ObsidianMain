import React, { useContext } from 'react';
import { DebugContext } from 'context/DebugContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h4 className="debug-section-header">{title}</h4>
    {children}
  </div>
);

export const PlayerStateSection: React.FC = () => {
  const { debug_fullHeal, debug_restoreResources, debug_clearDebuffs } = useContext(DebugContext)!;
  return (
    <DebugSection title="Character State">
      <button onClick={() => debug_fullHeal()} className="btn btn-secondary">
        Full Heal Self
      </button>
      <button onClick={() => debug_restoreResources()} className="btn btn-secondary">
        Restore HP/MP/SP
      </button>
      <button onClick={() => debug_clearDebuffs()} className="btn btn-secondary">
        Clear Debuffs
      </button>
    </DebugSection>
  );
};