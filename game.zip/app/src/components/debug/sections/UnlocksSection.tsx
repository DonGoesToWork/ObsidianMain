import React, { useContext } from 'react';
import { DebugContext } from 'context/DebugContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h4 className="debug-section-header">{title}</h4>
    {children}
  </div>
);

export const UnlocksSection: React.FC<{ showPlayerOnlyUnlocks?: boolean }> = ({ showPlayerOnlyUnlocks = true }) => {
  const { debug_maxProfessions, debug_learnAllRecipes, debug_learnAllSkills, debug_learnAllSpells, debug_unlockAll } = useContext(DebugContext)!;
  return (
    <DebugSection title="Unlocks">
      {showPlayerOnlyUnlocks && (
        <>
          <button onClick={() => debug_maxProfessions()} className="btn btn-secondary">
            Max Professions
          </button>
          <button onClick={() => debug_learnAllRecipes()} className="btn btn-secondary">
            Learn all Recipes
          </button>
        </>
      )}
      <button onClick={() => debug_learnAllSkills()} className="btn btn-secondary">
        Learn all Skills
      </button>
      <button onClick={() => debug_learnAllSpells()} className="btn btn-secondary">
        Learn all Spells
      </button>
      {showPlayerOnlyUnlocks && (
        <button onClick={() => debug_unlockAll()} className="btn btn-secondary">
          Unlock All
        </button>
      )}
    </DebugSection>
  );
};