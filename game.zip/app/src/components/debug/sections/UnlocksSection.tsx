import React, { useContext } from 'react';

import { DebugContext } from 'context/DebugContext';
import { DebugSetter } from '../shared/DebugSetter';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h3 className="debug-section-header">{title}</h3>
    {children}
  </div>
);

export const UnlocksSection: React.FC<{ showPlayerOnlyUnlocks?: boolean }> = ({ showPlayerOnlyUnlocks = true }) => {
  const { debug_learnAllRecipes, debug_learnAllEnchantmentRecipes, debug_learnAllSkills, debug_learnAllSpells, debug_unlockAll, debug_setProfessionLevel, debug_lockAll } =
    useContext(DebugContext)!;
  return (
    <DebugSection title="Unlocks">
      {showPlayerOnlyUnlocks && (
        <>
          <DebugSetter
            title="Set Profession Levels"
            onSet={debug_setProfessionLevel}
            quickSets={[
              { label: 'Set All 1', value: 1 },
              { label: 'Set All 100', value: 100 },
              { label: 'Set All 1000', value: 1000 },
            ]}
          />
          <hr style={{ border: 0, borderTop: '1px solid #444', margin: '10px 0' }} />
          <button onClick={() => debug_learnAllRecipes()} className="btn btn-secondary">
            Learn all Recipes
          </button>
          <button onClick={() => debug_learnAllEnchantmentRecipes()} className="btn btn-secondary">
            Learn all Enchantment Recipes
          </button>
        </>
      )}
      <button onClick={() => debug_learnAllSkills()} className="btn btn-secondary">
        Learn all Skills
      </button>
      <button onClick={() => debug_learnAllSpells()} className="btn btn-secondary">
        Learn all Spells
      </button>
      {showPlayerOnlyUnlocks && (
        <button onClick={() => debug_unlockAll()} className="btn btn-secondary">
          Unlock All
        </button>
      )}
      {showPlayerOnlyUnlocks && (
        <button onClick={() => debug_lockAll?.()} className="btn btn-secondary">
          Lock All
        </button>
      )}
    </DebugSection>
  );
};