import React, { useContext } from 'react';
import { DebugContext } from 'context/DebugContext';
import { WorldContext } from 'context/WorldContext';
import { UIContext } from 'context/UIContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h4 className="debug-section-header">{title}</h4>
    {children}
  </div>
);

export const MaxDebugSection: React.FC = () => {
  const { debug_test_all, debug_setGameTimeToStartOfDay } = useContext(DebugContext)!;
  const { changeGameState, debug_teleportToTown } = useContext(WorldContext)!;
  const { setActiveModal } = useContext(UIContext)!;

  return (
    <DebugSection title="General">
      <button onClick={() => debug_test_all()} className="btn btn-secondary">
        Do It All
      </button>
      <button
        onClick={() => {
          setActiveModal(null);
          changeGameState('combat-sim');
        }}
        className="btn btn-secondary"
      >
        Open Combat Sim
      </button>
      <button onClick={() => debug_teleportToTown()} className="btn btn-secondary">
        To Starter Town
      </button>
      <button onClick={() => setActiveModal('debug-shop-modal')} className="btn btn-secondary">
        Open Debug Shop
      </button>
      <button onClick={() => debug_setGameTimeToStartOfDay()} className="btn btn-secondary">
        Set Time to 12:00:00 AM
      </button>
    </DebugSection>
  );
};
