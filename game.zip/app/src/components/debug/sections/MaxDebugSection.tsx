import React, { useContext } from 'react';

import { DebugContext } from 'context/DebugContext';
import { UIContext } from 'context/UIContext';
import { WorldContext } from 'context/WorldContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h3 className="debug-section-header">{title}</h3>
    {children}
  </div>
);

export const MaxDebugSection: React.FC = () => {
  const { debug_test_all, debug_setGameTimeToStartOfDay, debug_craftGod } = useContext(DebugContext)!;
  const { changeGameState, debug_teleportToTown } = useContext(WorldContext)!;
  const { setActiveModal } = useContext(UIContext)!;

  return (
    <DebugSection title="General">
      <button onClick={() => debug_test_all()} className="btn btn-secondary">
        Do It All
      </button>
      <button onClick={() => debug_craftGod?.()} className="btn btn-secondary">
        Craft God
      </button>
      <button
        onClick={() => {
          setActiveModal(null);
          changeGameState('combat-sim');
        }}
        className="btn btn-secondary"
      >
        Open Combat Sim
      </button>
      <button onClick={() => debug_teleportToTown()} className="btn btn-secondary">
        To Starter Town
      </button>
      <button onClick={() => setActiveModal('debug-shop-modal')} className="btn btn-secondary">
        Open Debug Shop
      </button>
      <button onClick={() => debug_setGameTimeToStartOfDay()} className="btn btn-secondary">
        Set Time to 12:00:00 AM
      </button>
    </DebugSection>
  );
};