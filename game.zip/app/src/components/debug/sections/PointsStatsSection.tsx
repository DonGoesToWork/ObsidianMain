import React, { useContext } from 'react';

import { DebugContext } from 'context/DebugContext';
import { Player } from 'types';
import { DebugTargetContext } from '../DebugTargetContext';
import { DebugSetter } from '../shared/DebugSetter';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h3 className="debug-section-header">{title}</h3>
    {children}
  </div>
);

export const PointsStatsSection: React.FC = () => {
  const { debug_addPoints, debug_setStatPoints, debug_setPerkPoints } = useContext(DebugContext)!;
  const { primaryTarget } = useContext(DebugTargetContext)!;

  const currentStatPoints = primaryTarget && 'attributePoints' in primaryTarget ? (primaryTarget as Player).attributePoints : 0;
  const currentPerkPoints = primaryTarget && 'perkPoints' in primaryTarget ? (primaryTarget as Player).perkPoints : 0;

  return (
    <DebugSection title="Points">
      <DebugSetter
        title={`Add Stat Points (${currentStatPoints})`}
        onSet={(val) => debug_addPoints('stat', val)}
        quickSets={[
          { label: '+1', value: 1 },
          { label: '+10', value: 10 },
          { label: '+50', value: 50 },
        ]}
      />
      <DebugSetter
        title={`Set Stat Points (${currentStatPoints})`}
        onSet={debug_setStatPoints}
        quickSets={[
          { label: 'Set 0', value: 0 },
          { label: 'Set 10', value: 10 },
          { label: 'Set 50', value: 50 },
        ]}
      />
      <hr style={{ border: 'none', borderTop: '1px solid #444', margin: '10px 0' }} />
      <DebugSetter
        title={`Add Perk Points (${currentPerkPoints})`}
        onSet={(val) => debug_addPoints('perk', val)}
        quickSets={[
          { label: '+1', value: 1 },
          { label: '+10', value: 10 },
          { label: '+50', value: 50 },
        ]}
      />
      <DebugSetter
        title={`Set Perk Points (${currentPerkPoints})`}
        onSet={debug_setPerkPoints}
        quickSets={[
          { label: 'Set 0', value: 0 },
          { label: 'Set 10', value: 10 },
          { label: 'Set 50', value: 50 },
        ]}
      />
    </DebugSection>
  );
};
