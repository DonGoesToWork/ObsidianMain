import React, { useContext } from 'react';
import { DebugContext } from 'context/DebugContext';

const DebugSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="debug-section">
    <h4 className="debug-section-header">{title}</h4>
    {children}
  </div>
);

export const PointsStatsSection: React.FC = () => {
  const { debug_addPoints } = useContext(DebugContext)!;
  return (
    <DebugSection title="Points">
      <button onClick={() => debug_addPoints('stat', 10)} className="btn btn-secondary">
        +10 Stat Points
      </button>
      <button onClick={() => debug_addPoints('perk', 10)} className="btn btn-secondary">
        +10 Perk Points
      </button>
    </DebugSection>
  );
};