import React from 'react';

interface DebugTargetSelectorProps {
  available: { id: string; name: string }[];
  selected: string[];
  onToggle: (id: string) => void;
  onSelectAll: () => void;
  onSelectNone: () => void;
}

export const DebugTargetSelector: React.FC<DebugTargetSelectorProps> = ({ available, selected, onToggle, onSelectAll, onSelectNone }) => {
  return (
    <div className="debug-target-selector">
      <h3>Targets</h3>
      <div className="target-selection-buttons">
        <button className="btn" onClick={onSelectAll}>
          All
        </button>
        <button className="btn" onClick={onSelectNone}>
          None
        </button>
      </div>
      <div className="target-list">
        {available.map((target) => (
          <label key={target.id}>
            <input type="checkbox" checked={selected.includes(target.id)} onChange={() => onToggle(target.id)} />
            {target.name}
          </label>
        ))}
      </div>
    </div>
  );
};
