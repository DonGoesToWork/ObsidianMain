import React from "react";
import { DebugContextType, UIContextType } from "types";

type CurrencyItemsSectionProps = Pick<
  DebugContextType,
  | "debug_addGold"
  | "debug_duplicateItems"
  | "debug_giveRandomItems"
  | "debug_giveDamagedItem"
  | "debug_clearInventory"
> &
  Pick<UIContextType, "setActiveModal">;

export const CurrencyItemsSection: React.FC<CurrencyItemsSectionProps> = ({
  debug_addGold,
  setActiveModal,
  debug_duplicateItems,
  debug_giveRandomItems,
  debug_giveDamagedItem,
  debug_clearInventory,
}) => (
  <>
    <button onClick={() => debug_addGold(1000)} className="btn btn-secondary">
      +1k Gold
    </button>
    <button onClick={() => debug_addGold(10000)} className="btn btn-secondary">
      +10k Gold
    </button>
    <button
      onClick={() => debug_addGold(999999999)}
      className="btn btn-secondary"
    >
      +999m Gold
    </button>
    <button
      onClick={() => setActiveModal("debug-shop-modal")}
      className="btn btn-secondary"
    >
      Open Debug Shop
    </button>
    <button
      onClick={() => debug_duplicateItems()}
      className="btn btn-secondary"
    >
      Duplicate Items
    </button>
    <button
      onClick={() => debug_giveRandomItems(5)}
      className="btn btn-secondary"
    >
      Give 5x Random Item
    </button>
    <button
      onClick={() => debug_giveDamagedItem()}
      className="btn btn-secondary"
    >
      Give Damaged Item
    </button>
    <button onClick={() => debug_clearInventory()} className="btn btn-secondary">
      Clear Inventory
    </button>
  </>
);