import React from "react";
import { DebugContextType } from "types";

type UnlocksSectionProps = Pick<
  DebugContextType,
  | "debug_maxProfessions"
  | "debug_learnAllRecipes"
  | "debug_learnAllSkills"
  | "debug_learnAllSpells"
  | "debug_unlockAll"
>;

export const UnlocksSection: React.FC<UnlocksSectionProps> = ({
  debug_maxProfessions,
  debug_learnAllRecipes,
  debug_learnAllSkills,
  debug_learnAllSpells,
  debug_unlockAll,
}) => (
  <>
    <button
      onClick={() => debug_maxProfessions()}
      className="btn btn-secondary"
    >
      Max Professions
    </button>
    <button
      onClick={() => debug_learnAllRecipes()}
      className="btn btn-secondary"
    >
      Learn all Recipes
    </button>
    <button onClick={() => debug_learnAllSkills()} className="btn btn-secondary">
      Learn all Skills
    </button>
    <button onClick={() => debug_learnAllSpells()} className="btn btn-secondary">
      Learn all Spells
    </button>
    <button onClick={() => debug_unlockAll()} className="btn btn-secondary">
      Unlock All
    </button>
  </>
);