import React from "react";
import { DebugContextType } from "types";

type ExperienceLevelsSectionProps = Pick<
  DebugContextType,
  "debug_addXP" | "debug_addLevel"
>;

export const ExperienceLevelsSection: React.FC<
  ExperienceLevelsSectionProps
> = ({ debug_addXP, debug_addLevel }) => (
  <>
    <button onClick={() => debug_addXP(100)} className="btn btn-secondary">
      +100 XP
    </button>
    <button onClick={() => debug_addXP(1000)} className="btn btn-secondary">
      +1k XP
    </button>
    <button onClick={() => debug_addLevel(1)} className="btn btn-secondary">
      +1 Level
    </button>
    <button onClick={() => debug_addLevel(5)} className="btn btn-secondary">
      +5 Levels
    </button>
    <button onClick={() => debug_addLevel(25)} className="btn btn-secondary">
      +25 Levels
    </button>
  </>
);