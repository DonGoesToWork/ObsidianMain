import React, { useState } from 'react';

interface DebugSetterProps {
  title: string;
  onSet: (value: number) => void;
  quickSets?: { label: string; value: number }[];
  inputDefault?: number;
}

export const DebugSetter: React.FC<DebugSetterProps> = ({ title, onSet, quickSets, inputDefault = 1 }) => {
  const [value, setValue] = useState<string>(inputDefault.toString());

  const handleSet = () => {
    const numValue = parseInt(value, 10);
    if (!isNaN(numValue)) {
      onSet(numValue);
    }
  };

  const handleQuickSet = (quickValue: number) => {
    setValue(quickValue.toString());
    onSet(quickValue);
  };

  return (
    <div className="debug-setter">
      <h5>{title}</h5>
      <div className="input-group">
        <input type="number" value={value} onChange={(e) => setValue(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSet()} />
        <button className="btn btn-sm" onClick={handleSet}>
          Go
        </button>
      </div>
      {quickSets && quickSets.length > 0 && (
        <div className="quick-sets">
          {quickSets.map((qs) => (
            <button key={qs.label} className="btn btn-sm" onClick={() => handleQuickSet(qs.value)}>
              {qs.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};