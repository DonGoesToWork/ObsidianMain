import { Combatant, Mercenary, Player } from '../../types';
import React, { useContext, useEffect, useState } from 'react';

import { CombatantDisplay } from '../combat/CombatantDisplay';
import { DebugContext } from 'context/DebugContext';
import { DebugDamageControls } from '../debug/DebugDamageControls';
import { createCombatantFromCharacter } from 'utils/combatantFactory';
import { isCombatantDefeated } from 'utils/combatUtils';
import { usePlayer } from 'hooks/usePlayer';

const getCharId = (c: Player | Mercenary) => ('professions' in c ? 'player' : (c as Mercenary).id);

export const CombatSimulatorScreen: React.FC = () => {
  const player = usePlayer();
  const { debug_fullHeal, debug_restoreResources, debug_clearDebuffs, setDebugTargets } = useContext(DebugContext)!;
  const [selectedCharacterId, setSelectedCharacterId] = useState<string>('player');

  useEffect(() => {
    if (selectedCharacterId) {
      setDebugTargets([selectedCharacterId]);
    }
  }, [selectedCharacterId, setDebugTargets]);

  if (!player) return null;

  const allPartyMembers = [player, ...player.party];
  const allCombatants: Combatant[] = allPartyMembers.map((char) => createCombatantFromCharacter(char));
  const selectedCharacter = allPartyMembers.find((c) => getCharId(c) === selectedCharacterId);

  return (
    <div
      className="screen-content"
      style={{
        display: 'flex',
        gap: '10px',
        flexDirection: 'row',
        height: '100%',
      }}
    >
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div className="panel" style={{ height: '100%' }}>
          <h3 style={{ borderBottom: '1px solid #444', paddingBottom: '10px' }}>Combat Simulator</h3>
          <div style={{ paddingTop: '10px', overflowY: 'auto' }}>
            <DebugDamageControls character={selectedCharacter} />
            <div className="sim-control-group">
              <h3 style={{ marginTop: '10px' }}>Character State</h3>
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '10px',
                }}
              >
                <button onClick={debug_fullHeal} className="btn btn-secondary">
                  Full Heal
                </button>
                <button onClick={debug_restoreResources} className="btn btn-secondary">
                  Restore HP/MP/SP
                </button>
                <button onClick={debug_clearDebuffs} className="btn btn-secondary">
                  Clear Debuffs
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="team-panel" style={{ flex: 1, overflowY: 'auto', paddingRight: '10px' }}>
        {allCombatants.map((c) => (
          <CombatantDisplay
            key={c.id}
            combatant={c}
            isSelected={c.id === selectedCharacterId}
            onSelect={() => setSelectedCharacterId(c.id)}
            onLimbSelect={() => {}}
            selectedLimbId={null}
            isTargetable={false}
            isDefeated={isCombatantDefeated(c)}
          />
        ))}
      </div>
    </div>
  );
};
