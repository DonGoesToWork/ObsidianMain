import React, { useContext } from "react";
import { Zone, GameLocation } from "../../types";
import { calculateDistance } from "utils/mathUtils";
import { formatTravelTime } from "utils/formatUtils";
import { createLocationFromZone } from "utils/locationUtils";
import { WorldContext } from "context/WorldContext";
import { useAttributes } from "hooks/useAttributes";
import { useInventory } from "hooks/useInventory";
import { GameDataContext } from "context/GameDataContext";

type MapLocation = GameLocation;

const WorldMapScreen: React.FC = () => {
  const { level } = useAttributes();
  const { currentWeight, maxWeight } = useInventory();
  const { currentLocation, travelTo, generatedZones } = useContext(WorldContext)!;
  const GAME_DATA = useContext(GameDataContext)!;

  if (level === undefined || currentWeight === undefined || maxWeight === undefined) return null;

  const currentPos = currentLocation?.pos || { x: 0, y: 0 };

  const staticLocations = (Object.entries(GAME_DATA.ZONES) as [string, Zone][])
    .filter(([zoneId]) => zoneId !== "wilderness_transit")
    .map(
      ([zoneId, zoneData]): MapLocation =>
        createLocationFromZone(zoneId, zoneData),
    );

  const generatedLocations = Object.entries(generatedZones).map(
    ([zoneId, zoneData]): MapLocation =>
      createLocationFromZone(zoneId, zoneData),
  );

  const allLocations: MapLocation[] = [
    ...staticLocations,
    ...generatedLocations,
  ].filter(
    (loc, index, self) => index === self.findIndex((l) => l.id === loc.id),
  );

  const isEncumbered = currentWeight >= maxWeight;

  return (
    <div id="world-map-screen" className="screen-content">
      <h3>World Map</h3>
      <p>From here you can travel to distant, dangerous lands.</p>
      {isEncumbered && (
        <p style={{ color: "#ff6b6b", fontWeight: "bold" }}>
          You are too encumbered to travel.
        </p>
      )}
      <div id="zone-buttons" className="action-grid">
        {allLocations.map((loc) => {
          const isUnlocked = !loc.levelReq || level >= loc.levelReq;
          const distance = calculateDistance(currentPos, loc.pos);
          const isCurrentLocation = loc.id === currentLocation?.id;

          if (isCurrentLocation) {
            return (
              <button
                key={loc.id}
                className="btn current-location"
                disabled={true}
                title="You are already here."
              >
                {loc.name} (Current)
              </button>
            );
          }

          const buttonDisabled = !isUnlocked || isEncumbered;
          let buttonTitle = loc.name;
          if (!isUnlocked) {
            buttonTitle = `Requires Level ${loc.levelReq}`;
          } else if (isEncumbered) {
            buttonTitle = "You are too encumbered to travel.";
          }

          return (
            <button
              key={loc.id}
              className="btn"
              disabled={buttonDisabled}
              onClick={() => travelTo(loc.id)}
              title={buttonTitle}
            >
              {loc.name} {loc.levelReq && `(Lvl ${loc.levelReq})`}
              <br />
              <small>{formatTravelTime(distance)}</small>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default WorldMapScreen;