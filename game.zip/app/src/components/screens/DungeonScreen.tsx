import React from 'react';

const DungeonScreen: React.FC = () => {
  return (
    <div className="screen-content">
      <h3>Dungeon</h3>
      <p>Dungeon delving feature coming soon...</p>
    </div>
  );
};

export default DungeonScreen;
