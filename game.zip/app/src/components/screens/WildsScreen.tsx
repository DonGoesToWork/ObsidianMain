import React, { useContext, useMemo } from 'react';

import { CombatContext } from 'context/CombatContext';
import { LogContext } from 'context/LogContext';
import { WorldContext } from 'context/WorldContext';
import { useInventory } from 'hooks/useInventory';
import { ProfessionId } from 'types';

type GroupedAction = {
  type: ProfessionId;
  name: string;
  skillReq: number;
};

const WildsScreen: React.FC = () => {
  const { currentWeight, maxWeight } = useInventory();
  const { currentLocation, changeGameState, performWildsAction, isActionLocked } = useContext(WorldContext)!;
  const { startCombat } = useContext(CombatContext)!;
  const { logMessage } = useContext(LogContext)!;

  const groupedActions = useMemo((): Record<string, GroupedAction> => {
    if (!currentLocation?.gather) return {};
    const actionDisplayNames: Record<string, string> = {
      mining: `Mine (Difficulty: {skillReq})`,
      foraging: `Forage (Difficulty: {skillReq})`,
      skinning: 'Skin Beasts',
      woodcutting: `Cut Logs (Difficulty: {skillReq})`,
      alchemy: 'Gather Herbs',
    };

    return currentLocation.gather.reduce((acc, node) => {
      if (!acc[node.type]) {
        acc[node.type] = {
          type: node.type,
          name: actionDisplayNames[node.type] || `Gather ${node.type}`,
          skillReq: node.skillReq,
        };
      } else {
        acc[node.type].skillReq = Math.min(acc[node.type].skillReq, node.skillReq);
      }
      return acc;
    }, {} as Record<string, GroupedAction>);
  }, [currentLocation]);

  const handleExplore = () => {
    changeGameState('world-map');
  };

  if (!currentLocation || currentLocation.type !== 'wilds') {
    return (
      <div id="wilds-screen" className="screen-content">
        <h3>Unknown Area</h3>
        <p>You seem to be lost. You should return to town or check your map.</p>
        <div
          className="action-grid"
          style={{
            marginTop: 'auto',
            borderTop: '1px solid #444',
            paddingTop: '10px',
          }}
        >
          <button className="btn" onClick={handleExplore}>
            Explore the World
          </button>
        </div>
      </div>
    );
  }

  const handleWildsAction = (action: ProfessionId) => {
    if (currentWeight !== undefined && maxWeight !== undefined && currentWeight >= maxWeight) {
      logMessage(
        {
          floatingText: 'Over-encumbered!',
          detailedText: 'You are over-encumbered and cannot gather more items.',
        },
        'error'
      );
      return;
    }
    const ambushChance = 0.2; // 20% chance of ambush
    if (Math.random() < ambushChance) {
      if (currentLocation.monsterPacks && currentLocation.monsterPacks.length > 0) {
        const pack = currentLocation.monsterPacks[Math.floor(Math.random() * currentLocation.monsterPacks.length)];
        logMessage(
          {
            floatingText: 'Ambush!',
            detailedText: 'You were ambushed while gathering!',
          },
          'combat'
        );
        startCombat(pack, { zoneId: currentLocation.id, source: 'wilds' });
      } else {
        logMessage('You feel a threatening presence, but nothing appears.', 'info');
        performWildsAction(action);
      }
    } else {
      performWildsAction(action);
    }
  };

  return (
    <div id="wilds-screen" className="screen-content">
      <h3>{currentLocation.name}</h3>
      <p>The wilderness is dangerous, but full of resources. What will you do?</p>

      <div className="action-grid">
        {Object.values(groupedActions).map((action) => (
          <button key={action.type} className="btn" onClick={() => handleWildsAction(action.type)} disabled={isActionLocked}>
            {action.name.replace('{skillReq}', action.skillReq.toString())}
          </button>
        ))}
        <button className="btn" onClick={() => logMessage('You find no obvious tracks.', 'info')}>
          Search for tracks
        </button>
      </div>
    </div>
  );
};

export default WildsScreen;