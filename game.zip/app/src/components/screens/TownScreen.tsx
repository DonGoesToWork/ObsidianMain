import React, { useContext } from 'react';
import { NPCId, TownNPC } from '../../types';
import { usePlayer } from 'hooks/usePlayer';
import { useQuests } from 'hooks/useQuests';
import { WorldContext } from 'context/WorldContext';
import { UIContext } from 'context/UIContext';
import { LogContext } from 'context/LogContext';
import { GameDataContext } from 'context/GameDataContext';

const TownScreen: React.FC = () => {
  const player = usePlayer();
  const GAME_DATA = useContext(GameDataContext)!;
  const { quests, completeQuest } = useQuests();
  const { currentLocation } = useContext(WorldContext)!;
  const { setActiveModal } = useContext(UIContext)!;

  if (!player || !currentLocation || !quests) return null;

  const handleNpcInteraction = (npcId: NPCId) => {
    const npc = GAME_DATA.TOWN_NPCS[npcId];
    console.debug(`Interacting with NPC: ${npc.name} (ID: ${npcId})`);

    npc.services.forEach((service) => {
      if (service.type === 'modal') {
        const modalProps = (service as any).props || {};

        if (service.id === 'quest-modal') {
          const completableQuestId = service.quests.find((questId) => {
            const progress = quests.active[questId];
            return progress && progress.current >= progress.count;
          });

          // If a quest can be turned in, do that first and don't open the modal.
          if (completableQuestId) {
            completeQuest(completableQuestId);
            // After completing, check if there's another quest to offer.
            const hasMoreQuests = service.quests.some((qid) => {
              if (qid === completableQuestId) return false;
              const q = GAME_DATA.QUESTS[qid];
              if (!q) return false;
              const alreadyActive = !!quests.active[qid];
              const alreadyDone = !!quests.completed[qid];
              const levelOk = player.level >= (q.levelReq || 0);
              const prereqOk = !q.prereq || !!quests.completed[q.prereq];
              return !alreadyActive && !alreadyDone && levelOk && prereqOk;
            });

            if (hasMoreQuests) {
              // Re-open modal to show next available quest
              setActiveModal('quest-modal', {
                npcId,
                questIds: service.quests,
              });
            }
          } else {
            setActiveModal('quest-modal', { npcId, questIds: service.quests });
          }
        } else {
          setActiveModal(service.id, { npcId, ...modalProps });
        }
      }
    });
  };

  return (
    <div id="town-screen" className="screen-content">
      <h3>Welcome to {currentLocation.name}</h3>
      <p>The central hub for adventurers. Click on a service below to interact.</p>
      <div id="town-npc-grid" className="action-grid">
        {(Object.entries(GAME_DATA.TOWN_NPCS) as [NPCId, TownNPC][]).map(([npcId, npc]) => (
          <button key={npcId} className="btn" onClick={() => handleNpcInteraction(npcId)}>
            {npc.name}
          </button>
        ))}
      </div>
    </div>
  );
};

export default TownScreen;
