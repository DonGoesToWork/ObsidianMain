import React, { useState, useMemo, useContext } from 'react';
import { ClassId, RaceId, GameClass, GameRace } from '../types';
import { GameDataContext } from 'context/GameDataContext';

interface CharacterCreationProps {
  onFinalize: (name: string, race: RaceId, pClass: ClassId) => void;
}

interface Selection {
  class: ClassId | null;
  race: RaceId | null;
}

interface ChoiceCardProps {
  id: string;
  data: GameClass | GameRace;
  type: keyof Selection;
  selected: boolean;
  onSelect: (type: keyof Selection, id: string) => void;
}

const ChoiceCard: React.FC<ChoiceCardProps> = ({ id, data, type, selected, onSelect }) => (
  <div className={`choice-card ${selected ? 'selected' : ''}`} onClick={() => onSelect(type, id)}>
    <h4>{data.name}</h4>
    <p>{data.desc}</p>
  </div>
);

const CharacterCreation: React.FC<CharacterCreationProps> = ({ onFinalize }) => {
  const [selection, setSelection] = useState<Selection>({
    class: null,
    race: null,
  });
  const [name, setName] = useState('');
  const GAME_DATA = useContext(GameDataContext)!;

  const handleSelect = (type: keyof Selection, id: string) => {
    setSelection((prev) => ({ ...prev, [type]: id as any }));
  };

  const isFinalizeDisabled = useMemo(() => {
    return !(selection.class && selection.race && name.trim() !== '');
  }, [selection, name]);

  const handleFinalize = () => {
    if (selection.class && selection.race && name.trim()) {
      onFinalize(name.trim(), selection.race, selection.class);
    }
  };

  return (
    <div id="character-creation-screen">
      <div id="creation-content" className="panel">
        <h2>Create Your Hero</h2>
        <p>Your legend begins now. Choose your path.</p>

        <h3>Choose your Class</h3>
        <div id="class-choices" className="choice-grid">
          {(Object.entries(GAME_DATA.CLASSES) as [ClassId, GameClass][])
            .filter(([id]) => id !== 'none')
            .map(([id, data]) => (
              <ChoiceCard key={id} id={id} data={data} type="class" selected={selection.class === id} onSelect={handleSelect} />
            ))}
        </div>

        <h3>Choose your Race</h3>
        <div id="race-choices" className="choice-grid">
          {(Object.entries(GAME_DATA.RACES) as [RaceId, GameRace][])
            .filter(([, data]) => Object.keys(data.bonus).length > 0)
            .map(([id, data]) => (
              <ChoiceCard key={id} id={id} data={data} type="race" selected={selection.race === id} onSelect={handleSelect} />
            ))}
        </div>

        <div>
          <input type="text" id="creation-name" placeholder="Enter Character Name" value={name} onChange={(e) => setName(e.target.value)} />
        </div>

        <button id="finalize-creation-btn" className="btn" disabled={isFinalizeDisabled} onClick={handleFinalize}>
          Begin Adventure
        </button>
      </div>
    </div>
  );
};

export default CharacterCreation;
