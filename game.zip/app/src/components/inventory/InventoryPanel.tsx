import { UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import { getStandardInventoryColumns } from 'config/inventoryColumns';
import { ContextMenuOption, useContextMenu } from 'context/ContextMenuContext';
import { GameDataContext } from 'context/GameDataContext';
import { LogContext } from 'context/LogContext';
import { UIContext } from 'context/UIContext';
import { useInventory } from 'hooks/useInventory';
import { useModalState } from 'hooks/useModalState';
import { useParty } from 'hooks/useParty';
import { usePlayer } from 'hooks/usePlayer';
import React, { useCallback, useContext, useEffect, useMemo } from 'react';
import { ItemInstance, Limb, Mercenary, SortDirection, SortKey, StatusEffectInstance } from 'types';

interface InventoryPanelProps {
  useHistoryForContainers?: boolean;
}

export const InventoryPanel: React.FC<InventoryPanelProps> = ({ useHistoryForContainers = false }) => {
  const player = usePlayer();
  const { inventory, equipItem, consumeItem, giftItemToMercenary, dropItems, doUseItemOnItem, reorderInventory, sortInventory } = useInventory();
  const GAME_DATA = useContext(GameDataContext)!;
  const { party } = useParty();
  const { setActiveModal, heldItem, setHeldItem } = useContext(UIContext)!;
  const { showContextMenu } = useContextMenu();
  const { logMessage } = useContext(LogContext)!;
  const STANDARD_INVENTORY_COLUMNS = useMemo(() => getStandardInventoryColumns(GAME_DATA), [GAME_DATA]);

  const inventoryState = useModalState('rightSidebarInventory', 'main');

  const handleSortChange = useCallback(
    (newSortConfig: { key: SortKey; direction: SortDirection } | null) => {
      console.log('Sorting data with config:', newSortConfig);
      inventoryState.setSortConfig(newSortConfig);
      sortInventory(newSortConfig);
    },
    [inventoryState, sortInventory]
  );

  useEffect(() => {
    // On mount, apply the persisted sort config from UI state to the actual data.
    if (inventoryState.sortConfig) {
      sortInventory(inventoryState.sortConfig);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Only run on mount

  const handleItemTransfer = (item: ItemInstance, quantity: number, originalIndices: number[]) => {
    console.log('[InventoryPanel] handleItemTransfer called for item:', item, 'quantity:', quantity);
    if (!item || !inventory) {
      console.warn('[InventoryPanel] handleItemTransfer aborted: item or inventory is null/undefined.');
      return;
    }

    // With the data now being physically sorted, originalIndices from the display logic can be stale.
    // The reliable method is to find the item by its unique ID in the current, true inventory state.
    // Add a guard `i &&` to prevent crashes if the inventory array contains null gaps.
    const itemToDrop = inventory.find((i) => i && i.unique_id === item.unique_id);
    console.log('[InventoryPanel] Found item to drop:', itemToDrop);

    if (itemToDrop) {
      const amountToTake = Math.min(quantity, itemToDrop.quantity);
      console.log('[InventoryPanel] Calling dropItems with:', [{ unique_id: itemToDrop.unique_id, quantity: amountToTake }]);
      dropItems([{ unique_id: itemToDrop.unique_id, quantity: amountToTake }]);
    } else {
      console.warn(`[InventoryPanel] Could not find item with unique_id ${item.unique_id} to drop.`);
    }
  };

  if (!inventory || !party || !player) return null;

  const handleItemClick = (e: React.MouseEvent, item: ItemInstance, _originalIndices: number[]) => {
    // This logic is now primarily handled by ItemIcon's internal onClick.
    // We keep this handler for actions that are not "pick_up".
    const itemData = GAME_DATA.ITEMS[item.id];
    if (itemData.primaryAction === 'pick_up') {
      // Logic is in ItemIcon
      return;
    }

    if (item.isUnidentified) {
      logMessage('You must appraise this item to learn its secrets.', 'info');
    } else if (itemData.effect?.closesCutOfStage) {
      const bleedingLimbs: { limb: Limb; cut: StatusEffectInstance }[] = [];
      Object.values(player.body).forEach((limb) => {
        const openCut = limb.statusEffects.find((se) => se.id === 'cut' && !se.isClosed && se.currentStage! <= itemData.effect!.closesCutOfStage!);
        if (openCut) {
          bleedingLimbs.push({ limb, cut: openCut });
        }
      });

      if (bleedingLimbs.length > 0) {
        const limbOptions: ContextMenuOption[] = bleedingLimbs.map(({ limb, cut }) => ({
          label: `Apply to ${limb.displayName} (${GAME_DATA.STATUS_EFFECTS.cut.stages![cut.currentStage! - 1].name})`,
          onClick: () => consumeItem(item.unique_id, limb.id),
        }));
        showContextMenu(e.clientX, e.clientY, limbOptions);
      } else {
        logMessage('You have no open wounds that this can treat.', 'info');
      }
    } else if (itemData.type.includes('container')) {
      setActiveModal(
        'item-container-modal',
        {
          containerUniqueId: item.unique_id,
        },
        { history: useHistoryForContainers }
      );
    } else if (itemData.type.includes('equipment')) {
      equipItem(item.unique_id);
    } else if (itemData.type.includes('consumable') || itemData.type.includes('knowledge')) {
      consumeItem(item.unique_id);
    }
  };

  const handleItemContextMenu = (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => {
    e.preventDefault();
    e.stopPropagation();
    if (item.isUnarmed) return;

    const itemData = GAME_DATA.ITEMS[item.id];
    const options: ContextMenuOption[] = [];

    if (itemData.primaryAction === 'pick_up') {
      options.push({
        label: 'Pick Up',
        onClick: () => setHeldItem(item),
      });
    }

    if (item.isUnidentified) {
      options.push({
        label: 'Equip (Unidentified)',
        disabled: true,
      });
    } else {
      if (itemData.effect?.closesCutOfStage) {
        const bleedingLimbs: { limb: Limb; cut: StatusEffectInstance }[] = [];
        Object.values(player.body).forEach((limb) => {
          const openCut = limb.statusEffects.find((se) => se.id === 'cut' && !se.isClosed && se.currentStage! <= itemData.effect!.closesCutOfStage!);
          if (openCut) {
            bleedingLimbs.push({ limb, cut: openCut });
          }
        });

        const applyOption: ContextMenuOption = {
          label: 'Apply',
          disabled: bleedingLimbs.length === 0,
        };
        if (bleedingLimbs.length > 0) {
          applyOption.subMenu = bleedingLimbs.map(({ limb, cut }) => ({
            label: `On ${limb.displayName} (${GAME_DATA.STATUS_EFFECTS.cut.stages![cut.currentStage! - 1].name})`,
            onClick: () => consumeItem(item.unique_id, limb.id),
          }));
        }
        options.push(applyOption);
      } else if (itemData.type.includes('consumable')) {
        if (itemData.effect?.revive) {
          const corpseItems = inventory.filter((i: ItemInstance) => i.deceasedCharacter);
          if (corpseItems.length > 0) {
            options.push({
              label: 'Use',
              subMenu: corpseItems.map((corpse: ItemInstance) => ({
                label: `On Corpse of ${corpse.deceasedCharacter!.name}`,
                onClick: () => consumeItem(item.unique_id, corpse.unique_id),
              })),
            });
          }
        } else {
          options.push({
            label: 'Use',
            onClick: () => consumeItem(item.unique_id),
          });
        }
      } else if (itemData.type.includes('container')) {
        options.push({
          label: itemData.type.includes('corpse') ? 'Loot' : 'Open',
          onClick: () =>
            setActiveModal(
              'item-container-modal',
              {
                containerUniqueId: item.unique_id,
              },
              { history: useHistoryForContainers }
            ),
        });
      } else if (itemData.type.includes('equipment')) {
        if (itemData.slot === 'ring') {
          options.push({
            label: 'Equip',
            subMenu: [
              { label: 'Left Ring', onClick: () => equipItem(item.unique_id, 'left_ring') },
              { label: 'Right Ring', onClick: () => equipItem(item.unique_id, 'right_ring') },
            ],
          });
        } else if (itemData.slot === 'amulet') {
          options.push({
            label: 'Equip',
            subMenu: [
              { label: 'Amulet 1', onClick: () => equipItem(item.unique_id, 'amulet1') },
              { label: 'Amulet 2', onClick: () => equipItem(item.unique_id, 'amulet2') },
            ],
          });
        } else if (itemData.slot === 'weapon' || itemData.slot === 'shield') {
          options.push({
            label: 'Equip',
            subMenu: [
              { label: 'Left Hand', onClick: () => equipItem(item.unique_id, 'shield') },
              { label: 'Right Hand', onClick: () => equipItem(item.unique_id, 'weapon') },
            ],
          });
        } else if (itemData.slot === 'armlet') {
          options.push({
            label: 'Equip',
            subMenu: [
              { label: 'Left Armlet', onClick: () => equipItem(item.unique_id, 'left_armlet') },
              { label: 'Right Armlet', onClick: () => equipItem(item.unique_id, 'right_armlet') },
            ],
          });
        } else if (itemData.slot === 'glove') {
          options.push({
            label: 'Equip',
            subMenu: [
              { label: 'Left Glove', onClick: () => equipItem(item.unique_id, 'left_glove') },
              { label: 'Right Glove', onClick: () => equipItem(item.unique_id, 'right_glove') },
            ],
          });
        } else if (itemData.slot === 'leggings') {
          options.push({
            label: 'Equip',
            subMenu: [
              { label: 'Left Legging', onClick: () => equipItem(item.unique_id, 'left_legging') },
              { label: 'Right Legging', onClick: () => equipItem(item.unique_id, 'right_legging') },
            ],
          });
        } else if (itemData.slot === 'feet') {
          options.push({
            label: 'Equip',
            subMenu: [
              { label: 'Left Boot', onClick: () => equipItem(item.unique_id, 'left_foot') },
              { label: 'Right Boot', onClick: () => equipItem(item.unique_id, 'right_foot') },
            ],
          });
        } else {
          options.push({
            label: 'Equip',
            onClick: () => equipItem(item.unique_id),
          });
        }
      } else if (itemData.type.includes('knowledge')) {
        options.push({
          label: 'Read',
          onClick: () => consumeItem(item.unique_id),
        });
      }
    }

    const giftSubMenu: ContextMenuOption[] = party.map((merc: Mercenary) => ({
      label: `Gift to ${merc.name}`,
      onClick: () => giftItemToMercenary(merc.id, item),
    }));

    if (giftSubMenu.length > 0) {
      options.push({ label: 'Gift Item', subMenu: giftSubMenu });
    }

    if (!item.isUnarmed) {
      options.push({
        label: `Drop x${inventoryState.transferAmount}`,
        onClick: () => handleItemTransfer(item, inventoryState.transferAmount, originalIndices),
      });
    }

    if (options.length > 0) {
      showContextMenu(e.clientX, e.clientY, options);
    }
  };

  return (
    <UnifiedInventoryDisplay
      title="Inventory"
      items={inventory}
      onItemClick={handleItemClick}
      onItemContextMenu={handleItemContextMenu}
      onTransfer={handleItemTransfer}
      onUseItemOnItem={doUseItemOnItem}
      initialView="simple"
      columns={STANDARD_INVENTORY_COLUMNS}
      showSortButtons={true}
      showViewToggle={true}
      showFilterSearchBar={true}
      showFilterButtonBar={true}
      dynamicFilters={true}
      showTransferControls={true}
      transferButtonText="Drop"
      transferAmount={inventoryState.transferAmount}
      onTransferAmountChange={inventoryState.setTransferAmount}
      viewMode={inventoryState.viewMode}
      onViewModeChange={inventoryState.setViewMode}
      sortConfig={inventoryState.sortConfig}
      onSortChange={handleSortChange}
      isDraggable={true}
      padWithEmptySlots={true}
      onReorder={reorderInventory}
    />
  );
};