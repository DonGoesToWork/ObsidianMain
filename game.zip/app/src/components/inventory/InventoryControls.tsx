import React from 'react';
import { FilterCategory, SortKey } from '../shared/UnifiedInventoryDisplay';

const DEFAULT_FILTER_CATEGORIES: FilterCategory[] = [
  { key: 'All', label: 'All' },
  { key: 'equipment', label: 'Equipment' },
  { key: 'potion', label: 'Potions' },
  { key: 'material', label: 'Materials' },
  { key: 'tool', label: 'Tools' },
  { key: 'note', label: 'Notes' },
  { key: 'container', label: 'Containers' },
  { key: 'corpse', label: 'Corpses' },
];

interface InventoryControlsProps {
  showFilterSearchBar?: boolean;
  showFilterButtonBar?: boolean;
  filterCategories?: FilterCategory[];
  searchTerm: string;
  setSearchTerm: (value: string) => void;
  activeFilter: FilterCategory['key'];
  setActiveFilter: (key: FilterCategory['key']) => void;
  viewMode: 'simple' | 'detailed';
  showSortButtons?: boolean;
  requestSort: (key: SortKey) => void;
  getSortIndicator: (key: SortKey) => ' ▲' | ' ▼' | null;
  showTransferControls?: boolean;
  transferButtonText?: string;
  transferAmount: number;
  setTransferAmount: (amount: number) => void;
  transferAmounts: number[];
}

export const InventoryControls: React.FC<InventoryControlsProps> = ({
  showFilterSearchBar = false,
  showFilterButtonBar = false,
  filterCategories,
  searchTerm,
  setSearchTerm,
  activeFilter,
  setActiveFilter,
  viewMode,
  showSortButtons = true,
  requestSort,
  getSortIndicator,
  showTransferControls,
  transferButtonText = 'Transfer',
  transferAmount,
  setTransferAmount,
  transferAmounts,
}) => (
  <>
    {(showFilterSearchBar || showFilterButtonBar) && (
      <div className="inventory-filter-bar">
        {showFilterSearchBar && <input type="text" placeholder="Search..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />}
        {showFilterButtonBar && (
          <div className="filter-tabs">
            {(filterCategories || DEFAULT_FILTER_CATEGORIES).map((cat) => (
              <button key={cat.key} className={activeFilter === cat.key ? 'active' : ''} onClick={() => setActiveFilter(cat.key)}>
                {cat.label}
              </button>
            ))}
          </div>
        )}
      </div>
    )}
    <div className="inventory-controls">
      {showSortButtons && (
        <>
          <button className="sort-btn" onClick={() => requestSort('name')}>
            Name{getSortIndicator('name')}
          </button>
          <button className="sort-btn" onClick={() => requestSort('itemLevel')}>
            Level{getSortIndicator('itemLevel')}
          </button>
          <button className="sort-btn" onClick={() => requestSort('type')}>
            Type{getSortIndicator('type')}
          </button>
          <button className="sort-btn" onClick={() => requestSort('value')}>
            Value{getSortIndicator('value')}
          </button>
          <button className="sort-btn" onClick={() => requestSort('weight')}>
            Weight{getSortIndicator('weight')}
          </button>
        </>
      )}
      {showTransferControls && (
        <div className="transfer-controls">
          <span>{transferButtonText}:</span>
          {transferAmounts.map((amount) => (
            <button key={amount} onClick={() => setTransferAmount(amount)} className={transferAmount === amount ? 'active' : ''}>
              x{amount}
            </button>
          ))}
        </div>
      )}
    </div>
  </>
);
