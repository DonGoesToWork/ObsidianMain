import React from 'react';
import { ItemInstance } from 'types';
import { GroupedItem } from 'utils/itemUtils';
import { ItemIcon } from '../shared/ItemIcon';

interface InventoryGridViewProps {
  groupedAndSortedItems: (GroupedItem & { originalIndices: number[] })[];
  onItemClick?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onItemContextMenu?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onTransfer?: (item: ItemInstance, quantity: number, originalIndices: number[]) => void;
  handleItemTransfer: (groupedItem: GroupedItem & { originalIndices: number[] }) => void;
  disablePrimaryItemActions?: boolean;

  // Drag and Drop props
  isDraggable?: boolean;
  gridRef?: React.RefObject<HTMLDivElement>;
  onMouseDown?: (e: React.MouseEvent, groupedItem: GroupedItem & { originalIndices: number[] }, index: number) => void;
  onMouseUp?: (e: React.MouseEvent) => void;
  dragInfo?: { item: ItemInstance; startIndex: number } | null;
  dropIndex?: number | null;
}

export const InventoryGridView: React.FC<InventoryGridViewProps> = ({
  groupedAndSortedItems,
  onItemClick,
  onTransfer,
  onItemContextMenu,
  handleItemTransfer,
  disablePrimaryItemActions,
  gridRef,
  onMouseDown,
  onMouseUp,
  dragInfo,
  dropIndex,
}) => (
  <div className="inventory-grid" ref={gridRef}>
    {groupedAndSortedItems.map((groupedItem, index) => {
      // Handle empty slots first to prevent null reference errors
      if (!groupedItem || !groupedItem.item) {
        const isDropTarget = !!(dragInfo && index === dropIndex);
        return <div key={`empty-${index}`} className={`item-icon-wrapper empty ${isDropTarget ? 'drop-target-preview' : ''}`} />;
      }

      const isBeingDragged = dragInfo?.item.unique_id === groupedItem.item.unique_id;
      const isDropTarget = !!(dragInfo && index === dropIndex);

      // Render a placeholder for the item being dragged
      if (isBeingDragged) {
        return <div key={`${groupedItem.item.unique_id}-drag-placeholder`} className="item-icon-wrapper empty drag-source-placeholder" />;
      }

      return (
        <ItemIcon
          key={groupedItem.item.unique_id}
          item={groupedItem.item}
          count={groupedItem.count > 1 ? groupedItem.count : undefined}
          // onClick is now handled by onMouseDown/onMouseUp in UnifiedInventoryDisplay to distinguish clicks from drags.
          onMouseDown={onMouseDown ? (e: React.MouseEvent) => onMouseDown(e, groupedItem, index) : undefined}
          onContextMenu={onItemContextMenu ? (e) => onItemContextMenu(e, groupedItem.item, groupedItem.originalIndices) : undefined}
          disablePrimaryAction={disablePrimaryItemActions}
          isDropTarget={isDropTarget}
        />
      );
    })}
  </div>
);