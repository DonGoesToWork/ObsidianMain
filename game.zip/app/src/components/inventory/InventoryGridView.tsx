import React from 'react';
import { ItemInstance } from 'types';
import { GroupedItem } from 'utils/itemUtils';
import { ItemIcon } from '../shared/ItemIcon';

interface InventoryGridViewProps {
  groupedAndSortedItems: (GroupedItem & { originalIndices: number[] })[];
  onItemClick?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onItemContextMenu?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onTransfer?: (item: ItemInstance, quantity: number, originalIndices: number[]) => void;
  handleItemTransfer: (groupedItem: GroupedItem & { originalIndices: number[] }) => void;
}

export const InventoryGridView: React.FC<InventoryGridViewProps> = ({ groupedAndSortedItems, onItemClick, onTransfer, onItemContextMenu, handleItemTransfer }) => (
  <div className="inventory-grid">
    {groupedAndSortedItems.map((groupedItem) => {
      return (
        <ItemIcon
          key={`${groupedItem.item.id}-${groupedItem.originalIndices[0]}`}
          item={groupedItem.item}
          count={groupedItem.count > 1 ? groupedItem.count : undefined}
          onClick={(e) => {
            if (e.shiftKey && onTransfer) {
              handleItemTransfer(groupedItem);
              return;
            }
            if (onItemClick) {
              onItemClick(e, groupedItem.item, groupedItem.originalIndices);
            } else if (onTransfer) {
              handleItemTransfer(groupedItem);
            }
          }}
          onContextMenu={onItemContextMenu ? (e) => onItemContextMenu(e, groupedItem.item, groupedItem.originalIndices) : undefined}
        />
      );
    })}
  </div>
);