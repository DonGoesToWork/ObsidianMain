import { ViewMode } from 'types';
import React from 'react';

interface InventoryHeaderProps {
  title: string;
  showViewToggle?: boolean;
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
}

export const InventoryHeader: React.FC<InventoryHeaderProps> = ({ title, showViewToggle, viewMode, setViewMode }) => (
  <div className="inventory-header">
    <h4>{title}</h4>
    {showViewToggle && (
      <div className="view-toggle">
        <button onClick={() => setViewMode('simple')} disabled={viewMode === 'simple'}>
          Grid
        </button>
        <button onClick={() => setViewMode('detailed')} disabled={viewMode === 'detailed'}>
          List
        </button>
      </div>
    )}
  </div>
);
