import React from 'react';
import { ViewMode } from 'types';

interface InventoryHeaderProps {
  title: string;
  showViewToggle?: boolean;
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
}

export const InventoryHeader: React.FC<InventoryHeaderProps> = ({ title, showViewToggle, viewMode, setViewMode }) => {
  if (!title && !showViewToggle) {
    return null;
  }
  return (
    <div className="inventory-header">
      {title && <h3>{title}</h3>}
      {showViewToggle && (
        <div className="view-toggle">
          <button onClick={() => setViewMode('simple')} disabled={viewMode === 'simple'}>
            Grid
          </button>
          <button onClick={() => setViewMode('detailed')} disabled={viewMode === 'detailed'}>
            List
          </button>
        </div>
      )}
    </div>
  );
};
