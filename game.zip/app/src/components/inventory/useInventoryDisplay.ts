import React, { useContext, useMemo, useState, useEffect } from 'react';
import { ItemInstance, ItemType, ViewMode, RequirementStatus, Recipe, ProfessionId } from 'types';
import { ColumnDef, FilterCategory, SortDirection, SortKey } from '../shared/UnifiedInventoryDisplay';
import { calculateItemValue, getItemName, groupItems, getItemWeight, calculateItemLevel, GroupedItem } from 'utils/itemUtils';
import { GameDataContext } from 'context/GameDataContext';

export interface UseInventoryDisplayProps {
  items: ItemInstance[];
  initialView?: ViewMode;
  viewMode?: ViewMode;
  onViewModeChange?: (mode: ViewMode) => void;
  showViewToggle?: boolean;
  showFilterSearchBar?: boolean;
  showFilterButtonBar?: boolean;
  filterCategories?: FilterCategory[];
  dynamicFilters?: boolean;
  showSortButtons?: boolean;
  defaultSort?: { key: SortKey; direction: SortDirection };
  columns?: ColumnDef[];
  transferAmount?: number;
  onTransferAmountChange?: (amount: number) => void;
  onItemClick?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onItemContextMenu?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onTransfer?: (item: ItemInstance, quantity: number, originalIndices: number[]) => void;
  setActiveModal?: (id: string | null, options?: any, config?: any) => void;
  isInfiniteStock?: boolean;
}

const TRANSFER_AMOUNTS = [1, 5, 25, 100];

export const useInventoryDisplayLogic = (props: UseInventoryDisplayProps) => {
  const { items, initialView = 'simple', defaultSort = { key: 'name', direction: 'asc' }, dynamicFilters = false } = props;
  const GAME_DATA = useContext(GameDataContext)!;
  const setActiveModal = props.setActiveModal;

  const [internalViewMode, setInternalViewMode] = useState<ViewMode>(initialView);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState<FilterCategory['key']>('All');
  const [sortConfig, setSortConfig] = useState(defaultSort);
  const [internalTransferAmount, setInternalTransferAmount] = useState(1);

  const isViewModeControlled = props.viewMode !== undefined;
  const viewMode = isViewModeControlled ? props.viewMode! : internalViewMode;

  const setViewMode = (mode: ViewMode) => {
    if (props.onViewModeChange) {
      props.onViewModeChange(mode);
    } else {
      setInternalViewMode(mode);
    }
  };

  const transferAmount = props.transferAmount ?? internalTransferAmount;

  const setTransferAmount = (amount: number) => {
    if (props.onTransferAmountChange) {
      props.onTransferAmountChange(amount);
    } else {
      setInternalTransferAmount(amount);
    }
  };

  const finalFilterCategories = useMemo(() => {
    if (!dynamicFilters) {
      return props.filterCategories;
    }

    if (!items || items.length === 0) {
      return [{ key: 'All', label: 'All' }];
    }

    const categories = new Set<string>();
    items.forEach((item) => {
      const filterKey = (item as any).filterKey;
      if (filterKey) {
        categories.add(filterKey);
      } else {
        const itemData = GAME_DATA.ITEMS[item.id];
        if (itemData?.type[0]) {
          categories.add(itemData.type[0]);
        }
      }
    });

    const labelMap: Record<string, string> = {
      equipment: 'Equipment',
      potion: 'Potions',
      material: 'Materials',
      tool: 'Tools',
      note: 'Notes',
      container: 'Containers',
      corpse: 'Corpses',
    };

    const dynamicCats: FilterCategory[] = Array.from(categories)
      .sort()
      .map((catKey) => ({
        key: catKey,
        label: labelMap[catKey] || catKey.charAt(0).toUpperCase() + catKey.slice(1),
      }));

    return [{ key: 'All', label: 'All' }, ...dynamicCats];
  }, [dynamicFilters, items, props.filterCategories, GAME_DATA.ITEMS]);

  useEffect(() => {
    if (finalFilterCategories) {
      const currentFilterIsValid = finalFilterCategories.some((f) => f.key === activeFilter);
      if (!currentFilterIsValid) {
        setActiveFilter('All');
      }
    } else {
      if (activeFilter !== 'All') {
        setActiveFilter('All');
      }
    }
  }, [finalFilterCategories, activeFilter]);

  const getSortIndicator = (key: SortKey) => {
    if (sortConfig.key !== key) return null;
    return sortConfig.direction === 'asc' ? ' ▲' : ' ▼';
  };

  const requestSort = (key: SortKey) => {
    let direction: SortDirection = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const indexedItems = useMemo(() => items.map((item, index) => ({ item, originalIndex: index })), [items]);

  const filteredItems = useMemo(() => {
    return indexedItems.filter(({ item }) => {
      const itemData = GAME_DATA.ITEMS[item.id];

      const filterMatch = (() => {
        if (activeFilter === 'All') return true;

        const itemFilterKey = (item as any).filterKey;
        if (itemFilterKey) {
          return itemFilterKey === activeFilter;
        }

        if (itemData?.type.includes(activeFilter as ItemType)) return true;

        return false;
      })();

      const searchMatch = !searchTerm || getItemName(item, GAME_DATA).toLowerCase().includes(searchTerm.toLowerCase()) || itemData?.desc?.toLowerCase().includes(searchTerm.toLowerCase());

      return filterMatch && searchMatch;
    });
  }, [indexedItems, activeFilter, searchTerm, GAME_DATA]);

  const groupedAndSortedItems = useMemo(() => {
    const grouped = groupItems(
      filteredItems.map((fi) => fi.item),
      GAME_DATA
    );
    const sortable = Object.values(grouped).map((group) => {
      const originalFilteredIndices = group.indices;
      const originalItemIndices = originalFilteredIndices.map((i) => filteredItems[i].originalIndex);
      return { ...group, originalIndices: originalItemIndices };
    });

    sortable.sort((a, b) => {
      const itemA = a.item;
      const itemB = b.item;
      const dataA = GAME_DATA.ITEMS[itemA.id];
      const dataB = GAME_DATA.ITEMS[itemB.id];

      if (itemA.requirementStatus && itemB.requirementStatus) {
        const statusOrder = { full: 0, partial: 1, none: 2 };
        const statusA = statusOrder[itemA.requirementStatus as RequirementStatus] ?? 3;
        const statusB = statusOrder[itemB.requirementStatus as RequirementStatus] ?? 3;
        if (statusA !== statusB) return statusA - statusB;
      }

      let compareA: string | number;
      let compareB: string | number;

      switch (sortConfig.key) {
        case 'value':
          compareA = calculateItemValue(itemA, GAME_DATA);
          compareB = calculateItemValue(itemB, GAME_DATA);
          break;
        case 'type':
          compareA = dataA?.type[0] || '';
          compareB = dataB?.type[0] || '';
          break;
        case 'weight':
          compareA = getItemWeight(itemA, GAME_DATA);
          compareB = getItemWeight(itemB, GAME_DATA);
          break;
        case 'itemLevel':
          compareA = (itemA as any).levelReq ?? (itemA.isUnidentified && dataA ? dataA.itemLevel : calculateItemLevel(itemA, GAME_DATA));
          compareB = (itemB as any).levelReq ?? (itemB.isUnidentified && dataB ? dataB.itemLevel : calculateItemLevel(itemB, GAME_DATA));
          break;
        case 'stock':
          compareA = a.item.charges ?? a.count;
          compareB = b.item.charges ?? b.count;
          break;
        case 'requirementStatus':
          const statusOrder = { full: 0, partial: 1, none: 2 };
          compareA = statusOrder[itemA.requirementStatus as RequirementStatus] ?? 3;
          compareB = statusOrder[itemB.requirementStatus as RequirementStatus] ?? 3;
          break;
        case 'name':
        default:
          compareA = getItemName(itemA, GAME_DATA);
          compareB = getItemName(itemB, GAME_DATA);
          break;
      }

      if (typeof compareA === 'string' && typeof compareB === 'string') {
        const res = compareA.localeCompare(compareB);
        if (res !== 0) return sortConfig.direction === 'asc' ? res : -res;
      } else {
        if (compareA < compareB) return sortConfig.direction === 'asc' ? -1 : 1;
        if (compareA > compareB) return sortConfig.direction === 'asc' ? 1 : -1;
      }

      const nameA = getItemName(itemA, GAME_DATA);
      const nameB = getItemName(itemB, GAME_DATA);
      if (nameA !== nameB) return nameA.localeCompare(nameB);

      const levelA = itemA.levelReq ?? dataA?.itemLevel ?? 0;
      const levelB = itemB.levelReq ?? dataB?.itemLevel ?? 0;
      return levelA - levelB;
    });

    return sortable;
  }, [filteredItems, sortConfig, GAME_DATA]);

  const handleItemTransfer = (groupedItem: GroupedItem & { originalIndices: number[] }) => {
    if (!props.onTransfer) return;

    const doTransfer = () => {
      const stockCount = props.isInfiniteStock ? Infinity : groupedItem.item.charges ?? groupedItem.count;
      const amountToTransfer = Math.min(transferAmount, stockCount);
      if (amountToTransfer <= 0) return;
      props.onTransfer!(groupedItem.item, amountToTransfer, groupedItem.originalIndices);
    };

    const itemData = GAME_DATA.ITEMS[groupedItem.item.id];
    const isContainerWithItems = itemData?.type.includes('container') && (groupedItem.item.containerState?.items.length ?? 0) > 0;

    if (isContainerWithItems && setActiveModal) {
      setActiveModal(
        'confirmation-modal',
        {
          title: 'Confirm Transfer',
          message: 'This container has items inside. Transferring it can potentially cause all contents to be permanently lost. Are you sure?',
          onConfirm: () => {
            doTransfer();
            setActiveModal(null);
          },
          onCancel: () => setActiveModal(null),
        },
        { history: true, nested: true }
      );
    } else {
      doTransfer();
    }
  };

  return {
    viewMode,
    setViewMode,
    searchTerm,
    setSearchTerm,
    activeFilter,
    setActiveFilter,
    sortConfig,
    requestSort,
    getSortIndicator,
    transferAmount,
    setTransferAmount,
    transferAmounts: TRANSFER_AMOUNTS,
    groupedAndSortedItems,
    handleItemTransfer,
    finalFilterCategories,
  };
};