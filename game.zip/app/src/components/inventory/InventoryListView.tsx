import { ColumnDef, SortKey } from '../shared/UnifiedInventoryDisplay';
import { GameData, ItemInstance } from 'types';
import React, { useContext } from 'react';
import { calculateItemValue, getItemName, getItemWeight } from 'utils/itemUtils';

import { GameDataContext } from 'context/GameDataContext';
import { GroupedItem } from 'utils/itemUtils';
import { ItemIcon } from '../shared/ItemIcon';

const getDefaultColumns = (GAME_DATA: GameData): ColumnDef[] => [
  {
    key: 'name',
    label: 'Name',
    render: (item, g) => `${getItemName(item, GAME_DATA)}${g.count > 1 ? ` (${g.count})` : ''}`,
    className: 'inventory-row-name',
    isSortable: true,
  },
  {
    key: 'type',
    label: 'Type',
    render: (item) => GAME_DATA.ITEMS[item.id].type.join(', '),
    className: 'inventory-row-type',
    isSortable: true,
  },
  {
    key: 'value',
    label: 'Value',
    render: (item) => `${calculateItemValue(item, GAME_DATA)}g`,
    className: 'inventory-row-value',
    isSortable: true,
  },
  {
    key: 'weight',
    label: 'Weight',
    render: (item) => getItemWeight(item, GAME_DATA).toFixed(1),
    className: 'inventory-row-weight',
    isSortable: true,
  },
];

interface InventoryListViewProps {
  groupedAndSortedItems: (GroupedItem & { originalIndices: number[] })[];
  columns?: ColumnDef[];
  requestSort: (key: SortKey) => void;
  getSortIndicator: (key: SortKey) => ' ▲' | ' ▼' | null;
  onItemClick?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onItemContextMenu?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onTransfer?: (item: ItemInstance, quantity: number, originalIndices: number[]) => void;
  handleItemTransfer: (groupedItem: GroupedItem & { originalIndices: number[] }) => void;
  onRowMouseEnter?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onRowMouseLeave?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
}

export const InventoryListView: React.FC<InventoryListViewProps> = ({
  groupedAndSortedItems,
  columns,
  requestSort,
  getSortIndicator,
  onItemClick,
  onTransfer,
  onItemContextMenu,
  handleItemTransfer,
  onRowMouseEnter,
  onRowMouseLeave,
}) => {
  const GAME_DATA = useContext(GameDataContext)!;
  const finalColumns = columns || getDefaultColumns(GAME_DATA);
  return (
    <div className="inventory-detailed-view">
      <div className="inventory-row header">
        <div style={{ width: '42px', flexShrink: 0 }} />
        {finalColumns.map((col) => (
          <div
            key={col.key}
            className={`${col.className || ''} header-cell`}
            style={{ cursor: col.isSortable ? 'pointer' : 'default' }}
            onClick={col.isSortable ? () => requestSort(col.key) : undefined}
          >
            {col.label}
            {col.isSortable && getSortIndicator(col.key)}
          </div>
        ))}
      </div>
      <div className="inventory-row-container">
        {groupedAndSortedItems.map((groupedItem) => {
          const item = groupedItem.item;
          if ((item as any).isHeader) {
            return (
              <h3 key={item.unique_id} className="inventory-list-header">
                {item.name}
              </h3>
            );
          }
          return (
            <div
              key={`${item.id}-${groupedItem.originalIndices[0]}`}
              className="inventory-row"
              onClick={(e) => {
                if (e.shiftKey && onTransfer) {
                  handleItemTransfer(groupedItem);
                  return;
                }
                if (onItemClick) {
                  onItemClick(e, item, groupedItem.originalIndices);
                } else if (onTransfer) {
                  handleItemTransfer(groupedItem);
                }
              }}
              onContextMenu={onItemContextMenu ? (e) => onItemContextMenu(e, item, groupedItem.originalIndices) : undefined}
              onMouseEnter={onRowMouseEnter ? (e) => onRowMouseEnter(e, item, groupedItem.originalIndices) : undefined}
              onMouseLeave={onRowMouseLeave ? (e) => onRowMouseLeave(e, item, groupedItem.originalIndices) : undefined}
            >
              <ItemIcon item={item} />
              {finalColumns.map((col) => (
                <div key={col.key} className={col.className}>
                  {col.render(item, groupedItem)}
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
};
