import { GameData, ItemInstance } from "types";
import React, { useContext } from "react";
import { ItemIcon } from "../shared/ItemIcon";
import { ColumnDef, SortKey } from "../shared/UnifiedInventoryDisplay";
import { GroupedItem } from "utils/itemUtils";
import { calculateItemValue, getItemWeight, getItemName } from "utils/itemUtils";
import { GameDataContext } from "context/GameDataContext";

const getDefaultColumns = (GAME_DATA: GameData): ColumnDef[] => [
  {
    key: "name",
    label: "Name",
    render: (item, g) => `${getItemName(item)}${g.count > 1 ? ` (${g.count})` : ""}`,
    className: "inventory-row-name",
    isSortable: true,
  },
  {
    key: "type",
    label: "Type",
    render: (item) => GAME_DATA.ITEMS[item.id].type.join(", "),
    className: "inventory-row-type",
    isSortable: true,
  },
  {
    key: "value",
    label: "Value",
    render: (item) => `${calculateItemValue(item, GAME_DATA)}g`,
    className: "inventory-row-value",
    isSortable: true,
  },
  {
    key: "weight",
    label: "Weight",
    render: (item) => getItemWeight(item, GAME_DATA).toFixed(1),
    className: "inventory-row-weight",
    isSortable: true,
  },
];

interface InventoryListViewProps {
  groupedAndSortedItems: (GroupedItem & { originalIndices: number[] })[];
  columns?: ColumnDef[];
  requestSort: (key: SortKey) => void;
  getSortIndicator: (key: SortKey) => " ▲" | " ▼" | null;
  onItemClick?: (item: ItemInstance, originalIndices: number[]) => void;
  onItemContextMenu?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onTransfer?: (item: ItemInstance, quantity: number, originalIndices: number[]) => void;
  handleItemTransfer: (groupedItem: GroupedItem & { originalIndices: number[] }) => void;
}

export const InventoryListView: React.FC<InventoryListViewProps> = ({
  groupedAndSortedItems,
  columns,
  requestSort,
  getSortIndicator,
  onItemClick,
  onTransfer,
  onItemContextMenu,
  handleItemTransfer,
}) => {
  const GAME_DATA = useContext(GameDataContext)!;
  const finalColumns = columns || getDefaultColumns(GAME_DATA);
  return (
    <div className="inventory-detailed-view">
      <div className="inventory-row header">
        <div className="item-icon-wrapper" style={{ visibility: "hidden" }} />
        {finalColumns.map((col) => (
          <div
            key={col.key}
            className={`${col.className || ""} header-cell`}
            style={{ cursor: col.isSortable ? "pointer" : "default" }}
            onClick={col.isSortable ? () => requestSort(col.key) : undefined}
          >
            {col.label}
            {col.isSortable && getSortIndicator(col.key)}
          </div>
        ))}
      </div>
      <div className="inventory-row-container">
        {groupedAndSortedItems.map((groupedItem) => {
          const item = groupedItem.item;
          return (
            <div
              key={`${item.id}-${groupedItem.originalIndices[0]}`}
              className="inventory-row"
              onClick={(e) => {
                if (e.shiftKey && onTransfer) {
                  handleItemTransfer(groupedItem);
                  return;
                }
                if (onItemClick) {
                  onItemClick(item, groupedItem.originalIndices);
                } else if (onTransfer) {
                  handleItemTransfer(groupedItem);
                }
              }}
              onContextMenu={onItemContextMenu ? (e) => onItemContextMenu(e, item, groupedItem.originalIndices) : undefined}
            >
              <ItemIcon item={item} />
              {finalColumns.map((col) => (
                <div key={col.key} className={col.className}>
                  {col.render(item, groupedItem)}
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
};