import { CombatContext } from 'context/CombatContext';
import { GameDataContext } from 'context/GameDataContext';
import { UIContext } from 'context/UIContext';
import React, { useContext, useEffect } from 'react';
import { Combatant } from 'types';
import { isCombatantDefeated } from 'utils/combatUtils';
import { CombatantDisplay } from './combat/CombatantDisplay';

const CombatUI: React.FC = () => {
  const { currentCombat, enemies, selectedTargetId, setSelectedTargetId, selectedLimbId, playerUseSkill, playerAttack, setSelectedAction, selectedAction } =
    useContext(CombatContext)!;
  const GAME_DATA = useContext(GameDataContext)!;

  const { setActiveModal } = useContext(UIContext)!;

  useEffect(() => {
    if (currentCombat && !currentCombat.isPlayerTurn && setSelectedAction) {
      setSelectedAction(null);
    }
  }, [currentCombat?.isPlayerTurn, setSelectedAction]);

  if (!currentCombat || !currentCombat.isActive) {
    return null;
  }

  const playerTeam: Combatant[] = Object.values(currentCombat.combatants).filter((c: Combatant) => c.team === 'player');

  const handleSelectCombatant = (combatantId: string) => {
    const combatant = currentCombat.combatants[combatantId];

    if (selectedAction?.type === 'inspect') {
      setActiveModal('inspect-modal', { combatant }, { history: true });
      setSelectedAction(null);
      return;
    }

    if (isCombatantDefeated(combatant)) return;

    setSelectedTargetId(combatantId);
  };

  const handleLimbSelect = (targetId: string, limbId: string) => {
    if (!selectedAction || !targetId) return;

    if (selectedAction.type === 'attack') {
      playerAttack(targetId, limbId, false);
    } else if (selectedAction.type === 'skill' && selectedAction.skillId) {
      playerUseSkill(selectedAction.skillId, targetId, limbId, false);
    }
    setSelectedAction(null);
  };

  const isCombatantTargetable = (combatant: Combatant) => {
    if (selectedAction?.type === 'inspect') {
      return true;
    }

    if (isCombatantDefeated(combatant)) {
      if (selectedAction?.type === 'skill' && selectedAction.skillId) {
        const skill = GAME_DATA.SKILLS[selectedAction.skillId];
        // Allow targeting defeated combatants only for revive-like abilities
        return skill.effect.type === 'revive';
      }
      return false;
    }

    if (selectedAction?.type === 'attack') {
      return combatant.team === 'enemy';
    }

    if (selectedAction?.type === 'skill' && selectedAction.skillId) {
      const skill = GAME_DATA.SKILLS[selectedAction.skillId];
      if (!skill.validTargets) return false;

      const isSelfOrAlly = combatant.team === 'player' && (skill.validTargets.includes('self') || skill.validTargets.includes('ally'));
      const isEnemy = combatant.team === 'enemy' && skill.validTargets.includes('enemy');
      const isAny = skill.validTargets.includes('any');

      return isSelfOrAlly || isEnemy || isAny;
    }

    return false;
  };

  return (
    <div className="combat-view">
      <div className="combat-teams-display">
        <div className="team-panel player-team">
          <h3>Your Team</h3>
          {playerTeam.map((combatant: Combatant) => (
            <CombatantDisplay
              key={combatant.id}
              combatant={combatant}
              isSelected={combatant.id === selectedTargetId}
              onSelect={() => handleSelectCombatant(combatant.id)}
              onLimbSelect={(limbId) => handleLimbSelect(combatant.id, limbId)}
              selectedLimbId={selectedTargetId === combatant.id ? selectedLimbId : null}
              isTargetable={isCombatantTargetable(combatant)}
              isDefeated={isCombatantDefeated(combatant)}
            />
          ))}
        </div>
        <div className="team-panel enemy-team">
          <h3>Enemies</h3>
          {enemies.map((enemy) => (
            <CombatantDisplay
              key={enemy.id}
              combatant={enemy}
              isSelected={enemy.id === selectedTargetId}
              onSelect={() => handleSelectCombatant(enemy.id)}
              onLimbSelect={(limbId) => handleLimbSelect(enemy.id, limbId)}
              selectedLimbId={enemy.id === selectedTargetId ? selectedLimbId : null}
              isTargetable={isCombatantTargetable(enemy)}
              isDefeated={isCombatantDefeated(enemy)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default CombatUI;
