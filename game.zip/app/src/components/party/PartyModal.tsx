import React, { useContext } from "react";
import { Modal } from "../modals/Modal";
import { Mercenary } from "../../types";
import { EquipmentDisplay } from "../shared/EquipmentDisplay";
import { CharacterVitalsPanel } from "components/character/CharacterVitalsPanel";
import { CharacterTabs } from "components/character/CharacterTabs";
import { UnifiedInventoryDisplay } from "components/shared/UnifiedInventoryDisplay";
import { useParty } from "hooks/useParty";
import { usePlayer } from "hooks/usePlayer";
import { UIContext } from "context/UIContext";
import { useModalState } from "hooks/useModalState";

const MercenaryColumn: React.FC<{
  mercenary: Mercenary;
}> = ({ mercenary }) => {
  const { fireMercenary } = useParty();
  const { viewMode, setViewMode } = useModalState("party", mercenary.id);

  return (
    <div className="party-member-column">
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexShrink: 0,
        }}
      >
        <h4>{mercenary.name}</h4>
        <button className="btn btn-danger" style={{ minWidth: "auto", padding: "5px 10px" }} onClick={() => fireMercenary(mercenary.id)}>
          Fire
        </button>
      </div>

      <div className="party-member-scroll-content">
        <CharacterVitalsPanel character={mercenary} />

        <hr className="stat-divider" />

        <div>
          <h4>Equipment</h4>
          <EquipmentDisplay equipment={mercenary.equipment} />
        </div>

        <hr className="stat-divider" />

        <UnifiedInventoryDisplay
          title="Inventory"
          items={mercenary.inventory}
          showFilterBar={false}
          showSortButtons={false}
          showViewToggle={true}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
        />

        <hr className="stat-divider" />

        <CharacterTabs character={mercenary} />
      </div>
    </div>
  );
};

export const PartyModal: React.FC = () => {
  const player = usePlayer();
  const { party } = useParty();
  const { setActiveModal } = useContext(UIContext)!;

  if (!player || !party) return null;

  const totalEncumbrance = party.reduce((acc, m) => acc + m.currentWeight, player.currentWeight);
  const totalMaxEncumbrance = party.reduce((acc, m) => acc + m.maxWeight, player.maxWeight);

  return (
    <Modal
      title="Your Party"
      subTitle={`Encumbrance: ${totalEncumbrance.toFixed(1)} / ${totalMaxEncumbrance.toFixed(1)}`}
      onClose={() => setActiveModal(null)}
      size="xlarge"
    >
      {party.length === 0 ? (
        <p>You have no mercenaries in your party. Visit the Mercenary Guild in a town to hire some.</p>
      ) : (
        <div className="party-modal-layout">
          {party.map((merc) => (
            <MercenaryColumn key={merc.id} mercenary={merc} />
          ))}
          {/* Render empty columns if party is not full */}
          {Array.from({ length: 3 - party.length }).map((_, i) => (
            <div key={`empty-${i}`} className="party-member-column" style={{ backgroundColor: "#181818" }}>
              <p style={{ color: "#666", textAlign: "center", margin: "auto" }}>Slot Empty</p>
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
};