import React, { useContext, useEffect } from "react";

import { Modal } from "../modals/Modal";
import { UIContext } from "context/UIContext";
import { useParty } from "hooks/useParty";
import { useInventory } from "hooks/useInventory";

export const MercenaryGuildModal: React.FC = () => {
  const { gold } = useInventory();
  const { party, hireMercenary, refreshMercenaryGuild, mercenaryGuildData } = useParty();
  const { setActiveModal } = useContext(UIContext)!;

  useEffect(() => {
    refreshMercenaryGuild();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (gold === undefined || !party) return null;

  const availableMercs = mercenaryGuildData?.available || [];
  const canHire = party.length < 3;

  return (
    <Modal title="Mercenary Guild" onClose={() => setActiveModal(null)} size="large">
      <p>Welcome to the guild. These brave souls are looking for work. Take your pick, but remember, they don't work for free.</p>
      {!canHire && <p style={{ color: "#ff6b6b", fontWeight: "bold" }}>Your party is full. You cannot hire more mercenaries.</p>}

      <div className="mercenary-hire-list" style={{ marginTop: "10px" }}>
        {availableMercs.map((merc) => {
          const hasSufficientGold = gold >= merc.initialCost;
          return (
            <div key={merc.id} className="mercenary-for-hire">
              <div>
                <h4>{merc.name}</h4>
                <div className="mercenary-details">
                  <span>Level: {merc.level}</span>
                  <span>Class: {merc.class}</span>
                  <span>Race: {merc.race}</span>
                  <span className="mercenary-costs">Upkeep: {merc.dailyCost}g / day</span>
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <p className="mercenary-costs">Hire Fee: {merc.initialCost}g</p>
                <button className="btn" disabled={!canHire || !hasSufficientGold} onClick={() => hireMercenary(merc)}>
                  Hire
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </Modal>
  );
};