import { ItemIcon } from "components/shared/ItemIcon";
import React from "react";
import { UseCraftingReturn, ItemInstance, RequirementCheck } from "types";
import { GroupedItem } from "utils/itemUtils";

interface CreateInterfaceProps {
  crafting: UseCraftingReturn;
  transferAmount: number;
}

const MAX_TOOLS = 4;
const MAX_INGREDIENTS = 10;

export const CreateInterface: React.FC<CreateInterfaceProps> = ({
  crafting,
  transferAmount,
}) => {
  const {
    tools,
    setTools,
    ingredients,
    setIngredients,
    groupedIngredients,
    selectedRecipe,
    discoveredRecipe,
    requirementChecks,
    canCraftSingle,
    canCraftMultiple,
    handleCraft,
    handleRemoveItem,
  } = crafting;

  return (
    <div className="crafting-interface-main">
      <div className="crafting-slots-area">
        <h5>
          Tools ({tools.length}/{MAX_TOOLS})
        </h5>
        <div className="crafting-slots-grid">
          {tools.map((item: ItemInstance) => (
            <ItemIcon
              key={item.unique_id}
              item={item}
              onClick={() => handleRemoveItem(item, setTools, transferAmount)}
            />
          ))}
        </div>
        <h5 style={{ marginTop: "10px" }}>
          Ingredients ({ingredients.length}/{MAX_INGREDIENTS})
        </h5>
        <div className="crafting-slots-grid">
          {Object.values(groupedIngredients).map(
            ({ item, count }: GroupedItem) => (
              <ItemIcon
                key={`${item.unique_id}-${count}`}
                item={item}
                count={count}
                onClick={() =>
                  handleRemoveItem(item, setIngredients, transferAmount)
                }
              />
            ),
          )}
        </div>
      </div>
      <div className="crafting-result-area">
        {(selectedRecipe || discoveredRecipe) && (
          <ItemIcon
            item={{
              id: (selectedRecipe || discoveredRecipe)!.creates,
              unique_id: "preview",
              enchantments: {},
              quality: "Average",
              isUnidentified: false,
            }}
          />
        )}
        <h4>{(selectedRecipe || discoveredRecipe)?.name || "Experiment"}</h4>
        <div className="crafting-requirements-list">
          {Object.values(requirementChecks).map((c: RequirementCheck) => (
            <p key={c.text} className={c.ok ? "req-ok" : "req-fail"}>
              {c.text}
            </p>
          ))}
        </div>
        <div className="action-grid">
          <button
            className="btn"
            onClick={() => handleCraft(1)}
            disabled={!canCraftSingle}
          >
            Craft 1x
          </button>
          <button
            className="btn"
            onClick={() => handleCraft(5)}
            disabled={!canCraftMultiple(5)}
          >
            Craft 5x
          </button>
          <button
            className="btn"
            onClick={() => handleCraft(25)}
            disabled={!canCraftMultiple(25)}
          >
            Craft 25x
          </button>
        </div>
      </div>
    </div>
  );
};