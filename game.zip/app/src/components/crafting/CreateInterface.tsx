import { ItemInstance, RequirementCheck, UseCraftingReturn } from 'types';

import { ItemIcon } from 'components/shared/ItemIcon';
import React, { useContext } from 'react';
import { GroupedItem } from 'utils/itemUtils';
import { WorldContext } from 'context/WorldContext';

interface CreateInterfaceProps {
  crafting: UseCraftingReturn;
  transferAmount: number;
}

const MAX_TOOLS = 4;
const MAX_INGREDIENTS = 10;

export const CreateInterface: React.FC<CreateInterfaceProps> = ({ crafting, transferAmount }) => {
  const { tools, setIngredients, groupedIngredients, selectedRecipe, discoveredRecipe, requirementChecks, canCraftSingle, canCraftMultiple, handleCraft, handleRemoveItem } =
    crafting;
  const { isActionLocked } = useContext(WorldContext)!;

  const emptyToolSlots = Array.from({ length: Math.max(0, MAX_TOOLS - tools.length) });
  const emptyIngredientSlots = Array.from({
    length: Math.max(0, MAX_INGREDIENTS - Object.keys(groupedIngredients).length),
  });

  return (
    <div className="crafting-interface-panel">
      <h3>Item Creation</h3>
      <div className="crafting-target-slot">
        {selectedRecipe ? (
          <ItemIcon
            item={{
              id: selectedRecipe.creates,
              unique_id: 'preview_selected',
              quantity: selectedRecipe.quantity,
              enchantments: {},
            }}
          />
        ) : (
          <p>Choose Recipe to Craft</p>
        )}
      </div>

      <div className="crafting-slots-area">
        <h3>
          Tools ({tools.length}/{MAX_TOOLS})
        </h3>
        <div className="crafting-slots-grid">
          {tools.map((item: ItemInstance) => (
            <ItemIcon key={item.unique_id} item={item} onClick={() => handleRemoveItem(item, crafting.setTools, transferAmount)} />
          ))}
          {emptyToolSlots.map((_, i) => (
            <div key={`empty-tool-${i}`} className="item-icon-wrapper empty" />
          ))}
        </div>

        <h3 style={{ marginTop: '20px' }}>
          Ingredients ({Object.keys(groupedIngredients).length}/{MAX_INGREDIENTS})
        </h3>
        <div className="crafting-slots-grid">
          {Object.values(groupedIngredients).map((group: GroupedItem) => (
            <ItemIcon
              key={`${group.item.unique_id}-${group.count}`}
              item={group.item}
              count={group.count}
              onClick={() => handleRemoveItem(group.item, setIngredients, transferAmount)}
            />
          ))}
          {emptyIngredientSlots.map((_, i) => (
            <div key={`empty-ing-${i}`} className="item-icon-wrapper empty" />
          ))}
        </div>
      </div>

      <div className="crafting-result-area">
        <h3>{(selectedRecipe || discoveredRecipe)?.name || 'Experiment'}</h3>
        <div className="crafting-requirements-list">
          {Object.values(requirementChecks).map((check: RequirementCheck) =>
            check.text ? (
              <p key={check.text} className={check.ok ? 'req-ok' : 'req-fail'}>
                {check.provided !== undefined && check.required !== undefined ? `${check.text} ${check.provided}/${check.required}` : check.text}
              </p>
            ) : null
          )}
        </div>
        <div className="action-grid">
          <button className="btn" onClick={() => handleCraft(1)} disabled={!canCraftSingle || isActionLocked}>
            Craft 1x
          </button>
          <button className="btn" onClick={() => handleCraft(5)} disabled={!canCraftMultiple(5) || isActionLocked}>
            Craft 5x
          </button>
          <button className="btn" onClick={() => handleCraft(25)} disabled={!canCraftMultiple(25) || isActionLocked}>
            Craft 25x
          </button>
        </div>
      </div>
    </div>
  );
};