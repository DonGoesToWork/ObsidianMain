import { ItemIcon } from 'components/shared/ItemIcon';
import { UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import { GameDataContext } from 'context/GameDataContext';
import { WorldContext } from 'context/WorldContext';
import { useEnchanting } from 'hooks/useEnchanting';
import { useModalState } from 'hooks/useModalState';
import React, { useContext } from 'react';
import { ItemInstance } from 'types';
import { toRoman } from 'utils/formatUtils';
import { countItems, getItemName, getItemTier } from 'utils/itemUtils';
import { EnchantmentTile } from './EnchantmentTile';

export const EnchantingPanel: React.FC = () => {
  const {
    player,
    selectedItem,
    setSelectedItem,
    inventoryItems,
    enchantmentDetails,
    availableEnchants,
    hasMaxEnchants,
    itemTier,
    selectedEnchantment,
    handleEnchant,
    handleSelectItem,
    handleSelectTier,
  } = useEnchanting();

  const inventoryState = useModalState('crafting', 'enchanting_inventory');
  const GAME_DATA = useContext(GameDataContext)!;
  const { isActionLocked } = useContext(WorldContext)!;

  if (!player) return null;

  const getEnchantmentsView = (item: any) => {
    const enchantments = item.enchantments;
    const entries = Object.entries(enchantments);
    const tier = getItemTier(item, GAME_DATA);

    return (
      <>
        <p style={{ color: tier.color, marginBottom: '10px' }}>Enchantment Tier: {tier.name}</p>
        {entries.length > 0 && (
          <ul>
            {entries.map(([enchantId, tier]) => {
              if (tier === undefined) return null;
              const enchantDef = GAME_DATA.ENCHANTS.find((e) => e.id === enchantId);
              if (!enchantDef) return null;
              return <li key={enchantId}>{`T${toRoman(tier as number)} ${enchantDef.name} - ${enchantDef.loreNames[(tier as number) - 1]}`}</li>;
            })}
          </ul>
        )}
      </>
    );
  };

  const handleItemClick = (e: React.MouseEvent, item: ItemInstance) => {
    if (selectedItem?.unique_id === item.unique_id) {
      setSelectedItem(null);
    } else {
      handleSelectItem(e, item);
    }
  };

  return (
    <div className="crafting-modal-body" style={{ flexGrow: 1 }}>
      <div className="crafting-inventory-panel">
        <UnifiedInventoryDisplay
          title="Inventory"
          items={inventoryItems}
          showViewToggle={true}
          viewMode={inventoryState.viewMode}
          onViewModeChange={inventoryState.setViewMode}
          showFilterSearchBar={true}
          showFilterButtonBar={true}
          dynamicFilters={true}
          onItemClick={handleItemClick}
        />
      </div>

      <div className="crafting-interface-panel">
        <h3>Item Enchanting</h3>
        <div className="crafting-target-slot">{selectedItem ? <ItemIcon item={selectedItem} onClick={() => setSelectedItem(null)} /> : <p>Choose Item to Enchant</p>}</div>
        <div className="crafting-slots-area">
          {selectedItem && (
            <div className="enchanting-item-details">
              <h3>{getItemName(selectedItem, GAME_DATA)}</h3>
              {getEnchantmentsView(selectedItem)}
            </div>
          )}
          {enchantmentDetails && (
            <div className="enchantment-details-area">
              <h3>Enchantment Details</h3>
              <p>
                Selected Tier: <strong style={{ color: '#ffd700' }}>{toRoman(enchantmentDetails.selectedTier)}</strong>
              </p>
              <p>Current Tier: {enchantmentDetails.currentTier > 0 ? `T${toRoman(enchantmentDetails.currentTier)}` : 'None'}</p>

              <hr className="stat-divider" />

              <h3>Requirements</h3>
              <p style={{ color: enchantmentDetails.isKnown ? '#ffd700' : '#c99898' }}>• Recipe is known</p>
              <p style={{ color: enchantmentDetails.isHigherTier ? '#ffd700' : '#c99898' }}>• Tier must be higher than current</p>
              <p style={{ color: !enchantmentDetails.enchantTierIsTooHigh ? '#ffd700' : '#c99898' }}>• Enchant tier must not exceed item tier</p>
              <p style={{ color: !enchantmentDetails.maxEnchantsReached ? '#ffd700' : '#c99898' }}>• Item has not reached max enchantments</p>
              <p style={{ color: enchantmentDetails.hasCrystals ? '#ffd700' : '#c99898' }}>
                • {enchantmentDetails.crystalName}: {countItems(player.inventory, enchantmentDetails.crystalId)}/{enchantmentDetails.crystalCost}
              </p>

              <hr className="stat-divider" />

              <h3>Statistics</h3>
              <p>
                DR: {enchantmentDetails.dr} (vs {enchantmentDetails.playerSkill})
              </p>
              <p>
                Success Chance: <strong style={{ color: '#ffd700' }}>{enchantmentDetails.successChance.toFixed(1)}%</strong>
              </p>
              <p style={{ color: '#c99898', fontStyle: 'italic', marginTop: '10px' }}>Failure has a chance to destroy the item or lower its enchantment tier.</p>
            </div>
          )}
        </div>
        <div className="crafting-result-area">
          <button className="btn" onClick={handleEnchant} disabled={!enchantmentDetails?.canEnchant || isActionLocked}>
            Enchant
          </button>
        </div>
      </div>

      <div className="crafting-recipes-panel">
        <h3>Available Enchantments</h3>
        <div className="enchanting-grid-container">
          {selectedItem ? (
            availableEnchants.length > 0 ? (
              <div className="enchantment-grid">
                {availableEnchants.map((def) => (
                  <EnchantmentTile
                    key={def.id}
                    player={player}
                    enchantDef={def}
                    selectedItem={selectedItem}
                    onSelectTier={handleSelectTier}
                    selectedEnchantment={selectedEnchantment}
                    itemTier={itemTier}
                    hasMaxEnchants={hasMaxEnchants}
                  />
                ))}
              </div>
            ) : (
              <p>You do not know any applicable enchantments for this item.</p>
            )
          ) : (
            <p>Select an item from your inventory to begin enchanting.</p>
          )}
        </div>
      </div>
    </div>
  );
};
