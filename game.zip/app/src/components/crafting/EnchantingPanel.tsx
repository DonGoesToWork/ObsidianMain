import { GameData, GameItem, ItemId, ItemInstance } from "../../types";
import React, { useContext, useMemo, useState } from "react";

import { UnifiedInventoryDisplay } from "components/shared/UnifiedInventoryDisplay";
import { calculateEnchantSuccessChance } from "utils/craftingUtils";
import { countItems } from "utils/itemUtils";
import { PlayerContext } from "context/PlayerContext";
import { ProfessionsContext } from "../../context/ProfessionsContext";
import { useModalState } from "hooks/useModalState";
import { GameDataContext } from "context/GameDataContext";

type SelectedEnchantment = { def: any; rank: number };

const EnchantmentOptionButton: React.FC<{
  player: any;
  enchantDef: any;
  rank: number;
  crystalCounts: Record<string, number>;
  selectedEnchant: SelectedEnchantment | null;
  onSelect: (selection: SelectedEnchantment) => void;
  GAME_DATA: GameData;
}> = ({ player, enchantDef, rank, crystalCounts, selectedEnchant, onSelect, GAME_DATA }) => {
  const cost = enchantDef.cost[rank];
  const goldCost = enchantDef.gold[rank];
  const crystalId = Object.keys(cost)[0] as ItemId;
  const crystalCost = cost[crystalId];
  const canAfford = player.gold >= goldCost && (crystalCounts[crystalId] || 0) >= crystalCost;
  const successChance = calculateEnchantSuccessChance(player.professions.enchanting.level, rank);
  const selection = { def: enchantDef, rank };

  return (
    <button
      key={rank}
      className={`btn ${JSON.stringify(selectedEnchant) === JSON.stringify(selection) ? "selected" : ""}`}
      disabled={!canAfford}
      onClick={() => onSelect(selection)}
    >
      Rank {rank + 1}: +{enchantDef.scaling[rank]} (Chance: {successChance.toFixed(0)}%)
      <br />
      <small>
        ({goldCost}g, {GAME_DATA.ITEMS[crystalId].name} x{crystalCost})
      </small>
    </button>
  );
};

export const EnchantingPanel: React.FC = () => {
  const { player } = useContext(PlayerContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { enchantItem } = useContext(ProfessionsContext)!;
  const [selectedItem, setSelectedItem] = useState<ItemInstance | null>(null);
  const [selectedEnchant, setSelectedEnchant] = useState<SelectedEnchantment | null>(null);
  const { viewMode, setViewMode } = useModalState("crafting", "enchanting");

  const inventoryItems = useMemo(() => {
    return (
      player?.inventory
        .map((item: ItemInstance) => ({ item }))
        .filter(({ item }: { item: ItemInstance }) => {
          const itemData = GAME_DATA.ITEMS[item.id];
          return itemData?.type.includes("equipment") && !item.isUnidentified;
        })
        .map(({ item }: { item: ItemInstance }) => item) || []
    );
  }, [player?.inventory, GAME_DATA.ITEMS]);

  const crystalCounts = useMemo(() => {
    if (!player) return {};
    const counts: Record<string, number> = {};
    for (let i = 1; i <= 20; i++) {
      const id: ItemId = `mat_crystal_t${i}` as ItemId;
      counts[id] = countItems(player.inventory, id);
    }
    return counts;
  }, [player?.inventory]);

  if (!player) return null;

  const selectedItemData = selectedItem ? (GAME_DATA.ITEMS[selectedItem.id] as GameItem) : null;

  const availableEnchants =
    selectedItemData?.type.includes("equipment") && selectedItemData.slot
      ? GAME_DATA.ENCHANTS[selectedItemData.slot as keyof typeof GAME_DATA.ENCHANTS] || GAME_DATA.ENCHANTS.weapon
      : [];

  const handleEnchant = () => {
    if (selectedItem && selectedEnchant) {
      enchantItem(selectedItem.unique_id, selectedEnchant.def, selectedEnchant.rank);
      setSelectedItem(null);
      setSelectedEnchant(null);
    }
  };

  return (
    <div style={{ flexGrow: 1, display: "flex", flexDirection: "column" }}>
      <p>Enchanting Level: {player.professions.enchanting.level}</p>
      <div className="shop-layout" style={{ marginTop: "15px", flexGrow: 1, minHeight: 0 }}>
        <div className="shop-panel">
          <UnifiedInventoryDisplay
            title="Your Items"
            items={inventoryItems}
            showViewToggle={true}
            viewMode={viewMode}
            onViewModeChange={setViewMode}
            onItemClick={(item) => {
              setSelectedItem(item);
              setSelectedEnchant(null);
            }}
          />
        </div>
        <div className="shop-panel" style={{ overflowY: "auto" }}>
          <h4>Enchantment Options</h4>
          {selectedItem && selectedItemData ? (
            <div className="enchant-options">
              {availableEnchants.map((enchantDef: any, i: number) => (
                <div key={i} className="enchant-option">
                  <h5>Enchant {enchantDef.stat}</h5>
                  {enchantDef.scaling.map((_val: number, rank: number) => (
                    <EnchantmentOptionButton
                      key={rank}
                      player={player}
                      enchantDef={enchantDef}
                      rank={rank}
                      crystalCounts={crystalCounts}
                      selectedEnchant={selectedEnchant}
                      onSelect={setSelectedEnchant}
                      GAME_DATA={GAME_DATA}
                    />
                  ))}
                </div>
              ))}
              {selectedEnchant && (
                <div
                  style={{
                    marginTop: "10px",
                    borderTop: "1px solid #555",
                    paddingTop: "15px",
                  }}
                >
                  <p>
                    Selected: Enchant {selectedEnchant.def.stat} Rank {selectedEnchant.rank + 1}
                  </p>
                  <button className="btn" onClick={handleEnchant}>
                    Attempt Enchantment
                  </button>
                </div>
              )}
            </div>
          ) : (
            <p>Select an item to enchant.</p>
          )}
        </div>
      </div>
    </div>
  );
};