import { EnchantDef, ItemId, ItemInstance, Player } from '../../types';
import React, { useContext, useEffect, useMemo, useState } from 'react';
import { calculateItemLevel, countItems, getItemName, getItemTier, ITEM_RARITY_TIERS } from 'utils/itemUtils';

import { GameDataContext } from 'context/GameDataContext';
import { ItemIcon } from 'components/shared/ItemIcon';
import { PlayerContext } from 'context/PlayerContext';
import { ProfessionsContext } from '../../context/ProfessionsContext';
import { UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import { calculateEnchantSuccessChance } from 'utils/craftingUtils';
import { useModalState } from 'hooks/useModalState';

const toRoman = (num: number): string => {
  if (num < 1 || num > 3999) return num.toString();
  const val = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1];
  const syb = ['M', 'CM', 'D', 'CD', 'C', 'XC', 'L', 'XL', 'X', 'IX', 'V', 'IV', 'I'];
  let roman = '';
  for (let i = 0; i < val.length; i++) {
    while (num >= val[i]) {
      roman += syb[i];
      num -= val[i];
    }
  }
  return roman;
};

interface EnchantmentTileProps {
  player: Player;
  enchantDef: EnchantDef;
  selectedItem: ItemInstance;
  onSelectTier: (enchantId: string, tier: number) => void;
  selectedEnchantment: { enchantId: string; tier: number } | null;
  itemTier: number;
  hasMaxEnchants: boolean;
}

const EnchantmentTile: React.FC<EnchantmentTileProps> = ({ player, enchantDef, selectedItem, onSelectTier, selectedEnchantment, itemTier, hasMaxEnchants }) => {
  const currentTier = selectedItem.enchantments[enchantDef.id] || 0;
  const isEnchantOnItem = currentTier > 0;

  return (
    <div className="enchantment-tile">
      <div className="enchantment-header">
        <h3>{enchantDef.name}</h3>
        <p className="enchantment-desc">{enchantDef.desc}</p>
      </div>
      <p className="current-enchant-tier">{currentTier > 0 ? `T${currentTier} - ${enchantDef.loreNames[currentTier - 1]}` : 'Not Enchanted'}</p>
      <div className="tier-buttons">
        {Array.from({ length: enchantDef.scaling.length }).map((_, i) => {
          const tier = i + 1;
          const rank = i;
          const isHigherTier = tier > currentTier;
          const isTierTooHigh = tier > itemTier;

          const materialCost = enchantDef.cost[rank];
          const crystalId = Object.keys(materialCost)[0] as ItemId;
          const crystalCostCount = materialCost[crystalId];
          const hasCrystals = countItems(player.inventory, crystalId) >= crystalCostCount;

          let statusClass = 'none';
          if (!isEnchantOnItem && hasMaxEnchants) {
            statusClass = 'none'; // Red
          } else if (isHigherTier && !isTierTooHigh) {
            statusClass = hasCrystals ? 'full' : 'partial';
          }

          const isSelected = selectedEnchantment?.enchantId === enchantDef.id && selectedEnchantment?.tier === tier;

          return (
            <button
              key={i}
              className={`btn ${isSelected ? 'selected' : ''}`}
              onClick={() => onSelectTier(enchantDef.id, tier)}
              disabled={isTierTooHigh}
              title={isTierTooHigh ? `Item level too low for Tier ${tier} enchants.` : !isEnchantOnItem && hasMaxEnchants ? 'Item has reached max enchantments.' : ''}
            >
              {toRoman(tier)} <span className={`req-indicator ${statusClass}`} />
            </button>
          );
        })}
      </div>
    </div>
  );
};

export const EnchantingPanel: React.FC = () => {
  const { player } = useContext(PlayerContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { enchantItem } = useContext(ProfessionsContext)!;
  const inventoryState = useModalState('crafting', 'enchanting_inventory');

  const [selectedItem, setSelectedItem] = useState<ItemInstance | null>(null);
  const [selectedEnchantment, setSelectedEnchantment] = useState<{ enchantId: string; tier: number } | null>(null);

  useEffect(() => {
    if (selectedItem && player) {
      const updatedItem = player.inventory.find((item) => item.unique_id === selectedItem.unique_id);
      if (updatedItem) {
        if (JSON.stringify(updatedItem) !== JSON.stringify(selectedItem)) {
          setSelectedItem(updatedItem);
        }
      } else {
        setSelectedItem(null);
      }
    }
  }, [player, selectedItem]);

  const inventoryItems = useMemo(() => {
    return (
      player?.inventory.filter((item: ItemInstance) => {
        const itemData = GAME_DATA.ITEMS[item.id];
        return !item.isUnidentified && !itemData.isUnarmed;
      }) || []
    );
  }, [player?.inventory, GAME_DATA.ITEMS]);

  const itemTier = useMemo(() => {
    if (!selectedItem) return Infinity;
    const calculatedLevel = calculateItemLevel(selectedItem, GAME_DATA);
    return Math.floor(calculatedLevel / 10) + 1;
  }, [selectedItem, GAME_DATA]);

  const numEnchantments = selectedItem ? Object.keys(selectedItem.enchantments).length : 0;
  const hasMaxEnchants = selectedItem ? numEnchantments >= Object.keys(ITEM_RARITY_TIERS).length - 1 : false;

  const availableEnchants = useMemo(() => {
    if (!selectedItem) return [];
    const itemData = GAME_DATA.ITEMS[selectedItem.id];

    return GAME_DATA.ENCHANTS.filter((enchant) => {
      if (enchant.type === 'global') {
        return true;
      }
      if (enchant.type === 'local') {
        if (!enchant.appliesTo) {
          return true; // Universal local enchant
        }
        const { hasStat, hasItemType } = enchant.appliesTo;

        // If appliesTo is specified, but no conditions inside, it should match anything
        if ((!hasStat || hasStat.length === 0) && (!hasItemType || hasItemType.length === 0)) return true;

        const itemStats = itemData.stats || {};
        const itemTypes = itemData.type || [];

        const statMatch = hasStat && hasStat.some((s) => itemStats[s] !== undefined);
        const typeMatch = hasItemType && hasItemType.some((t) => itemTypes.includes(t));

        return !!(statMatch || typeMatch);
      }
      return false;
    });
  }, [selectedItem, GAME_DATA]);

  const enchantmentDetails = useMemo(() => {
    if (!player || !selectedItem || !selectedEnchantment) return null;

    const enchantDef = GAME_DATA.ENCHANTS.find((e) => e.id === selectedEnchantment.enchantId);
    if (!enchantDef) return null;

    const currentTier = selectedItem.enchantments[enchantDef.id] || 0;
    const selectedTier = selectedEnchantment.tier;
    const rank = selectedTier - 1;

    if (rank < 0 || rank >= enchantDef.scaling.length) return null;

    const isHigherTier = selectedTier > currentTier;

    const materialCost = enchantDef.cost[rank];
    const crystalId = Object.keys(materialCost)[0] as ItemId;
    const crystalCostCount = materialCost[crystalId];
    const hasCrystals = countItems(player.inventory, crystalId) >= crystalCostCount;

    const numExistingEnchants = Object.keys(selectedItem.enchantments).length;
    const isNewEnchantType = !selectedItem.enchantments[enchantDef.id];
    const maxEnchantsReached = isNewEnchantType && numExistingEnchants >= Object.keys(ITEM_RARITY_TIERS).length - 1;
    const enchantTierIsTooHigh = selectedTier > itemTier;

    const canEnchant = isHigherTier && hasCrystals && !enchantTierIsTooHigh && !maxEnchantsReached;
    const playerSkill = player.professions.enchanting.level;

    const baseDr = (rank + 1) * 10;
    const finalDr = baseDr + numExistingEnchants;
    const successChance = calculateEnchantSuccessChance(playerSkill, finalDr);

    return {
      enchantDef,
      currentTier,
      selectedTier,
      isHigherTier,
      enchantTierIsTooHigh,
      maxEnchantsReached,
      crystalId,
      crystalName: GAME_DATA.ITEMS[crystalId]?.name || 'Unknown Crystal',
      crystalCost: crystalCostCount,
      hasCrystals,
      successChance,
      canEnchant,
      dr: finalDr,
      playerSkill,
    };
  }, [player, selectedItem, selectedEnchantment, GAME_DATA, itemTier]);

  const handleEnchant = () => {
    if (!enchantmentDetails?.canEnchant || !selectedItem || !selectedEnchantment) return;
    const { enchantDef } = enchantmentDetails;
    const rank = selectedEnchantment.tier - 1;
    enchantItem(selectedItem.unique_id, enchantDef, rank);
    setSelectedEnchantment(null);
  };

  const handleSelectItem = (_e: React.MouseEvent, item: ItemInstance) => {
    setSelectedItem(item);
    setSelectedEnchantment(null);
  };

  const handleSelectTier = (enchantId: string, tier: number) => {
    if (selectedEnchantment?.enchantId === enchantId && selectedEnchantment?.tier === tier) {
      setSelectedEnchantment(null);
    } else {
      setSelectedEnchantment({ enchantId, tier });
    }
  };

  if (!player) return null;

  const getEnchantmentsView = (item: ItemInstance) => {
    const enchantments = item.enchantments;
    const entries = Object.entries(enchantments);
    const tier = getItemTier(item, GAME_DATA);

    return (
      <>
        <p style={{ color: tier.color, marginBottom: '10px' }}>Enchantment Tier: {tier.name}</p>
        {entries.length > 0 && (
          <ul>
            {entries.map(([enchantId, tier]) => {
              if (tier === undefined) return null;
              const enchantDef = GAME_DATA.ENCHANTS.find((e) => e.id === enchantId);
              if (!enchantDef) return null;
              return <li key={enchantId}>{`T${toRoman(tier)} ${enchantDef.name} - ${enchantDef.loreNames[tier - 1]}`}</li>;
            })}
          </ul>
        )}
      </>
    );
  };

  return (
    <div className="crafting-modal-body" style={{ flexGrow: 1 }}>
      <div className="crafting-inventory-panel">
        <UnifiedInventoryDisplay
          title="Inventory"
          items={inventoryItems}
          showViewToggle={true}
          viewMode={inventoryState.viewMode}
          onViewModeChange={inventoryState.setViewMode}
          showFilterSearchBar={true}
          showFilterButtonBar={true}
          dynamicFilters={true}
          onItemClick={handleSelectItem}
        />
      </div>

      <div className="crafting-interface-panel">
        <h3>Item Enchanting</h3>
        <div className="crafting-target-slot">{selectedItem ? <ItemIcon item={selectedItem} onClick={() => setSelectedItem(null)} /> : <p>Choose Item to Enchant</p>}</div>
        <div className="crafting-slots-area">
          {selectedItem && (
            <div className="enchanting-item-details">
              <h3>{getItemName(selectedItem, GAME_DATA)}</h3>
              {getEnchantmentsView(selectedItem)}
            </div>
          )}
          {enchantmentDetails && (
            <div className="enchantment-details-area">
              <h3>Enchantment Details</h3>
              <p>
                Selected Tier: <strong style={{ color: '#ffd700' }}>{toRoman(enchantmentDetails.selectedTier)}</strong>
              </p>
              <p>Current Tier: {enchantmentDetails.currentTier > 0 ? `T${toRoman(enchantmentDetails.currentTier)}` : 'None'}</p>

              <hr className="stat-divider" />

              <h3>Requirements</h3>
              <p style={{ color: enchantmentDetails.isHigherTier ? '#ffd700' : '#c99898' }}>• Tier must be higher than current</p>
              <p style={{ color: !enchantmentDetails.enchantTierIsTooHigh ? '#ffd700' : '#c99898' }}>• Enchant tier must not exceed item tier</p>
              <p style={{ color: !enchantmentDetails.maxEnchantsReached ? '#ffd700' : '#c99898' }}>• Item has not reached max enchantments</p>
              <p style={{ color: enchantmentDetails.hasCrystals ? '#ffd700' : '#c99898' }}>
                • {enchantmentDetails.crystalName}: {countItems(player.inventory, enchantmentDetails.crystalId)}/{enchantmentDetails.crystalCost}
              </p>

              <hr className="stat-divider" />

              <h3>Statistics</h3>
              <p>
                DR: {enchantmentDetails.dr} (vs {enchantmentDetails.playerSkill})
              </p>
              <p>
                Success Chance: <strong style={{ color: '#ffd700' }}>{enchantmentDetails.successChance.toFixed(1)}%</strong>
              </p>
              <p style={{ color: '#c99898', fontStyle: 'italic', marginTop: '10px' }}>Failure has a chance to destroy the item or lower its enchantment tier.</p>
            </div>
          )}
        </div>
        <div className="crafting-result-area">
          <button className="btn" onClick={handleEnchant} disabled={!enchantmentDetails?.canEnchant}>
            Enchant
          </button>
        </div>
      </div>

      <div className="crafting-recipes-panel">
        <h3>Available Enchantments</h3>
        <div className="enchanting-grid-container">
          {selectedItem ? (
            availableEnchants.length > 0 ? (
              <div className="enchantment-grid">
                {availableEnchants.map((def) => (
                  <EnchantmentTile
                    key={def.id}
                    player={player}
                    enchantDef={def}
                    selectedItem={selectedItem}
                    onSelectTier={handleSelectTier}
                    selectedEnchantment={selectedEnchantment}
                    itemTier={itemTier}
                    hasMaxEnchants={hasMaxEnchants}
                  />
                ))}
              </div>
            ) : (
              <p>This item cannot be enchanted.</p>
            )
          ) : (
            <p>Select an item from your inventory to begin enchanting.</p>
          )}
        </div>
      </div>
    </div>
  );
};