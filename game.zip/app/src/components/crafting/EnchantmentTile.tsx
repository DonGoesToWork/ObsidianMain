import React from 'react';
import { EnchantDef, ItemId, ItemInstance, Player } from 'types';
import { toRoman } from 'utils/formatUtils';
import { countItems } from 'utils/itemUtils';

interface EnchantmentTileProps {
  player: Player;
  enchantDef: EnchantDef;
  selectedItem: ItemInstance;
  onSelectTier: (enchantId: string, tier: number) => void;
  selectedEnchantment: { enchantId: string; tier: number } | null;
  itemTier: number;
  hasMaxEnchants: boolean;
}

export const EnchantmentTile: React.FC<EnchantmentTileProps> = ({ player, enchantDef, selectedItem, onSelectTier, selectedEnchantment, itemTier, hasMaxEnchants }) => {
  const currentTier = selectedItem.enchantments[enchantDef.id] || 0;
  const isEnchantOnItem = currentTier > 0;

  return (
    <div className="enchantment-tile">
      <div className="enchantment-header">
        <h3>{enchantDef.name}</h3>
        <p className="enchantment-desc">{enchantDef.desc}</p>
      </div>
      <p className="current-enchant-tier">{currentTier > 0 ? `T${currentTier} - ${enchantDef.loreNames[currentTier - 1]}` : 'Not Enchanted'}</p>
      <div className="tier-buttons">
        {Array.from({ length: enchantDef.scaling.length }).map((_, i) => {
          const tier = i + 1;
          const rank = i;
          const isHigherTier = tier > currentTier;
          const isTierTooHigh = tier > itemTier;

          const recipeId = `${enchantDef.id}_t${tier}`;
          const isKnown = !!player.knownEnchantments[recipeId];

          if (!isKnown) {
            return null; // Don't render tiers the player hasn't learned
          }

          const materialCost = enchantDef.cost[rank];
          const crystalId = Object.keys(materialCost)[0] as ItemId;
          const crystalCostCount = materialCost[crystalId];
          const hasCrystals = countItems(player.inventory, crystalId) >= crystalCostCount;

          let statusClass = 'none';
          if (isKnown) {
            if (!isEnchantOnItem && hasMaxEnchants) {
              statusClass = 'none'; // Red
            } else if (isHigherTier && !isTierTooHigh) {
              statusClass = hasCrystals ? 'full' : 'partial';
            }
          }

          const isSelected = selectedEnchantment?.enchantId === enchantDef.id && selectedEnchantment?.tier === tier;

          return (
            <button
              key={i}
              className={`btn ${isSelected ? 'selected' : ''}`}
              onClick={() => onSelectTier(enchantDef.id, tier)}
              title={
                !isKnown
                  ? 'Recipe not known.'
                  : isTierTooHigh
                  ? `Item level too low for Tier ${tier} enchants.`
                  : !isEnchantOnItem && hasMaxEnchants
                  ? 'Item has reached max enchantments.'
                  : ''
              }
            >
              {toRoman(tier)} <span className={`req-indicator ${statusClass}`} />
            </button>
          );
        })}
      </div>
    </div>
  );
};
