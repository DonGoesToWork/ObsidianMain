import { ProfessionId, Recipe, UseCraftingReturn, GameData } from "types";
import React, { useMemo, useContext } from "react";
import { GameDataContext } from "context/GameDataContext";

interface RecipeEntryProps {
  recipe: Recipe;
  onSelect: (recipe: Recipe) => void;
  disabled?: boolean;
  GAME_DATA: GameData;
}

const RecipeEntry: React.FC<RecipeEntryProps> = ({ recipe, onSelect, disabled, GAME_DATA }) => (
  <div className={`recipe-entry ${disabled ? "disabled" : ""}`} onClick={disabled ? undefined : () => onSelect(recipe)}>
    <h4>
      {recipe.name} (Lvl {recipe.levelReq})
    </h4>
    <p>Creates: {GAME_DATA.ITEMS[recipe.creates].name}</p>
    <small>
      Materials:{" "}
      {Object.entries(recipe.materials)
        .map(([mat, count]) => `${GAME_DATA.ITEMS[mat as string].name} x${count}`)
        .join(", ")}
    </small>
  </div>
);

interface CreateRecipeListProps {
  crafting: UseCraftingReturn;
}

export const CreateRecipeList: React.FC<CreateRecipeListProps> = ({ crafting }) => {
  const GAME_DATA = useContext(GameDataContext)!;
  const { recipeProfession, setRecipeProfession, knownRecipes, craftableRecipes, uncraftableRecipes, handleSelectRecipe } = crafting;

  const craftableProfessions = useMemo(() => {
    return (Object.keys(GAME_DATA.RECIPES) as ProfessionId[]).filter(
      (p) => (GAME_DATA.RECIPES as Record<ProfessionId, Recipe[]>)[p]!.length > 0,
    );
  }, [GAME_DATA.RECIPES]);

  return (
    <div className="crafting-recipes-panel">
      <h4>Known Recipes</h4>
      <div className="recipe-list-container">
        <div className="tabs">
          {craftableProfessions.map((prof) => (
            <button
              key={prof}
              className={`tab-btn ${recipeProfession === prof ? "active" : ""}`}
              onClick={() => setRecipeProfession(prof)}
            >
              {prof.charAt(0).toUpperCase() + prof.slice(1)}
            </button>
          ))}
        </div>
        <div className="recipe-list">
          {knownRecipes.length === 0 ? (
            <p>You have not learned any recipes for this profession.</p>
          ) : (
            <>
              {craftableRecipes.map((recipe: Recipe) => (
                <RecipeEntry key={recipe.id} recipe={recipe} onSelect={handleSelectRecipe} GAME_DATA={GAME_DATA} />
              ))}
              {craftableRecipes.length > 0 && uncraftableRecipes.length > 0 && <hr className="divider" />}
              {uncraftableRecipes.map((recipe: Recipe) => (
                <RecipeEntry key={recipe.id} recipe={recipe} onSelect={handleSelectRecipe} disabled={true} GAME_DATA={GAME_DATA} />
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  );
};