import { ColumnDef, UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import React, { useContext, useMemo, useState } from 'react';
import { calculateEnchantSuccessChance, getRequirementStatus, getUpgradeChecks } from 'utils/craftingUtils';
import { calculateItemLevel, calculateItemTier, calculateItemValue, getItemName } from 'utils/itemUtils';
import { ItemInstance } from '../../types';

import { GameDataContext } from 'context/GameDataContext';
import { LogContext } from 'context/LogContext';
import { PlayerContext } from 'context/PlayerContext';
import { WorldContext } from 'context/WorldContext';
import { useModalState } from 'hooks/useModalState';
import { ProfessionsContext } from '../../context/ProfessionsContext';
import { ItemIcon } from '../shared/ItemIcon';

const getUpgradeListColumns = (GAME_DATA: any): ColumnDef[] => [
  {
    key: 'name',
    label: 'Name',
    render: (item, g) => `${getItemName(item, GAME_DATA)}`,
    className: 'shop-item-name',
    isSortable: true,
  },
  {
    key: 'itemLevel',
    label: 'Lvl',
    render: (item) => GAME_DATA.ITEMS[item.id].itemLevel,
    className: 'shop-item-level',
    isSortable: true,
  },
  {
    key: 'value',
    label: 'Value',
    render: (item) => `${calculateItemValue({ ...item, quantity: 1 }, GAME_DATA)}g`,
    className: 'shop-item-value',
    isSortable: true,
  },
];

export const UpgradePanel: React.FC = () => {
  const { player } = useContext(PlayerContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { upgradeItem } = useContext(ProfessionsContext)!;
  const { logMessage } = useContext(LogContext)!;
  const { isActionLocked } = useContext(WorldContext)!;
  const inventoryState = useModalState('crafting', 'upgrade_inventory');
  const [targetItem, setTargetItem] = useState<ItemInstance | null>(null);

  const upgradeListColumns = useMemo(() => getUpgradeListColumns(GAME_DATA), [GAME_DATA]);

  const upgradeableItems = useMemo(() => {
    if (!player) return [];
    const items = [...player.inventory, ...Object.values(player.equipment).filter((i): i is ItemInstance => !!i)];

    return items
      .filter((item: ItemInstance) => {
        const data = GAME_DATA.ITEMS[item.id];
        const itemLevel = calculateItemLevel(item, GAME_DATA);
        const itemTier = calculateItemTier(itemLevel);
        const currentPlus = item.plus_value || 0;
        return (
          !item.isUnmodifiable &&
          !data.isUnmodifiable &&
          data.type.includes('equipment') &&
          !data.isUnarmed &&
          currentPlus < itemTier &&
          !item.isUnidentified
        );
      })
      .flatMap((item) => {
        if (item.quantity > 1) {
          return Array.from({ length: item.quantity }, (_, i) => ({
            ...item,
            quantity: 1,
            unique_id: `${item.unique_id}_clone_${i}`,
          }));
        }
        return item;
      })
      .map((item) => {
        const requirementChecks = getUpgradeChecks(player, item, GAME_DATA);
        delete (requirementChecks as any).recipeKnown;
        const requirementStatus = getRequirementStatus(requirementChecks);
        return { ...item, requirementStatus };
      });
  }, [player, GAME_DATA]);

  const requirements = useMemo(() => {
    if (!player || !targetItem) return null;
    const checks = getUpgradeChecks(player, targetItem, GAME_DATA);
    delete (checks as any).recipeKnown;
    return checks;
  }, [player, targetItem, GAME_DATA]);

  const successDetails = useMemo(() => {
    if (!player || !targetItem) return null;
    const currentPlus = targetItem.plus_value || 0;
    const itemLevel = calculateItemLevel(targetItem, GAME_DATA);
    const itemTier = calculateItemTier(itemLevel);
    const baseDr = (itemTier - 1) * 10 + 5;
    const finalDr = baseDr + Math.max(0, currentPlus);
    const successChance = calculateEnchantSuccessChance(player.professions.smithing.level, finalDr);
    return {
      dr: finalDr,
      chance: successChance,
    };
  }, [player, targetItem, GAME_DATA]);

  const canUpgrade = requirements && Object.values(requirements).every((r) => r.ok);

  const handleUpgrade = () => {
    if (!targetItem || !canUpgrade) {
      logMessage('Cannot upgrade item.', 'error');
      return;
    }
    upgradeItem(targetItem);
    setTargetItem(null);
  };

  const handleSelectUpgradeable = (e: React.MouseEvent, item: ItemInstance) => {
    const data = GAME_DATA.ITEMS[item.id];
    if (item.isUnmodifiable || data.isUnmodifiable) {
      logMessage('This item cannot be modified.', 'error');
      return;
    }

    const originalUniqueId = item.unique_id.includes('_clone_') ? item.unique_id.split('_clone_')[0] : item.unique_id;

    const realItemFromInventory = player?.inventory.find((i) => i.unique_id === originalUniqueId);
    const realItemFromEquipment = Object.values(player?.equipment || {}).find((i) => i?.unique_id === originalUniqueId);
    const realItem = realItemFromInventory || realItemFromEquipment;

    if (!realItem) {
      logMessage('Original item not found for upgrading.', 'error');
      console.error('Could not find item with original unique id:', originalUniqueId, 'from item:', item);
      return;
    }

    setTargetItem({ ...realItem, quantity: 1 });
  };

  if (!player) return null;

  return (
    <div className="crafting-modal-body" style={{ flexGrow: 1 }}>
      <div className="crafting-inventory-panel">
        <UnifiedInventoryDisplay
          title="Inventory"
          items={player.inventory.filter((i) => !i.isUnidentified)}
          onItemClick={handleSelectUpgradeable}
          viewMode={inventoryState.viewMode}
          onViewModeChange={inventoryState.setViewMode}
          showViewToggle={true}
          showFilterSearchBar={true}
          showFilterButtonBar={true}
          dynamicFilters={true}
          disablePrimaryItemActions={true}
        />
      </div>
      <div className="crafting-interface-panel">
        <h3>Item Upgrade</h3>
        <div className="crafting-target-slot">{targetItem ? <ItemIcon item={targetItem} onClick={() => setTargetItem(null)} /> : <p>Choose Item to Upgrade</p>}</div>
        <div className="crafting-slots-area">
          {targetItem && requirements && (
            <div className="crafting-requirements-list">
              {requirements.upgradeable?.ok === false ? (
                <p>
                  <strong>{`${getItemName(targetItem, GAME_DATA)} is Already Maxed`}</strong>
                </p>
              ) : (
                successDetails && (
                  <>
                    <p>
                      Upgrade: <strong>{getItemName({ ...targetItem, plus_value: (targetItem.plus_value || 0) + 1 }, GAME_DATA)}</strong>
                    </p>
                    <hr className="stat-divider" />
                    <h3>Requirements:</h3>
                    {Object.values(requirements).map((c) => {
                      if (c.provided !== undefined && c.required !== undefined) {
                        return (
                          <p key={c.text} className={c.ok ? 'req-ok' : 'req-fail'}>
                            {c.text}: {c.provided}/{c.required}
                          </p>
                        );
                      }
                      return (
                        <p key={c.text} className={c.ok ? 'req-ok' : 'req-fail'}>
                          {c.text}
                        </p>
                      );
                    })}
                    <hr className="stat-divider" />
                    <p>
                      DR: {successDetails.dr} (vs {player.professions.smithing.level})
                    </p>
                    <p>
                      Success Chance: <strong style={{ color: '#87ceeb' }}>{successDetails.chance.toFixed(1)}%</strong>
                    </p>
                    <p
                      style={{
                        color: '#ff6b6b',
                        fontWeight: 'bold',
                        marginTop: '10px',
                      }}
                    >
                      Failure will destroy the item.
                    </p>
                  </>
                )
              )}
            </div>
          )}
        </div>
        <div className="crafting-result-area">
          {targetItem && (
            <button className="btn" onClick={handleUpgrade} disabled={!canUpgrade || isActionLocked}>
              Attempt Upgrade
            </button>
          )}
        </div>
      </div>
      <div className="crafting-recipes-panel">
        <UnifiedInventoryDisplay
          title="Upgradeable Items"
          items={upgradeableItems}
          onItemClick={handleSelectUpgradeable}
          viewMode={'detailed'}
          showViewToggle={false}
          showSortButtons={true}
          columns={upgradeListColumns}
          showFilterSearchBar={true}
          showFilterButtonBar={false}
          dynamicFilters={true}
          defaultSort={{ key: 'requirementStatus', direction: 'asc' }}
          disablePrimaryItemActions={true}
        />
      </div>
    </div>
  );
};