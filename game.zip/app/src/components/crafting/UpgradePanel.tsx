import { ITEM_QUALITY_ORDER, calculateItemLevel, countItems, getQualityGrade, getItemName } from 'utils/itemUtils';
import { ItemId, ItemInstance, GameData } from '../../types';
import React, { useContext, useMemo, useState } from 'react';

import { ItemIcon } from '../shared/ItemIcon';
import { UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import { calculateUpgradeSuccessChance } from 'utils/craftingUtils';
import { PlayerContext } from 'context/PlayerContext';
import { LogContext } from 'context/LogContext';
import { ProfessionsContext } from '../../context/ProfessionsContext';
import { useModalState } from 'hooks/useModalState';
import { GameDataContext } from 'context/GameDataContext';

export const UpgradePanel: React.FC = () => {
  const { player } = useContext(PlayerContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { upgradeItem } = useContext(ProfessionsContext)!;
  const { logMessage } = useContext(LogContext)!;
  const { viewMode, setViewMode } = useModalState('crafting', 'upgrade');
  const [targetItem, setTargetItem] = useState<ItemInstance | null>(null);

  const inventoryItems = useMemo(() => {
    if (!player) return [];
    return player.inventory.concat(Object.values(player.equipment).filter((i): i is ItemInstance => !!i)).filter((item: ItemInstance) => {
      const data = GAME_DATA.ITEMS[item.id];
      const quality = item.quality || 'Average';
      return data.type.includes('equipment') && data.recipeId && quality !== 'One-of-a-kind' && item !== targetItem && !item.isUnidentified;
    });
  }, [player, targetItem, GAME_DATA.ITEMS]);

  const requirements = useMemo(() => {
    if (!player || !targetItem) return null;
    const itemData = GAME_DATA.ITEMS[targetItem.id];
    const grade = getQualityGrade(targetItem.quality);

    if (grade >= ITEM_QUALITY_ORDER.length - 1) return null;

    const itemLevel = calculateItemLevel(targetItem, GAME_DATA);
    const requiredTier = Math.min(11, Math.max(1, Math.floor(itemLevel / 10) + 1));
    const emberId = `mat_reforge_ember_t${requiredTier}` as ItemId;
    const emberData = GAME_DATA.ITEMS[emberId];
    if (!emberData) {
      console.error(`Could not find reforging ember data for ID: ${emberId}`);
      return null;
    }

    const materialCost = grade + 1;
    const goldCost = itemData.value * (grade + 1) * 5;
    const hasMaterials = countItems(player.inventory, emberId) >= materialCost;
    const hasGold = player.gold >= goldCost;
    const knowsRecipe = !!player.knownRecipes[itemData.recipeId!];

    const successChance = calculateUpgradeSuccessChance(grade, player.professions.smithing.level);

    return {
      materialCost,
      goldCost,
      hasMaterials,
      hasGold,
      knowsRecipe,
      successChance,
      emberName: emberData.name,
    };
  }, [player, targetItem, GAME_DATA]);

  const canUpgrade = requirements && requirements.hasMaterials && requirements.hasGold && requirements.knowsRecipe;

  const handleUpgrade = () => {
    if (!targetItem || !canUpgrade) {
      logMessage('Cannot upgrade item.', 'error');
      return;
    }
    upgradeItem(targetItem);
    setTargetItem(null);
  };

  if (!player) return null;

  return (
    <div className="crafting-modal-body" style={{ flexGrow: 1 }}>
      <div className="crafting-interface-panel">
        <div className="crafting-inventory-panel">
          <UnifiedInventoryDisplay
            title="Your Items"
            items={inventoryItems}
            onItemClick={(_e, item) => setTargetItem(item)}
            viewMode={viewMode}
            onViewModeChange={setViewMode}
            showViewToggle={true}
          />
        </div>
      </div>
      <div className="crafting-recipes-panel">
        <h4>Item Upgrade</h4>
        <div className="repair-panel-target-slot" style={{ marginBottom: '10px' }}>
          {targetItem ? <ItemIcon item={targetItem} onClick={() => setTargetItem(null)} /> : <p>Select Item to Upgrade</p>}
        </div>
        {targetItem && requirements && (
          <div className="crafting-requirements-list">
            <p>
              Next Quality: <strong>{ITEM_QUALITY_ORDER[getQualityGrade(targetItem.quality) + 1]}</strong>
            </p>
            <hr className="stat-divider" />
            <h5>Requirements:</h5>
            <p className={requirements.knowsRecipe ? 'req-ok' : 'req-fail'}>Knows original recipe: {requirements.knowsRecipe ? '✔' : '❌'}</p>
            <p className={requirements.hasGold ? 'req-ok' : 'req-fail'}>
              Gold: {requirements.goldCost} {requirements.hasGold ? '✔' : '❌'}
            </p>
            <p className={requirements.hasMaterials ? 'req-ok' : 'req-fail'}>
              {requirements.emberName}: {requirements.materialCost} {requirements.hasMaterials ? '✔' : '❌'}
            </p>
            <hr className="stat-divider" />
            <p>
              Success Chance: <strong style={{ color: '#87ceeb' }}>{requirements.successChance.toFixed(1)}%</strong>
            </p>
            <p
              style={{
                color: '#ff6b6b',
                fontWeight: 'bold',
                marginTop: '10px',
              }}
            >
              Failure will destroy the item.
            </p>
            <div className="crafting-result-area">
              <button className="btn" onClick={handleUpgrade} disabled={!canUpgrade}>
                Attempt Upgrade
              </button>
            </div>
          </div>
        )}
        {targetItem && !requirements && <p>This item cannot be upgraded further.</p>}
      </div>
    </div>
  );
};