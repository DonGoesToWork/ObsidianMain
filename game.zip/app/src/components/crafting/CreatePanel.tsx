import { ColumnDef, UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import { ItemInstance, ProfessionId, Recipe, RecipeId, RequirementStatus } from 'types';
import React, { useContext, useMemo, useState } from 'react';
import { getCraftingChecks, getRequirementStatus } from 'utils/craftingUtils';
import { getFullItemName } from 'utils/itemUtils';
import { CreateInterface } from './CreateInterface';
import { GameDataContext } from 'context/GameDataContext';
import { RecipeTooltip } from 'components/shared/RecipeTooltip';
import { WorldContext } from 'context/WorldContext';
import { useCrafting } from 'hooks/useCrafting';
import { useModalState } from 'hooks/useModalState';
import { usePlayer } from 'hooks/usePlayer';

interface RecipeDisplayItem extends ItemInstance {
  isHeader?: boolean;
  recipe: Recipe;
  levelReq: number;
  requirementStatus: RequirementStatus;
  filterKey: string;
}

const getCreateListColumns = (GAME_DATA: any): ColumnDef[] => [
  {
    key: 'name',
    label: 'Recipe Name',
    render: (item: ItemInstance) => {
      const displayItem = item as RecipeDisplayItem;
      if (displayItem.isHeader) {
        return <h3 className="inventory-list-header">{displayItem.name}</h3>;
      }
      return (
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div className={`req-indicator ${displayItem.requirementStatus}`}></div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <span>{getFullItemName(displayItem, GAME_DATA)}</span>
          </div>
        </div>
      );
    },
    className: 'shop-item-name',
    isSortable: true,
  },
  {
    key: 'itemLevel',
    label: 'Level',
    render: (item) => GAME_DATA.ITEMS[item.id].itemLevel,
    className: 'shop-item-level',
    isSortable: true,
  },
];

export const CreatePanel: React.FC = () => {
  const crafting = useCrafting();
  const { recipeProfession, setRecipeProfession, handleSelectRecipe } = crafting;
  const player = usePlayer();
  const GAME_DATA = useContext(GameDataContext)!;
  const { currentLocation } = useContext(WorldContext)!;
  const inventoryState = useModalState('crafting', 'create_inventory');
  const recipeListColumns = useMemo(() => getCreateListColumns(GAME_DATA), [GAME_DATA]);

  const [hoveredRecipe, setHoveredRecipe] = useState<{ recipe: Recipe; anchorEl: HTMLElement } | null>(null);

  const craftableProfessions = useMemo(() => {
    if (!player) return [];
    const professions = new Set<ProfessionId>();
    Object.keys(player.knownRecipes).forEach((recipeId) => {
      const recipe = GAME_DATA.ALL_RECIPES[recipeId as RecipeId];
      if (recipe) {
        professions.add(recipe.profession);
      }
    });
    return Array.from(professions).sort();
  }, [GAME_DATA.ALL_RECIPES, player]);

  const recipeListItems = useMemo(() => {
    if (!player) return [];

    return crafting.knownRecipes.map((recipe: Recipe): RecipeDisplayItem => {
      const checks = getCraftingChecks(player, recipe, [], currentLocation, true, GAME_DATA, { checkInventoryForTools: true });
      const requirementStatus = getRequirementStatus(checks);

      const createdItemData = GAME_DATA.ITEMS[recipe.creates];
      const primaryType = createdItemData.type[0];

      // If it's a material recipe, use 'material' as the category key.
      const filterKey = primaryType === 'material' ? 'material' : primaryType;

      return {
        id: recipe.creates,
        unique_id: recipe.id,
        name: recipe.name,
        enchantments: {},
        recipe: recipe,
        levelReq: recipe.levelReq,
        requirementStatus: requirementStatus,
        filterKey: filterKey,
        plus_value: 0,
      };
    });
  }, [crafting.knownRecipes, player, currentLocation, GAME_DATA]);

  const handleTransfer = (_: ItemInstance, quantity: number, indices: number[]) => {
    if (!crafting.player || !crafting.playerInventoryForDisplay) return;
    const itemsToAdd = indices.slice(0, quantity).map((idx) => crafting.playerInventoryForDisplay[idx]);
    crafting.handleAddItemToCraft(itemsToAdd);
  };

  const handleRecipeSelect = (e: React.MouseEvent, item: ItemInstance) => {
    const displayItem = item as RecipeDisplayItem;
    if (displayItem.isHeader) return;
    if (displayItem.recipe && displayItem.requirementStatus === 'full') {
      handleSelectRecipe(displayItem.recipe);
    }
  };

  const handleRowEnter = (e: React.MouseEvent, item: ItemInstance) => {
    const displayItem = item as RecipeDisplayItem;
    if (displayItem.recipe) {
      setHoveredRecipe({ recipe: displayItem.recipe, anchorEl: e.currentTarget as HTMLElement });
    }
  };

  const handleRowLeave = () => {
    setHoveredRecipe(null);
  };

  if (!player) return null;

  return (
    <div className="crafting-modal-body" style={{ flexGrow: 1 }}>
      <div className="crafting-inventory-panel">
        <UnifiedInventoryDisplay
          title="Inventory"
          items={crafting.playerInventoryForDisplay}
          onTransfer={handleTransfer}
          transferButtonText="Add"
          viewMode={inventoryState.viewMode}
          onViewModeChange={inventoryState.setViewMode}
          showViewToggle={true}
          showFilterSearchBar={true}
          showFilterButtonBar={true}
          dynamicFilters={true}
          showTransferControls
          transferAmount={inventoryState.transferAmount}
          onTransferAmountChange={inventoryState.setTransferAmount}
        />
      </div>

      <CreateInterface crafting={crafting} transferAmount={inventoryState.transferAmount} />

      <div className="crafting-recipes-panel">
        <div className="tabs">
          {craftableProfessions.map((prof) => (
            <button key={prof} className={`tab-btn ${recipeProfession === prof ? 'active' : ''}`} onClick={() => setRecipeProfession(prof)}>
              {prof.charAt(0).toUpperCase() + prof.slice(1)}
            </button>
          ))}
        </div>
        <UnifiedInventoryDisplay
          title="Known Recipes"
          items={recipeListItems}
          onItemClick={handleRecipeSelect}
          viewMode={'detailed'}
          showViewToggle={false}
          showSortButtons={false}
          columns={recipeListColumns}
          showFilterSearchBar={true}
          showFilterButtonBar={true}
          dynamicFilters={true}
          defaultSort={{ key: 'requirementStatus', direction: 'asc' }}
          onRowMouseEnter={handleRowEnter}
          onRowMouseLeave={handleRowLeave}
        />
        {hoveredRecipe && <RecipeTooltip recipe={hoveredRecipe.recipe} anchorEl={hoveredRecipe.anchorEl} />}
      </div>
    </div>
  );
};