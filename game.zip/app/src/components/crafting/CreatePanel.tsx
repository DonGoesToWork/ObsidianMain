import { CreateInterface } from "./CreateInterface";
import { CreateRecipeList } from "./CreateRecipeList";
import React from "react";
import { UnifiedInventoryDisplay } from "components/shared/UnifiedInventoryDisplay";
import { useCrafting } from "hooks/useCrafting";
import { useModalState } from "hooks/useModalState";

export const CreatePanel: React.FC = () => {
  const crafting = useCrafting();
  const { viewMode, setViewMode, transferAmount, setTransferAmount } = useModalState("crafting", "create");

  if (!crafting.player) return null;

  return (
    <div className="crafting-modal-body" style={{ flexGrow: 1 }}>
      <div className="crafting-inventory-panel">
        <UnifiedInventoryDisplay
          title="Your Inventory"
          items={crafting.playerInventoryForDisplay}
          onTransfer={(_, quantity, indices) => {
            const itemsToAdd = indices
              .slice(0, quantity)
              .map((idx) => crafting.player!.inventory[crafting.playerInventoryMap[idx]]);
            crafting.handleAddItemToCraft(itemsToAdd);
          }}
          transferButtonText="Add"
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          showViewToggle
          showTransferControls
          transferAmount={transferAmount}
          onTransferAmountChange={setTransferAmount}
        />
      </div>

      <CreateInterface crafting={crafting} transferAmount={transferAmount} />

      <CreateRecipeList crafting={crafting} />
    </div>
  );
};