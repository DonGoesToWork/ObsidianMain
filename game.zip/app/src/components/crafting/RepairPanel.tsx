import { ItemInstance, Recipe, GameData } from "../../types";
import React, { useContext, useMemo, useState } from "react";

import { ItemIcon } from "../shared/ItemIcon";
import { UnifiedInventoryDisplay } from "components/shared/UnifiedInventoryDisplay";
import { getCraftingChecks } from "utils/craftingUtils";
import { groupItems } from "utils/itemUtils";
import { PlayerContext } from "context/PlayerContext";
import { WorldContext } from "context/WorldContext";
import { LogContext } from "context/LogContext";
import { ProfessionsContext } from "../../context/ProfessionsContext";
import { useModalState } from "hooks/useModalState";
import { GameDataContext } from "context/GameDataContext";

const MAX_REPAIR_MATERIALS = 10;
const MAX_TOOLS = 4;

export const RepairPanel: React.FC = () => {
  const { player } = useContext(PlayerContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { repairItem } = useContext(ProfessionsContext)!;
  const { currentLocation } = useContext(WorldContext)!;
  const { logMessage } = useContext(LogContext)!;
  const { viewMode, setViewMode, transferAmount, setTransferAmount } = useModalState("crafting", "repair");

  const [targetItem, setTargetItem] = useState<ItemInstance | null>(null);
  const [materials, setMaterials] = useState<ItemInstance[]>([]);
  const [tools, setTools] = useState<ItemInstance[]>([]);

  const availableItems = useMemo(() => {
    if (!player) return [];
    const itemsInPanel = new Set([targetItem, ...materials, ...tools].filter(Boolean));
    return player.inventory
      .concat(Object.values(player.equipment).filter(Boolean) as ItemInstance[])
      .filter((item: ItemInstance) => {
        const data = GAME_DATA.ITEMS[item.id];
        const isEquip = data.type.includes("equipment");
        const isDamaged =
          item.currentDurability !== undefined && item.maxDurability !== undefined && item.currentDurability < item.maxDurability;
        return isEquip && isDamaged && !item.isUnrepairable && !itemsInPanel.has(item) && !item.isUnidentified;
      });
  }, [player, targetItem, materials, tools, GAME_DATA.ITEMS]);

  const groupedMaterials = groupItems(materials, GAME_DATA);

  const recipe: Recipe | null = useMemo(() => {
    if (!targetItem) return null;
    const itemData = GAME_DATA.ITEMS[targetItem.id];
    return itemData.recipeId ? GAME_DATA.ALL_RECIPES[itemData.recipeId] : null;
  }, [targetItem, GAME_DATA]);

  const handleAddItem = (_item: ItemInstance, quantity: number, originalIndices: number[]) => {
    const itemsToAdd = originalIndices.slice(0, quantity).map((i) => availableItems[i]);
    if (itemsToAdd.length === 0) return;

    if (!targetItem) {
      setTargetItem(itemsToAdd[0]);
      return;
    }

    const newTools = [...tools];
    const newMaterials = [...materials];

    itemsToAdd.forEach((itemToAdd) => {
      const data = GAME_DATA.ITEMS[itemToAdd.id];
      const isTool = data.type.includes("tool");
      if (isTool) {
        if (newTools.length < MAX_TOOLS) newTools.push(itemToAdd);
      } else {
        if (newMaterials.length < MAX_REPAIR_MATERIALS) newMaterials.push(itemToAdd);
      }
    });

    if (newTools.length > MAX_TOOLS) logMessage("Tool slots are full.", "error");
    if (newMaterials.length > MAX_REPAIR_MATERIALS) logMessage("Material slots are full.", "error");

    setTools(newTools.slice(0, MAX_TOOLS));
    setMaterials(newMaterials.slice(0, MAX_REPAIR_MATERIALS));
  };

  const requirementChecks = useMemo(() => {
    if (!player || !recipe) return {};
    return getCraftingChecks(player, recipe, tools, currentLocation, true, GAME_DATA);
  }, [player, recipe, tools, currentLocation, GAME_DATA]);

  const canRepair = useMemo(() => {
    if (!targetItem || materials.length === 0) return false;
    return Object.values(requirementChecks).every((c) => c.ok);
  }, [targetItem, materials, requirementChecks]);

  const handleRepair = () => {
    if (!targetItem) return;
    repairItem(targetItem, materials, tools);
    setTargetItem(null);
    setMaterials([]);
    setTools([]);
  };

  if (!player) return null;

  return (
    <div className="crafting-modal-body" style={{ flexGrow: 1 }}>
      <div className="crafting-interface-panel">
        <div className="crafting-inventory-panel">
          <UnifiedInventoryDisplay
            title="Your Items"
            items={availableItems}
            onTransfer={handleAddItem}
            transferButtonText="Add"
            viewMode={viewMode}
            onViewModeChange={setViewMode}
            showViewToggle={true}
            showTransferControls={true}
            transferAmount={transferAmount}
            onTransferAmountChange={setTransferAmount}
          />
        </div>
        <div className="crafting-interface-main">
          <div className="repair-panel-target-slot">
            {targetItem ? <ItemIcon item={targetItem} onClick={() => setTargetItem(null)} /> : <p>Add Item to Repair Here</p>}
          </div>
          <div className="crafting-slots-area">
            <h5>
              Tools ({tools.length}/{MAX_TOOLS})
            </h5>
            <div className="crafting-slots-grid">
              {tools.map((item, i) => (
                <ItemIcon key={i} item={item} onClick={() => setTools((p) => p.filter((_, idx) => idx !== i))} />
              ))}
            </div>
            <h5 style={{ marginTop: "10px" }}>
              Repair Materials ({materials.length}/{MAX_REPAIR_MATERIALS})
            </h5>
            <div className="crafting-slots-grid">
              {Object.values(groupedMaterials).map(({ item, count }, i) => (
                <ItemIcon key={`${i}-${count}`} item={item} count={count} onClick={() => setMaterials((p) => p.filter((m) => m !== item))} />
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="crafting-recipes-panel">
        <h4>Repair Details</h4>
        {recipe && targetItem && (
          <>
            <h5>Requirements for {recipe.name}</h5>
            <div className="crafting-requirements-list" style={{ marginTop: "10px" }}>
              {Object.values(requirementChecks).map((c) => (
                <p key={c.text} className={c.ok ? "req-ok" : "req-fail"}>
                  {c.text}
                </p>
              ))}
            </div>

            <div className="crafting-result-area">
              <button className="btn" onClick={handleRepair} disabled={!canRepair}>
                Attempt Repair
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};