import { ColumnDef, UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import { ItemInstance, PlayerEquipmentSlot, Recipe, RequirementStatus } from 'types';
import React, { useContext, useEffect, useMemo, useState } from 'react';
import { calculateItemValue, getItemName, groupItems } from 'utils/itemUtils';
import { calculateRepairSuccessChance, getRepairChecks, getRequirementStatus } from 'utils/craftingUtils';

import { GameDataContext } from 'context/GameDataContext';
import { GroupedItem } from 'utils/itemUtils';
import { ItemIcon } from '../shared/ItemIcon';
import { LogContext } from 'context/LogContext';
import { PlayerContext } from 'context/PlayerContext';
import { ProfessionsContext } from '../../context/ProfessionsContext';
import { WorldContext } from 'context/WorldContext';
import { useModalState } from 'hooks/useModalState';

const MAX_REPAIR_MATERIALS = 10;
const MAX_TOOLS = 4;

const getRepairListColumns = (GAME_DATA: any): ColumnDef[] => [
  {
    key: 'name',
    label: 'Name',
    render: (item: any) => (
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <div className={`req-indicator ${item.requirementStatus}`}></div>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <span>{getItemName(item, GAME_DATA)}</span>
          <small style={{ color: '#aaa' }}>
            Durability: {item.currentDurability?.toFixed(0)} / {item.maxDurability}
          </small>
        </div>
      </div>
    ),
    className: 'shop-item-name',
    isSortable: true,
  },
  {
    key: 'itemLevel',
    label: 'Lvl',
    render: (item) => GAME_DATA.ITEMS[item.id].itemLevel,
    className: 'shop-item-level',
    isSortable: true,
  },
  {
    key: 'value',
    label: 'Value',
    render: (item) => `${calculateItemValue(item, GAME_DATA)}g`,
    className: 'shop-item-value',
    isSortable: true,
  },
];

export const RepairPanel: React.FC = () => {
  const { player } = useContext(PlayerContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { repairItem, repairAllItems } = useContext(ProfessionsContext)!;
  const { currentLocation } = useContext(WorldContext)!;
  const { logMessage } = useContext(LogContext)!;
  const inventoryState = useModalState('crafting', 'repair_inventory');
  const repairListColumns = useMemo(() => getRepairListColumns(GAME_DATA), [GAME_DATA]);

  const [targetItem, setTargetItem] = useState<ItemInstance | null>(null);
  const [materials, setMaterials] = useState<ItemInstance[]>([]);
  const [tools, setTools] = useState<ItemInstance[]>([]);

  useEffect(() => {
    if (targetItem && player) {
      const itemUniqueId = targetItem.unique_id;
      let updatedItem: ItemInstance | null = null;

      updatedItem = player.inventory.find((item) => item.unique_id === itemUniqueId) || null;

      if (!updatedItem) {
        for (const slot in player.equipment) {
          const equippedItem = player.equipment[slot as PlayerEquipmentSlot];
          if (equippedItem?.unique_id === itemUniqueId) {
            updatedItem = equippedItem;
            break;
          }
        }
      }

      if (updatedItem) {
        const isDamaged = updatedItem.currentDurability !== undefined && updatedItem.maxDurability !== undefined && updatedItem.currentDurability < updatedItem.maxDurability;
        if (!isDamaged) {
          setTargetItem(null);
          setMaterials([]);
          setTools([]);
        } else {
          if (JSON.stringify(updatedItem) !== JSON.stringify(targetItem)) {
            setTargetItem(updatedItem);
          }
        }
      } else {
        setTargetItem(null);
        setMaterials([]);
        setTools([]);
      }
    }
  }, [player, targetItem]);

  const availableItemsForGrid = useMemo(() => {
    if (!player) return [];
    const itemsInPanel = new Set([targetItem, ...materials, ...tools].filter(Boolean));
    return player.inventory.filter((item) => !itemsInPanel.has(item) && !item.isUnidentified);
  }, [player, targetItem, materials, tools]);

  const repairableItems = useMemo(() => {
    if (!player) return [];
    const items = [...player.inventory, ...Object.values(player.equipment).filter((i): i is ItemInstance => !!i)];

    const augmentedItems = items
      .filter((item: ItemInstance) => {
        if (!item?.id || !GAME_DATA.ITEMS[item.id]) {
          if (item) console.warn('Item data not found in GAME_DATA for repairableItems:', item.id);
          return false;
        }
        const data = GAME_DATA.ITEMS[item.id];
        return (
          data.type.includes('equipment') &&
          item.currentDurability !== undefined &&
          item.maxDurability !== undefined &&
          item.currentDurability < item.maxDurability &&
          !item.isUnrepairable &&
          !item.isUnidentified &&
          data.recipeId &&
          player.knownRecipes[data.recipeId]
        );
      })
      .map((item) => {
        const itemData = GAME_DATA.ITEMS[item.id];
        const recipe = itemData.recipeId ? GAME_DATA.ALL_RECIPES[itemData.recipeId] : null;
        const checks = getRepairChecks(player, recipe, player.inventory, player.inventory, currentLocation, GAME_DATA, true);
        const requirementStatus = getRequirementStatus(checks);
        return { ...item, requirementStatus };
      });

    const statusOrder: Record<RequirementStatus, number> = { full: 0, partial: 1, none: 2 };
    augmentedItems.sort((a, b) => {
      const statusDiff = statusOrder[a.requirementStatus] - statusOrder[b.requirementStatus];
      if (statusDiff !== 0) return statusDiff;
      const levelA = a.levelReq ?? GAME_DATA.ITEMS[a.id].itemLevel;
      const levelB = b.levelReq ?? GAME_DATA.ITEMS[b.id].itemLevel;
      return levelA - levelB;
    });
    return augmentedItems;
  }, [player, GAME_DATA, currentLocation]);

  const groupedMaterials = useMemo(() => groupItems(materials, GAME_DATA), [materials, GAME_DATA]);

  const recipe: Recipe | null = useMemo(() => {
    if (!targetItem) return null;
    const itemData = GAME_DATA.ITEMS[targetItem.id];
    return itemData.recipeId ? GAME_DATA.ALL_RECIPES[itemData.recipeId] : null;
  }, [targetItem, GAME_DATA]);

  const handleAddItem = (_: ItemInstance, quantity: number, originalIndices: number[]) => {
    const itemsToAdd = originalIndices.slice(0, quantity).map((i) => availableItemsForGrid[i]);
    if (itemsToAdd.length === 0) return;

    const newTools = [...tools];
    const newMaterials = [...materials];

    itemsToAdd.forEach((itemToAdd) => {
      const data = GAME_DATA.ITEMS[itemToAdd.id];
      const isTool = data.type.includes('tool');
      if (isTool) {
        if (newTools.length < MAX_TOOLS) newTools.push(itemToAdd);
      } else {
        if (newMaterials.length < MAX_REPAIR_MATERIALS) newMaterials.push(itemToAdd);
      }
    });

    if (newTools.length > MAX_TOOLS) logMessage('Tool slots are full.', 'error');
    if (newMaterials.length > MAX_REPAIR_MATERIALS) logMessage('Material slots are full.', 'error');

    setTools(newTools.slice(0, MAX_TOOLS));
    setMaterials(newMaterials.slice(0, MAX_REPAIR_MATERIALS));
  };

  const requirementChecks = useMemo(() => {
    if (!player || !recipe) return {};
    const checks = getRepairChecks(player, recipe, materials, tools, currentLocation, GAME_DATA, false);
    const playerSkill = player.professions[recipe.profession].level;
    const successChance = calculateRepairSuccessChance(playerSkill, recipe.levelReq);
    checks.dr = { ok: true, text: `DR: ${recipe.levelReq} (vs ${playerSkill})` };
    checks.success = { ok: true, text: `Success: ${successChance.toFixed(1)}%` };
    return checks;
  }, [player, recipe, materials, tools, currentLocation, GAME_DATA]);

  const canRepair = useMemo(() => {
    if (!targetItem || materials.length === 0) return false;
    return Object.values(requirementChecks).every((c) => c.ok);
  }, [targetItem, materials, requirementChecks]);

  const handleRepair = () => {
    if (!targetItem) return;
    repairItem(targetItem, materials, tools);
    setTargetItem(null);
    setMaterials([]);
    setTools([]);
  };

  const handleSelectRepairable = (e: React.MouseEvent, item: ItemInstance) => {
    setTargetItem(item);

    const itemData = GAME_DATA.ITEMS[item.id];
    const itemRecipe = itemData.recipeId ? GAME_DATA.ALL_RECIPES[itemData.recipeId] : null;

    if (!player || !itemRecipe) {
      setMaterials([]);
      setTools([]);
      return;
    }

    const inventoryPool = player.inventory.filter((i) => i.unique_id !== item.unique_id);

    const neededMaterials: ItemInstance[] = [];
    if (itemRecipe.materials) {
      Object.entries(itemRecipe.materials).forEach(([matId, requiredCount]) => {
        let foundCount = 0;
        for (let i = inventoryPool.length - 1; i >= 0; i--) {
          if (foundCount >= requiredCount) break;
          if (inventoryPool[i].id === matId) {
            neededMaterials.push(inventoryPool.splice(i, 1)[0]);
            foundCount++;
          }
        }
      });
    }

    const neededTools: ItemInstance[] = [];
    if (itemRecipe.tools) {
      itemRecipe.tools.forEach((toolId) => {
        const toolIndex = inventoryPool.findIndex((invItem) => invItem.id === toolId);
        if (toolIndex !== -1) {
          neededTools.push(inventoryPool.splice(toolIndex, 1)[0]);
        }
      });
    }

    setMaterials(neededMaterials);
    setTools(neededTools);
  };

  const handleRemoveItem = (itemToRemove: ItemInstance, setter: React.Dispatch<React.SetStateAction<ItemInstance[]>>) => {
    setter((prev) => {
      let index = -1;
      for (let i = prev.length - 1; i >= 0; i--) {
        const item = prev[i];
        if (item.id === itemToRemove.id) {
          index = i;
          break;
        }
      }

      if (index > -1) {
        const newItems = [...prev];
        newItems.splice(index, 1);
        return newItems;
      }
      return prev;
    });
  };

  if (!player) return null;

  return (
    <div className="crafting-modal-body" style={{ flexGrow: 1 }}>
      <div className="crafting-inventory-panel">
        <UnifiedInventoryDisplay
          title="Inventory"
          items={availableItemsForGrid}
          onTransfer={handleAddItem}
          transferButtonText="Add"
          viewMode={inventoryState.viewMode}
          onViewModeChange={inventoryState.setViewMode}
          showFilterSearchBar={true}
          showFilterButtonBar={true}
          dynamicFilters={true}
          showViewToggle={true}
          showTransferControls={true}
          transferAmount={inventoryState.transferAmount}
          onTransferAmountChange={inventoryState.setTransferAmount}
        />
      </div>
      <div className="crafting-interface-panel">
        <h3>Item Repair</h3>
        <div className="crafting-target-slot">{targetItem ? <ItemIcon item={targetItem} onClick={() => setTargetItem(null)} /> : <p>Choose Item to Repair</p>}</div>
        <div className="crafting-slots-area">
          <h3>
            Tools ({tools.length}/{MAX_TOOLS})
          </h3>
          <div className="crafting-slots-grid">
            {tools.map((item) => (
              <ItemIcon key={item.unique_id} item={item} onClick={() => handleRemoveItem(item, setTools)} />
            ))}
            {Array.from({ length: MAX_TOOLS - tools.length }).map((_, i) => (
              <div key={`empty-tool-${i}`} className="item-icon-wrapper empty" />
            ))}
          </div>
          <h3 style={{ marginTop: '20px' }}>
            Repair Materials ({Object.keys(groupedMaterials).length}/{MAX_REPAIR_MATERIALS})
          </h3>
          <div className="crafting-slots-grid">
            {Object.values(groupedMaterials).map((group: GroupedItem) => (
              <ItemIcon key={group.item.unique_id} item={group.item} count={group.count} onClick={() => handleRemoveItem(group.item, setMaterials)} />
            ))}
            {Array.from({ length: MAX_REPAIR_MATERIALS - Object.keys(groupedMaterials).length }).map((_, i) => (
              <div key={`empty-mat-${i}`} className="item-icon-wrapper empty" />
            ))}
          </div>
        </div>
        <div className="crafting-result-area">
          {recipe && targetItem && (
            <div className="crafting-requirements-list">
              {Object.values(requirementChecks).map((c) => {
                if (c.provided !== undefined && c.required !== undefined) {
                  const percentage = c.required > 0 ? (c.provided / c.required) * 100 : 100;
                  return (
                    <p key={c.text} className={c.ok ? 'req-ok' : 'req-fail'}>
                      {c.text} - {c.provided}/{c.required} ({percentage.toFixed(0)}%)
                    </p>
                  );
                }
                return (
                  <p key={c.text} className={c.ok ? 'req-ok' : 'req-fail'}>
                    {c.text}
                  </p>
                );
              })}
            </div>
          )}
          <div className="action-grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
            <button className="btn" onClick={handleRepair} disabled={!canRepair}>
              Attempt Repair
            </button>
            <button className="btn" onClick={repairAllItems} disabled={!repairableItems.some((i) => i.requirementStatus === 'full')}>
              Repair All
            </button>
          </div>
        </div>
      </div>
      <div className="crafting-recipes-panel">
        <UnifiedInventoryDisplay
          title="Repairable Items"
          items={repairableItems}
          onItemClick={handleSelectRepairable}
          viewMode={'detailed'}
          showViewToggle={false}
          showSortButtons={false}
          columns={repairListColumns}
          showFilterSearchBar={true}
          showFilterButtonBar={false}
          dynamicFilters={true}
          defaultSort={{ key: 'requirementStatus', direction: 'asc' }}
        />
      </div>
    </div>
  );
};
