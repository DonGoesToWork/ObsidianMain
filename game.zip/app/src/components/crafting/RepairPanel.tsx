import { ColumnDef, UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import React, { useContext, useMemo, useState } from 'react';
import { ItemInstance, Recipe, RequirementStatus } from 'types';
import { calculateRepairSuccessChance, getRepairChecks, getRequirementStatus } from 'utils/craftingUtils';
import { calculateItemValue, getItemName, groupItems } from 'utils/itemUtils';

import { GameDataContext } from 'context/GameDataContext';
import { LogContext } from 'context/LogContext';
import { PlayerContext } from 'context/PlayerContext';
import { WorldContext } from 'context/WorldContext';
import { useModalState } from 'hooks/useModalState';
import { GroupedItem } from 'utils/itemUtils';
import { ProfessionsContext } from '../../context/ProfessionsContext';
import { ItemIcon } from '../shared/ItemIcon';

const MAX_REPAIR_MATERIALS = 10;
const MAX_TOOLS = 4;

const getRepairListColumns = (GAME_DATA: any): ColumnDef[] => [
  {
    key: 'name',
    label: 'Name',
    render: (item: any) => (
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <div className={`req-indicator ${item.requirementStatus}`}></div>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <span>{getItemName(item, GAME_DATA)}</span>
          <small style={{ color: '#aaa' }}>
            Durability: {item.currentDurability?.toFixed(0)} / {item.maxDurability}
          </small>
        </div>
      </div>
    ),
    className: 'shop-item-name',
    isSortable: true,
  },
  {
    key: 'itemLevel',
    label: 'Lvl',
    render: (item) => GAME_DATA.ITEMS[item.id].itemLevel,
    className: 'shop-item-level',
    isSortable: true,
  },
  {
    key: 'value',
    label: 'Value',
    render: (item) => `${calculateItemValue(item, GAME_DATA)}g`,
    className: 'shop-item-value',
    isSortable: true,
  },
];

export const RepairPanel: React.FC = () => {
  const { player } = useContext(PlayerContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { repairItem, repairAllItems } = useContext(ProfessionsContext)!;
  const { currentLocation, isActionLocked } = useContext(WorldContext)!;
  const { logMessage } = useContext(LogContext)!;
  const inventoryState = useModalState('crafting', 'repair_inventory');
  const repairListColumns = useMemo(() => getRepairListColumns(GAME_DATA), [GAME_DATA]);

  const [targetItem, setTargetItem] = useState<ItemInstance | null>(null);
  const [materials, setMaterials] = useState<ItemInstance[]>([]);
  const [tools, setTools] = useState<ItemInstance[]>([]);

  // This useEffect is buggy. It causes the entire item stack to be selected.
  // The Upgrade panel works without it, relying on the memoized `upgradeableItems` list to stay in sync.
  // We will adopt the same pattern here for consistency and to fix the bug.
  // useEffect(() => { ... });

  const availableItemsForGrid = useMemo(() => {
    if (!player) return [];

    const itemsInCrafting = [targetItem, ...tools, ...materials].filter(Boolean);
    const stackableQuantities: Record<string, number> = {};
    const unstackableIds = new Set<string>();

    for (const item of itemsInCrafting) {
      if (GAME_DATA.ITEMS[item!.id].stackable) {
        stackableQuantities[item!.id] = (stackableQuantities[item!.id] || 0) + item!.quantity;
      } else {
        unstackableIds.add(item!.unique_id);
      }
    }

    const displayItems: ItemInstance[] = [];
    player.inventory.forEach((item) => {
      if (item.isUnidentified) return;

      if (GAME_DATA.ITEMS[item.id].stackable) {
        const quantityInCrafting = stackableQuantities[item.id] || 0;
        if (item.quantity > quantityInCrafting) {
          displayItems.push({ ...item, quantity: item.quantity - quantityInCrafting });
        }
      } else {
        if (!unstackableIds.has(item.unique_id)) {
          displayItems.push(item);
        }
      }
    });

    return displayItems;
  }, [player, targetItem, materials, tools, GAME_DATA]);

  const repairableItems = useMemo(() => {
    if (!player) return [];
    const items = [...player.inventory, ...Object.values(player.equipment).filter((i): i is ItemInstance => !!i)];

    const augmentedItems = items
      .filter((item: ItemInstance) => {
        if (!item?.id || !GAME_DATA.ITEMS[item.id]) {
          if (item) console.warn('Item data not found in GAME_DATA for repairableItems:', item.id);
          return false;
        }
        const data = GAME_DATA.ITEMS[item.id];
        return (
          data.type.includes('equipment') &&
          item.currentDurability !== undefined &&
          item.maxDurability !== undefined &&
          item.currentDurability < item.maxDurability &&
          !item.isUnrepairable &&
          !item.isUnidentified &&
          data.recipeId &&
          player.knownRecipes[data.recipeId]
        );
      })
      .flatMap((item) => {
        if (item.quantity > 1) {
          return Array.from({ length: item.quantity }, (_, i) => ({
            ...item,
            quantity: 1,
            unique_id: `${item.unique_id}_repair_${i}`, // Ensure unique key for React
          }));
        }
        return item;
      })
      .map((item) => {
        const itemData = GAME_DATA.ITEMS[item.id];
        const recipe = itemData.recipeId ? GAME_DATA.ALL_RECIPES[itemData.recipeId] : null;
        const checks = getRepairChecks(player, recipe, player.inventory, player.inventory, currentLocation, GAME_DATA, true);
        const requirementStatus = getRequirementStatus(checks);
        return { ...item, requirementStatus };
      });

    const statusOrder: Record<RequirementStatus, number> = { full: 0, partial: 1, none: 2 };
    augmentedItems.sort((a, b) => {
      const statusDiff = statusOrder[a.requirementStatus] - statusOrder[b.requirementStatus];
      if (statusDiff !== 0) return statusDiff;
      const levelA = a.levelReq ?? GAME_DATA.ITEMS[a.id].itemLevel;
      const levelB = b.levelReq ?? GAME_DATA.ITEMS[b.id].itemLevel;
      return levelA - levelB;
    });
    return augmentedItems;
  }, [player, GAME_DATA, currentLocation]);

  const groupedMaterials = useMemo(() => groupItems(materials, GAME_DATA), [materials, GAME_DATA]);
  const groupedTools = useMemo(() => groupItems(tools, GAME_DATA), [tools, GAME_DATA]);

  const recipe: Recipe | null = useMemo(() => {
    if (!targetItem) return null;
    const itemData = GAME_DATA.ITEMS[targetItem.id];
    return itemData.recipeId ? GAME_DATA.ALL_RECIPES[itemData.recipeId] : null;
  }, [targetItem, GAME_DATA]);

  const handleAddItem = (item: ItemInstance, quantity: number, originalIndices: number[]) => {
    const itemData = GAME_DATA.ITEMS[item.id];
    const isTool = itemData.type.includes('tool');
    const setter = isTool ? setTools : setMaterials;
    const maxSlots = isTool ? MAX_TOOLS : MAX_REPAIR_MATERIALS;
    const slotName = isTool ? 'Tool' : 'Material';

    if (GAME_DATA.ITEMS[item.id].stackable) {
      setter((prev) => {
        const newItems = [...prev];
        const existing = newItems.find((i) => i.id === item.id);
        if (existing) {
          existing.quantity += quantity;
        } else if (prev.length < maxSlots) {
          newItems.push({ ...item, quantity });
        } else {
          logMessage(`${slotName} slots are full.`, 'error');
        }
        return newItems;
      });
    } else {
      // Unstackable items are processed one by one up to the transfer quantity
      const itemsToAdd = originalIndices.slice(0, quantity).map((i) => availableItemsForGrid[i]);
      setter((prev) => {
        const newItems = [...prev];
        for (const singleItem of itemsToAdd) {
          if (newItems.length < maxSlots) {
            if (!newItems.find((i) => i.unique_id === singleItem.unique_id)) {
              newItems.push(singleItem);
            }
          } else {
            logMessage(`${slotName} slots are full.`, 'error');
            break;
          }
        }
        return newItems;
      });
    }
  };

  const requirementChecks = useMemo(() => {
    if (!player || !recipe) return {};
    const checks = getRepairChecks(player, recipe, materials, tools, currentLocation, GAME_DATA, false);
    const playerSkill = player.professions[recipe.profession].level;
    const successChance = calculateRepairSuccessChance(playerSkill, recipe.levelReq);
    checks.dr = { ok: true, text: `DR: ${recipe.levelReq} (vs ${playerSkill})` };
    checks.success = { ok: true, text: `Success: ${successChance.toFixed(1)}%` };
    return checks;
  }, [player, recipe, materials, tools, currentLocation, GAME_DATA]);

  const canRepair = useMemo(() => {
    if (!targetItem || materials.length === 0) return false;
    return Object.values(requirementChecks).every((c) => c.ok);
  }, [targetItem, materials, requirementChecks]);

  const handleRepair = () => {
    if (!targetItem) return;
    repairItem(targetItem, materials, tools);
    setTargetItem(null);
    setMaterials([]);
    setTools([]);
  };

  const handleSelectRepairable = (e: React.MouseEvent, item: ItemInstance) => {
    const originalUniqueId = item.unique_id.includes('_repair_') ? item.unique_id.split('_repair_')[0] : item.unique_id;

    const realItemFromInventory = player?.inventory.find((i) => i.unique_id === originalUniqueId);
    const realItemFromEquipment = Object.values(player?.equipment || {}).find((i) => i?.unique_id === originalUniqueId);
    const realItem = realItemFromInventory || realItemFromEquipment;

    if (!realItem) {
      logMessage('Original item not found for repair.', 'error');
      console.error('Could not find item with original unique id:', originalUniqueId, 'from item:', item);
      return;
    }

    setTargetItem({ ...realItem, quantity: 1 });

    const itemData = GAME_DATA.ITEMS[realItem.id];
    const itemRecipe = itemData.recipeId ? GAME_DATA.ALL_RECIPES[itemData.recipeId] : null;

    if (!player || !itemRecipe) {
      setMaterials([]);
      setTools([]);
      return;
    }

    const inventoryPool = JSON.parse(JSON.stringify(player.inventory.filter((i) => i.unique_id !== realItem.unique_id)));

    const neededMaterials: ItemInstance[] = [];
    if (itemRecipe.materials) {
      Object.entries(itemRecipe.materials).forEach(([matId, requiredCount]) => {
        let count = 0;
        for (let i = inventoryPool.length - 1; i >= 0; i--) {
          if (count >= requiredCount) break;
          const invItem = inventoryPool[i];
          if (invItem.id === matId) {
            const takeAmount = Math.min(invItem.quantity, requiredCount - count);
            neededMaterials.push({ ...invItem, quantity: takeAmount });
            invItem.quantity -= takeAmount;
            count += takeAmount;
            if (invItem.quantity <= 0) {
              inventoryPool.splice(i, 1);
            }
          }
        }
      });
    }

    const neededTools: ItemInstance[] = [];
    if (itemRecipe.tools) {
      itemRecipe.tools.forEach((toolId) => {
        const toolIndex = inventoryPool.findIndex((invItem: ItemInstance) => invItem.id === toolId);
        if (toolIndex !== -1) {
          const toolStack = inventoryPool[toolIndex];
          if (toolStack.quantity > 1) {
            neededTools.push({ ...toolStack, quantity: 1 });
            toolStack.quantity -= 1;
          } else {
            neededTools.push(inventoryPool.splice(toolIndex, 1)[0]);
          }
        }
      });
    }

    setMaterials(neededMaterials);
    setTools(neededTools);
  };

  const handleRemoveItem = (itemToRemove: ItemInstance, setter: React.Dispatch<React.SetStateAction<ItemInstance[]>>, transferAmount: number) => {
    setter((prev) => {
      const newItems = [...prev];
      if (GAME_DATA.ITEMS[itemToRemove.id].stackable) {
        const index = newItems.findIndex((i) => i.id === itemToRemove.id);
        if (index > -1) {
          const item = newItems[index];
          const amountToRemove = Math.min(transferAmount, item.quantity);
          item.quantity -= amountToRemove;
          if (item.quantity <= 0) {
            newItems.splice(index, 1);
          }
        }
      } else {
        const index = newItems.findIndex((i) => i.unique_id === itemToRemove.unique_id);
        if (index > -1) {
          newItems.splice(index, 1);
        }
      }
      return newItems;
    });
  };

  if (!player) return null;

  return (
    <div className="crafting-modal-body" style={{ flexGrow: 1 }}>
      <div className="crafting-inventory-panel">
        <UnifiedInventoryDisplay
          title="Inventory"
          items={availableItemsForGrid}
          onTransfer={handleAddItem}
          transferButtonText="Add"
          viewMode={inventoryState.viewMode}
          onViewModeChange={inventoryState.setViewMode}
          showFilterSearchBar={true}
          showFilterButtonBar={true}
          dynamicFilters={true}
          showViewToggle={true}
          showTransferControls={true}
          transferAmount={inventoryState.transferAmount}
          onTransferAmountChange={inventoryState.setTransferAmount}
          disablePrimaryItemActions={true}
        />
      </div>
      <div className="crafting-interface-panel">
        <h3>Item Repair</h3>
        <div className="crafting-target-slot">{targetItem ? <ItemIcon item={targetItem} onClick={() => setTargetItem(null)} /> : <p>Choose Item to Repair</p>}</div>
        <div className="crafting-slots-area">
          <h3>
            Tools ({Object.keys(groupedTools).length}/{MAX_TOOLS})
          </h3>
          <div className="crafting-slots-grid">
            {Object.values(groupedTools).map((group: GroupedItem) => (
              <ItemIcon
                key={group.item.unique_id}
                item={group.item}
                count={group.count}
                onClick={() => handleRemoveItem(group.item, setTools, inventoryState.transferAmount)}
              />
            ))}
            {Array.from({ length: MAX_TOOLS - Object.keys(groupedTools).length }).map((_, i) => (
              <div key={`empty-tool-${i}`} className="item-icon-wrapper empty" />
            ))}
          </div>
          <h3 style={{ marginTop: '20px' }}>
            Repair Materials ({Object.keys(groupedMaterials).length}/{MAX_REPAIR_MATERIALS})
          </h3>
          <div className="crafting-slots-grid">
            {Object.values(groupedMaterials).map((group: GroupedItem) => (
              <ItemIcon
                key={group.item.unique_id}
                item={group.item}
                count={group.count}
                onClick={() => handleRemoveItem(group.item, setMaterials, inventoryState.transferAmount)}
              />
            ))}
            {Array.from({ length: MAX_REPAIR_MATERIALS - Object.keys(groupedMaterials).length }).map((_, i) => (
              <div key={`empty-mat-${i}`} className="item-icon-wrapper empty" />
            ))}
          </div>
        </div>
        <div className="crafting-result-area">
          {recipe && targetItem && (
            <div className="crafting-requirements-list">
              {Object.values(requirementChecks).map((c) => {
                if (c.provided !== undefined && c.required !== undefined) {
                  const percentage = c.required > 0 ? (c.provided / c.required) * 100 : 100;
                  return (
                    <p key={c.text} className={c.ok ? 'req-ok' : 'req-fail'}>
                      {c.text} - {c.provided}/{c.required} ({percentage.toFixed(0)}%)
                    </p>
                  );
                }
                return (
                  <p key={c.text} className={c.ok ? 'req-ok' : 'req-fail'}>
                    {c.text}
                  </p>
                );
              })}
            </div>
          )}
          <div className="action-grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
            <button className="btn" onClick={handleRepair} disabled={!canRepair || isActionLocked}>
              Attempt Repair
            </button>
            <button className="btn" onClick={repairAllItems} disabled={!repairableItems.some((i) => i.requirementStatus === 'full') || isActionLocked}>
              Repair All
            </button>
          </div>
        </div>
      </div>
      <div className="crafting-recipes-panel">
        <UnifiedInventoryDisplay
          title="Repairable Items"
          items={repairableItems}
          onItemClick={handleSelectRepairable}
          viewMode={'detailed'}
          showViewToggle={false}
          showSortButtons={false}
          columns={repairListColumns}
          showFilterSearchBar={true}
          showFilterButtonBar={false}
          dynamicFilters={true}
          defaultSort={{ key: 'requirementStatus', direction: 'asc' }}
          disablePrimaryItemActions={true}
        />
      </div>
    </div>
  );
};