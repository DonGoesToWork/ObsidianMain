import React, { useMemo, useRef, useEffect, useState } from "react";
import { LogEntry } from "types";

const LOG_FILTERS = ["all", "combat", "loot", "quest", "skill"];

interface LogDisplayProps {
  logs: LogEntry[];
}

export const LogDisplay: React.FC<LogDisplayProps> = ({ logs }) => {
  const [filter, setFilter] = useState("all");
  const logContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs, filter]);

  const filteredLogs = useMemo(() => {
    if (filter === "all") return logs;
    const combatTypes = ["damage", "crit", "heal", "combat"];
    return logs.filter((log) =>
      filter === "combat"
        ? combatTypes.includes(log.type)
        : log.type === filter,
    );
  }, [logs, filter]);

  return (
    <>
      <div id="log-tabs">
        {LOG_FILTERS.map((f) => (
          <div
            key={f}
            className={`log-tab ${filter === f ? "active" : ""}`}
            onClick={() => setFilter(f)}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </div>
        ))}
      </div>
      <div id="log-messages" ref={logContainerRef}>
        {filteredLogs.map((log, index) => (
          <p
            key={`${log.id}-${index}`}
            className={`log-${log.type} log-all`}
            dangerouslySetInnerHTML={{ __html: log.message }}
          ></p>
        ))}
      </div>
    </>
  );
};