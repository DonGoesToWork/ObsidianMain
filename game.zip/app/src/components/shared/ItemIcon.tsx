import React, { useContext, useLayoutEffect, useRef, useState } from 'react';
import { GameItem, ItemInstance, StatBlock } from 'types';
import { calculateItemValue, getFullItemName, getItemTier, getItemWeight } from 'utils/itemUtils';

import { GameDataContext } from 'context/GameDataContext';
import ReactDOM from 'react-dom';
import { getPotionEffectDescription } from 'utils/potionUtils';

interface ItemTooltipProps {
  item: ItemInstance;
  itemData: GameItem;
  anchorRef: React.RefObject<HTMLElement>;
}

const ItemTooltip: React.FC<ItemTooltipProps> = ({ item, itemData, anchorRef }) => {
  const tooltipRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ top: -9999, left: -9999 });
  const GAME_DATA = useContext(GameDataContext)!;

  const tier = getItemTier(item, GAME_DATA);

  useLayoutEffect(() => {
    if (anchorRef.current && tooltipRef.current) {
      const anchorRect = anchorRef.current.getBoundingClientRect();
      const tooltipRect = tooltipRef.current.getBoundingClientRect();

      let top = anchorRect.top - tooltipRect.height - 5;
      let left = anchorRect.left + anchorRect.width / 2 - tooltipRect.width / 2;

      if (top < 0) {
        top = anchorRect.bottom + 5;
      }
      if (left < 0) {
        left = 5;
      }
      if (left + tooltipRect.width > window.innerWidth) {
        left = window.innerWidth - tooltipRect.width - 5;
      }

      setPosition({ top, left });
    }
  }, [item, anchorRef]);

  const tooltipRoot = document.getElementById('tooltip-root');
  if (!tooltipRoot) return null;

  const renderStats = (stats: any, title: string) => {
    if (!stats || Object.keys(stats).length === 0) return null;
    return (
      <>
        <h3>{title}</h3>
        {Object.entries(stats).map(([stat, value]) => {
          if (title === 'Enchantments') {
            const enchantId = stat;
            const tier = value as number;
            const enchantDef = GAME_DATA.ENCHANTS.find((e) => e.id === enchantId);
            if (!enchantDef) return null;

            if (enchantDef.specialEffect) {
              return <p key={enchantId}>{enchantDef.name}</p>;
            }

            const val = enchantDef.scaling[tier - 1];
            let displayValue: string;

            if (
              enchantDef.stat &&
              ['critChance', 'goldFind', 'xpGain', 'attackPowerPercent', 'spellPowerPercent', 'armorPercent', 'lifeLeechPercent'].includes(enchantDef.stat)
            ) {
              displayValue = `+${val.toFixed(2)}%`;
            } else if (enchantDef.stat === 'attackSpeed') {
              displayValue = `${val > 0 ? '+' : ''}${(val * 100).toFixed(0)}%`;
            } else if (enchantDef.stat && ['worldHpRegen', 'worldMpRegen', 'worldSpRegen'].includes(enchantDef.stat)) {
              displayValue = `+${(val * 60).toFixed(2)}/hr`;
            } else {
              displayValue = `${val > 0 ? '+' : ''}${Math.round(val)}`;
            }

            return <p key={enchantId}>{`${enchantDef.name}: ${displayValue}`}</p>;
          } else {
            const statName = stat.charAt(0).toUpperCase() + stat.slice(1).replace(/([A-Z])/g, ' $1');
            let displayValue: string;
            const baseValue = value as number;

            if (stat === 'attackSpeed' && typeof baseValue === 'number') {
              displayValue = `${baseValue > 0 ? '+' : ''}${(baseValue * 100).toFixed(1)}%`;
            } else if (typeof baseValue === 'number' && baseValue > 0) {
              displayValue = `+${baseValue}`;
            } else {
              displayValue = `${baseValue}`;
            }

            const plusValue = item.plus_value || 0;
            if (plusValue > 0 && (stat === 'attackPower' || stat === 'armor' || stat === 'spellPower')) {
              const itemBaseValue = GAME_DATA.ITEMS[item.id]?.stats?.[stat as keyof StatBlock] || 0;
              if (itemBaseValue > 0) {
                const bonusValue = Math.ceil(itemBaseValue * plusValue * 0.1);
                if (bonusValue > 0) {
                  displayValue += ` [+${bonusValue}]`;
                }
              }
            }

            return <p key={stat}>{`${statName}: ${displayValue}`}</p>;
          }
        })}
      </>
    );
  };

  const effectDesc = getPotionEffectDescription(item, itemData, GAME_DATA);

  const renderNoteTooltip = () => {
    if (itemData.teachesRecipe) {
      const recipeData = GAME_DATA.ALL_RECIPES[itemData.teachesRecipe];
      if (!recipeData) return <p>An illegible note.</p>;
      return (
        <>
          <p>Teaches the recipe for {recipeData.name}.</p>
          <p className="item-desc">Use this item to learn the recipe permanently.</p>
        </>
      );
    }
    if (itemData.teachesAbility) {
      const abilityData = GAME_DATA.SKILLS[itemData.teachesAbility];
      if (!abilityData) return <p>An illegible note.</p>;
      return (
        <>
          <p>
            Teaches the {abilityData.abilityType} "{abilityData.name}".
          </p>
          <p className="item-desc">Use this item to learn the ability permanently.</p>
        </>
      );
    }
    return null;
  };

  const renderContainerTooltip = () => {
    if (!item.containerState) return null;
    const contentsWeight = item.containerState.items.reduce((sum, i) => sum + getItemWeight(i, GAME_DATA), 0);
    const numItems = item.containerState.items.reduce((acc, i) => acc + i.quantity, 0);
    const numUniqueItems = item.containerState.items.length;
    const gridStyle: React.CSSProperties = {};
    if (numUniqueItems > 0) {
      const gridSize = Math.ceil(Math.sqrt(numUniqueItems));
      gridStyle.display = 'grid';
      gridStyle.gridTemplateColumns = `repeat(${gridSize}, 24px)`;
      gridStyle.gap = '2px';
      gridStyle.marginTop = '10px';
      gridStyle.maxHeight = '300px';
      gridStyle.overflowY = 'auto';
      gridStyle.padding = '5px';
      gridStyle.background = 'rgba(0,0,0,0.2)';
    }

    return (
      <>
        <p>Items: {numItems} / 900</p>
        <p>
          Contents Weight: {contentsWeight.toFixed(2)} / {item.containerState.capacity.toFixed(2)}
        </p>
        {numUniqueItems > 0 && (
          <div className="tooltip-item-grid" style={gridStyle}>
            {item.containerState.items.map((innerItem) => (
              <ItemIcon key={innerItem.unique_id} item={innerItem} showTooltip={false} />
            ))}
          </div>
        )}
      </>
    );
  };

  const deceasedChar = item.deceasedCharacter;
  const fullItemName = getFullItemName(item, GAME_DATA);
  const totalValue = calculateItemValue({ ...item, quantity: 1 }, GAME_DATA);

  const tooltipContent = (
    <div
      className="item-tooltip"
      ref={tooltipRef}
      style={{
        top: `${position.top}px`,
        left: `${position.left}px`,
        maxWidth: '400px',
      }}
    >
      <h3 style={{ color: tier.color }}>{fullItemName}</h3>

      {itemData.type.includes('note') ? (
        renderNoteTooltip()
      ) : (
        <>
          {itemData.type.includes('equipment') && (
            <p>
              {itemData.twoHanded ? 'Two-Hand' : 'One-Hand'} {itemData.slot!.charAt(0).toUpperCase() + itemData.slot!.slice(1)}
            </p>
          )}

          {!itemData.type.includes('container') && renderStats(itemData.stats, 'Base Stats')}
          {!item.isUnidentified && renderStats(item.enchantments, 'Enchantments')}

          {effectDesc && (
            <>
              <h3>Effect</h3>
              <p>{effectDesc}</p>
            </>
          )}

          {itemData.type.includes('container') && (
            <>
              <h3>Container</h3>
              {renderContainerTooltip()}
            </>
          )}

          <h3>Other</h3>
          {item.isUnrepairable && <p style={{ color: '#ff4d4d', fontWeight: 'bold' }}>UNREPAIRABLE</p>}
          {item.isBroken && !item.isUnrepairable && <p style={{ color: '#ff4d4d', fontWeight: 'bold' }}>Broken</p>}
          {item.currentDurability !== undefined && item.maxDurability !== undefined && !itemData.isUnarmed && (
            <p>
              Durability: {item.currentDurability.toFixed(0)} / {item.maxDurability.toFixed(0)}
            </p>
          )}

          {itemData.chargeUnit && item.charges !== undefined && item.maxCharges !== undefined && (
            <p>
              {itemData.chargeUnit?.charAt(0).toUpperCase() + itemData.chargeUnit!.slice(1) + 's'}: {item.charges} / {item.maxCharges}
            </p>
          )}
          <p>Item Level: {itemData.itemLevel}</p>
        </>
      )}

      {deceasedChar && (
        <>
          <h3 style={{ marginTop: '8px' }}>Deceased</h3>
          <p>Remains of: {deceasedChar.name}</p>
          <p>
            Lvl {deceasedChar.level} {deceasedChar.race} {deceasedChar.class}
          </p>
        </>
      )}

      <p>Weight: {getItemWeight(item, GAME_DATA).toFixed(2)}</p>

      {itemData.value > 0 && <p className="item-value">Value: {totalValue}g</p>}

      {itemData.defaultAttack && (
        <>
          <h3 style={{ marginTop: '8px' }}>Default Attack</h3>
          <p>
            {itemData.defaultAttack.name} ({itemData.defaultAttack.tags.join(' / ')})
          </p>
        </>
      )}

      {itemData.desc && <p className="item-desc">"{itemData.desc}"</p>}
      {item.isUnidentified && Object.keys(item.enchantments).length > 0 && (
        <p className="item-desc" style={{ color: '#a335ee', fontStyle: 'italic' }}>
          "Contained Unknown Magic."
        </p>
      )}
    </div>
  );

  return ReactDOM.createPortal(tooltipContent, tooltipRoot);
};

interface ItemIconProps {
  item: ItemInstance;
  onClick?: (event: React.MouseEvent) => void;
  onContextMenu?: (event: React.MouseEvent) => void;
  count?: number;
  showTooltip?: boolean;
}

const getIconForItem = (item: ItemInstance, itemData: GameItem): string => {
  return itemData.icon || '❓';
};

export const ItemIcon: React.FC<ItemIconProps> = ({ item, onClick, onContextMenu, count, showTooltip: forceShowTooltip }) => {
  const GAME_DATA = useContext(GameDataContext)!;
  const [showTooltip, setShowTooltip] = useState(false);
  const iconRef = useRef<HTMLDivElement>(null);

  if (!item) return null;
  const itemData = GAME_DATA.ITEMS[item.id];
  if (!itemData) return null;

  const displayCount = count ?? item.quantity;

  const tier = getItemTier(item, GAME_DATA);
  const shouldShow = forceShowTooltip === undefined ? showTooltip : forceShowTooltip;
  const wrapperClass = `item-icon-wrapper ${tier.className} ${item.isBroken ? 'broken' : ''}`;

  return (
    <div
      ref={iconRef}
      className={wrapperClass}
      onClick={onClick}
      onContextMenu={onContextMenu}
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
    >
      <div className="item-icon">
        <span role="img" aria-label={itemData.name}>
          {getIconForItem(item, itemData)}
        </span>
      </div>
      {displayCount > 1 && <span className="item-count">{displayCount}</span>}
      {shouldShow && iconRef.current && <ItemTooltip item={item} itemData={itemData} anchorRef={iconRef} />}
    </div>
  );
};