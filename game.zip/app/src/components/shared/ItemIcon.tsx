import React, { useState, useRef, useLayoutEffect, useContext } from 'react';
import ReactDOM from 'react-dom';
import { ItemInstance, GameItem, ItemQuality } from 'types';
import { getItemTier, getItemName, calculateItemValue, getItemWeight } from 'utils/itemUtils';
import { getPotionEffectDescription } from 'utils/potionUtils';
import { GameDataContext } from 'context/GameDataContext';

interface ItemTooltipProps {
  item: ItemInstance;
  itemData: GameItem;
  anchorRef: React.RefObject<HTMLElement>;
}

const ItemTooltip: React.FC<ItemTooltipProps> = ({ item, itemData, anchorRef }) => {
  const tooltipRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ top: -9999, left: -9999 });
  const GAME_DATA = useContext(GameDataContext)!;

  const tier = getItemTier(item, GAME_DATA);

  useLayoutEffect(() => {
    if (anchorRef.current && tooltipRef.current) {
      const anchorRect = anchorRef.current.getBoundingClientRect();
      const tooltipRect = tooltipRef.current.getBoundingClientRect();

      let top = anchorRect.top - tooltipRect.height - 5;
      let left = anchorRect.left + anchorRect.width / 2 - tooltipRect.width / 2;

      if (top < 0) {
        top = anchorRect.bottom + 5;
      }
      if (left < 0) {
        left = 5;
      }
      if (left + tooltipRect.width > window.innerWidth) {
        left = window.innerWidth - tooltipRect.width - 5;
      }

      setPosition({ top, left });
    }
  }, [item, anchorRef]);

  const tooltipRoot = document.getElementById('tooltip-root');
  if (!tooltipRoot) return null;

  if (item.isUnidentified) {
    const unidentifiedContent = (
      <div className="item-tooltip" ref={tooltipRef} style={{ top: `${position.top}px`, left: `${position.left}px` }}>
        <h3 style={{ color: '#999' }}>Unidentified Item</h3>
        {itemData.type.includes('equipment') && <p>{itemData.slot!.charAt(0).toUpperCase() + itemData.slot!.slice(1)}</p>}
        <p>Item Level: {itemData.itemLevel}</p>
        <p className="item-value">Weight: {itemData.weight}</p>
      </div>
    );
    return ReactDOM.createPortal(unidentifiedContent, tooltipRoot);
  }

  const renderStats = (stats: any, title: string) => {
    if (!stats || Object.keys(stats).length === 0) return null;
    return (
      <>
        <h4>{title}</h4>
        {Object.entries(stats).map(([stat, value]) => {
          const statName = stat.charAt(0).toUpperCase() + stat.slice(1).replace(/([A-Z])/g, ' $1');
          let displayValue: string;

          if (stat === 'attackSpeed' && typeof value === 'number') {
            displayValue = `${value > 0 ? '+' : ''}${(value * 100).toFixed(1)}%`;
          } else if (typeof value === 'number' && value > 0) {
            displayValue = `+${value}`;
          } else {
            displayValue = `${value}`;
          }

          return <p key={stat}>{`${statName}: ${displayValue}`}</p>;
        })}
      </>
    );
  };

  const effectDesc = getPotionEffectDescription(item, itemData, GAME_DATA);

  const renderNoteTooltip = () => {
    if (itemData.teachesRecipe) {
      const recipeData = GAME_DATA.ALL_RECIPES[itemData.teachesRecipe];
      if (!recipeData) return <p>An illegible note.</p>;
      return (
        <>
          <p>Teaches the recipe for {recipeData.name}.</p>
          <p className="item-desc">Use this item to learn the recipe permanently.</p>
        </>
      );
    }
    if (itemData.teachesAbility) {
      const abilityData = GAME_DATA.SKILLS[itemData.teachesAbility];
      if (!abilityData) return <p>An illegible note.</p>;
      return (
        <>
          <p>
            Teaches the {abilityData.abilityType} "{abilityData.name}".
          </p>
          <p className="item-desc">Use this item to learn the ability permanently.</p>
        </>
      );
    }
    return null;
  };

  const renderContainerTooltip = () => {
    if (!item.containerState) return null;

    const contentsWeight = item.containerState.items.reduce((sum, i) => sum + getItemWeight(i, GAME_DATA), 0);

    const numItems = item.containerState.items.length;
    const gridStyle: React.CSSProperties = {};
    if (numItems > 0) {
      const gridSize = Math.ceil(Math.sqrt(numItems));
      gridStyle.display = 'grid';
      gridStyle.gridTemplateColumns = `repeat(${gridSize}, 24px)`;
      gridStyle.gap = '2px';
      gridStyle.marginTop = '10px';
      gridStyle.maxHeight = '300px';
      gridStyle.overflowY = 'auto';
      gridStyle.padding = '5px';
      gridStyle.background = 'rgba(0,0,0,0.2)';
    }

    return (
      <>
        <h4>Container</h4>
        <p>Items: {numItems} / 900</p>
        <p>
          Weight: {contentsWeight.toFixed(2)} / {item.containerState.capacity.toFixed(2)}
        </p>
        <p>Total Weight: {getItemWeight(item, GAME_DATA).toFixed(2)}</p>

        {numItems > 0 && (
          <div className="tooltip-item-grid" style={gridStyle}>
            {item.containerState.items.map((innerItem) => (
              <ItemIcon key={innerItem.unique_id} item={innerItem} showTooltip={false} />
            ))}
          </div>
        )}
      </>
    );
  };

  const deceasedChar = item.deceasedCharacter;

  const tooltipContent = (
    <div
      className="item-tooltip"
      ref={tooltipRef}
      style={{
        top: `${position.top}px`,
        left: `${position.left}px`,
        maxWidth: '400px',
      }}
    >
      <h3 style={{ color: tier.color }}>{getItemName(item, GAME_DATA)}</h3>

      {itemData.type.includes('note') ? (
        renderNoteTooltip()
      ) : itemData.type.includes('container') ? (
        renderContainerTooltip()
      ) : (
        <>
          {item.quality && (
            <p
              className="item-quality"
              style={{
                color: GAME_DATA.ITEM_QUALITIES[item.quality as ItemQuality]?.color || 'white',
              }}
            >
              {item.quality}
            </p>
          )}
          {itemData.type.includes('equipment') && (
            <p>
              {itemData.twoHanded ? 'Two-Hand' : 'One-Hand'} {itemData.slot!.charAt(0).toUpperCase() + itemData.slot!.slice(1)}
            </p>
          )}

          {renderStats(itemData.stats, 'Base Stats')}
          {renderStats(item.enchantments, 'Enchantments')}

          {effectDesc && (
            <>
              <h4>Effect</h4>
              <p>{effectDesc}</p>
            </>
          )}

          {item.isUnrepairable && <p style={{ color: '#ff4d4d', fontWeight: 'bold' }}>UNREPAIRABLE</p>}
          {item.isBroken && !item.isUnrepairable && <p style={{ color: '#ff4d4d', fontWeight: 'bold' }}>Broken</p>}
          {item.currentDurability !== undefined && item.maxDurability !== undefined && !itemData.isUnarmed && (
            <p>
              Durability: {item.currentDurability.toFixed(0)} / {item.maxDurability.toFixed(0)}
            </p>
          )}

          {itemData.chargeUnit && item.charges !== undefined && item.maxCharges !== undefined && (
            <p>
              {itemData.chargeUnit?.charAt(0).toUpperCase() + itemData.chargeUnit!.slice(1) + 's'}: {item.charges} / {item.maxCharges}
            </p>
          )}
          <p>Item Level: {itemData.itemLevel}</p>
        </>
      )}

      {deceasedChar && (
        <>
          <h4 style={{ marginTop: '8px' }}>Deceased</h4>
          <p>Remains of: {deceasedChar.name}</p>
          <p>
            Lvl {deceasedChar.level} {deceasedChar.race} {deceasedChar.class}
          </p>
        </>
      )}

      {!itemData.type.includes('container') && <p>Weight: {getItemWeight(item, GAME_DATA).toFixed(2)}</p>}

      {itemData.value > 0 && <p className="item-value">Value: {calculateItemValue(item, GAME_DATA)}g</p>}

      {itemData.defaultAttack && (
        <>
          <h4 style={{ marginTop: '8px' }}>Default Attack</h4>
          <p>
            {itemData.defaultAttack.name} ({itemData.defaultAttack.tags.join(' / ')})
          </p>
        </>
      )}

      {itemData.desc && <p className="item-desc">"{itemData.desc}"</p>}
    </div>
  );

  return ReactDOM.createPortal(tooltipContent, tooltipRoot);
};

interface ItemIconProps {
  item: ItemInstance;
  onClick?: (event: React.MouseEvent) => void;
  onContextMenu?: (event: React.MouseEvent) => void;
  count?: number;
  showTooltip?: boolean;
}

const getIconForItem = (item: ItemInstance, itemData: GameItem): string => {
  if (item.isUnidentified) return '❓';
  return itemData.icon || '❓';
};

export const ItemIcon: React.FC<ItemIconProps> = ({ item, onClick, onContextMenu, count, showTooltip: forceShowTooltip }) => {
  const GAME_DATA = useContext(GameDataContext)!;
  const [showTooltip, setShowTooltip] = useState(false);
  const iconRef = useRef<HTMLDivElement>(null);

  if (!item) return null;
  const itemData = GAME_DATA.ITEMS[item.id];
  if (!itemData) return null;

  const tier = getItemTier(item, GAME_DATA);
  const shouldShow = forceShowTooltip === undefined ? showTooltip : forceShowTooltip;
  const wrapperClass = `item-icon-wrapper ${item.isUnidentified ? 'unidentified' : tier.className} ${item.isBroken ? 'broken' : ''}`;

  return (
    <div
      ref={iconRef}
      className={wrapperClass}
      onClick={onClick}
      onContextMenu={onContextMenu}
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
    >
      <div className="item-icon">
        <span role="img" aria-label={itemData.name}>
          {getIconForItem(item, itemData)}
        </span>
      </div>
      {count && count > 1 && <span className="item-count">{count}</span>}
      {shouldShow && iconRef.current && <ItemTooltip item={item} itemData={itemData} anchorRef={iconRef} />}
    </div>
  );
};