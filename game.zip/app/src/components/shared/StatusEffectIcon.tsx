import React, { useContext, useLayoutEffect, useRef, useState } from 'react';
import { Combatant, Mercenary, Player, StatusEffect, StatusEffectInstance } from 'types';

import { GameDataContext } from 'context/GameDataContext';
import ReactDOM from 'react-dom';
import { formatDuration } from 'utils/formatUtils';

const toRoman = (num: number): string => {
  if (num < 1 || num > 5) return num.toString();
  const map: Record<number, string> = {
    1: 'I',
    2: 'II',
    3: 'III',
    4: 'IV',
    5: 'V',
  };
  return map[num];
};

interface StatusEffectTooltipProps {
  statusEffectInstance: StatusEffectInstance;
  statusEffectData: StatusEffect;
  anchorRef: React.RefObject<HTMLElement>;
  affectedLimbs?: string[];
  character?: Combatant | Player | Mercenary;
}

const StatusEffectTooltip: React.FC<StatusEffectTooltipProps> = ({ statusEffectInstance, statusEffectData, anchorRef, affectedLimbs, character }) => {
  const tooltipRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ top: -9999, left: -9999 });

  useLayoutEffect(() => {
    if (anchorRef.current && tooltipRef.current) {
      const anchorRect = anchorRef.current.getBoundingClientRect();
      const tooltipRect = tooltipRef.current.getBoundingClientRect();

      let top = anchorRect.top - tooltipRect.height - 5;
      let left = anchorRef.current.offsetLeft - tooltipRect.width / 2 + anchorRect.width / 2;

      if (top < 0) {
        top = anchorRect.bottom + 5;
      }
      if (left < 0) {
        left = 5;
      }
      if (left + tooltipRect.width > window.innerWidth) {
        left = window.innerWidth - tooltipRect.width - 5;
      }

      setPosition({ top, left });
    }
  }, [statusEffectInstance, anchorRef]);

  const tooltipRoot = document.getElementById('tooltip-root');
  if (!tooltipRoot) return null;

  const durationText = () => {
    if (statusEffectInstance.id === 'encumbered' || statusEffectInstance.turnsRemaining === Infinity || statusEffectInstance.durationInMinutes === Infinity) {
      return 'Permanent';
    }

    if (statusEffectInstance.turnsRemaining > 0) {
      return `${statusEffectInstance.turnsRemaining} turn(s) remaining`;
    }
    if (statusEffectInstance.durationInMinutes > 0) {
      return `${formatDuration(statusEffectInstance.durationInMinutes)} remaining`;
    }
    return 'Permanent';
  };

  const currentStage = statusEffectInstance.currentStage || 1;
  const stageData = statusEffectData.stages ? statusEffectData.stages[currentStage - 1] : null;

  let title = stageData?.name || statusEffectData.name;
  if ((statusEffectInstance.id === 'cut' || statusEffectInstance.id === 'external_bleed') && statusEffectInstance.currentStage) {
    title = `${statusEffectData.name} ${toRoman(statusEffectInstance.currentStage)}`;
  }

  let literalEffectText = '';
  const onTurnEffect = stageData?.effects?.onTurn || statusEffectData.effects?.onTurn;
  if (onTurnEffect?.type === 'damage_percent_max_hp' && character) {
    const totalMaxHp = Object.values(character.body).reduce((sum: number, l: any) => sum + l.maxHp, 0);
    const damagePerTurn = totalMaxHp * ((onTurnEffect as any).percent / 100);
    const damagePerSecond = damagePerTurn / 6;
    literalEffectText = `-${damagePerSecond.toFixed(1)} HP / sec`;
  } else if (onTurnEffect?.type === 'damage_percent_max_hp') {
    literalEffectText = `-${(onTurnEffect as any).percent}% max HP / turn`;
  }

  const tooltipContent = (
    <div className="status-effect-tooltip" ref={tooltipRef} style={{ top: `${position.top}px`, left: `${position.left}px` }}>
      <h3 style={{ color: statusEffectData.isBeneficial ? '#4caf50' : '#f44336' }}>
        {title}
        {statusEffectInstance.id !== 'cut' && statusEffectInstance.isClosed && ' (Patched)'}
      </h3>
      {stageData && (
        <h3 className="status-effect-stage-name">
          {statusEffectInstance.id === 'cut' ? (statusEffectInstance.isClosed ? 'Patched ' : 'Open ') : ''}
          {stageData.name}
        </h3>
      )}
      {literalEffectText && <p className="status-effect-literal">{literalEffectText}</p>}
      <p className="status-effect-desc">"{stageData?.desc || statusEffectData.desc}"</p>
      {affectedLimbs && !affectedLimbs.every((limb) => limb === 'Body') && (statusEffectInstance.id === 'cut' || statusEffectInstance.id === 'external_bleed') && (
        <div className="status-effect-limb-info">on {affectedLimbs.join(', ')}</div>
      )}
      <p style={{ color: '#ccc', marginTop: '8px' }}>{durationText()}</p>
    </div>
  );

  return ReactDOM.createPortal(tooltipContent, tooltipRoot);
};

interface StatusEffectIconProps {
  statusEffectInstance: StatusEffectInstance;
  isLimbIcon?: boolean;
  affectedLimbs?: string[];
  count?: number;
  character?: Combatant | Player | Mercenary;
}

export const StatusEffectIcon: React.FC<StatusEffectIconProps> = ({ statusEffectInstance, isLimbIcon = false, affectedLimbs, count, character }) => {
  const GAME_DATA = useContext(GameDataContext)!;
  const statusEffectData = GAME_DATA.STATUS_EFFECTS[statusEffectInstance.id];
  const [showTooltip, setShowTooltip] = useState(false);
  const iconRef = useRef<HTMLDivElement>(null);

  if (!statusEffectData) return null;

  const stage = statusEffectInstance.currentStage;
  let stageClass = '';
  if (stage) {
    if (stage <= 2) stageClass = 'stage-1-2';
    else if (stage === 3) stageClass = 'stage-3';
    else if (stage === 4) stageClass = 'stage-4';
    else if (stage >= 5) stageClass = 'stage-5';
  }

  const wrapperClass = `status-effect-icon-wrapper ${statusEffectData.isBeneficial ? 'beneficial' : 'detrimental'} ${isLimbIcon ? 'limb-icon' : ''} ${stageClass} ${
    statusEffectInstance.isClosed ? 'closed' : ''
  }`;

  const durationDisplay =
    statusEffectInstance.id === 'encumbered' || statusEffectInstance.turnsRemaining === Infinity || statusEffectInstance.durationInMinutes === Infinity
      ? '∞'
      : statusEffectInstance.turnsRemaining > 0
      ? statusEffectInstance.turnsRemaining
      : statusEffectInstance.durationInMinutes > 0
      ? formatDuration(statusEffectInstance.durationInMinutes)
      : null;

  return (
    <div ref={iconRef} className={wrapperClass} onMouseEnter={() => setShowTooltip(true)} onMouseLeave={() => setShowTooltip(false)}>
      <span role="img" aria-label={statusEffectData.name}>
        {statusEffectData.icon}
      </span>
      {count && count > 1 && <span className="status-effect-count">{count}</span>}
      {durationDisplay && !isLimbIcon && <span className="status-effect-duration">{durationDisplay}</span>}
      {showTooltip && iconRef.current && (
        <StatusEffectTooltip
          statusEffectInstance={statusEffectInstance}
          statusEffectData={statusEffectData}
          anchorRef={iconRef}
          affectedLimbs={affectedLimbs}
          character={character}
        />
      )}
    </div>
  );
};
