import React from "react";

interface ResourceBarProps {
  current: number;
  max: number;
  label: string;
  color: string;
  className?: string;
}

export const ResourceBar: React.FC<ResourceBarProps> = ({
  current,
  max,
  label,
  color,
  className = "",
}) => {
  const percentage = max > 0 ? (current / max) * 100 : 0;
  const text = `${label}: ${Math.floor(current)}/${max} (${percentage.toFixed(
    0,
  )}%)`;

  return (
    <div className={`stat-bar-container ${className}`} title={text}>
      <div className="stat-bar">
        <div
          className="bar-fill"
          style={{ width: `${percentage}%`, backgroundColor: color }}
        />
      </div>
      <div className="bar-text">{text}</div>
    </div>
  );
};
