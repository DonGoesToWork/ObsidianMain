import { ItemInstance, ItemType, ProfessionId } from 'types';
import { UseInventoryDisplayProps, useInventoryDisplayLogic } from '../inventory/useInventoryDisplay';

import React from 'react';
import { GroupedItem } from 'utils/itemUtils';
import { InventoryControls } from '../inventory/InventoryControls';
import { InventoryGridView } from '../inventory/InventoryGridView';
import { InventoryHeader } from '../inventory/InventoryHeader';
import { InventoryListView } from '../inventory/InventoryListView';

export type SortKey = 'name' | 'value' | 'type' | 'weight' | 'itemLevel' | 'stock' | 'requirementStatus' | 'durability';
export type SortDirection = 'asc' | 'desc';

export interface ColumnDef {
  key: SortKey;
  label: string;
  render: (item: ItemInstance, groupedItem: GroupedItem) => React.ReactNode;
  className?: string;
  isSortable?: boolean;
}

export interface FilterCategory {
  key: 'All' | ItemType | ProfessionId | string;
  label: string;
}

export interface UnifiedInventoryDisplayProps extends UseInventoryDisplayProps {
  title: string;
  onItemClick?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onItemContextMenu?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  showTransferControls?: boolean;
  onTransfer?: (item: ItemInstance, quantity: number, originalIndices: number[]) => void;
  transferButtonText?: string;
  onRowMouseEnter?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onRowMouseLeave?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
}

export const UnifiedInventoryDisplay: React.FC<UnifiedInventoryDisplayProps> = (props) => {
  const logic = useInventoryDisplayLogic(props);

  return (
    <div className="inventory-panel unified">
      <InventoryHeader title={props.title} showViewToggle={props.showViewToggle} viewMode={logic.viewMode} setViewMode={logic.setViewMode} />

      <InventoryControls
        searchTerm={logic.searchTerm}
        setSearchTerm={logic.setSearchTerm}
        activeFilter={logic.activeFilter}
        setActiveFilter={logic.setActiveFilter}
        viewMode={logic.viewMode}
        requestSort={logic.requestSort}
        getSortIndicator={logic.getSortIndicator}
        transferAmount={logic.transferAmount}
        setTransferAmount={logic.setTransferAmount}
        transferAmounts={logic.transferAmounts}
        showFilterSearchBar={props.showFilterSearchBar}
        showFilterButtonBar={props.showFilterButtonBar}
        filterCategories={logic.finalFilterCategories}
        showSortButtons={props.showSortButtons && logic.viewMode === 'simple'}
        showTransferControls={props.showTransferControls}
        transferButtonText={props.transferButtonText}
      />

      {logic.viewMode === 'simple' ? (
        <InventoryGridView {...props} {...logic} groupedAndSortedItems={logic.groupedAndSortedItems} />
      ) : (
        <InventoryListView {...props} {...logic} groupedAndSortedItems={logic.groupedAndSortedItems} columns={props.columns} />
      )}
    </div>
  );
};