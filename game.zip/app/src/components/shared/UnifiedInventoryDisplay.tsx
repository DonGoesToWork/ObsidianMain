import { PLAYER_INVENTORY_MAX_UNIQUE_ITEMS } from 'config/GLOBAL_QUICK_DEV_CONFIGURATION';
import { UIContext } from 'context/UIContext';
import React, { useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { ItemInstance, ItemType, ProfessionId, SortKey } from 'types';
import { UseInventoryDisplayProps, useInventoryDisplayLogic } from '../../hooks/useInventoryDisplay';

import { GroupedItem } from 'utils/itemUtils';
import { InventoryControls } from '../inventory/InventoryControls';
import { InventoryGridView } from '../inventory/InventoryGridView';
import { InventoryHeader } from '../inventory/InventoryHeader';
import { InventoryListView } from '../inventory/InventoryListView';

export interface ColumnDef {
  key: SortKey;
  label: string;
  render: (item: ItemInstance, groupedItem: GroupedItem) => React.ReactNode;
  className?: string;
  isSortable?: boolean;
}

export interface FilterCategory {
  key: 'All' | ItemType | ProfessionId | string;
  label: string;
}

export interface UnifiedInventoryDisplayProps extends UseInventoryDisplayProps {
  title: string;
  onItemClick?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onItemContextMenu?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  showTransferControls?: boolean;
  onTransfer?: (item: ItemInstance, quantity: number, originalIndices: number[]) => void;
  transferButtonText?: string;
  onRowMouseEnter?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onRowMouseLeave?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  disablePrimaryItemActions?: boolean;
  isDraggable?: boolean;
  padWithEmptySlots?: boolean;
  onReorder?: (draggedItemUniqueId: string, targetIndex: number) => void;
  onUseItemOnItem?: (heldItemUniqueId: string, targetItemUniqueId: string) => void;
}

export const UnifiedInventoryDisplay: React.FC<UnifiedInventoryDisplayProps> = (props) => {
  const logic = useInventoryDisplayLogic(props);
  const uiContext = useContext(UIContext);
  const gridRef = useRef<HTMLDivElement>(null);
  const scrollIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const [dragInfo, setDragInfo] = useState<{ item: ItemInstance; startIndex: number; originalIndices: number[] } | null>(null);
  const [dropIndex, setDropIndex] = useState<number | null>(null);
  const dropIndexRef = useRef<number | null>(null);

  const isDragging = useRef(false);
  const mouseDownInfo = useRef<{
    e: React.MouseEvent;
    groupedItem: GroupedItem & { originalIndices: number[] };
    index: number;
  } | null>(null);

  const displayedItems = useMemo(() => {
    if (!props.padWithEmptySlots) {
      return logic.groupedAndSortedItems;
    }
    const padded = [...logic.groupedAndSortedItems];
    while (padded.length < PLAYER_INVENTORY_MAX_UNIQUE_ITEMS) {
      padded.push(null as any); // Using any to allow nulls, will be handled in render
    }
    return padded;
  }, [logic.groupedAndSortedItems, props.padWithEmptySlots]);

  const itemsToRender = useMemo(() => {
    if (!props.isDraggable || !dragInfo || dropIndex === null) {
      return displayedItems;
    }

    const list = [...displayedItems];
    const itemAtDropIndex = list[dropIndex];
    const draggedItem = list[dragInfo.startIndex];

    if (!draggedItem) {
      return displayedItems;
    }

    // If hovering over an empty slot, just move the item without shifting others
    if (!itemAtDropIndex) {
      console.log(`[DragDrop Visual] Hovering over EMPTY slot ${dropIndex}. Swapping.`);
      list[dragInfo.startIndex] = null;
      list[dropIndex] = draggedItem;
    } else {
      // If hovering over an occupied slot, perform the insert/shift preview
      console.log(`[DragDrop Visual] Hovering over OCCUPIED slot ${dropIndex}. Shifting.`);
      const [removedItem] = list.splice(dragInfo.startIndex, 1);
      if (removedItem) {
        list.splice(dropIndex, 0, removedItem);
      }
    }

    return list;
  }, [props.isDraggable, displayedItems, dragInfo, dropIndex]);

  const handleMouseDown = (e: React.MouseEvent, groupedItem: GroupedItem & { originalIndices: number[] }, index: number) => {
    if (!props.isDraggable || e.button !== 0 || !groupedItem) return;

    console.log(`[DragDrop] MouseDown on item ${groupedItem.item.unique_id} at index ${index}. Potential drag starts.`);
    isDragging.current = false;
    mouseDownInfo.current = { e, groupedItem, index };

    setDragInfo({ item: groupedItem.item, startIndex: index, originalIndices: groupedItem.originalIndices });

    const itemToHold: any = { ...groupedItem.item, quantity: groupedItem.count };
    itemToHold.pickupPosition = { x: e.clientX, y: e.clientY };
    uiContext?.setHeldItem(itemToHold);

    e.preventDefault();
  };

  const stopScrolling = useCallback(() => {
    if (scrollIntervalRef.current) {
      clearInterval(scrollIntervalRef.current);
      scrollIntervalRef.current = null;
    }
  }, []);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!mouseDownInfo.current) return;

      if (!isDragging.current) {
        const dx = e.clientX - mouseDownInfo.current.e.clientX;
        const dy = e.clientY - mouseDownInfo.current.e.clientY;
        if (Math.sqrt(dx * dx + dy * dy) > 5) {
          console.log("[DragDrop] Drag threshold exceeded. It's a drag.");
          isDragging.current = true;
          logic.disableAllSorting();
        }
      }

      if (isDragging.current) {
        if (!gridRef.current) return;
        const grid = gridRef.current;
        const rect = grid.getBoundingClientRect();
        const isInsideGrid = e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom;

        if (isInsideGrid) {
          const x = e.clientX - rect.left + grid.scrollLeft;
          const y = e.clientY - rect.top + grid.scrollTop;

          const colWidth = 60 + 10;
          const rowHeight = 54 + 10;
          const numCols = Math.floor(grid.clientWidth / colWidth) || 1;
          const col = Math.floor(x / colWidth);
          const row = Math.floor(y / rowHeight);

          let index = row * numCols + col;
          index = Math.max(0, Math.min(displayedItems.length - 1, index));

          if (index !== dropIndexRef.current) {
            setDropIndex(index);
            dropIndexRef.current = index;
          }
        }
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      stopScrolling();
      const itemOnCursor = uiContext?.heldItem;

      if (isDragging.current) {
        console.log(`[DragDrop] MouseUp, was a drag. Final Drop Index: ${dropIndexRef.current}`);
        if (dragInfo && dropIndexRef.current !== null && props.onReorder) {
          const targetCanonicalIndex = dropIndexRef.current;
          if (targetCanonicalIndex !== dragInfo.startIndex) {
            props.onReorder(dragInfo.item.unique_id, targetCanonicalIndex);
          }
        }
      } else {
        console.log('[DragDrop] MouseUp, was a click.');
        if (mouseDownInfo.current) {
          const { e: mouseDownEvent, groupedItem } = mouseDownInfo.current;
          const clickedItem = groupedItem.item;

          if (e.shiftKey && props.onTransfer) {
            console.log('[DragDrop] Shift-click detected, transferring item.');
            logic.handleItemTransfer(groupedItem);
          } else if (itemOnCursor && itemOnCursor.unique_id !== clickedItem.unique_id) {
            if (props.onUseItemOnItem) {
              props.onUseItemOnItem(itemOnCursor.unique_id, clickedItem.unique_id);
            }
          } else if (props.onItemClick) {
            console.log('[DragDrop] Click detected, calling onItemClick.');
            props.onItemClick(mouseDownEvent, clickedItem, groupedItem.originalIndices);
          } else if (props.onTransfer) {
            console.log('[DragDrop] Click detected, calling onTransfer.');
            logic.handleItemTransfer(groupedItem);
          }
        }
      }

      setDragInfo(null);
      setDropIndex(null);
      dropIndexRef.current = null;
      uiContext?.setHeldItem(null);
      mouseDownInfo.current = null;
      isDragging.current = false;

      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };

    if (dragInfo) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      stopScrolling();
    };
  }, [dragInfo, stopScrolling, displayedItems, props, uiContext, logic]);

  return (
    <div className="inventory-panel unified">
      <InventoryHeader title={props.title} showViewToggle={props.showViewToggle} viewMode={logic.viewMode} setViewMode={logic.setViewMode} />

      <InventoryControls
        searchTerm={logic.searchTerm}
        setSearchTerm={logic.setSearchTerm}
        activeFilter={logic.activeFilter}
        setActiveFilter={logic.setActiveFilter}
        viewMode={logic.viewMode}
        requestSort={logic.requestSort}
        getSortIndicator={logic.getSortIndicator}
        transferAmount={logic.transferAmount}
        setTransferAmount={logic.setTransferAmount}
        transferAmounts={logic.transferAmounts}
        showFilterSearchBar={props.showFilterSearchBar}
        showFilterButtonBar={props.showFilterButtonBar}
        filterCategories={logic.finalFilterCategories}
        showSortButtons={props.showSortButtons && logic.viewMode === 'simple'}
        showTransferControls={props.showTransferControls}
        transferButtonText={props.transferButtonText}
      />

      {logic.viewMode === 'simple' ? (
        <InventoryGridView
          {...props}
          {...logic}
          gridRef={gridRef}
          onMouseDown={handleMouseDown}
          dragInfo={dragInfo}
          dropIndex={dropIndex}
          groupedAndSortedItems={itemsToRender as any}
        />
      ) : (
        <InventoryListView
          {...props}
          {...logic}
          groupedAndSortedItems={logic.groupedAndSortedItems.filter((i): i is GroupedItem & { originalIndices: number[] } => !!i)}
          columns={props.columns}
        />
      )}
    </div>
  );
};