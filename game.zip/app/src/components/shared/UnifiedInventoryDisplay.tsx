import { GroupedItem } from 'utils/itemUtils';
import { ItemInstance, ItemType, ViewMode } from 'types';
import React from 'react';
import { useInventoryDisplayLogic, UseInventoryDisplayProps } from '../inventory/useInventoryDisplay';
import { InventoryHeader } from '../inventory/InventoryHeader';
import { InventoryControls } from '../inventory/InventoryControls';
import { InventoryGridView } from '../inventory/InventoryGridView';
import { InventoryListView } from '../inventory/InventoryListView';

export type SortKey = 'name' | 'value' | 'type' | 'weight' | 'itemLevel' | 'stock';
export type SortDirection = 'asc' | 'desc';

export interface ColumnDef {
  key: SortKey;
  label: string;
  render: (item: ItemInstance, groupedItem: GroupedItem) => React.ReactNode;
  className?: string;
  isSortable?: boolean;
}

export interface FilterCategory {
  key: 'All' | ItemType;
  label: string;
}

export interface UnifiedInventoryDisplayProps extends UseInventoryDisplayProps {
  title: string;
  onItemClick?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  onItemContextMenu?: (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => void;
  showTransferControls?: boolean;
  onTransfer?: (item: ItemInstance, quantity: number, originalIndices: number[]) => void;
  transferButtonText?: string;
}

export const UnifiedInventoryDisplay: React.FC<UnifiedInventoryDisplayProps> = (props) => {
  const logic = useInventoryDisplayLogic(props);

  return (
    <div className="inventory-panel unified">
      <InventoryHeader title={props.title} showViewToggle={props.showViewToggle} viewMode={logic.viewMode} setViewMode={logic.setViewMode} />

      <InventoryControls
        searchTerm={logic.searchTerm}
        setSearchTerm={logic.setSearchTerm}
        activeFilter={logic.activeFilter}
        setActiveFilter={logic.setActiveFilter}
        viewMode={logic.viewMode}
        requestSort={logic.requestSort}
        getSortIndicator={logic.getSortIndicator}
        transferAmount={logic.transferAmount}
        setTransferAmount={logic.setTransferAmount}
        transferAmounts={logic.transferAmounts}
        showFilterBar={props.showFilterBar}
        filterCategories={props.filterCategories}
        showSortButtons={props.showSortButtons}
        showTransferControls={props.showTransferControls}
        transferButtonText={props.transferButtonText}
      />

      {logic.viewMode === 'simple' ? (
        <InventoryGridView {...props} {...logic} groupedAndSortedItems={logic.groupedAndSortedItems} />
      ) : (
        <InventoryListView {...props} {...logic} groupedAndSortedItems={logic.groupedAndSortedItems} columns={props.columns} />
      )}
    </div>
  );
};