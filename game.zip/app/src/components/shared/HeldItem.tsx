import { UIContext } from 'context/UIContext';
import React, { useContext, useLayoutEffect, useState } from 'react';
import { ItemIcon } from './ItemIcon';

export const HeldItem: React.FC = () => {
  const { heldItem } = useContext(UIContext)!;
  const [position, setPosition] = useState({ x: 0, y: 0 });

  useLayoutEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
    };

    if (heldItem) {
      // When a new item is picked up, immediately set its position to where the pickup occurred.
      if ((heldItem as any).pickupPosition) {
        setPosition((heldItem as any).pickupPosition);
      }
      window.addEventListener('mousemove', handleMouseMove);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [heldItem]);

  if (!heldItem) {
    return null;
  }

  return (
    <div className="held-item-container" style={{ top: position.y, left: position.x }}>
      <ItemIcon item={heldItem} showTooltip={false} />
    </div>
  );
};