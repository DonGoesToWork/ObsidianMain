import { AbilityId, Combatant, Mercenary, Player } from 'types';
import React, { useContext } from 'react';

import { GameDataContext } from 'context/GameDataContext';
import { WorldContext } from 'context/WorldContext';
import { getAbilityDescription } from 'utils/abilityUtils';
import { usePlayer } from 'hooks/usePlayer';

interface AbilitiesListDisplayProps {
  character: Player | Mercenary | Combatant;
  abilityIds: AbilityId[];
  onFavoriteToggle?: (abilityId: AbilityId) => void;
  favoriteAbilities?: AbilityId[];
}

export const AbilitiesListDisplay: React.FC<AbilitiesListDisplayProps> = ({ character, abilityIds, onFavoriteToggle, favoriteAbilities }) => {
  const player = usePlayer();
  const GAME_DATA = useContext(GameDataContext)!;
  const { castAbilityOutOfCombat } = useContext(WorldContext)!;
  if (!player) return null;

  const isPlayer = 'professions' in character;

  return (
    <div className="skills-list">
      {abilityIds.map((id) => {
        const ability = GAME_DATA.SKILLS[id];
        const currentRank = character.skills?.[id]?.rank || 0;
        if (!ability || currentRank === 0) return null;

        const desc = getAbilityDescription(ability, currentRank);
        const isFavorite = favoriteAbilities?.includes(id);

        const canBeCast = isPlayer && ability.validTargets && ability.validTargets.length > 0;

        return (
          <button
            key={id}
            className={`skill-entry ${canBeCast ? 'can-cast' : ''}`}
            onClick={(e) => {
              if (canBeCast && castAbilityOutOfCombat) {
                castAbilityOutOfCombat(id, e);
              }
            }}
          >
            {onFavoriteToggle && (ability.abilityType === 'Skill' || ability.abilityType === 'Spell') && (
              <span
                className="favorite-star"
                onClick={(e) => {
                  e.stopPropagation();
                  onFavoriteToggle(id);
                }}
                title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
              >
                {isFavorite ? '★' : '☆'}
              </span>
            )}
            <div className="skill-info">
              <h4>
                {ability.name} (Rank {currentRank})
              </h4>
              <p>{desc}</p>
            </div>
          </button>
        );
      })}
    </div>
  );
};
