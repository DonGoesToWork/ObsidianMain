import React from "react";
import { Equipment, PlayerEquipmentSlot } from "types";
import { ItemIcon } from "./ItemIcon";

interface EquipmentDisplayProps {
  equipment: Equipment;
  onContextMenu?: (event: React.MouseEvent, slot: PlayerEquipmentSlot) => void;
}

const SLOT_LABELS: Record<PlayerEquipmentSlot, string> = {
  head: "Head",
  amulet: "Amulet",
  chest: "Chest",
  legs: "Legs",
  weapon: "Hand 1",
  shield: "Hand 2",
  ring1: "Ring 1",
  ring2: "Ring 2",
};

const renderSlot = (
  slot: PlayerEquipmentSlot,
  equipment: Equipment,
  props: EquipmentDisplayProps,
) => {
  const item = equipment[slot];
  const { onContextMenu } = props;
  return (
    <div className="equipment-slot" data-slot={slot}>
      <label>{SLOT_LABELS[slot]}</label>
      {item ? (
        <ItemIcon
          item={item}
          onContextMenu={
            onContextMenu ? (e) => onContextMenu(e, slot) : undefined
          }
        />
      ) : (
        <div className="item-icon-wrapper empty"></div>
      )}
    </div>
  );
};

export const EquipmentDisplay: React.FC<EquipmentDisplayProps> = (props) => {
  const { equipment } = props;
  return (
    <div className="equipment-grid">
      {renderSlot("head", equipment, props)}
      {renderSlot("amulet", equipment, props)}
      {renderSlot("chest", equipment, props)}
      {renderSlot("legs", equipment, props)}
      {renderSlot("weapon", equipment, props)}
      {renderSlot("shield", equipment, props)}
      {renderSlot("ring1", equipment, props)}
      {renderSlot("ring2", equipment, props)}
    </div>
  );
};
