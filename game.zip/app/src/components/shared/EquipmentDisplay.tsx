import { Equipment, PlayerEquipmentSlot } from 'types';

import React from 'react';
import { ItemIcon } from './ItemIcon';

interface EquipmentDisplayProps {
  equipment: Equipment;
  onContextMenu?: (event: React.MouseEvent, slot: PlayerEquipmentSlot) => void;
}

const SLOT_LABELS: Record<PlayerEquipmentSlot, string> = {
  head: 'Head',
  amulet1: 'Amulet 1',
  amulet2: 'Amulet 2',
  chest: 'Chest',
  groin: 'Groin',
  weapon: 'R-Hand',
  shield: 'L-Hand',
  left_ring: 'L-Ring',
  right_ring: 'R-Ring',
  left_armlet: 'L-Armlet',
  right_armlet: 'R-Armlet',
  left_glove: 'L-Glove',
  right_glove: 'R-Glove',
  left_legging: 'L-Leg',
  right_legging: 'R-Leg',
  left_foot: 'L-Foot',
  right_foot: 'R-Foot',
};

const renderSlot = (slot: PlayerEquipmentSlot, equipment: Equipment, props: EquipmentDisplayProps) => {
  const item = equipment[slot];
  const { onContextMenu } = props;
  const label = SLOT_LABELS[slot];
  if (!label) return null; // Don't render slots that aren't defined in the labels
  return (
    <div className="equipment-slot" data-slot={slot}>
      <label>{label}</label>
      {item ? <ItemIcon item={item} onContextMenu={onContextMenu ? (e) => onContextMenu(e, slot) : undefined} /> : <div className="item-icon-wrapper empty"></div>}
    </div>
  );
};

export const EquipmentDisplay: React.FC<EquipmentDisplayProps> = (props) => {
  const { equipment } = props;
  return (
    <div className="equipment-grid">
      {renderSlot('head', equipment, props)}
      {renderSlot('amulet1', equipment, props)}
      {renderSlot('amulet2', equipment, props)}
      {renderSlot('left_armlet', equipment, props)}
      {renderSlot('right_armlet', equipment, props)}
      {renderSlot('chest', equipment, props)}
      {renderSlot('left_glove', equipment, props)}
      {renderSlot('right_glove', equipment, props)}
      {renderSlot('groin', equipment, props)}
      {renderSlot('weapon', equipment, props)}
      {renderSlot('shield', equipment, props)}
      {renderSlot('left_ring', equipment, props)}
      {renderSlot('right_ring', equipment, props)}
      {renderSlot('left_legging', equipment, props)}
      {renderSlot('right_legging', equipment, props)}
      {renderSlot('left_foot', equipment, props)}
      {renderSlot('right_foot', equipment, props)}
    </div>
  );
};