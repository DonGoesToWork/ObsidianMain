import { ItemId, Recipe } from 'types';
import React, { useContext, useLayoutEffect, useRef, useState } from 'react';

import { GameDataContext } from 'context/GameDataContext';
import ReactDOM from 'react-dom';
import { countItems } from 'utils/itemUtils';
import { usePlayer } from 'hooks/usePlayer';

interface RecipeTooltipProps {
  recipe: Recipe;
  anchorEl: HTMLElement | null;
}

export const RecipeTooltip: React.FC<RecipeTooltipProps> = ({ recipe, anchorEl }) => {
  const tooltipRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ top: -9999, left: -9999 });
  const GAME_DATA = useContext(GameDataContext)!;
  const player = usePlayer();

  useLayoutEffect(() => {
    if (anchorEl && tooltipRef.current) {
      const anchorRect = anchorEl.getBoundingClientRect();
      const tooltipRect = tooltipRef.current.getBoundingClientRect();

      let top = anchorRect.top - tooltipRect.height - 5;
      let left = anchorRect.left + anchorRect.width / 2 - tooltipRect.width / 2;

      if (top < 0) {
        top = anchorRect.bottom + 5;
      }
      if (left < 0) {
        left = 5;
      }
      if (left + tooltipRect.width > window.innerWidth) {
        left = window.innerWidth - tooltipRect.width - 5;
      }

      setPosition({ top, left });
    }
  }, [recipe, anchorEl]);

  const tooltipRoot = document.getElementById('tooltip-root');
  if (!tooltipRoot || !anchorEl || !player) return null;

  const createdItemData = GAME_DATA.ITEMS[recipe.creates];

  const tooltipContent = (
    <div
      className="item-tooltip"
      ref={tooltipRef}
      style={{
        top: `${position.top}px`,
        left: `${position.left}px`,
      }}
    >
      <h3>{recipe.name}</h3>
      <p>
        Creates: {createdItemData.name} x{recipe.quantity}
      </p>
      <hr className="stat-divider" />

      <h3>Materials</h3>
      {Object.entries(recipe.materials).map(([itemId, count]) => {
        const itemData = GAME_DATA.ITEMS[itemId as ItemId];
        const haveCount = countItems(player.inventory, itemId as ItemId);
        return (
          <p key={itemId} style={{ color: haveCount >= count ? 'inherit' : '#ff6b6b' }}>
            {itemData.name}: {haveCount}/{count}
          </p>
        );
      })}

      {recipe.tools && recipe.tools.length > 0 && (
        <>
          <h3 style={{ marginTop: '8px' }}>Tools</h3>
          {recipe.tools.map((toolId) => {
            const toolData = GAME_DATA.ITEMS[toolId];
            const hasTool = countItems(player.inventory, toolId) > 0;
            return (
              <p key={toolId} style={{ color: hasTool ? 'inherit' : '#ff6b6b' }}>
                {toolData.name}: {hasTool ? 1 : 0}/1
              </p>
            );
          })}
        </>
      )}
    </div>
  );

  return ReactDOM.createPortal(tooltipContent, tooltipRoot);
};
