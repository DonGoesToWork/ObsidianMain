import React, { useContext } from 'react';
import ReactDOM from 'react-dom';
import { UIContext } from 'context/UIContext';

const FloatingTextItem: React.FC<{ text: string; onEnd: () => void }> = ({ text, onEnd }) => {
  React.useEffect(() => {
    const timer = setTimeout(onEnd, 3900); // just before animation ends
    return () => clearTimeout(timer);
  }, [onEnd]);

  return <div className="floating-text-item">{text}</div>;
};

export const FloatingTextDisplay: React.FC = () => {
  const { floatingTexts, setFloatingTexts } = useContext(UIContext)!;
  const container = document.getElementById('floating-text-root');

  if (!container) return null;

  const handleRemove = (id: number) => {
    setFloatingTexts((texts) => texts.filter((t) => t.id !== id));
  };

  return ReactDOM.createPortal(
    <div id="floating-text-container">
      {floatingTexts.map((textItem) => (
        <FloatingTextItem key={textItem.id} text={textItem.text} onEnd={() => handleRemove(textItem.id)} />
      ))}
    </div>,
    container
  );
};
