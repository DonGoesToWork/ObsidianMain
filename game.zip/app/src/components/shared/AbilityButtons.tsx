import React, { useContext } from 'react';
import { AbilityId, Combatant, Player } from 'types';
import { FAVORITE_ABILITY_HOTKEYS } from '../../config/uiConfig';
import { getHotkeyDisplay, ActionName } from '../../config/hotkeys';
import { GameDataContext } from 'context/GameDataContext';

interface AbilityButtonsProps {
  type: 'combat' | 'world';
  abilityIds: AbilityId[];
  character: Player | Combatant;
  getHotkeyFor: (actionName: ActionName) => string;
  onAbilityClick: (abilityId: AbilityId, e?: React.MouseEvent) => void;
  onFavoriteToggle?: (abilityId: AbilityId) => void; // only for 'world' type
  isFavoriteList?: boolean;
  selectedSkillId?: AbilityId | null; // only for 'combat' type
}

export const AbilityButtons: React.FC<AbilityButtonsProps> = ({
  type,
  abilityIds,
  character,
  getHotkeyFor,
  onAbilityClick,
  onFavoriteToggle,
  isFavoriteList,
  selectedSkillId,
}) => {
  const GAME_DATA = useContext(GameDataContext)!;
  return (
    <div className="action-panel-grid">
      {abilityIds.map((abilityId, index) => {
        const abilityData = GAME_DATA.SKILLS[abilityId];
        if (!abilityData) return null;

        const resourceType = abilityData.resourceType.toLowerCase() as 'mp' | 'sp';
        const canAfford = abilityData.resourceType === 'None' || (character && character[resourceType] >= abilityData.resourceCost);

        let hotkeyDisplay = '';
        if (isFavoriteList && index < 9) {
          const hotkeyActionName = FAVORITE_ABILITY_HOTKEYS[index];
          hotkeyDisplay = hotkeyActionName ? getHotkeyDisplay(getHotkeyFor(hotkeyActionName)) : '';
        }

        const title = `${abilityData.name} - ${abilityData.desc} (Cost: ${abilityData.resourceCost} ${abilityData.resourceType})`;

        if (type === 'world') {
          return (
            <button key={abilityId} className="btn action-panel-ability-btn" onClick={(e) => onAbilityClick(abilityId, e)} disabled={!canAfford} title={title}>
              <span
                className="favorite-star"
                onClick={(e) => {
                  e.stopPropagation();
                  onFavoriteToggle!(abilityId);
                }}
                title={isFavoriteList ? 'Remove from favorites' : 'Add to favorites'}
              >
                {isFavoriteList ? '★' : '☆'}
              </span>
              <div className="ability-info">
                {abilityData.name}
                <small>
                  {abilityData.resourceCost} {abilityData.resourceType}
                </small>
              </div>
              {hotkeyDisplay && <span>({hotkeyDisplay})</span>}
            </button>
          );
        } else {
          // combat
          const buttonClasses = `btn combat-btn ${selectedSkillId === abilityId ? 'selected' : ''}`;
          return (
            <button key={abilityId} className={buttonClasses} onClick={() => onAbilityClick(abilityId)} disabled={!canAfford} title={title}>
              {abilityData.name} {hotkeyDisplay ? `(${hotkeyDisplay})` : ''}
            </button>
          );
        }
      })}
    </div>
  );
};
