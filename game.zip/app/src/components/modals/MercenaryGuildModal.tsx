import React, { useContext, useEffect } from 'react';

import { UIContext } from 'context/UIContext';
import { WorldContext } from 'context/WorldContext';
import { useInventory } from 'hooks/useInventory';
import { useParty } from 'hooks/useParty';
import { formatDuration } from 'utils/formatUtils';
import { Modal } from '../modals/Modal';

export const MercenaryGuildModal: React.FC = () => {
  const { gold } = useInventory();
  const { party, hireMercenary, refreshMercenaryGuild, mercenaryGuildData } = useParty();
  const { setActiveModal } = useContext(UIContext)!;
  const { isActionLocked, currentLocation, gameTime } = useContext(WorldContext)!;

  useEffect(() => {
    if (currentLocation) {
      console.log('MercenaryGuildModal.tsx: useEffect triggered, refreshing guild.');
      refreshMercenaryGuild(currentLocation.levelReq);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentLocation]); // Depend on currentLocation to ensure it's loaded

  if (gold === undefined || !party || !currentLocation) return null;

  const availableMercs = mercenaryGuildData?.available || [];
  const canHire = party.length < 3;

  const lastRefreshDate = new Date(mercenaryGuildData?.lastRefreshed || 0);
  const nextRefreshTime = new Date(lastRefreshDate);
  nextRefreshTime.setDate(nextRefreshTime.getDate() + 1);
  nextRefreshTime.setHours(6, 0, 0, 0);

  const timeToRefreshMs = Math.max(0, nextRefreshTime.getTime() - gameTime.getTime());
  const timeToRestock = formatDuration(timeToRefreshMs / 60000); // formatDuration expects minutes

  return (
    <Modal title="Mercenary Guild" subTitle={`Restocks In: ${timeToRestock}`} onClose={() => setActiveModal(null)} size="large">
      <p>Welcome to the guild. These brave souls are looking for work. Take your pick, but remember, they don't work for free.</p>
      {!canHire && <p style={{ color: '#ff6b6b', fontWeight: 'bold' }}>Your party is full. You cannot hire more mercenaries.</p>}

      <div className="mercenary-hire-list" style={{ marginTop: '10px' }}>
        {availableMercs.length > 0 ? (
          availableMercs.map((merc) => {
            const hasSufficientGold = gold >= merc.initialCost;
            return (
              <div key={merc.id} className="mercenary-for-hire">
                <div>
                  <h3>{merc.name}</h3>
                  <div className="mercenary-details">
                    <span>Level: {merc.level}</span>
                    <span>Class: {merc.class}</span>
                    <span>Race: {merc.race}</span>
                    <span className="mercenary-costs">Upkeep: {merc.dailyCost}g / day</span>
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <p className="mercenary-costs">Hire Fee: {merc.initialCost}g</p>
                  <button className="btn" disabled={!canHire || !hasSufficientGold || isActionLocked} onClick={() => hireMercenary(merc)}>
                    Hire
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <p>There are no mercenaries available for hire right now. Check back later.</p>
        )}
      </div>
    </Modal>
  );
};