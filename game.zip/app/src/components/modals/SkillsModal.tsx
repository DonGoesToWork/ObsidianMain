import { Ability, AbilityId, Player } from '../../types';
import React, { useContext, useMemo, useState } from 'react';
import { canLearnAbility, getAbilityDescription, getUnlearnedAbilities, groupAbilitiesByTypeAndCategory } from 'utils/abilityUtils';

import { AbilitiesPanel } from '../character/AbilitiesPanel';
import { Modal } from './Modal';
import { PerkPanel } from '../character/PerkPanel';
import { UIContext } from 'context/UIContext';
import { usePlayer } from 'hooks/usePlayer';
import { useAbilities } from 'hooks/useAbilities';
import { GameDataContext } from 'context/GameDataContext';

interface SkillGroupProps {
  abilities: [AbilityId, Ability][];
  onLearn: (id: AbilityId) => void;
}

const SkillGroup: React.FC<SkillGroupProps> = ({ abilities, onLearn }) => {
  const player = usePlayer()!;
  const GAME_DATA = useContext(GameDataContext)!;
  return (
    <>
      {abilities.map(([id, ability]) => {
        const currentRank = player.skills[id]?.rank || 0;
        const { can, reason } = canLearnAbility(player, id, GAME_DATA);
        const desc = getAbilityDescription(ability, currentRank > 0 ? currentRank : 1);

        if (ability.abilityType !== 'Perk' && currentRank > 0) {
          return null; // Don't show already-learned skills/spells in the learn list.
        }

        return (
          <div key={id} className={`skill-entry ${!can && currentRank === 0 ? 'locked' : ''}`}>
            <div className="skill-info">
              <h4>
                {ability.name} {currentRank > 0 && `(Rank ${currentRank})`}
              </h4>
              <p>{desc}</p>
              {reason && currentRank === 0 && <small className="skill-req">{reason}</small>}
            </div>
            <button className="btn" disabled={!can} onClick={() => onLearn(id)}>
              {currentRank > 0 ? 'Improve' : 'Learn'}
            </button>
          </div>
        );
      })}
    </>
  );
};

export const SkillsModal: React.FC = () => {
  const player = usePlayer();
  const GAME_DATA = useContext(GameDataContext)!;
  const { learnAbility, learnPerk, toggleFavoriteAbility, favoriteAbilities, perkPoints } = useAbilities();
  const { setActiveModal } = useContext(UIContext)!;
  const [tab, setTab] = useState<'abilities' | 'skills'>('abilities');

  if (!player) return null;

  const unlearnedAbilityIds = useMemo(() => getUnlearnedAbilities(player, GAME_DATA), [player, GAME_DATA]);
  const groupedUnlearned = useMemo(() => groupAbilitiesByTypeAndCategory(unlearnedAbilityIds, GAME_DATA), [unlearnedAbilityIds, GAME_DATA]);

  const handleLearn = (id: AbilityId) => {
    const abilityData = GAME_DATA.SKILLS[id];
    if (abilityData?.abilityType === 'Perk') {
      learnPerk(id);
    } else {
      learnAbility(id);
    }
  };

  const renderSkillGroups = (abilityType: 'active' | 'passive') => {
    const abilities = groupedUnlearned[abilityType] || {};
    if (Object.keys(abilities).length === 0) {
      return <p>No new {abilityType === 'active' ? 'skills or spells' : 'perks'} available to learn.</p>;
    }
    return Object.entries(abilities)
      .sort(([catA], [catB]) => catA.localeCompare(catB))
      .map(([category, abilityList]) => (
        <div key={category} className="perk-category">
          <h4>{category}</h4>
          <SkillGroup abilities={abilityList} onLearn={handleLearn} />
        </div>
      ));
  };

  return (
    <Modal title="Skills & Perks" onClose={() => setActiveModal(null)} size="xlarge">
      <h4>
        Available Perk Points: <span className="points-available">{perkPoints}</span>
      </h4>
      <div className="tabs">
        <button className={`tab-btn ${tab === 'abilities' ? 'active' : ''}`} onClick={() => setTab('abilities')}>
          My Abilities & Perks
        </button>
        <button className={`tab-btn ${tab === 'skills' ? 'active' : ''}`} onClick={() => setTab('skills')}>
          Learn New Abilities
        </button>
      </div>
      <div className="tab-content">
        {tab === 'abilities' && (
          <>
            <AbilitiesPanel character={player} onFavoriteToggle={toggleFavoriteAbility} favoriteAbilities={favoriteAbilities} />
            <hr className="stat-divider" />
            <PerkPanel />
          </>
        )}
        {tab === 'skills' && (
          <div className="skills-list">
            <h3>Active Skills & Spells</h3>
            {renderSkillGroups('active')}

            <h3 style={{ marginTop: '10px' }}>Passive Perks</h3>
            {renderSkillGroups('passive')}
          </div>
        )}
      </div>
    </Modal>
  );
};
