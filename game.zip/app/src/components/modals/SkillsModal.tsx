import React, { useContext, useMemo, useState } from 'react';
import { canLearnAbility, getAbilityDescription, getUnlearnedAbilities, groupAbilitiesByTypeAndCategory } from 'utils/abilityUtils';
import { Ability, AbilityId } from '../../types';

import { GameDataContext } from 'context/GameDataContext';
import { UIContext } from 'context/UIContext';
import { WorldContext } from 'context/WorldContext';
import { useAbilities } from 'hooks/useAbilities';
import { usePlayer } from 'hooks/usePlayer';
import { AbilitiesPanel } from '../character/AbilitiesPanel';
import { PerkPanel } from '../character/PerkPanel';
import { Modal } from './Modal';

interface SkillGroupProps {
  abilities: [AbilityId, Ability][];
  onLearn: (id: AbilityId) => void;
}

const SkillGroup: React.FC<SkillGroupProps> = ({ abilities, onLearn }) => {
  const player = usePlayer()!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { isActionLocked } = useContext(WorldContext)!;
  return (
    <>
      {abilities.map(([id, ability]) => {
        const currentRank = player.skills[id]?.rank || 0;
        const { can, reason } = canLearnAbility(player, id, GAME_DATA);
        const desc = getAbilityDescription(ability, currentRank > 0 ? currentRank : 1);

        if (ability.abilityType !== 'Perk' && currentRank > 0) {
          return null; // Don't show already-learned skills/spells in the learn list.
        }

        return (
          <div key={id} className={`skill-entry ${!can && currentRank === 0 ? 'locked' : ''}`}>
            <div className="skill-info">
              <h3>
                {ability.name} {currentRank > 0 && `(Rank ${currentRank})`}
              </h3>
              <p>{desc}</p>
              {reason && currentRank === 0 && <small className="skill-req">{reason}</small>}
            </div>
            <button className="btn" disabled={!can || isActionLocked} onClick={() => onLearn(id)}>
              {currentRank > 0 ? 'Improve' : 'Learn'}
            </button>
          </div>
        );
      })}
    </>
  );
};

export const SkillsModal: React.FC = () => {
  const player = usePlayer();
  const GAME_DATA = useContext(GameDataContext)!;
  const { learnAbility, learnPerk, toggleFavoriteAbility, favoriteAbilities, perkPoints } = useAbilities();
  const { setActiveModal } = useContext(UIContext)!;
  const { withActionLock } = useContext(WorldContext)!;
  const [tab, setTab] = useState<'abilities' | 'skills'>('abilities');

  const unlearnedAbilityIds = useMemo(() => getUnlearnedAbilities(player, GAME_DATA), [player, GAME_DATA]);
  const groupedUnlearned = useMemo(() => groupAbilitiesByTypeAndCategory(unlearnedAbilityIds, GAME_DATA), [unlearnedAbilityIds, GAME_DATA]);

  if (!player) return null;

  const handleLearn = (id: AbilityId) => {
    withActionLock?.(() => {
      const abilityData = GAME_DATA.SKILLS[id];
      if (abilityData?.abilityType === 'Perk') {
        learnPerk(id);
      } else {
        learnAbility(id);
      }
    });
  };

  const renderSkillGroups = (abilityType: 'active' | 'passive') => {
    const abilities = groupedUnlearned[abilityType] || {};
    if (Object.keys(abilities).length === 0) {
      return <p>No new {abilityType === 'active' ? 'skills or spells' : 'perks'} available to learn.</p>;
    }
    return Object.entries(abilities)
      .sort(([catA], [catB]) => catA.localeCompare(catB))
      .map(([category, abilityList]) => (
        <div key={category} className="perk-category">
          <h3>{category}</h3>
          <SkillGroup abilities={abilityList} onLearn={handleLearn} />
        </div>
      ));
  };

  return (
    <Modal title="Skills & Perks" onClose={() => setActiveModal(null)} size="xlarge">
      <h3>
        Available Perk Points: <span className="points-available">{perkPoints}</span>
      </h3>
      <div className="tabs">
        <button className={`tab-btn ${tab === 'abilities' ? 'active' : ''}`} onClick={() => setTab('abilities')}>
          My Abilities & Perks
        </button>
        <button className={`tab-btn ${tab === 'skills' ? 'active' : ''}`} onClick={() => setTab('skills')}>
          Learn New Abilities
        </button>
      </div>
      <div className="tab-content">
        {tab === 'abilities' && (
          <>
            <AbilitiesPanel character={player} onFavoriteToggle={toggleFavoriteAbility} favoriteAbilities={favoriteAbilities} />
            <hr className="stat-divider" />
            <PerkPanel />
          </>
        )}
        {tab === 'skills' && (
          <div className="skills-list">
            <h3>Active Skills & Spells</h3>
            {renderSkillGroups('active')}

            <h3 style={{ marginTop: '10px' }}>Passive Perks</h3>
            {renderSkillGroups('passive')}
          </div>
        )}
      </div>
    </Modal>
  );
};