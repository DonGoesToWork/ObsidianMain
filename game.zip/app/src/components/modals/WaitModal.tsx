import { AlertnessLevel, AppraiseOptions, ItemId, RestOptions } from '../../types';
import React, { useContext, useMemo, useState } from 'react';
import { calculateTimeToFullHeal, calculateTimeToFullHealForParty } from 'utils/playerUtils';

import { GameDataContext } from 'context/GameDataContext';
import { Modal } from './Modal';
import { UIContext } from 'context/UIContext';
import { WorldContext } from 'context/WorldContext';
import { usePlayer } from 'hooks/usePlayer';

const alertnessDescriptions: Record<AlertnessLevel, string> = {
  passive: 'Normal rest. 150% Regen Rate. Normal encounter chance.',
  'half-awake': 'Eyes closed, ears open. 125% Regen Rate. 50% reduced encounter chance.',
  'fully-alert': 'Sitting around awake. 100% Regen Rate. 90% reduced encounter chance.',
};

const RestTab: React.FC = () => {
  const player = usePlayer();
  const { setActiveModal } = useContext(UIContext)!;
  const { passTime } = useContext(WorldContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const [alertness, setAlertness] = useState<AlertnessLevel>('passive');
  const [aids, setAids] = useState<ItemId[]>([]); // Future-proofing for rest aids

  const timeToFullHeal = useMemo(() => {
    if (!player) return { minutes: 0, formatted: '0s' };
    return calculateTimeToFullHeal(player, alertness, aids, GAME_DATA);
  }, [player, alertness, aids, GAME_DATA]);

  const timeToFullPartyHeal = useMemo(() => {
    if (!player) return { minutes: 0, formatted: '0s' };
    return calculateTimeToFullHealForParty(player, alertness, aids, GAME_DATA);
  }, [player, alertness, aids, GAME_DATA]);

  const handleFullRest = () => {
    if (timeToFullHeal.minutes <= 0 || timeToFullHeal.minutes === Infinity) return;

    const restOptions: RestOptions = {
      isResting: true,
      alertnessLevel: alertness,
      aids,
    };
    passTime(timeToFullHeal.minutes, restOptions);
    setActiveModal(null);
  };

  const handleFullPartyRest = () => {
    if (timeToFullPartyHeal.minutes <= 0 || timeToFullPartyHeal.minutes === Infinity) return;
    const restOptions: RestOptions = {
      isResting: true,
      alertnessLevel: alertness,
      aids,
    };
    passTime(timeToFullPartyHeal.minutes, restOptions);
    setActiveModal(null);
  };

  const handleQuickRest = (seconds: number) => {
    if (seconds <= 0) return;

    const restOptions: RestOptions = {
      isResting: true,
      alertnessLevel: alertness,
      aids,
    };
    passTime(seconds / 60, restOptions);
    setActiveModal(null);
  };

  const restButtonsConfig = [
    { label: 'Seconds', unit: 's', values: [6, 12, 18] },
    { label: 'Minutes', unit: 'm', values: [1, 2, 5, 15] },
    { label: 'Hours', unit: 'h', values: [1, 2, 4, 8, 24] },
  ];

  return (
    <div>
      <h1>Rest</h1>
      <p>You find a relatively safe place to make camp.</p>
      <div className="section-divider">
        <h3>Alertness Level</h3>
        <p style={{ color: '#ccc', fontSize: '0.9em', minHeight: '40px', marginTop: '5px' }}>{alertnessDescriptions[alertness]}</p>
        <div className="action-grid">
          <button onClick={() => setAlertness('passive')} className={`btn ${alertness === 'passive' ? 'selected' : ''}`}>
            Passive
          </button>
          <button onClick={() => setAlertness('half-awake')} className={`btn ${alertness === 'half-awake' ? 'selected' : ''}`}>
            Half-Awake
          </button>
          <button onClick={() => setAlertness('fully-alert')} className={`btn ${alertness === 'fully-alert' ? 'selected' : ''}`}>
            Fully Alert
          </button>
        </div>
      </div>
      <div className="section-divider">
        <h3>Quick Rest</h3>
        {restButtonsConfig.map((row) => (
          <div key={row.label} style={{ marginBottom: '10px' }}>
            <p style={{ marginBottom: '5px', color: '#ccc' }}>{row.label}</p>
            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
              {row.values.map((value) => {
                const seconds = row.unit === 's' ? value : row.unit === 'm' ? value * 60 : value * 3600;
                return (
                  <button key={value} className="btn" onClick={() => handleQuickRest(seconds)} style={{ minWidth: 'auto', flex: '1' }}>
                    {value}
                    {row.unit}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '10px' }}>
          <button
            className="btn"
            onClick={handleFullRest}
            disabled={timeToFullHeal.minutes <= 0 || timeToFullHeal.minutes === Infinity}
            style={{ flex: '1', height: 'auto', padding: '10px', lineHeight: '1.4' }}
          >
            Full Rest
            <br />
            <small>[ {timeToFullHeal.formatted} ]</small>
          </button>
          <button
            className="btn"
            onClick={handleFullPartyRest}
            disabled={timeToFullPartyHeal.minutes <= 0 || timeToFullPartyHeal.minutes === Infinity}
            style={{ flex: '1', height: 'auto', padding: '10px', lineHeight: '1.4' }}
          >
            Full Party Rest
            <br />
            <small>[ {timeToFullPartyHeal.formatted} ]</small>
          </button>
        </div>
      </div>
    </div>
  );
};

const AppraiseTab: React.FC = () => {
  const player = usePlayer();
  const { setActiveModal } = useContext(UIContext)!;
  const { passTime } = useContext(WorldContext)!;

  const unidentifiedItemsCount = useMemo(() => {
    return player?.inventory.filter((i) => i.isUnidentified).length ?? 0;
  }, [player]);

  const handleAppraise = (hours: number) => {
    const appraiseOptions: AppraiseOptions = { isAppraising: true };
    passTime(hours * 60, appraiseOptions);
    setActiveModal(null);
  };

  const appraiseButtons = [1, 2, 4, 8, 16, 24];

  return (
    <div>
      <h1>Appraise</h1>
      <p>You can spend time meticulously examining your gear to uncover its hidden properties. The longer you spend, the more you might discover.</p>
      <p style={{ marginTop: '15px' }}>
        You have <strong style={{ color: '#a335ee' }}>{unidentifiedItemsCount}</strong> items with unknown magic.
      </p>
      <div className="section-divider">
        <h3>Appraise for...</h3>
        <div className="action-grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
          {appraiseButtons.map((hours) => (
            <button key={hours} className="btn" onClick={() => handleAppraise(hours)}>
              {hours} Hour{hours > 1 ? 's' : ''}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export const WaitModal: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'Rest' | 'Appraise'>('Rest');
  const { setActiveModal } = useContext(UIContext)!;
  return (
    <Modal title="Wait" onClose={() => setActiveModal(null)} size="medium">
      <div className="tabs">
        <button className={`tab-btn ${activeTab === 'Rest' ? 'active' : ''}`} onClick={() => setActiveTab('Rest')}>
          Rest
        </button>
        <button className={`tab-btn ${activeTab === 'Appraise' ? 'active' : ''}`} onClick={() => setActiveTab('Appraise')}>
          Appraise
        </button>
      </div>
      <div className="tab-content" style={{ paddingTop: '15px' }}>
        {activeTab === 'Rest' ? <RestTab /> : <AppraiseTab />}
      </div>
    </Modal>
  );
};
