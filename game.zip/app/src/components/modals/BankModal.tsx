import { UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import { getStandardInventoryColumns } from 'config/inventoryColumns';
import { GameDataContext } from 'context/GameDataContext';
import { UIContext } from 'context/UIContext';
import { useInventory } from 'hooks/useInventory';
import { useModalState } from 'hooks/useModalState';
import React, { useContext, useMemo } from 'react';
import { ItemInstance } from 'types';
import { Modal } from './Modal';

export const BankModal: React.FC = () => {
  const { inventory, bank, moveItemToBank, moveItemFromBank } = useInventory();
  const GAME_DATA = useContext(GameDataContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  const STANDARD_INVENTORY_COLUMNS = useMemo(() => getStandardInventoryColumns(GAME_DATA), [GAME_DATA]);

  const playerState = useModalState('bank', 'player');
  const bankState = useModalState('bank', 'bank');

  if (!inventory || !bank)
    return (
      <Modal title="Bank" onClose={() => setActiveModal(null)}>
        <p>Loading...</p>
      </Modal>
    );

  const handleTransferToBank = (item: ItemInstance, quantity: number, _originalIndices: number[]) => {
    moveItemToBank(item.unique_id, quantity);
  };

  const handleTransferFromBank = (item: ItemInstance, quantity: number, _originalIndices: number[]) => {
    moveItemFromBank(item.unique_id, quantity);
  };

  return (
    <Modal title="Bank" onClose={() => setActiveModal(null)} size="xlarge">
      <div className="shop-layout">
        <div className="shop-panel">
          <UnifiedInventoryDisplay
            title="Your Inventory"
            items={inventory}
            onTransfer={handleTransferToBank}
            transferButtonText="Deposit"
            showTransferControls={true}
            columns={STANDARD_INVENTORY_COLUMNS}
            viewMode={playerState.viewMode}
            onViewModeChange={playerState.setViewMode}
            transferAmount={playerState.transferAmount}
            onTransferAmountChange={playerState.setTransferAmount}
            showFilterSearchBar={true}
            showFilterButtonBar={true}
          />
        </div>
        <div className="shop-panel">
          <UnifiedInventoryDisplay
            title="Bank Storage"
            items={bank}
            onTransfer={handleTransferFromBank}
            transferButtonText="Withdraw"
            showTransferControls={true}
            columns={STANDARD_INVENTORY_COLUMNS}
            viewMode={bankState.viewMode}
            onViewModeChange={bankState.setViewMode}
            transferAmount={bankState.transferAmount}
            onTransferAmountChange={bankState.setTransferAmount}
            showFilterSearchBar={true}
            showFilterButtonBar={true}
          />
        </div>
      </div>
    </Modal>
  );
};