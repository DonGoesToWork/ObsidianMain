import React, { useContext, useMemo } from "react";
import { Modal } from "./Modal";
import { UnifiedInventoryDisplay } from "components/shared/UnifiedInventoryDisplay";
import { ItemInstance } from "types";
import { useInventory } from "hooks/useInventory";
import { UIContext } from "context/UIContext";
import { useModalState } from "hooks/useModalState";
import { getStandardInventoryColumns } from "config/inventoryColumns";
import { GameDataContext } from "context/GameDataContext";

export const BankModal: React.FC = () => {
  const { inventory, bank, moveItemsToBank, moveItemsFromBank } = useInventory();
  const GAME_DATA = useContext(GameDataContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  const STANDARD_INVENTORY_COLUMNS = useMemo(() => getStandardInventoryColumns(GAME_DATA), [GAME_DATA]);

  const playerState = useModalState("bank", "player");
  const bankState = useModalState("bank", "bank");

  if (!inventory || !bank)
    return (
      <Modal title="Bank" onClose={() => setActiveModal(null)}>
        <p>Loading...</p>
      </Modal>
    );

  const handleTransferToBank = (_item: ItemInstance, quantity: number, indices: number[]) => {
    const idsToMove = indices.slice(0, quantity).map((i) => inventory[i].unique_id);
    moveItemsToBank(idsToMove);
  };

  const handleTransferFromBank = (_item: ItemInstance, quantity: number, indices: number[]) => {
    const idsToMove = indices.slice(0, quantity).map((i) => bank[i].unique_id);
    moveItemsFromBank(idsToMove);
  };

  return (
    <Modal title="Bank" onClose={() => setActiveModal(null)} size="xlarge">
      <div className="shop-layout">
        <div className="shop-panel">
          <UnifiedInventoryDisplay
            title="Your Inventory"
            items={inventory}
            onTransfer={handleTransferToBank}
            transferButtonText="Deposit"
            showTransferControls={true}
            columns={STANDARD_INVENTORY_COLUMNS}
            viewMode={playerState.viewMode}
            onViewModeChange={playerState.setViewMode}
            transferAmount={playerState.transferAmount}
            onTransferAmountChange={playerState.setTransferAmount}
          />
        </div>
        <div className="shop-panel">
          <UnifiedInventoryDisplay
            title="Bank Storage"
            items={bank}
            onTransfer={handleTransferFromBank}
            transferButtonText="Withdraw"
            showTransferControls={true}
            columns={STANDARD_INVENTORY_COLUMNS}
            viewMode={bankState.viewMode}
            onViewModeChange={bankState.setViewMode}
            transferAmount={bankState.transferAmount}
            onTransferAmountChange={bankState.setTransferAmount}
          />
        </div>
      </div>
    </Modal>
  );
};