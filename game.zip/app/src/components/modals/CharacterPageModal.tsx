import React, { useContext } from 'react';

import { InventoryPanel } from 'components/inventory/InventoryPanel';
import { PlayerContext } from 'context/PlayerContext';
import { UIContext } from 'context/UIContext';
import { CharacterTabs } from '../character/CharacterTabs';
import { CharacterVitalsPanel } from '../character/CharacterVitalsPanel';
import { EquipmentPanel } from '../character/EquipmentPanel';
import { Modal } from '../modals/Modal';

export const CharacterPageModal: React.FC = () => {
  const { player } = useContext(PlayerContext)!;
  const { setActiveModal } = useContext(UIContext)!;

  if (!player) return null;
  return (
    <Modal title="Character" onClose={() => setActiveModal(null)} size="xlarge">
      <div className="character-page-layout">
        <div className="character-page-col">
          <div className="panel" style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            <CharacterVitalsPanel character={player} />
          </div>
        </div>
        <div className="character-page-col">
          <EquipmentPanel />
        </div>
        <div className="character-page-col">
          <InventoryPanel useHistoryForContainers={true} />
        </div>
        <div className="character-page-col">
          <CharacterTabs />
        </div>
      </div>
    </Modal>
  );
};
