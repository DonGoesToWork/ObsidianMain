import { CharacterTabs } from 'components/character/CharacterTabs';
import { CharacterVitalsPanel } from 'components/character/CharacterVitalsPanel';
import { UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import { UIContext } from 'context/UIContext';
import { useModalState } from 'hooks/useModalState';
import React, { useContext } from 'react';
import { Combatant } from 'types';
import { EquipmentDisplay } from '../shared/EquipmentDisplay';
import { Modal } from './Modal';

export const InspectModal: React.FC<{ combatant: Combatant | undefined }> = ({ combatant }) => {
  const { setActiveModal } = useContext(UIContext)!;
  const { viewMode, setViewMode } = useModalState('inspect', combatant?.id);

  if (!combatant) return null;

  return (
    <Modal title={`Inspect: ${combatant.name}`} onClose={() => setActiveModal(null)} size="xlarge">
      <div className="character-page-layout modal-inspect">
        <div className="character-page-col">
          <div className="panel" style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            <CharacterVitalsPanel character={combatant} layoutMode="stack" />
          </div>
        </div>
        <div className="character-page-col">
          <div className="equipment-panel">
            <h3>Equipment</h3>
            {combatant.equipment && <EquipmentDisplay equipment={combatant.equipment} />}
          </div>
        </div>
        <div className="character-page-col">
          <UnifiedInventoryDisplay
            title="Inventory"
            items={combatant.inventory || []}
            showFilterSearchBar={false}
            showFilterButtonBar={false}
            showSortButtons={false}
            showViewToggle={true}
            viewMode={viewMode}
            onViewModeChange={setViewMode}
          />
        </div>
        <div className="character-page-col">
          <CharacterTabs character={combatant} />
        </div>
      </div>
    </Modal>
  );
};
