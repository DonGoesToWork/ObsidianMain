import { Ability, AbilityId } from '../../types';
import React, { useContext } from 'react';
import { canLearnAbility, getAbilityDescription, groupAbilitiesByTypeAndCategory } from 'utils/abilityUtils';

import { GameDataContext } from 'context/GameDataContext';
import { Modal } from './Modal';
import { UIContext } from 'context/UIContext';
import { useAbilities } from 'hooks/useAbilities';
import { usePlayer } from 'hooks/usePlayer';

interface PerkGroupProps {
  abilities: [AbilityId, Ability][];
  learnPerk: (id: AbilityId) => void;
}

const PerkGroup: React.FC<PerkGroupProps> = ({ abilities, learnPerk }) => {
  const player = usePlayer()!;
  const GAME_DATA = useContext(GameDataContext)!;
  return (
    <>
      {abilities.map(([id, ability]) => {
        const currentRank = player.skills[id]?.rank || 0;
        const { can, reason } = canLearnAbility(player, id, GAME_DATA);
        const desc = getAbilityDescription(ability, currentRank > 0 ? currentRank : 1);

        // Don't show skills or spells here.
        if (ability.abilityType !== 'Perk') {
          return null;
        }

        return (
          <div key={id} className={`skill-entry ${!can && currentRank === 0 ? 'locked' : ''}`}>
            <div className="skill-info">
              <h3>
                {ability.name} {currentRank > 0 && `(Rank ${currentRank})`}
              </h3>
              <p>{desc}</p>
              {reason && currentRank === 0 && <small className="skill-req">{reason}</small>}
            </div>
            <button className="btn" disabled={!can} onClick={() => learnPerk(id)}>
              {currentRank > 0 ? 'Improve' : 'Learn'}
            </button>
          </div>
        );
      })}
    </>
  );
};

export const PerksModal: React.FC = () => {
  const { learnedPerks, learnPerk, perkPoints } = useAbilities();
  const GAME_DATA = useContext(GameDataContext)!;
  const { setActiveModal } = React.useContext(UIContext)!;

  const availablePerks = React.useMemo(() => {
    return (Object.keys(GAME_DATA.SKILLS) as AbilityId[]).filter((id) => {
      const ability = GAME_DATA.SKILLS[id];
      if (!ability || ability.abilityType !== 'Perk') return false;
      const currentRank = learnedPerks.find((p) => p === id) ? 1 : 0; // simplified
      return !(ability.maxRank && currentRank >= ability.maxRank);
    });
  }, [learnedPerks, GAME_DATA.SKILLS]);

  const groupedAvailable = React.useMemo(() => groupAbilitiesByTypeAndCategory(availablePerks, GAME_DATA).passive || {}, [availablePerks, GAME_DATA]);
  const groupedLearned = React.useMemo(() => groupAbilitiesByTypeAndCategory(learnedPerks, GAME_DATA).passive || {}, [learnedPerks, GAME_DATA]);

  const renderPerkGroups = (groupedAbilities: Record<string, [AbilityId, Ability][]>) => {
    if (Object.keys(groupedAbilities).length === 0) {
      return <p>No perks in this category.</p>;
    }
    return Object.entries(groupedAbilities)
      .sort(([catA], [catB]) => catA.localeCompare(catB))
      .map(([category, abilityList]) => (
        <div key={category} className="perk-category">
          <h3>{category}</h3>
          <PerkGroup abilities={abilityList} learnPerk={learnPerk} />
        </div>
      ));
  };

  return (
    <Modal title="Perks" onClose={() => setActiveModal(null)} size="large">
      <h3>
        Available Perk Points: <span className="points-available">{perkPoints}</span>
      </h3>
      <div className="skills-list">
        <h3>Available Perks</h3>
        {renderPerkGroups(groupedAvailable)}

        <h3 style={{ marginTop: '10px' }}>Learned Perks</h3>
        {renderPerkGroups(groupedLearned)}
      </div>
    </Modal>
  );
};
