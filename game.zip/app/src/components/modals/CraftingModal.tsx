import { GameData, ItemId, ItemInstance, RequirementStatus } from 'types';
import React, { useContext, useMemo, useState } from 'react';
import { calculateItemLevel, countItems } from 'utils/itemUtils';
import { getCraftingChecks, getRepairChecks, getRequirementStatus, getUpgradeChecks } from 'utils/craftingUtils';

import { CreatePanel } from '../crafting/CreatePanel';
import { EnchantingPanel } from '../crafting/EnchantingPanel';
import { GameDataContext } from 'context/GameDataContext';
import { Modal } from './Modal';
import { RepairPanel } from '../crafting/RepairPanel';
import { UIContext } from 'context/UIContext';
import { UpgradePanel } from '../crafting/UpgradePanel';
import { WorldContext } from 'context/WorldContext';
import { useInventory } from 'hooks/useInventory';
import { usePlayer } from 'hooks/usePlayer';

type CraftingMode = 'Create' | 'Repair' | 'Upgrade' | 'Enchanting';

export const CraftingModal: React.FC = () => {
  const player = usePlayer();
  const { gold } = useInventory();
  const { gameTime, currentLocation } = useContext(WorldContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  const GAME_DATA = useContext(GameDataContext)!;

  const [activeMode, setActiveMode] = useState<CraftingMode>('Create');

  const tabStatuses = useMemo(() => {
    if (!player) return {};

    const getListStatus = (items: any[], type: CraftingMode): RequirementStatus => {
      if (items.length === 0) return 'none';
      const statuses = items.map((item) => item.requirementStatus);
      if (statuses.some((s) => s === 'full')) return 'full';
      if (statuses.some((s) => s === 'partial')) return 'partial';
      return 'none';
    };

    const createList = Object.values(GAME_DATA.ALL_RECIPES)
      .filter((r) => player.knownRecipes[r.id])
      .map((r) => ({ requirementStatus: getRequirementStatus(getCraftingChecks(player, r, [], currentLocation, true, GAME_DATA, { checkInventoryForTools: true })) }));

    const repairableItems = [...player.inventory, ...Object.values(player.equipment).filter((i): i is ItemInstance => !!i)]
      .filter((item: ItemInstance) => {
        if (!item?.id || !GAME_DATA.ITEMS[item.id]) {
          if (item) console.warn('Item data not found in GAME_DATA for repair check:', item.id);
          return false;
        }
        const data = GAME_DATA.ITEMS[item.id];
        return (
          data.type.includes('equipment') &&
          item.currentDurability !== undefined &&
          item.maxDurability !== undefined &&
          item.currentDurability < item.maxDurability &&
          !item.isUnrepairable &&
          !item.isUnidentified &&
          data.recipeId &&
          player.knownRecipes[data.recipeId]
        );
      })
      .map((item) => {
        const itemData = GAME_DATA.ITEMS[item.id];
        const recipe = itemData.recipeId ? GAME_DATA.ALL_RECIPES[itemData.recipeId] : null;
        return { requirementStatus: getRequirementStatus(getRepairChecks(player, recipe, player.inventory, player.inventory, currentLocation, GAME_DATA, true)) };
      });

    const upgradeableItems = [...player.inventory, ...Object.values(player.equipment).filter((i): i is ItemInstance => !!i)]
      .filter((item: ItemInstance) => {
        if (!item?.id || !GAME_DATA.ITEMS[item.id]) {
          if (item) console.warn('Item data not found in GAME_DATA for upgrade check:', item.id);
          return false;
        }
        const data = GAME_DATA.ITEMS[item.id];
        const itemLevel = calculateItemLevel(item, GAME_DATA);
        const itemTier = Math.floor(itemLevel / 10) + 1;
        const currentPlus = item.plus_value || 0;
        return data.type.includes('equipment') && data.recipeId && currentPlus < itemTier && !item.isUnidentified && player.knownRecipes[data.recipeId!];
      })
      .map((item) => ({ requirementStatus: getRequirementStatus(getUpgradeChecks(player, item, GAME_DATA)) }));

    const enchantingItems =
      player?.inventory.filter((item: ItemInstance) => {
        const itemData = GAME_DATA.ITEMS[item.id];
        return itemData.type.includes('equipment') && !item.isUnidentified && !itemData.isUnarmed;
      }) || [];

    let canEnchantSomething = false;
    if (enchantingItems.length > 0) {
      for (const item of enchantingItems) {
        const itemData = GAME_DATA.ITEMS[item.id];
        const availableEnchants = GAME_DATA.ENCHANTS.filter((enchant) => {
          if (enchant.type === 'global') {
            return true;
          }
          if (enchant.type === 'local') {
            if (!enchant.appliesTo) {
              return true; // Universal local enchant
            }
            const { hasStat, hasItemType } = enchant.appliesTo;

            if ((!hasStat || hasStat.length === 0) && (!hasItemType || hasItemType.length === 0)) return true;

            const itemStats = itemData.stats || {};
            const itemTypes = itemData.type || [];

            const statMatch = hasStat && hasStat.some((s) => itemStats[s] !== undefined);
            const typeMatch = hasItemType && hasItemType.some((t) => itemTypes.includes(t));

            return !!(statMatch || typeMatch);
          }
          return false;
        });

        for (const enchantDef of availableEnchants) {
          const currentTier = item.enchantments[enchantDef.id] || 0;
          if (currentTier >= enchantDef.scaling.length) continue;

          const nextRank = currentTier;
          const cost = enchantDef.cost[nextRank];
          if (!cost) continue;

          const crystalId = Object.keys(cost)[0] as ItemId;
          const crystalCostCount = cost[crystalId];
          if (countItems(player.inventory, crystalId) >= crystalCostCount) {
            canEnchantSomething = true;
            break;
          }
        }
        if (canEnchantSomething) break;
      }
    }

    return {
      Create: getListStatus(createList, 'Create'),
      Repair: getListStatus(repairableItems, 'Repair'),
      Upgrade: getListStatus(upgradeableItems, 'Upgrade'),
      Enchanting: canEnchantSomething ? 'full' : 'none',
    };
  }, [player, currentLocation, GAME_DATA]);

  if (!player || gold === undefined) return null;

  return (
    <Modal
      title={'Crafting'}
      subTitle={`Location: ${currentLocation?.name} - Time: ${gameTime.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      })}`}
      onClose={() => setActiveModal(null)}
      size="xlarge"
    >
      <span></span>
      <div className="tabs">
        <button className={`tab-btn ${activeMode === 'Create' ? 'active' : ''}`} onClick={() => setActiveMode('Create')}>
          Create <span className={`req-indicator ${tabStatuses.Create}`}></span>
        </button>
        <button className={`tab-btn ${activeMode === 'Repair' ? 'active' : ''}`} onClick={() => setActiveMode('Repair')}>
          Repair <span className={`req-indicator ${tabStatuses.Repair}`}></span>
        </button>
        <button className={`tab-btn ${activeMode === 'Upgrade' ? 'active' : ''}`} onClick={() => setActiveMode('Upgrade')}>
          Upgrade <span className={`req-indicator ${tabStatuses.Upgrade}`}></span>
        </button>
        <button className={`tab-btn ${activeMode === 'Enchanting' ? 'active' : ''}`} onClick={() => setActiveMode('Enchanting')}>
          Enchant <span className={`req-indicator ${tabStatuses.Enchanting}`}></span>
        </button>
      </div>
      <div className="tab-content" style={{ display: 'flex', flexGrow: 1, minHeight: 0 }}>
        {activeMode === 'Create' && <CreatePanel />}
        {activeMode === 'Repair' && <RepairPanel />}
        {activeMode === 'Upgrade' && <UpgradePanel />}
        {activeMode === 'Enchanting' && <EnchantingPanel />}
      </div>
    </Modal>
  );
};