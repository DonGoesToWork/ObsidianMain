import React, { useState, useContext } from 'react';
import { Modal } from './Modal';
import { CreatePanel } from '../crafting/CreatePanel';
import { RepairPanel } from '../crafting/RepairPanel';
import { UpgradePanel } from '../crafting/UpgradePanel';
import { EnchantingPanel } from '../crafting/EnchantingPanel';
import { WorldContext } from 'context/WorldContext';
import { UIContext } from 'context/UIContext';
import { useInventory } from 'hooks/useInventory';
import { usePlayer } from 'hooks/usePlayer';

type CraftingMode = 'Create' | 'Repair' | 'Upgrade' | 'Enchanting';

export const CraftingModal: React.FC = () => {
  const player = usePlayer();
  const { gold } = useInventory();
  const { gameTime, currentLocation } = useContext(WorldContext)!;
  const { setActiveModal } = useContext(UIContext)!;

  const [activeMode, setActiveMode] = useState<CraftingMode>('Create');

  if (!player || gold === undefined) return null;

  return (
    <Modal
      title={'Crafting'}
      subTitle={`Location: ${currentLocation?.name} - Time: ${gameTime.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      })} - Gold: ${gold.toLocaleString()}`}
      onClose={() => setActiveModal(null)}
      size="xlarge"
    >
      <span></span>
      <div className="tabs">
        <button className={`tab-btn ${activeMode === 'Create' ? 'active' : ''}`} onClick={() => setActiveMode('Create')}>
          Create
        </button>
        <button className={`tab-btn ${activeMode === 'Repair' ? 'active' : ''}`} onClick={() => setActiveMode('Repair')}>
          Repair
        </button>
        <button className={`tab-btn ${activeMode === 'Upgrade' ? 'active' : ''}`} onClick={() => setActiveMode('Upgrade')}>
          Upgrade
        </button>
        <button className={`tab-btn ${activeMode === 'Enchanting' ? 'active' : ''}`} onClick={() => setActiveMode('Enchanting')}>
          Enchanting
        </button>
      </div>
      <div className="tab-content" style={{ display: 'flex', flexGrow: 1, minHeight: 0 }}>
        {activeMode === 'Create' && <CreatePanel />}
        {activeMode === 'Repair' && <RepairPanel />}
        {activeMode === 'Upgrade' && <UpgradePanel />}
        {activeMode === 'Enchanting' && <EnchantingPanel />}
      </div>
    </Modal>
  );
};
