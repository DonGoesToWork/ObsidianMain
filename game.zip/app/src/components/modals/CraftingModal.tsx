import { UIContext } from 'context/UIContext';
import { WorldContext } from 'context/WorldContext';
import { useCraftingTabs } from 'hooks/useCraftingTabs';
import React, { useContext, useState } from 'react';
import { CreatePanel } from '../crafting/CreatePanel';
import { EnchantingPanel } from '../crafting/EnchantingPanel';
import { RepairPanel } from '../crafting/RepairPanel';
import { UpgradePanel } from '../crafting/UpgradePanel';
import { Modal } from './Modal';

type CraftingMode = 'Create' | 'Repair' | 'Upgrade' | 'Enchanting';

export const CraftingModal: React.FC = () => {
  const { gameTime, currentLocation } = useContext(WorldContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  const tabStatuses = useCraftingTabs();
  const [activeMode, setActiveMode] = useState<CraftingMode>('Create');

  return (
    <Modal
      title={'Crafting'}
      subTitle={`Location: ${currentLocation?.name} - Time: ${gameTime.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      })}`}
      onClose={() => setActiveModal(null)}
      size="xlarge"
    >
      <span></span>
      <div className="tabs">
        <button className={`tab-btn ${activeMode === 'Create' ? 'active' : ''}`} onClick={() => setActiveMode('Create')}>
          Create <span className={`req-indicator ${tabStatuses.Create}`}></span>
        </button>
        <button className={`tab-btn ${activeMode === 'Repair' ? 'active' : ''}`} onClick={() => setActiveMode('Repair')}>
          Repair <span className={`req-indicator ${tabStatuses.Repair}`}></span>
        </button>
        <button className={`tab-btn ${activeMode === 'Upgrade' ? 'active' : ''}`} onClick={() => setActiveMode('Upgrade')}>
          Upgrade <span className={`req-indicator ${tabStatuses.Upgrade}`}></span>
        </button>
        <button className={`tab-btn ${activeMode === 'Enchanting' ? 'active' : ''}`} onClick={() => setActiveMode('Enchanting')}>
          Enchant <span className={`req-indicator ${tabStatuses.Enchanting}`}></span>
        </button>
      </div>
      <div className="tab-content" style={{ display: 'flex', flexGrow: 1, minHeight: 0 }}>
        {activeMode === 'Create' && <CreatePanel />}
        {activeMode === 'Repair' && <RepairPanel />}
        {activeMode === 'Upgrade' && <UpgradePanel />}
        {activeMode === 'Enchanting' && <EnchantingPanel />}
      </div>
    </Modal>
  );
};
