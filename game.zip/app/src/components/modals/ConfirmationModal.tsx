import React, { useContext } from "react";
import { Modal } from "./Modal";
import { UIContext } from "context/UIContext";

interface ConfirmationModalProps {
  title: string;
  message: React.ReactNode;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmationModal: React.FC<ConfirmationModalProps> = ({
  title,
  message,
  onConfirm,
  onCancel,
}) => {
  return (
    <Modal title={title} onClose={onCancel} size="small">
      <p>{message}</p>
      <div className="modal-footer-actions">
        <div className="action-grid" style={{ gridTemplateColumns: "1fr 1fr" }}>
          <button className="btn" onClick={onConfirm}>
            Yes
          </button>
          <button className="btn btn-secondary" onClick={onCancel}>
            No
          </button>
        </div>
      </div>
    </Modal>
  );
};