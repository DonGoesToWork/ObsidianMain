import React, { useContext } from 'react';
import { WorldContext } from 'context/WorldContext';
import { Modal } from './Modal';

interface ConfirmationModalProps {
  title: string;
  message: React.ReactNode;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ title, message, onConfirm, onCancel }) => {
  const { isActionLocked } = useContext(WorldContext)!;
  return (
    <Modal title={title} onClose={onCancel} size="small">
      <p>{message}</p>
      <div className="modal-footer-actions">
        <div className="action-grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <button className="btn" onClick={onConfirm} disabled={isActionLocked}>
            Yes
          </button>
          <button className="btn btn-secondary" onClick={onCancel} disabled={isActionLocked}>
            No
          </button>
        </div>
      </div>
    </Modal>
  );
};