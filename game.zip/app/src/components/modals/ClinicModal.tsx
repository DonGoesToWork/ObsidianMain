import { ItemInstance, Mercenary, Player } from 'types';
import React, { useContext } from 'react';

import { Modal } from './Modal';
import { UIContext } from 'context/UIContext';
import { isCombatantDefeated } from 'utils/combatUtils';
import { useInventory } from 'hooks/useInventory';
import { useParty } from 'hooks/useParty';
import { usePlayer } from 'hooks/usePlayer';

const HEAL_BROKEN_LIMB_COST = 10000;
const REVIVE_ALLY_COST = 50000;

const CharacterClinicCard: React.FC<{ character: Player | Mercenary }> = ({ character }) => {
  const { gold } = useInventory();
  const { healBrokenLimb, reviveDownedAlly } = useParty();

  const defeated = isCombatantDefeated(character as any);
  const isPlayerCharacter = 'professions' in character;

  return (
    <div className="clinic-character-card">
      <h3>{character.name}</h3>
      <div className="clinic-limb-list">
        {defeated ? (
          <div className="clinic-service-item">
            <span>Character is Down</span>
            {!isPlayerCharacter && (
              <button className="btn" disabled={(gold || 0) < REVIVE_ALLY_COST} onClick={() => reviveDownedAlly((character as Mercenary).id)}>
                Revive ({REVIVE_ALLY_COST.toLocaleString()}g)
              </button>
            )}
          </div>
        ) : (
          Object.values(character.body).map((limb) =>
            limb.state === 'Destroyed' ? (
              <div key={limb.id} className="clinic-service-item">
                <span>
                  {limb.displayName} <span className="destroyed-text">(Destroyed)</span>
                </span>
                <button
                  className="btn"
                  disabled={(gold || 0) < HEAL_BROKEN_LIMB_COST}
                  onClick={() => healBrokenLimb(isPlayerCharacter ? 'player' : (character as Mercenary).id, limb.id)}
                >
                  Heal ({HEAL_BROKEN_LIMB_COST.toLocaleString()}g)
                </button>
              </div>
            ) : null
          )
        )}
        {!defeated && Object.values(character.body).every((l) => l.state !== 'Destroyed') && <p className="no-services-text">No limbs require healing.</p>}
      </div>
    </div>
  );
};

const CorpseClinicCard: React.FC<{ corpse: ItemInstance }> = ({ corpse }) => {
  const { gold } = useInventory();
  const { reviveFallenAlly, party } = useParty();
  const deceasedChar = corpse.deceasedCharacter;

  if (!deceasedChar) return null;

  const canAfford = (gold || 0) >= REVIVE_ALLY_COST;
  const partyHasSpace = (party?.length || 0) < 3;
  const itemsInCorpse = corpse.containerState?.items.length || 0;

  return (
    <div className="clinic-character-card">
      <h3>Corpse of {deceasedChar.name}</h3>
      <div className="clinic-limb-list">
        <div className="clinic-service-item">
          <span>Character can be revived.</span>
          <button className="btn" disabled={!canAfford || !partyHasSpace} onClick={() => reviveFallenAlly(corpse)}>
            Revive ({REVIVE_ALLY_COST.toLocaleString()}g)
          </button>
        </div>
        {!canAfford && <p className="no-services-text req-fail">Not enough gold.</p>}
        {!partyHasSpace && <p className="no-services-text req-fail">Your party is full.</p>}
        {itemsInCorpse > 0 && <p className="no-services-text req-fail">Warning: Loot corpse before reviving or items will be lost!</p>}
      </div>
    </div>
  );
};

export const ClinicModal: React.FC = () => {
  const player = usePlayer();
  const { inventory } = useInventory();
  const { setActiveModal } = useContext(UIContext)!;

  if (!player || !inventory) return null;

  const characters = [player, ...player.party];
  const corpseItems = inventory.filter((item) => item.deceasedCharacter);

  return (
    <Modal title="Clinic" onClose={() => setActiveModal(null)} size="xlarge">
      <p>"Feeling a bit under the weather? Let's see what we can patch up. My services aren't cheap."</p>
      <div className="clinic-layout">
        {characters.map((char) => (
          <CharacterClinicCard key={'professions' in char ? 'player' : char.id} character={char} />
        ))}
        {corpseItems.map((corpse) => (
          <CorpseClinicCard key={corpse.unique_id} corpse={corpse} />
        ))}
      </div>
    </Modal>
  );
};