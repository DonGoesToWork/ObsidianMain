import { UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import React, { useContext, useEffect, useMemo } from 'react';
import { ItemInstance, SortKey } from 'types';
import { getItemName, getItemWeight } from 'utils/itemUtils';

import { getStandardInventoryColumns } from 'config/inventoryColumns';
import { GameDataContext } from 'context/GameDataContext';
import { UIContext } from 'context/UIContext';
import { useInventory } from 'hooks/useInventory';
import { useModalState } from 'hooks/useModalState';
import { Modal } from './Modal';

export const ItemContainerModal: React.FC<{ containerUniqueId: string }> = ({ containerUniqueId }) => {
  const { inventory, moveItemToContainer, moveItemFromContainer } = useInventory();
  const GAME_DATA = useContext(GameDataContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  const STANDARD_INVENTORY_COLUMNS = useMemo(() => getStandardInventoryColumns(GAME_DATA), [GAME_DATA]);

  const modalId = 'itemContainer';

  const container = useMemo(() => {
    console.log('[ItemContainerModal] Searching for container:', containerUniqueId, 'in inventory:', inventory);
    return inventory?.find((item) => item && item.unique_id === containerUniqueId);
  }, [inventory, containerUniqueId]);

  const playerItemsForDisplay = useMemo(
    () => inventory?.filter((item): item is ItemInstance => !!(item && item.unique_id !== containerUniqueId)) || [],
    [inventory, containerUniqueId]
  );

  const playerState = useModalState(modalId, 'player');
  const containerState = useModalState(modalId, containerUniqueId);

  const defaultSort = useMemo(() => ({ key: 'name' as SortKey, direction: 'asc' as const }), []);
  const playerSortConfig = playerState.sortConfig === undefined ? defaultSort : playerState.sortConfig;
  const containerSortConfig = containerState.sortConfig === undefined ? defaultSort : containerState.sortConfig;

  useEffect(() => {
    // This can happen if the container is moved/dropped while the modal is open or opening.
    // It can also happen if the inventory has `null`s and the container is not found due to an error.
    if (inventory && !container) {
      console.warn(`[ItemContainerModal] Container with id ${containerUniqueId} not found. Closing modal.`);
      setActiveModal(null);
    }
  }, [inventory, container, containerUniqueId, setActiveModal]);

  if (!inventory || !container) {
    // Return null or a loading state while waiting for the effect to close the modal.
    return null;
  }

  if (!container.containerState) {
    const containerData = GAME_DATA.ITEMS[container.id];
    container.containerState = {
      items: [],
      capacity: containerData.capacity || 50,
    };
  }

  const containerItems = container.containerState.items;
  const currentWeight = containerItems.reduce((sum, i) => sum + getItemWeight(i, GAME_DATA), 0);
  const capacity = container.containerState.capacity;
  const subtitle = `Items: ${containerItems.reduce((acc, i) => acc + i.quantity, 0)} / 900 - Item Weight: ${currentWeight.toFixed(1)} / ${capacity.toFixed(
    1
  )} - Total Weight: ${getItemWeight(container, GAME_DATA).toFixed(2)}`;

  const handleTransferToContainer = (item: ItemInstance, quantity: number, originalIndices: number[]) => {
    moveItemToContainer(item.unique_id, quantity, container.unique_id);
  };

  const handleTransferFromContainer = (item: ItemInstance, quantity: number, originalIndices: number[]) => {
    moveItemFromContainer(item.unique_id, quantity, container.unique_id);
  };

  const title = container.deceasedCharacter ? `Loot ${getItemName(container, GAME_DATA)}` : `${getItemName(container, GAME_DATA)}`;
  const panelTitle = container.deceasedCharacter ? 'Corpse Contents' : 'Container';

  return (
    <Modal title={title} subTitle={subtitle} onClose={() => setActiveModal(null)} size="xlarge">
      <div className="shop-layout">
        <div className="shop-panel">
          <UnifiedInventoryDisplay
            title="Your Inventory"
            items={playerItemsForDisplay}
            onTransfer={handleTransferToContainer}
            transferButtonText="Deposit"
            showTransferControls={true}
            columns={STANDARD_INVENTORY_COLUMNS}
            viewMode={playerState.viewMode}
            onViewModeChange={playerState.setViewMode}
            transferAmount={playerState.transferAmount}
            onTransferAmountChange={playerState.setTransferAmount}
            sortConfig={playerSortConfig}
            onSortChange={playerState.setSortConfig}
            showFilterSearchBar={true}
            showFilterButtonBar={true}
            disablePrimaryItemActions={true}
          />
        </div>
        <div className="shop-panel">
          <UnifiedInventoryDisplay
            title={panelTitle}
            items={containerItems}
            onTransfer={handleTransferFromContainer}
            transferButtonText="Withdraw"
            showTransferControls={true}
            columns={STANDARD_INVENTORY_COLUMNS}
            viewMode={containerState.viewMode}
            onViewModeChange={containerState.setViewMode}
            transferAmount={containerState.transferAmount}
            onTransferAmountChange={containerState.setTransferAmount}
            sortConfig={containerSortConfig}
            onSortChange={containerState.setSortConfig}
            showFilterSearchBar={true}
            showFilterButtonBar={true}
            disablePrimaryItemActions={true}
          />
        </div>
      </div>
    </Modal>
  );
};

export default ItemContainerModal;