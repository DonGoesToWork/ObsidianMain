import { UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import React, { useContext, useMemo } from 'react';
import { ItemInstance } from 'types';
import { getItemName, getItemWeight } from 'utils/itemUtils';

import { getStandardInventoryColumns } from 'config/inventoryColumns';
import { GameDataContext } from 'context/GameDataContext';
import { UIContext } from 'context/UIContext';
import { useInventory } from 'hooks/useInventory';
import { useModalState } from 'hooks/useModalState';
import { Modal } from './Modal';

export const ItemContainerModal: React.FC<{ containerUniqueId: string }> = ({ containerUniqueId }) => {
  const { inventory, moveItemToContainer, moveItemFromContainer } = useInventory();
  const GAME_DATA = useContext(GameDataContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  const STANDARD_INVENTORY_COLUMNS = useMemo(() => getStandardInventoryColumns(GAME_DATA), [GAME_DATA]);

  const modalId = 'itemContainer';

  const container = useMemo(() => inventory?.find((item) => item.unique_id === containerUniqueId), [inventory, containerUniqueId]);

  const playerItemsForDisplay = useMemo(() => inventory?.filter((item) => item.unique_id !== containerUniqueId) || [], [inventory, containerUniqueId]);

  const playerState = useModalState(modalId, 'player');
  const containerState = useModalState(modalId, containerUniqueId);

  if (!inventory || !container) {
    return (
      <Modal title="Container" onClose={() => setActiveModal(null)}>
        <p>Container not found or has been moved.</p>
      </Modal>
    );
  }

  if (!container.containerState) {
    const containerData = GAME_DATA.ITEMS[container.id];
    container.containerState = {
      items: [],
      capacity: containerData.capacity || 50,
    };
  }

  const containerItems = container.containerState.items;
  const currentWeight = containerItems.reduce((sum, i) => sum + getItemWeight(i, GAME_DATA), 0);
  const capacity = container.containerState.capacity;
  const subtitle = `Items: ${containerItems.reduce(
    (acc, i) => acc + i.quantity,
    0
  )} / 900  |  Weight: ${currentWeight.toFixed(1)} / ${capacity.toFixed(1)} | Total Weight: ${getItemWeight(container, GAME_DATA).toFixed(2)}`;

  const handleTransferToContainer = (item: ItemInstance, quantity: number, originalIndices: number[]) => {
    moveItemToContainer(item.unique_id, quantity, container.unique_id);
  };

  const handleTransferFromContainer = (item: ItemInstance, quantity: number, originalIndices: number[]) => {
    moveItemFromContainer(item.unique_id, quantity, container.unique_id);
  };

  const title = container.deceasedCharacter ? `Loot ${getItemName(container, GAME_DATA)}` : `${getItemName(container, GAME_DATA)}`;
  const panelTitle = container.deceasedCharacter ? 'Corpse Contents' : 'Container';

  return (
    <Modal title={title} subTitle={subtitle} onClose={() => setActiveModal(null)} size="xlarge">
      <div className="shop-layout">
        <div className="shop-panel">
          <UnifiedInventoryDisplay
            title="Your Inventory"
            items={playerItemsForDisplay}
            onTransfer={handleTransferToContainer}
            transferButtonText="Deposit"
            showTransferControls={true}
            columns={STANDARD_INVENTORY_COLUMNS}
            viewMode={playerState.viewMode}
            onViewModeChange={playerState.setViewMode}
            transferAmount={playerState.transferAmount}
            onTransferAmountChange={playerState.setTransferAmount}
            showFilterSearchBar={true}
            showFilterButtonBar={true}
          />
        </div>
        <div className="shop-panel">
          <UnifiedInventoryDisplay
            title={panelTitle}
            items={containerItems}
            onTransfer={handleTransferFromContainer}
            transferButtonText="Withdraw"
            showTransferControls={true}
            columns={STANDARD_INVENTORY_COLUMNS}
            viewMode={containerState.viewMode}
            onViewModeChange={containerState.setViewMode}
            transferAmount={containerState.transferAmount}
            onTransferAmountChange={containerState.setTransferAmount}
            showFilterSearchBar={true}
            showFilterButtonBar={true}
          />
        </div>
      </div>
    </Modal>
  );
};

export default ItemContainerModal;