import { UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import { ItemInstance } from 'types';
import React, { useContext, useMemo } from 'react';
import { getItemName, getItemWeight } from 'utils/itemUtils';

import { Modal } from './Modal';
import { UIContext } from 'context/UIContext';
import { useInventory } from 'hooks/useInventory';
import { useModalState } from 'hooks/useModalState';
import { getStandardInventoryColumns } from 'config/inventoryColumns';
import { GameDataContext } from 'context/GameDataContext';

export const ItemContainerModal: React.FC<{ containerUniqueId: string }> = ({ containerUniqueId }) => {
  const { inventory, moveItemToContainer, moveItemFromContainer } = useInventory();
  const GAME_DATA = useContext(GameDataContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  const STANDARD_INVENTORY_COLUMNS = useMemo(() => getStandardInventoryColumns(GAME_DATA), [GAME_DATA]);

  const modalId = 'itemContainer';

  const container = useMemo(() => inventory?.find((item) => item.unique_id === containerUniqueId), [inventory, containerUniqueId]);

  const playerItemsForDisplay = useMemo(() => inventory?.filter((item) => item.unique_id !== containerUniqueId) || [], [inventory, containerUniqueId]);

  const playerState = useModalState(modalId, 'player');
  const containerState = useModalState(modalId, containerUniqueId);

  if (!inventory || !container) {
    return (
      <Modal title="Container" onClose={() => setActiveModal(null)}>
        <p>Container not found or has been moved.</p>
      </Modal>
    );
  }

  if (!container.containerState) {
    const containerData = GAME_DATA.ITEMS[container.id];
    container.containerState = {
      items: [],
      capacity: containerData.capacity || 50,
    };
  }

  const containerItems = container.containerState.items;
  const currentWeight = containerItems.reduce((sum, i) => sum + getItemWeight(i, GAME_DATA), 0);
  const capacity = container.containerState.capacity;
  const subtitle = `Items: ${containerItems.length} / 900  |  Weight: ${currentWeight.toFixed(1)} / ${capacity.toFixed(1)}`;

  const handleTransferToContainer = (_item: ItemInstance, quantity: number, indices: number[]) => {
    const itemsToMove = indices.slice(0, quantity).map((i) => playerItemsForDisplay[i]);
    itemsToMove.forEach((item) => {
      moveItemToContainer(item.unique_id, container.unique_id);
    });
  };

  const handleTransferFromContainer = (_item: ItemInstance, quantity: number, indices: number[]) => {
    const itemsToMove = indices.slice(0, quantity).map((i) => containerItems[i]);
    itemsToMove.forEach((item) => {
      moveItemFromContainer(item.unique_id, container.unique_id);
    });
  };

  const title = container.deceasedCharacter ? `Loot ${getItemName(container, GAME_DATA)}` : `${getItemName(container, GAME_DATA)}`;
  const panelTitle = container.deceasedCharacter ? 'Corpse Contents' : 'Container';

  return (
    <Modal title={title} subTitle={subtitle} onClose={() => setActiveModal(null)} size="xlarge">
      <div className="shop-layout">
        <div className="shop-panel">
          <UnifiedInventoryDisplay
            title="Your Inventory"
            items={playerItemsForDisplay}
            onTransfer={handleTransferToContainer}
            transferButtonText="Deposit"
            showTransferControls={true}
            columns={STANDARD_INVENTORY_COLUMNS}
            viewMode={playerState.viewMode}
            onViewModeChange={playerState.setViewMode}
            transferAmount={playerState.transferAmount}
            onTransferAmountChange={playerState.setTransferAmount}
          />
        </div>
        <div className="shop-panel">
          <UnifiedInventoryDisplay
            title={panelTitle}
            items={containerItems}
            onTransfer={handleTransferFromContainer}
            transferButtonText="Withdraw"
            showTransferControls={true}
            columns={STANDARD_INVENTORY_COLUMNS}
            viewMode={containerState.viewMode}
            onViewModeChange={containerState.setViewMode}
            transferAmount={containerState.transferAmount}
            onTransferAmountChange={containerState.setTransferAmount}
          />
        </div>
      </div>
    </Modal>
  );
};

export default ItemContainerModal;