import React, { useContext } from 'react';

import { WorldContext } from 'context/WorldContext';
import { Modal } from './Modal';

export const DeathModal: React.FC = () => {
  const { continueFromDeath, resetGame, isActionLocked } = useContext(WorldContext)!;

  return (
    <Modal title="You Have Died" onClose={() => {}} size="small">
      <p>Your journey has met a brutal end. However, the threads of fate are not so easily severed. You will lose 10% of your gold.</p>
      <div className="modal-footer-actions">
        <div className="action-grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <button className="btn" onClick={continueFromDeath} disabled={isActionLocked}>
            Continue
          </button>
          <button className="btn btn-danger" onClick={resetGame} disabled={isActionLocked}>
            Restart
          </button>
        </div>
      </div>
    </Modal>
  );
};