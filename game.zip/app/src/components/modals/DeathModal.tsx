import React, { useContext } from "react";
import { Modal } from "./Modal";
import { WorldContext } from "context/WorldContext";

export const DeathModal: React.FC = () => {
  const { continueFromDeath, resetGame } = useContext(WorldContext)!;

  return (
    <Modal title="You Have Died" onClose={() => {}} size="small">
      <p>
        Your journey has met a brutal end. However, the threads of fate are not
        so easily severed.
      </p>
      <div className="modal-footer-actions">
        <div className="action-grid" style={{ gridTemplateColumns: "1fr 1fr" }}>
          <button className="btn" onClick={continueFromDeath}>
            Continue
          </button>
          <button className="btn btn-danger" onClick={resetGame}>
            Restart
          </button>
        </div>
      </div>
    </Modal>
  );
};