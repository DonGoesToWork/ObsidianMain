import React, { useContext, useState } from 'react';
import { QuestId } from '../../types';
import { Modal } from './Modal';
import { useQuests } from 'hooks/useQuests';
import { UIContext } from 'context/UIContext';
import { GameDataContext } from 'context/GameDataContext';

export const QuestLogModal: React.FC = () => {
  const { quests } = useQuests();
  const GAME_DATA = useContext(GameDataContext)!;
  const { setActiveModal } = useContext(UIContext)!;

  const [tab, setTab] = useState<'active' | 'completed'>('active');

  if (!quests) return null;

  return (
    <Modal title="Quest Log" onClose={() => setActiveModal(null)} size="large">
      <div className="tabs">
        <button className={`tab-btn ${tab === 'active' ? 'active' : ''}`} onClick={() => setTab('active')}>
          Active
        </button>
        <button className={`tab-btn ${tab === 'completed' ? 'active' : ''}`} onClick={() => setTab('completed')}>
          Completed
        </button>
      </div>
      <div className="quest-list">
        {tab === 'active' && Object.entries(quests.active).length === 0 && <p>No active quests.</p>}
        {tab === 'active' &&
          Object.entries(quests.active).map(([questId, progress]) => {
            const questData = GAME_DATA.QUESTS[questId as QuestId];
            if (!questData) return null;
            const targetName = progress.type === 'kill' ? GAME_DATA.MONSTERS[progress.target]?.name : GAME_DATA.ITEMS[progress.target]?.name;

            return (
              <div key={questId} className="quest-entry">
                <h4>{questData.name}</h4>
                <p>{questData.startDesc}</p>
                <p className="quest-objective">
                  - {targetName}: {progress.current} / {progress.count}
                </p>
              </div>
            );
          })}
        {tab === 'completed' && Object.keys(quests.completed).length === 0 && <p>No completed quests.</p>}
        {tab === 'completed' &&
          Object.keys(quests.completed).map((questId) => {
            const questData = GAME_DATA.QUESTS[questId as QuestId];
            if (!questData) return null;
            return (
              <div key={questId} className="quest-entry completed">
                <h4>{questData.name}</h4>
              </div>
            );
          })}
      </div>
    </Modal>
  );
};
