import { ColumnDef, FilterCategory, UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import React, { useContext, useEffect } from 'react';
import { calculateItemValue, getItemName } from 'utils/itemUtils';

import { GameDataContext } from 'context/GameDataContext';
import { Modal } from './Modal';
import { UIContext } from 'context/UIContext';
import { useModalState } from 'hooks/useModalState';
import { useShop } from 'hooks/useShop';

const SHOP_FILTER_CATEGORIES: FilterCategory[] = [
  { key: 'All', label: 'All' },
  { key: 'equipment', label: 'Equipment' },
  { key: 'potion', label: 'Consumables' },
  { key: 'material', label: 'Materials' },
  { key: 'tool', label: 'Tools' },
  { key: 'note', label: 'Writings' },
  { key: 'container', label: 'Containers' },
];

export const GeneralStoreModal: React.FC<{ npcId?: string }> = ({ npcId }) => {
  const { setActiveModal } = useContext(UIContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const {
    player,
    currentLocation,
    playerItemsForDisplay,
    merchantItemsForDisplay,
    playerOfferItems,
    merchantOfferItems,
    playerItemsValue,
    merchantItemsValue,
    playerGoldChange,
    canAccept,
    shopInfo,
    handlePlayerTransfer,
    handleMerchantTransfer,
    handleReturnFromPlayerOffer,
    handleReturnFromMerchantOffer,
    handleReset,
    handleAccept,
    refreshShopInventory,
  } = useShop();

  const playerState = useModalState('shop', 'player');
  const merchantState = useModalState('shop', 'merchant');
  const playerOfferState = useModalState('shop', 'playerOffer');
  const merchantOfferState = useModalState('shop', 'merchantOffer');

  useEffect(() => {
    if (currentLocation) {
      refreshShopInventory(currentLocation.id, currentLocation.levelReq || 1, false);
    }
  }, [currentLocation, refreshShopInventory]);

  const merchantColumns: ColumnDef[] = [
    {
      key: 'name',
      label: 'Name',
      render: (item, g) => `${getItemName(item, GAME_DATA)}${g.count > 1 ? ` (${g.count})` : ''}`,
      className: 'shop-item-name',
      isSortable: true,
    },
    {
      key: 'itemLevel',
      label: 'Lvl',
      render: (item) => GAME_DATA.ITEMS[item.id].itemLevel,
      className: 'shop-item-level',
      isSortable: true,
    },
    {
      key: 'value',
      label: 'Value',
      render: (item) => `${calculateItemValue(item, GAME_DATA)}g`,
      className: 'shop-item-value',
      isSortable: true,
    },
  ];

  if (!player || !currentLocation) return null;

  return (
    <Modal
      title={GAME_DATA.TOWN_NPCS[npcId as keyof typeof GAME_DATA.TOWN_NPCS]?.name || 'Shop'}
      subTitle={`Restocks In: ${shopInfo.timeToRestock}`}
      onClose={() => setActiveModal(null)}
      size="xlarge"
    >
      <div className="trade-layout">
        <div className="trade-panel">
          <UnifiedInventoryDisplay
            title={`Your Items (${player.gold.toLocaleString()}G)`}
            items={playerItemsForDisplay}
            onTransfer={handlePlayerTransfer}
            transferButtonText="Offer"
            showTransferControls={true}
            showViewToggle
            showFilterSearchBar
            showFilterButtonBar
            showSortButtons
            viewMode={playerState.viewMode}
            onViewModeChange={playerState.setViewMode}
            transferAmount={playerState.transferAmount}
            onTransferAmountChange={playerState.setTransferAmount}
          />
        </div>
        <div className="trade-panel offer-panel">
          <UnifiedInventoryDisplay
            title={`Your Offer (Value: ${playerItemsValue.toLocaleString()}G)`}
            items={playerOfferItems}
            showFilterSearchBar={false}
            showFilterButtonBar={false}
            showSortButtons={false}
            showViewToggle={true}
            viewMode={playerOfferState.viewMode}
            onViewModeChange={playerOfferState.setViewMode}
            onTransfer={handleReturnFromPlayerOffer}
            transferButtonText="Return"
            showTransferControls
            transferAmount={playerState.transferAmount}
            onTransferAmountChange={playerState.setTransferAmount}
          />
        </div>
        <div className="trade-panel deal-details">
          <div className="deal-buttons">
            <button className="btn" onClick={handleAccept} disabled={!canAccept}>
              Accept
            </button>
            <div className="deal-summary">
              <p>Balance:</p>
              <p className={playerGoldChange >= 0 ? 'req-ok' : 'req-fail'}>{`${playerGoldChange >= 0 ? '+' : ''}${playerGoldChange}`}G</p>
            </div>
            <button className="btn" onClick={handleReset}>
              Reset
            </button>
          </div>
        </div>
        <div className="trade-panel offer-panel">
          <UnifiedInventoryDisplay
            title={`Merchant's Offer (Value: ${merchantItemsValue.toLocaleString()}G)`}
            items={merchantOfferItems}
            showFilterSearchBar={false}
            showFilterButtonBar={false}
            showSortButtons={false}
            showViewToggle={true}
            viewMode={merchantOfferState.viewMode}
            onViewModeChange={merchantOfferState.setViewMode}
            onTransfer={handleReturnFromMerchantOffer}
            transferButtonText="Return"
            showTransferControls
            transferAmount={merchantState.transferAmount}
            onTransferAmountChange={merchantState.setTransferAmount}
          />
        </div>
        <div className="trade-panel">
          <UnifiedInventoryDisplay
            title="For Sale"
            items={merchantItemsForDisplay}
            onTransfer={handleMerchantTransfer}
            transferButtonText="Offer"
            showTransferControls={true}
            filterCategories={SHOP_FILTER_CATEGORIES}
            columns={merchantColumns}
            showViewToggle
            showFilterSearchBar={true}
            showFilterButtonBar={true}
            viewMode={merchantState.viewMode}
            onViewModeChange={merchantState.setViewMode}
            transferAmount={merchantState.transferAmount}
            onTransferAmountChange={merchantState.setTransferAmount}
          />
        </div>
      </div>
    </Modal>
  );
};