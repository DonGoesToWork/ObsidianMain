import React, { useContext } from 'react';
import { NPCId, QuestId } from '../../types';
import { Modal } from './Modal';
import { usePlayer } from 'hooks/usePlayer';
import { useQuests } from 'hooks/useQuests';
import { UIContext } from 'context/UIContext';
import { GameDataContext } from 'context/GameDataContext';

export const QuestGiverModal: React.FC<{
  npcId: NPCId;
  questIds: QuestId[];
}> = ({ npcId, questIds }) => {
  const player = usePlayer();
  const { acceptQuest, quests } = useQuests();
  const GAME_DATA = useContext(GameDataContext)!;
  const { setActiveModal } = useContext(UIContext)!;

  if (!player || !quests) return null;

  const npc = GAME_DATA.TOWN_NPCS[npcId as NPCId];

  const availableQuests = questIds.filter((qid: QuestId) => {
    const q = GAME_DATA.QUESTS[qid];
    if (!q) return false;
    const alreadyActive = !!quests.active[qid];
    const alreadyDone = !!quests.completed[qid];
    const levelOk = player.level >= (q.levelReq || 0);
    const prereqOk = !q.prereq || !!quests.completed[q.prereq];
    return !alreadyActive && !alreadyDone && levelOk && prereqOk;
  });

  return (
    <Modal title={npc.name} onClose={() => setActiveModal(null)} size="medium">
      <div className="quest-list">
        {availableQuests.length === 0 && <p>I have no tasks for you right now. Check back later.</p>}
        {availableQuests.map((questId: QuestId) => {
          const questData = GAME_DATA.QUESTS[questId];
          return (
            <div key={questId} className="quest-entry">
              <h4>{questData.name}</h4>
              <p>{questData.startDesc}</p>
              <button
                className="btn"
                onClick={() => {
                  acceptQuest(questId);
                  setActiveModal(null);
                }}
              >
                Accept
              </button>
            </div>
          );
        })}
      </div>
    </Modal>
  );
};
