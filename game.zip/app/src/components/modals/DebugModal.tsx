import React, { useContext } from "react";

import { Modal } from "./Modal";
import { DebugContext } from "context/DebugContext";
import { UIContext } from "context/UIContext";
import { WorldContext } from "context/WorldContext";
import { PlayerStateSection } from "../debug/PlayerStateSection";
import { CurrencyItemsSection } from "../debug/CurrencyItemsSection";
import { ExperienceLevelsSection } from "../debug/ExperienceLevelsSection";
import { PointsStatsSection } from "../debug/PointsStatsSection";
import { UnlocksSection } from "../debug/UnlocksSection";
import { MaxDebugSection } from "../debug/MaxDebugSection";

interface SectionProps {
  title: string;
  children: React.ReactNode;
}

const DebugSection: React.FC<SectionProps> = ({ title, children }) => (
  <div className="debug-section">
    <h4 className="debug-section-header">{title}</h4>
    <div className="action-grid">{children}</div>
  </div>
);

export const DebugModal: React.FC = () => {
  const debugContext = useContext(DebugContext);
  const worldContext = useContext(WorldContext);
  const uiContext = useContext(UIContext);

  if (!debugContext || !worldContext || !uiContext) {
    return (
      <Modal title="Debug Menu" onClose={() => {}} size="xlarge">
        <p>Loading context...</p>
      </Modal>
    );
  }

  const { setActiveModal } = uiContext;

  return (
    <Modal
      title="Debug Menu"
      onClose={() => setActiveModal(null)}
      size="xlarge"
    >
      <p>Use these buttons to test game features.</p>
      <div className="tab-content">
        <div className="debug-layout">
          <DebugSection title="Player State">
            <PlayerStateSection {...debugContext} />
          </DebugSection>

          <DebugSection title="Currency & Items">
            <CurrencyItemsSection
              {...debugContext}
              setActiveModal={setActiveModal}
            />
          </DebugSection>

          <DebugSection title="Experience & Levels">
            <ExperienceLevelsSection {...debugContext} />
          </DebugSection>

          <DebugSection title="Points & Stats">
            <PointsStatsSection {...debugContext} />
          </DebugSection>

          <DebugSection title="Unlocks">
            <UnlocksSection {...debugContext} />
          </DebugSection>

          <DebugSection title="Max Debug">
            <MaxDebugSection
              debug_test_all={debugContext.debug_test_all}
              debug_teleportToTown={worldContext.debug_teleportToTown}
              changeGameState={worldContext.changeGameState}
              closeModal={() => setActiveModal(null)}
            />
          </DebugSection>
        </div>
      </div>
    </Modal>
  );
};