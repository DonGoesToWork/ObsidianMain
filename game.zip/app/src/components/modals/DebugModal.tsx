import React, { useContext, useState, useMemo, useCallback } from 'react';
import { Modal } from './Modal';
import { usePlayer } from 'hooks/usePlayer';
import { DebugContext } from 'context/DebugContext';
import { Player, Mercenary } from 'types';
import { DebugTargetSelector } from '../debug/DebugTargetSelector';
import { GeneralTab } from '../debug/tabs/GeneralTab';
import { PlayerTab } from '../debug/tabs/PlayerTab';
import { PartyTab } from '../debug/tabs/PartyTab';
import { EnemyTab } from '../debug/tabs/EnemyTab';
import { AllTab } from '../debug/tabs/AllTab';
import { CombatContext } from 'context/CombatContext';
import { UIContext } from 'context/UIContext';

type DebugTab = 'General' | 'Player' | 'Party' | 'Enemy' | 'All';

export const DebugModal: React.FC = () => {
  const player = usePlayer();
  const { currentCombat } = useContext(CombatContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  const { debugTargets, setDebugTargets } = useContext(DebugContext)!;
  const [activeTab, setActiveTab] = useState<DebugTab>('General');

  const allCharacters = useMemo(() => {
    if (!player) return [];
    return [player, ...(player.party || [])];
  }, [player]);

  const enemies = useMemo(() => {
    if (!currentCombat) return [];
    return Object.values(currentCombat.combatants).filter((c) => c.team === 'enemy');
  }, [currentCombat]);

  const availableTargets = useMemo(() => {
    const mapToTarget = (c: Player | Mercenary) => ({
      id: 'professions' in c ? 'player' : c.id,
      name: c.name,
    });
    switch (activeTab) {
      case 'Player':
        return player ? [mapToTarget(player)] : [];
      case 'Party':
        return allCharacters.map(mapToTarget);
      case 'Enemy':
        return enemies.map((e) => ({ id: e.id, name: e.name }));
      case 'All':
        return [...allCharacters.map(mapToTarget), ...enemies.map((e) => ({ id: e.id, name: e.name }))];
      default:
        return [];
    }
  }, [activeTab, player, allCharacters, enemies]);

  // Effect to update targets when tab changes
  React.useEffect(() => {
    if (activeTab === 'Player' && player) {
      setDebugTargets(['player']);
    } else {
      setDebugTargets([]);
    }
  }, [activeTab, player, setDebugTargets]);

  const handleToggleTarget = useCallback(
    (id: string) => {
      setDebugTargets((prev) => (prev.includes(id) ? prev.filter((targetId) => targetId !== id) : [...prev, id]));
    },
    [setDebugTargets],
  );

  const handleSelectAll = useCallback(() => {
    setDebugTargets(availableTargets.map((t) => t.id));
  }, [availableTargets, setDebugTargets]);

  const handleSelectNone = useCallback(() => {
    setDebugTargets([]);
  }, [setDebugTargets]);

  const renderContent = () => {
    const showTargetSelector = ['Party', 'Enemy', 'All'].includes(activeTab);
    const hasAvailableTargets = availableTargets.length > 0;

    return (
      <div className="debug-modal-body">
        {showTargetSelector && hasAvailableTargets && (
          <DebugTargetSelector
            available={availableTargets}
            selected={debugTargets}
            onToggle={handleToggleTarget}
            onSelectAll={handleSelectAll}
            onSelectNone={handleSelectNone}
          />
        )}
        <div className="debug-actions-panel">
          {activeTab === 'General' && <GeneralTab />}
          {activeTab === 'Player' && <PlayerTab />}
          {activeTab === 'Party' && <PartyTab />}
          {activeTab === 'Enemy' && <EnemyTab />}
          {activeTab === 'All' && <AllTab />}
        </div>
      </div>
    );
  };

  if (!player) return null;

  const TABS: DebugTab[] = ['General', 'Player', 'Party', 'Enemy', 'All'];

  return (
    <Modal title="Debug Menu" onClose={() => setActiveModal(null)} size="xlarge">
      <div className="debug-modal-content">
        <div className="tabs">
          {TABS.map((tab) => (
            <button key={tab} className={`tab-btn ${activeTab === tab ? 'active' : ''}`} onClick={() => setActiveTab(tab)}>
              {tab}
            </button>
          ))}
        </div>
        {renderContent()}
      </div>
    </Modal>
  );
};