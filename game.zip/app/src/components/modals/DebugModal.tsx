import { CombatContext } from 'context/CombatContext';
import { DebugContext } from 'context/DebugContext';
import { UIContext } from 'context/UIContext';
import { usePlayer } from 'hooks/usePlayer';
import React, { useCallback, useContext, useMemo, useState } from 'react';
import { Mercenary, Player } from 'types';
import { DebugTargetContext } from '../debug/DebugTargetContext';
import { DebugTargetSelector } from '../debug/DebugTargetSelector';
import { GenericDebugTab } from '../debug/tabs/GenericDebugTab';
import { PartyDebugTab } from '../debug/tabs/PartyDebugTab';
import { PlayerDebugTab } from '../debug/tabs/PlayerDebugTab';
import { Modal } from './Modal';

type DebugTab = 'Player' | 'Party' | 'Enemy' | 'All';

export const DebugModal: React.FC = () => {
  const player = usePlayer();
  const { currentCombat } = useContext(CombatContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  const { debugTargets, setDebugTargets } = useContext(DebugContext)!;
  const [activeTab, setActiveTab] = useState<DebugTab>('Player');

  const allCharacters = useMemo(() => {
    if (!player) return [];
    return [player, ...(player.party || [])];
  }, [player]);

  const enemies = useMemo(() => {
    if (!currentCombat) return [];
    return Object.values(currentCombat.combatants).filter((c) => c.team === 'enemy');
  }, [currentCombat]);

  const availableTargets = useMemo(() => {
    const mapToTarget = (c: Player | Mercenary) => ({
      id: 'professions' in c ? 'player' : c.id,
      name: c.name,
    });
    switch (activeTab) {
      case 'Player':
        return player ? [mapToTarget(player)] : [];
      case 'Party':
        return allCharacters.map(mapToTarget);
      case 'Enemy':
        return enemies.map((e) => ({ id: e.id, name: e.name }));
      case 'All':
        return [...allCharacters.map(mapToTarget), ...enemies.map((e) => ({ id: e.id, name: e.name }))];
      default:
        return [];
    }
  }, [activeTab, player, allCharacters, enemies]);

  // Effect to update targets when tab changes
  React.useEffect(() => {
    if (activeTab === 'Player' && player) {
      setDebugTargets(['player']);
    } else {
      setDebugTargets([]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab]);

  const handleToggleTarget = useCallback(
    (id: string) => {
      setDebugTargets((prev) => (prev.includes(id) ? prev.filter((targetId) => targetId !== id) : [...prev, id]));
    },
    [setDebugTargets]
  );

  const handleSelectAll = useCallback(() => {
    setDebugTargets(availableTargets.map((t) => t.id));
  }, [availableTargets, setDebugTargets]);

  const handleSelectNone = useCallback(() => {
    setDebugTargets([]);
  }, [setDebugTargets]);

  const primaryTarget = useMemo(() => {
    const primaryId = debugTargets[0];
    if (!primaryId) return player; // Default to player if no target selected

    if (primaryId === 'player') return player;

    if (currentCombat?.combatants[primaryId]) {
      return currentCombat.combatants[primaryId];
    }

    return allCharacters.find((c) => ('professions' in c ? 'player' : c.id) === primaryId) || player;
  }, [debugTargets, player, currentCombat, allCharacters]);

  const renderContent = () => {
    const showTargetSelector = ['Party', 'Enemy', 'All'].includes(activeTab);
    const hasAvailableTargets = availableTargets.length > 0;

    let TabContentComponent;
    switch (activeTab) {
      case 'Player':
        TabContentComponent = PlayerDebugTab;
        break;
      case 'Party':
        TabContentComponent = PartyDebugTab;
        break;
      case 'Enemy':
      case 'All':
        TabContentComponent = GenericDebugTab;
        break;
      default:
        TabContentComponent = () => null;
    }

    return (
      <div className="debug-modal-body">
        {showTargetSelector && hasAvailableTargets && (
          <DebugTargetSelector
            available={availableTargets}
            selected={debugTargets}
            onToggle={handleToggleTarget}
            onSelectAll={handleSelectAll}
            onSelectNone={handleSelectNone}
          />
        )}
        <div className="debug-actions-panel">
          <TabContentComponent />
        </div>
      </div>
    );
  };

  if (!player) return null;

  const TABS: DebugTab[] = ['Player', 'Party', 'Enemy', 'All'];

  return (
    <Modal title="Debug Menu" onClose={() => setActiveModal(null)} size="xlarge">
      <DebugTargetContext.Provider value={{ primaryTarget }}>
        <div className="debug-modal-content">
          <div className="tabs">
            {TABS.map((tab) => (
              <button key={tab} className={`tab-btn ${activeTab === tab ? 'active' : ''}`} onClick={() => setActiveTab(tab)}>
                {tab}
              </button>
            ))}
          </div>
          {renderContent()}
        </div>
      </DebugTargetContext.Provider>
    </Modal>
  );
};