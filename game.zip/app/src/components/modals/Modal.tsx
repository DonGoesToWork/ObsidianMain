import React from "react";

interface ModalProps {
  title: string;
  subTitle?: string;
  children: React.ReactNode;
  onClose: () => void;
  size?: "small" | "medium" | "large" | "xlarge";
}

export const Modal: React.FC<ModalProps> = ({
  title,
  subTitle,
  children,
  onClose,
  size = "medium",
}) => {
  return (
    <div
      className={`modal-content modal-${size}`}
      onClick={(e) => e.stopPropagation()}
    >
      <div className="modal-header">
        <div>
          <h2>{title}</h2>
          {subTitle && <h3 className="modal-subtitle">{subTitle}</h3>}
        </div>
        <button className="modal-close-btn" onClick={onClose}>
          ×
        </button>
      </div>
      <div className="modal-body">{children}</div>
    </div>
  );
};