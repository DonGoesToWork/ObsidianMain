import React, { useContext, useState } from 'react';

import { UIContext } from 'context/UIContext';
import { WorldContext } from 'context/WorldContext';
import { HotkeySettingsPanel } from './HotkeySettingsPanel';
import { Modal } from './Modal';

const DataSettingsPanel: React.FC = () => {
  const { saveGame, resetGame } = useContext(WorldContext)!;

  return (
    <div style={{ width: '100%' }}>
      <p>Game is auto-saved. You can manually save or reset your progress here.</p>
      <div className="action-grid section-divider">
        <button onClick={saveGame} className="btn">
          Save Game
        </button>
        <button onClick={resetGame} id="reset-btn" className="btn btn-danger">
          Reset Game
        </button>
      </div>
    </div>
  );
};

export const SettingsModal: React.FC = () => {
  const { setActiveModal } = useContext(UIContext)!;
  const [tab, setTab] = useState<'Data' | 'Hotkeys'>('Data');

  return (
    <Modal title="Options" onClose={() => setActiveModal(null)} size="medium">
      <div className="tabs">
        <button className={`tab-btn ${tab === 'Data' ? 'active' : ''}`} onClick={() => setTab('Data')}>
          Game
        </button>
        <button className={`tab-btn ${tab === 'Hotkeys' ? 'active' : ''}`} onClick={() => setTab('Hotkeys')}>
          Hotkeys
        </button>
      </div>
      <div className="tab-content" style={{ display: 'flex', flexGrow: 1, minHeight: 0 }}>
        {tab === 'Data' && <DataSettingsPanel />}
        {tab === 'Hotkeys' && <HotkeySettingsPanel onClose={() => setActiveModal(null)} />}
      </div>
    </Modal>
  );
};
