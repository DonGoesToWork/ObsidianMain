import React, { useContext, useState } from "react";
import { Modal } from "./Modal";
import { HotkeySettingsPanel } from "./HotkeySettingsPanel";
import { UIContext } from "context/UIContext";
import { WorldContext } from "context/WorldContext";

const DataSettingsPanel: React.FC = () => {
  const { saveGame, resetGame } = useContext(WorldContext)!;
  const { zoomLevel, setZoomLevel } = useContext(UIContext)!;

  return (
    <div style={{ width: "100%" }}>
      <p>
        Game is auto-saved. You can manually save or reset your progress here.
      </p>
      <div className="action-grid section-divider">
        <button onClick={saveGame} className="btn">
          Save Game
        </button>
        <button onClick={resetGame} id="reset-btn" className="btn btn-danger">
          Reset Game
        </button>
      </div>
      <div className="section-divider">
        <h4>UI Zoom</h4>
        <div className="zoom-slider-container">
          <span>{zoomLevel}%</span>
          <input
            type="range"
            min="50"
            max="150"
            value={zoomLevel}
            onChange={(e) => setZoomLevel(Number(e.target.value))}
            className="zoom-slider"
          />
        </div>
      </div>
    </div>
  );
};

export const SettingsModal: React.FC = () => {
  const { setActiveModal } = useContext(UIContext)!;
  const [tab, setTab] = useState<"Data" | "Hotkeys">("Data");

  return (
    <Modal title="Options" onClose={() => setActiveModal(null)} size="large">
      <div className="tabs">
        <button
          className={`tab-btn ${tab === "Data" ? "active" : ""}`}
          onClick={() => setTab("Data")}
        >
          Game
        </button>
        <button
          className={`tab-btn ${tab === "Hotkeys" ? "active" : ""}`}
          onClick={() => setTab("Hotkeys")}
        >
          Hotkeys
        </button>
      </div>
      <div
        className="tab-content"
        style={{ display: "flex", flexGrow: 1, minHeight: 0 }}
      >
        {tab === "Data" && <DataSettingsPanel />}
        {tab === "Hotkeys" && (
          <HotkeySettingsPanel onClose={() => setActiveModal(null)} />
        )}
      </div>
    </Modal>
  );
};