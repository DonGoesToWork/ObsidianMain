import { UIContext } from 'context/UIContext';
import React, { useContext } from 'react';
import { Modal } from './Modal';

export const NotImplementedModal: React.FC<{ title: string }> = ({ title }) => {
  const { setActiveModal } = useContext(UIContext)!;
  return (
    <Modal title={title} onClose={() => setActiveModal(null)} size="small">
      <p>This feature is not yet implemented. Check back later!</p>
    </Modal>
  );
};
