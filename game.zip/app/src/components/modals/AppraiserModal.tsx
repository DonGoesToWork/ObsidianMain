import React, { useContext } from "react";

import { LogContext } from "context/LogContext";
import { Modal } from "./Modal";
import { ProfessionsContext } from "context/ProfessionsContext";
import { UIContext } from "context/UIContext";
import { useInventory } from "hooks/useInventory";

export const AppraiserModal: React.FC = () => {
  const { inventory, gold } = useInventory();
  const { identifyAllItems } = useContext(ProfessionsContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  const { logMessage } = useContext(LogContext)!;

  if (!inventory || gold === undefined) return null;

  const unidentifiedItems = inventory.filter((i) => i.isUnidentified);
  const count = unidentifiedItems.length;

  // Simple cost calculation: 50 gold per item. Could be made more complex later.
  const cost = count * 50;

  const handleIdentify = () => {
    if (gold < cost) {
      logMessage("You don't have enough gold.", "error");
      return;
    }
    if (count > 0) {
      identifyAllItems(cost);
    }
    setActiveModal(null);
  };

  return (
    <Modal title="Appraiser" onClose={() => setActiveModal(null)} size="medium">
      {count > 0 ? (
        <>
          <p>I see you have some interesting items... but their true nature is hidden.</p>
          <p style={{ marginTop: "15px" }}>
            You have <strong style={{ color: "#ffd700" }}>{count}</strong> unidentified item(s).
          </p>
          <p>
            I can reveal their properties for a fee of <strong style={{ color: "#ffd700" }}>{cost}</strong> gold.
          </p>
          <div className="modal-footer-actions">
            <button className="btn" onClick={handleIdentify} disabled={gold < cost}>
              Identify all items ({cost}g)
            </button>
          </div>
        </>
      ) : (
        <p>You have no items that need identifying. Come back when you find something mysterious!</p>
      )}
    </Modal>
  );
};