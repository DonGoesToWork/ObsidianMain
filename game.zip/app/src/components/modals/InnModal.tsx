import React, { useContext } from "react";

import { Modal } from "./Modal";
import { usePlayer } from "hooks/usePlayer";
import { UIContext } from "context/UIContext";
import { WorldContext } from "context/WorldContext";

export const InnModal: React.FC = () => {
  const player = usePlayer();
  const { performInnAction } = useContext(WorldContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  if (!player) return null;

  const options = [
    {
      id: "eat",
      name: "Hearty Meal",
      cost: 15,
      desc: "Restores Thirst and Hunger.",
      check: () => player.vitals.hunger.current >= player.vitals.hunger.max && player.vitals.thirst.current >= player.vitals.thirst.max,
    },
    {
      id: "rest",
      name: "Night's Rest",
      cost: 25,
      desc: "Fully restores HP, MP, and Alertness.",
      check: () => player.mp >= player.maxMp && player.vitals.alertness.current >= player.vitals.alertness.max,
    },
  ];

  return (
    <Modal title="The Weary Traveler Inn" onClose={() => setActiveModal(null)} size="medium">
      <p>Welcome! What can I get for you?</p>
      <div className="action-grid" style={{ marginTop: "10px" }}>
        {options.map((opt) => (
          <button
            key={opt.id}
            className="btn"
            disabled={player.gold < opt.cost || opt.check()}
            onClick={() => performInnAction(opt.id as "eat" | "rest", opt.cost)}
          >
            {opt.name}
            <br />
            <small>({opt.cost}g)</small>
          </button>
        ))}
      </div>
    </Modal>
  );
};