import React, { useState, useEffect, useContext } from 'react';
import { HotkeyContext } from '../../context/HotkeyContext';
import { ActionName, ACTION_CATEGORIES, ACTION_DISPLAY_NAMES, getHotkeyDisplay, DEFAULT_HOTKEYS } from '../../config/hotkeys';
import { UIContext } from 'context/UIContext';

interface HotkeySettingsPanelProps {
  onClose: () => void;
}

export const HotkeySettingsPanel: React.FC<HotkeySettingsPanelProps> = ({ onClose }) => {
  const { hotkeys, saveHotkeys, resetHotkeys } = useContext(HotkeyContext)!;
  const [tempHotkeys, setTempHotkeys] = useState(hotkeys);
  const [listeningFor, setListeningFor] = useState<ActionName | null>(null);
  const [conflicts, setConflicts] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const counts: Record<string, number> = {};
    const currentConflicts: Record<string, boolean> = {};

    Object.values(tempHotkeys).forEach((code) => {
      if (code) {
        // Ignore unbound actions
        counts[code] = (counts[code] || 0) + 1;
      }
    });

    Object.keys(tempHotkeys).forEach((action) => {
      const code = tempHotkeys[action as ActionName];
      if (code && counts[code] > 1) {
        currentConflicts[action] = true;
      }
    });

    setConflicts(currentConflicts);
  }, [tempHotkeys]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (listeningFor) {
        e.preventDefault();
        e.stopPropagation();

        let code = e.code;
        if (e.key === 'Escape') {
          code = ''; // Unbind
        }

        setTempHotkeys((prev) => ({
          ...prev,
          [listeningFor]: code,
        }));
        setListeningFor(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown, true);
    return () => window.removeEventListener('keydown', handleKeyDown, true);
  }, [listeningFor]);

  const handleSave = () => {
    if (Object.keys(conflicts).length > 0) {
      alert('Please resolve keybinding conflicts before saving.');
      return;
    }
    saveHotkeys(tempHotkeys);
    onClose();
  };

  const handleReset = () => {
    setTempHotkeys(DEFAULT_HOTKEYS);
  };

  return (
    <div className="hotkey-settings-panel">
      <p>Click a key to rebind it. Press Escape while rebinding to unbind an action.</p>
      {Object.entries(ACTION_CATEGORIES).map(([catKey, category]) => (
        <div key={catKey} className="hotkey-category">
          <h4>{category.name}</h4>
          <div className="hotkey-grid">
            {category.actions.map((action) => (
              <div key={action} className="hotkey-row">
                <span className="hotkey-label">{ACTION_DISPLAY_NAMES[action]}</span>
                <button
                  className={`hotkey-input-btn ${listeningFor === action ? 'listening' : ''} ${conflicts[action] ? 'conflict' : ''}`}
                  onClick={() => setListeningFor(action)}
                >
                  {listeningFor === action ? 'Press a key...' : getHotkeyDisplay(tempHotkeys[action]) || 'None'}
                </button>
              </div>
            ))}
          </div>
        </div>
      ))}
      <div className="hotkey-actions">
        <button className="btn btn-secondary" onClick={handleReset}>
          Reset to Defaults
        </button>
        <button className="btn" onClick={handleSave} disabled={Object.keys(conflicts).length > 0}>
          Save & Close
        </button>
      </div>
    </div>
  );
};
