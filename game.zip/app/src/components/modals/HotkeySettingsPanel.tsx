import React, { useContext, useEffect, useState } from 'react';
import { ACTION_CATEGORIES, ACTION_DISPLAY_NAMES, ActionName, DEFAULT_HOTKEYS, formatKeyCode, HotkeyConfig } from '../../config/hotkeys';

import { HotkeyContext } from '../../context/HotkeyContext';

interface HotkeySettingsPanelProps {
  onClose: () => void;
}

type ListeningState = {
  action: ActionName;
  type: 'primary' | 'secondary';
};

export const HotkeySettingsPanel: React.FC<HotkeySettingsPanelProps> = ({ onClose }) => {
  const { hotkeys, saveHotkeys } = useContext(HotkeyContext)!;
  const [tempHotkeys, setTempHotkeys] = useState<Record<ActionName, HotkeyConfig>>(hotkeys);
  const [listeningFor, setListeningFor] = useState<ListeningState | null>(null);
  const [conflicts, setConflicts] = useState<Record<string, { primary?: boolean; secondary?: boolean }>>({});

  useEffect(() => {
    const counts: Record<string, number> = {};
    const newConflicts: Record<string, { primary?: boolean; secondary?: boolean }> = {};

    Object.values(tempHotkeys).forEach((config) => {
      if (config.primary) counts[config.primary] = (counts[config.primary] || 0) + 1;
      if (config.secondary) counts[config.secondary] = (counts[config.secondary] || 0) + 1;
    });

    (Object.keys(tempHotkeys) as ActionName[]).forEach((action) => {
      const config = tempHotkeys[action];
      const actionConflicts: { primary?: boolean; secondary?: boolean } = {};
      if (config.primary && counts[config.primary] > 1) {
        actionConflicts.primary = true;
      }
      if (config.secondary && counts[config.secondary] > 1) {
        actionConflicts.secondary = true;
      }
      if (config.primary && config.secondary && config.primary === config.secondary) {
        actionConflicts.primary = true;
        actionConflicts.secondary = true;
      }
      if (actionConflicts.primary || actionConflicts.secondary) {
        newConflicts[action] = actionConflicts;
      }
    });

    setConflicts(newConflicts);
  }, [tempHotkeys]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (listeningFor) {
        e.preventDefault();
        e.stopPropagation();

        let code: string | null = e.code;
        if (e.key === 'Escape') {
          code = null;
        }

        setTempHotkeys((prev) => ({
          ...prev,
          [listeningFor.action]: {
            ...prev[listeningFor.action],
            [listeningFor.type]: code,
          },
        }));
        setListeningFor(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown, true);
    return () => window.removeEventListener('keydown', handleKeyDown, true);
  }, [listeningFor]);

  const handleClear = (actionToClear: ActionName) => {
    setTempHotkeys((prev) => ({
      ...prev,
      [actionToClear]: { primary: null, secondary: null },
    }));
  };

  const handleSave = () => {
    if (Object.keys(conflicts).length > 0) {
      alert('Please resolve keybinding conflicts before saving.');
      return;
    }
    saveHotkeys(tempHotkeys);
    onClose();
  };

  const handleReset = () => {
    setTempHotkeys(DEFAULT_HOTKEYS);
  };

  return (
    <div className="hotkey-settings-panel">
      <p>Click a key to rebind it. Press Escape while rebinding to unbind an action.</p>
      {Object.entries(ACTION_CATEGORIES).map(([catKey, category]) => (
        <div key={catKey} className="hotkey-category">
          <h3>{category.name}</h3>
          <div className="hotkey-grid">
            {category.actions.map((action) => {
              const hotkeyConfig = tempHotkeys[action];
              return (
                <div key={action} className="hotkey-row">
                  <span className="hotkey-label">{ACTION_DISPLAY_NAMES[action]}</span>
                  <div className="hotkey-binding-controls">
                    <button
                      className={`hotkey-input-btn ${listeningFor?.action === action && listeningFor.type === 'primary' ? 'listening' : ''} ${
                        conflicts[action]?.primary ? 'conflict' : ''
                      }`}
                      onClick={() => setListeningFor({ action, type: 'primary' })}
                    >
                      {listeningFor?.action === action && listeningFor.type === 'primary' ? '...' : formatKeyCode(hotkeyConfig.primary) || 'None'}
                    </button>
                    <button
                      className={`hotkey-input-btn ${listeningFor?.action === action && listeningFor.type === 'secondary' ? 'listening' : ''} ${
                        conflicts[action]?.secondary ? 'conflict' : ''
                      }`}
                      onClick={() => setListeningFor({ action, type: 'secondary' })}
                    >
                      {listeningFor?.action === action && listeningFor.type === 'secondary' ? '...' : formatKeyCode(hotkeyConfig.secondary) || 'None'}
                    </button>
                    <button className="btn" onClick={() => handleClear(action)}>
                      Clear
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
      <div className="hotkey-actions">
        <button className="btn btn-secondary" onClick={handleReset}>
          Reset to Defaults
        </button>
        <button className="btn" onClick={handleSave} disabled={Object.keys(conflicts).length > 0}>
          Save & Close
        </button>
      </div>
    </div>
  );
};
