import { ColumnDef, UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import React, { useContext, useMemo } from 'react';
import { GameData, ItemId, ItemInstance, SortKey } from '../../types';

import { DEFAULT_ITEM_FILTER_CATEGORIES } from 'components/inventory/InventoryControls';
import { GameDataContext } from 'context/GameDataContext';
import { UIContext } from 'context/UIContext';
import { useInventory } from 'hooks/useInventory';
import { useModalState } from 'hooks/useModalState';
import { getItemName } from 'utils/itemUtils';
import { Modal } from './Modal';

export const DebugShopModal: React.FC = () => {
  const { setActiveModal } = useContext(UIContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { addItem } = useInventory();
  const shopState = useModalState('debugShop', 'main');

  const defaultSort = useMemo(() => ({ key: 'itemLevel' as SortKey, direction: 'asc' as const }), []);
  const sortConfig = shopState.sortConfig === undefined ? defaultSort : shopState.sortConfig;

  const allItems = useMemo(() => {
    return (Object.keys(GAME_DATA.ITEMS) as ItemId[]).map((id) => ({
      id,
      unique_id: `debug_item_${id}`,
      quantity: 1,
      enchantments: {},
      isUnidentified: false,
    }));
  }, [GAME_DATA.ITEMS]);

  const handleBuy = (item: ItemInstance, quantity: number) => {
    addItem(item.id, quantity, { isUnidentified: false });
  };

  const getColumns = (GAME_DATA: GameData): ColumnDef[] => [
    { key: 'name', label: 'Name', render: (item) => getItemName(item, GAME_DATA), className: 'inventory-row-name', isSortable: true },
    {
      key: 'itemLevel',
      label: 'Level',
      render: (item) => GAME_DATA.ITEMS[item.id].itemLevel,
      className: 'inventory-row-level',
      isSortable: true,
    },
    {
      key: 'value',
      label: 'Value',
      render: (item) => `${GAME_DATA.ITEMS[item.id].value}g`,
      className: 'inventory-row-value',
      isSortable: true,
    },
  ];

  const columns = useMemo(() => getColumns(GAME_DATA), [GAME_DATA]);

  return (
    <Modal title={'Debug Shop'} onClose={() => setActiveModal(null)} size="xlarge">
      <p>All items are free. Go nuts. Click to buy selected amount. SHIFT+Click to buy selected amount.</p>
      <div className="shop-layout" style={{ gridTemplateColumns: '1fr' }}>
        <div className="shop-panel">
          <UnifiedInventoryDisplay
            title="All Game Items"
            items={allItems}
            initialView="detailed"
            onTransfer={handleBuy}
            filterCategories={DEFAULT_ITEM_FILTER_CATEGORIES}
            columns={columns}
            showViewToggle={true}
            showTransferControls={true}
            transferButtonText="Buy"
            isInfiniteStock={true}
            viewMode={shopState.viewMode}
            onViewModeChange={shopState.setViewMode}
            transferAmount={shopState.transferAmount}
            onTransferAmountChange={shopState.setTransferAmount}
            sortConfig={sortConfig}
            onSortChange={shopState.setSortConfig}
            showFilterSearchBar={true}
            showFilterButtonBar={true}
            disablePrimaryItemActions={true}
          />
        </div>
      </div>
    </Modal>
  );
};