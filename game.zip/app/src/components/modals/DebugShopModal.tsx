import React, { useContext, useMemo } from 'react';
import { ItemId, ItemInstance, GameData } from '../../types';
import { UnifiedInventoryDisplay, ColumnDef, FilterCategory } from 'components/shared/UnifiedInventoryDisplay';
import { Modal } from './Modal';
import { getItemName } from 'utils/itemUtils';
import { UIContext } from 'context/UIContext';
import { useInventory } from 'hooks/useInventory';
import { GameDataContext } from 'context/GameDataContext';

const SHOP_TABS: FilterCategory[] = [
  { key: 'All', label: 'All' },
  { key: 'equipment', label: 'Equipment' },
  { key: 'potion', label: 'Potions' },
  { key: 'material', label: 'Materials' },
  { key: 'tool', label: 'Tools' },
  { key: 'note', label: 'Writings' },
  { key: 'container', label: 'Containers' },
];

export const DebugShopModal: React.FC = () => {
  const { setActiveModal } = useContext(UIContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { addItem } = useInventory();

  const allItems = useMemo(() => {
    return (Object.keys(GAME_DATA.ITEMS) as ItemId[]).map((id) => ({
      id,
      unique_id: `debug_item_${id}`,
      enchantments: {},
      isUnidentified: false,
    }));
  }, [GAME_DATA.ITEMS]);

  const handleBuy = (_e: React.MouseEvent, item: ItemInstance) => {
    addItem(item.id, 1, { isUnidentified: false });
  };

  const getColumns = (GAME_DATA: GameData): ColumnDef[] => [
    { key: 'name', label: 'Name', render: (item) => getItemName(item, GAME_DATA), className: 'inventory-row-name', isSortable: true },
    {
      key: 'itemLevel',
      label: 'Level',
      render: (item) => GAME_DATA.ITEMS[item.id].itemLevel,
      className: 'inventory-row-level',
      isSortable: true,
    },
    {
      key: 'value',
      label: 'Value',
      render: (item) => `${GAME_DATA.ITEMS[item.id].value}g`,
      className: 'inventory-row-value',
      isSortable: true,
    },
  ];

  const columns = useMemo(() => getColumns(GAME_DATA), [GAME_DATA]);

  return (
    <Modal title={'Debug Shop'} onClose={() => setActiveModal(null)} size="xlarge">
      <p>All items are free. Go nuts.</p>
      <div className="shop-layout" style={{ gridTemplateColumns: '1fr' }}>
        <div className="shop-panel">
          <UnifiedInventoryDisplay
            title="All Game Items"
            items={allItems}
            initialView="detailed"
            onItemClick={handleBuy}
            filterCategories={SHOP_TABS}
            columns={columns}
            showViewToggle={false}
          />
        </div>
      </div>
    </Modal>
  );
};