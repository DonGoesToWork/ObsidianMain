import { BaseStatBlock, ClassId, Combatant, Mercenary, Player, RaceId, StatusEffectInstance } from 'types';
import React, { useContext } from 'react';

import { GameDataContext } from 'context/GameDataContext';
import { LimbDisplay } from './LimbDisplay';
import { ResourceBar } from '../shared/ResourceBar';
import { StatusEffectIcon } from '../shared/StatusEffectIcon';
import { UIContext } from 'context/UIContext';
import { WorldContext } from 'context/WorldContext';
import { useAttributes } from 'hooks/useAttributes';

interface CharacterVitalsPanelProps {
  character: Combatant | Player | Mercenary;
  contextualLinks?: boolean;
  layoutMode?: 'fill' | 'stack';
}

const STAT_DESCRIPTIONS: Record<string, string> = {
  strength: 'Increases Attack Power and Max Weight.',
  constitution: 'Increases maximum Health.',
  intelligence: 'Increases maximum Mana and Spell Power.',
  dexterity: 'Increases maximum Stamina, Evasion, and Critical Strike Chance.',
};

const AttributesDisplay: React.FC<{
  character: Player | Combatant | Mercenary;
}> = ({ character }) => {
  const { spendAttributePoint } = useAttributes();
  const isPlayer = 'professions' in character;
  const player = isPlayer ? (character as Player) : null;

  const coreStatKeys: (keyof BaseStatBlock)[] = ['strength', 'constitution', 'intelligence', 'dexterity'];
  const statsSource = character.totalStats;

  return (
    <div className="stats-panel" style={{ padding: 0, marginTop: '15px' }}>
      <h3>Attributes</h3>
      {player && player.attributePoints > 0 && <p className="points-available">Available points: {player.attributePoints}</p>}
      {coreStatKeys.map((stat) => (
        <p key={stat} className="stat-row">
          <strong title={STAT_DESCRIPTIONS[stat]}>{stat.charAt(0).toUpperCase() + stat.slice(1)}:</strong>
          <span>{statsSource[stat] || 0}</span>
          {player && player.attributePoints > 0 && (
            <button className="btn-plus" onClick={() => spendAttributePoint(stat)}>
              +
            </button>
          )}
        </p>
      ))}
    </div>
  );
};

export const CharacterVitalsPanel: React.FC<CharacterVitalsPanelProps> = ({ character, contextualLinks = false, layoutMode = 'fill' }) => {
  const { setActiveModal } = useContext(UIContext)!;
  const { gameTime, currentLocation } = useContext(WorldContext)!;
  const GAME_DATA = useContext(GameDataContext)!;

  const isPlayerCharacter = 'professions' in character;
  const isMercenary = 'mercenaryId' in character;
  const mainPlayer = isPlayerCharacter ? (character as Player) : null;

  const allStatusEffects = [...(character.statusEffects || []), ...Object.values(character.body).flatMap((l) => l.statusEffects || [])];

  const raceName = GAME_DATA.RACES[character.race as RaceId]?.name ?? character.race;
  const className = character.class === 'none' ? 'None' : GAME_DATA.CLASSES[character.class as ClassId]?.name ?? character.class;
  const subtitle = `${raceName} ${className}`;

  const groupedEffects = allStatusEffects.reduce((acc, instance) => {
    const key = `${instance.id}-${instance.currentStage}-${instance.turnsRemaining}-${instance.durationInMinutes}-${instance.isClosed}`;
    if (!acc[key]) {
      acc[key] = {
        representative: instance,
        count: 0,
      };
    }
    acc[key].count++;
    return acc;
  }, {} as Record<string, { representative: StatusEffectInstance; count: number }>);

  const locationLevel = currentLocation?.levelReq ? ` (Lvl ${currentLocation.levelReq})` : '';

  const currentWeight = (character as any).currentWeight ?? 0;
  const maxCarryWeight = (character as any).maxCarryWeight ?? 0;

  return (
    <>
      <div onClick={contextualLinks ? () => setActiveModal('character') : undefined} style={contextualLinks ? { cursor: 'pointer' } : {}}>
        <h2 id={isPlayerCharacter ? 'player-name' : undefined}>{character.name}</h2>
        <p className="player-subtitle" style={{ textTransform: 'capitalize' }}>
          {subtitle} ({character.level})
        </p>
      </div>

      {isPlayerCharacter && contextualLinks && mainPlayer && (
        <div className="player-info-section">
          <p>
            <span id="player-location">
              {currentLocation?.name}
              {locationLevel}
            </span>
          </p>
          <p>
            <span id="game-time">{gameTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
          </p>
          <p>Gold: {mainPlayer.gold.toLocaleString()}</p>
          <p>Fame: {mainPlayer.fame}</p>
          <p>
            Encumbrance:{' '}
            <span style={{ color: currentWeight > maxCarryWeight ? '#ff6b6b' : 'inherit' }}>
              {currentWeight.toFixed(1)} / {maxCarryWeight.toFixed(1)}
            </span>
          </p>
          <p>
            Party:{' '}
            <span
              id="party-size"
              onClick={contextualLinks ? () => setActiveModal('party-modal') : undefined}
              style={contextualLinks ? { cursor: 'pointer', textDecoration: 'underline' } : {}}
            >
              {mainPlayer.party.length} / 3
            </span>
          </p>
        </div>
      )}

      <div className={`player-panel-content ${layoutMode === 'stack' ? 'layout-stack' : ''}`}>
        {'xp' in character && 'xpToNextLevel' in character && <ResourceBar label="XP" current={character.xp} max={character.xpToNextLevel} color="#a08c2c" />}
        <hr className="stat-divider" />
        <LimbDisplay body={character.body} character={character} />
        <hr className="stat-divider" />
        <div className="resource-bars">
          <ResourceBar label="MP" current={character.mp} max={character.maxMp} color="#2c5da0" />
          <ResourceBar label="SP" current={character.sp} max={character.maxSp} color="#2ca055" />
        </div>

        {'vitals' in character && (
          <div className="resource-bars" style={{ marginTop: '8px' }}>
            <ResourceBar label="Hunger" current={character.vitals.hunger.current} max={character.vitals.hunger.max} color="saddlebrown" />
            <ResourceBar label="Thirst" current={character.vitals.thirst.current} max={character.vitals.thirst.max} color="#1d3c69" />
            {isMercenary ? (
              <ResourceBar label="Happiness" current={(character as Mercenary).happiness} max={100} color="#ffc107" />
            ) : (
              isPlayerCharacter && (
                <>
                  <ResourceBar label="Alertness" current={character.vitals.alertness.current} max={character.vitals.alertness.max} color="#8B0000" />
                  <ResourceBar label="Courage" current={character.vitals.courage.current} max={character.vitals.courage.max} color="#2E8B57" />
                </>
              )
            )}
          </div>
        )}

        {allStatusEffects.length > 0 && (
          <div id="status-effects-display">
            <div className="status-effect-row">
              {Object.values(groupedEffects).map(({ representative, count }, i) => (
                <StatusEffectIcon key={`${representative.id}-${i}`} statusEffectInstance={representative} count={count > 1 ? count : undefined} character={character} />
              ))}
            </div>
          </div>
        )}

        <AttributesDisplay character={character} />
      </div>
    </>
  );
};