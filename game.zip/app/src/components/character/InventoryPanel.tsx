import React, { useContext, useMemo } from "react";
import { useContextMenu, ContextMenuOption } from "../../context/ContextMenuContext";
import { ItemInstance, Mercenary } from "types";
import { UIContext } from "context/UIContext";
import { ProfessionsContext } from "context/ProfessionsContext";
import { useInventory } from "hooks/useInventory";
import { useParty } from "hooks/useParty";
import { useModalState } from "hooks/useModalState";
import { UnifiedInventoryDisplay } from "components/shared/UnifiedInventoryDisplay";
import { getStandardInventoryColumns } from "config/inventoryColumns";
import { GameDataContext } from "context/GameDataContext";

interface InventoryPanelProps {
  useHistoryForContainers?: boolean;
}

export const InventoryPanel: React.FC<InventoryPanelProps> = ({ useHistoryForContainers = false }) => {
  const { inventory, equipItem, consumeItem, giftItemToMercenary, dropItems } = useInventory();
  const { party } = useParty();
  const GAME_DATA = useContext(GameDataContext)!;
  const { identifyItem } = useContext(ProfessionsContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  const { showContextMenu } = useContextMenu();
  const STANDARD_INVENTORY_COLUMNS = useMemo(() => getStandardInventoryColumns(GAME_DATA), [GAME_DATA]);


  const { transferAmount, setTransferAmount } = useModalState("rightSidebarInventory", "main");

  const handleItemTransfer = (_item: ItemInstance, quantity: number, originalIndices: number[]) => {
    if (!inventory) return;
    const idsToDrop = originalIndices.slice(0, quantity).map((i) => inventory[i].unique_id);
    dropItems(idsToDrop);
  };

  if (!inventory || !party) return null;

  const handleItemClick = (item: ItemInstance, _originalIndices: number[]) => {
    const itemData = GAME_DATA.ITEMS[item.id];
    if (item.isUnidentified) {
      identifyItem(item.unique_id);
    } else if (itemData.type.includes("container")) {
      setActiveModal(
        "item-container-modal",
        {
          containerUniqueId: item.unique_id,
        },
        { history: useHistoryForContainers },
      );
    } else if (itemData.type.includes("equipment")) {
      equipItem(item.unique_id);
    } else if (itemData.type.includes("potion") || itemData.type.includes("note")) {
      consumeItem(item.unique_id);
    }
  };

  const handleItemContextMenu = (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => {
    e.preventDefault();
    e.stopPropagation();
    if (item.isUnarmed) return;

    const itemData = GAME_DATA.ITEMS[item.id];
    const options: ContextMenuOption[] = [];

    if (item.isUnidentified) {
      options.push({
        label: "Identify",
        onClick: () => identifyItem(item.unique_id),
      });
    } else {
      if (itemData.type.includes("container")) {
        options.push({
          label: itemData.type.includes("corpse") ? "Loot" : "Open",
          onClick: () =>
            setActiveModal(
              "item-container-modal",
              {
                containerUniqueId: item.unique_id,
              },
              { history: useHistoryForContainers },
            ),
        });
      } else if (itemData.type.includes("equipment")) {
        options.push({
          label: "Equip",
          onClick: () => equipItem(item.unique_id),
        });
      } else if (itemData.type.includes("potion")) {
        if (itemData.effect?.revive) {
          const corpseItems = inventory.filter((i: ItemInstance) => i.deceasedCharacter);
          if (corpseItems.length > 0) {
            options.push({
              label: "Use",
              subMenu: corpseItems.map((corpse: ItemInstance) => ({
                label: `On Corpse of ${corpse.deceasedCharacter!.name}`,
                onClick: () => consumeItem(item.unique_id, corpse.unique_id),
              })),
            });
          }
        } else {
          options.push({
            label: "Quaff",
            onClick: () => consumeItem(item.unique_id),
          });
        }
      } else if (itemData.type.includes("note")) {
        options.push({
          label: "Read",
          onClick: () => consumeItem(item.unique_id),
        });
      }
    }

    const giftSubMenu: ContextMenuOption[] = party.map((merc: Mercenary) => ({
      label: `Gift to ${merc.name}`,
      onClick: () => giftItemToMercenary(merc.id, item),
    }));

    if (giftSubMenu.length > 0) {
      options.push({ label: "Gift Item", subMenu: giftSubMenu });
    }

    if (!item.isUnarmed) {
      options.push({
        label: `Drop x${transferAmount}`,
        onClick: () => {
          const idsToDrop = originalIndices.slice(0, transferAmount).map((i) => inventory[i].unique_id);
          dropItems(idsToDrop);
        },
      });
    }

    if (options.length > 0) {
      showContextMenu(e.clientX, e.clientY, options);
    }
  };

  return (
    <UnifiedInventoryDisplay
      title="Inventory"
      items={inventory}
      onItemClick={handleItemClick}
      onItemContextMenu={handleItemContextMenu}
      onTransfer={handleItemTransfer}
      initialView="simple"
      columns={STANDARD_INVENTORY_COLUMNS}
      showSortButtons={true}
      showViewToggle={true}
      showTransferControls={true}
      transferButtonText="Drop"
      transferAmount={transferAmount}
      onTransferAmountChange={setTransferAmount}
    />
  );
};