import { ContextMenuOption, useContextMenu } from 'context/ContextMenuContext';
import { UIContext } from 'context/UIContext';
import { useInventory } from 'hooks/useInventory';
import React, { useContext } from 'react';
import { PlayerEquipmentSlot } from 'types';
import { EquipmentDisplay } from '../shared/EquipmentDisplay';

export const EquipmentPanel: React.FC = () => {
  const { equipment, unequipItem, doUseItemOnItem } = useInventory();
  const { showContextMenu } = useContextMenu();
  const { heldItem, setHeldItem } = useContext(UIContext)!;

  if (!equipment) return null;

  const handleItemClick = (e: React.MouseEvent, slot: PlayerEquipmentSlot) => {
    e.stopPropagation();
    const targetItem = equipment[slot];

    if (heldItem && targetItem) {
      doUseItemOnItem(heldItem.unique_id, targetItem.unique_id);
      setHeldItem(null);
    }
    // No other default click action for equipped items for now
  };

  const handleContextMenu = (e: React.MouseEvent, slot: PlayerEquipmentSlot) => {
    e.preventDefault();
    e.stopPropagation();
    const item = equipment[slot];
    if (!item) return;

    const options: ContextMenuOption[] = [];
    if (!item.isUnarmed) {
      options.push({
        label: 'Unequip',
        onClick: () => unequipItem(slot),
      });
    }

    if (options.length > 0) {
      showContextMenu(e.clientX, e.clientY, options);
    }
  };

  return (
    <div className="equipment-panel">
      <h3>Equipment</h3>
      <EquipmentDisplay equipment={equipment} onContextMenu={handleContextMenu} onItemClick={handleItemClick} />
    </div>
  );
};
