import { useInventory } from 'hooks/useInventory';
import React from 'react';
import { PlayerEquipmentSlot } from 'types';
import { ContextMenuOption, useContextMenu } from '../../context/ContextMenuContext';
import { EquipmentDisplay } from '../shared/EquipmentDisplay';

export const EquipmentPanel: React.FC = () => {
  const { equipment, unequipItem } = useInventory();
  const { showContextMenu } = useContextMenu();

  if (!equipment) return null;

  const handleContextMenu = (e: React.MouseEvent, slot: PlayerEquipmentSlot) => {
    e.preventDefault();
    e.stopPropagation();
    const item = equipment[slot];
    if (!item) return;

    const options: ContextMenuOption[] = [];
    if (!item.isUnarmed) {
      options.push({
        label: 'Unequip',
        onClick: () => unequipItem(slot),
      });
    }

    if (options.length > 0) {
      showContextMenu(e.clientX, e.clientY, options);
    }
  };

  return (
    <div className="equipment-panel">
      <h3>Equipment</h3>
      <EquipmentDisplay equipment={equipment} onContextMenu={handleContextMenu} />
    </div>
  );
};