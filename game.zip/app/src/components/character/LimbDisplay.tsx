import { GameDataContext } from 'context/GameDataContext';
import React, { useContext } from 'react';
import { BodyPlan, Combatant, Limb, Mercenary, Player } from 'types';
import { getWeaponDisplayStat } from 'utils/itemUtils';
import { StatusEffectIcon } from '../shared/StatusEffectIcon';

interface LimbDisplayProps {
  body: BodyPlan<Limb>;
  character: Combatant | Player | Mercenary;
}

export const LimbDisplay: React.FC<LimbDisplayProps> = ({ body, character }) => {
  const GAME_DATA = useContext(GameDataContext)!;
  return (
    <div className="limbs-display">
      {Object.values(body).map((limb) => {
        const percentage = limb.maxHp > 0 ? (limb.currentHp / limb.maxHp) * 100 : 0;

        const isWeaponHand = limb.equipmentSlots.includes('weapon');
        let weaponStatText = '';
        if (isWeaponHand && character.equipment.weapon) {
          const weaponStat = getWeaponDisplayStat(character.equipment.weapon, GAME_DATA);
          if (weaponStat) {
            weaponStatText = weaponStat.text;
          }
        }

        const text = `${limb.displayName}: ${limb.currentHp.toFixed(0)}/${limb.maxHp} (${percentage.toFixed(0)}%), 🛡️: ${limb.armorValue.toFixed(0)}${weaponStatText}`;

        const title = `HP: ${limb.currentHp.toFixed(0)} / ${limb.maxHp.toFixed(0)}, Armor: ${limb.armorValue.toFixed(0)}`;

        return (
          <div key={limb.id} className="limb-info-row">
            <div className="stat-bar-container limb-bar" title={title}>
              <div className="stat-bar">
                <div
                  className="bar-fill"
                  style={{
                    width: `${percentage}%`,
                    backgroundColor: limb.state === 'Injured' ? '#c88f2d' : limb.state === 'Destroyed' ? '#666' : '#a02c2c',
                  }}
                ></div>
              </div>
              <div className="bar-text">{text}</div>
            </div>
            <div className="limb-effects">
              {limb.statusEffects.map((effect, i) => (
                <StatusEffectIcon key={`${effect.instanceId}-${i}`} statusEffectInstance={effect} isLimbIcon={true} character={character} />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};
