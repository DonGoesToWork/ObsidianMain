import React, { useContext } from 'react';
import { BodyPlan, Limb, Combatant, Player, Mercenary } from 'types';
import { StatusEffectIcon } from '../shared/StatusEffectIcon';
import { GameDataContext } from 'context/GameDataContext';

interface LimbDisplayProps {
  body: BodyPlan<Limb>;
  character: Combatant | Player | Mercenary;
}

export const LimbDisplay: React.FC<LimbDisplayProps> = ({ body, character }) => {
  const GAME_DATA = useContext(GameDataContext)!;
  return (
    <div className="limbs-display">
      {Object.values(body).map((limb) => {
        const percentage = limb.maxHp > 0 ? (limb.currentHp / limb.maxHp) * 100 : 0;

        const isWeaponHand = limb.equipmentSlots.includes('weapon');
        let weaponStatText = '';
        if (isWeaponHand && character.equipment.weapon) {
          const weapon = character.equipment.weapon;
          const weaponData = GAME_DATA.ITEMS[weapon.id];
          let displayValue = 0;
          let baseValue = 0;
          let icon = '⚔️';

          if (weaponData?.stats?.attackPower) {
            baseValue = weaponData.stats.attackPower;
            icon = '⚔️';
          } else if (weaponData?.stats?.spellPower) {
            baseValue = weaponData.stats.spellPower;
            icon = '🥍';
          }

          if (baseValue > 0) {
            displayValue = baseValue;
            const plusValue = weapon.plus_value || 0;
            if (plusValue > 0) {
              displayValue += Math.ceil(baseValue * plusValue * 0.1);
            }
            weaponStatText = `, ${icon}:${displayValue}`;
          }
        }

        const text = `${limb.displayName}: ${limb.currentHp.toFixed(0)}/${limb.maxHp} (${percentage.toFixed(0)}%), 🛡️: ${limb.armorValue.toFixed(
          0
        )}${weaponStatText}`;

        const title = `HP: ${limb.currentHp.toFixed(0)} / ${limb.maxHp.toFixed(0)}, Armor: ${limb.armorValue.toFixed(0)}`;

        return (
          <div key={limb.id} className="limb-info-row">
            <div className="stat-bar-container limb-bar" title={title}>
              <div className="stat-bar">
                <div
                  className="bar-fill"
                  style={{
                    width: `${percentage}%`,
                    backgroundColor: limb.state === 'Injured' ? '#c88f2d' : limb.state === 'Destroyed' ? '#666' : '#a02c2c',
                  }}
                ></div>
              </div>
              <div className="bar-text">{text}</div>
            </div>
            <div className="limb-effects">
              {limb.statusEffects.map((effect, i) => (
                <StatusEffectIcon key={`${effect.instanceId}-${i}`} statusEffectInstance={effect} isLimbIcon={true} character={character} />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};