import React, { useState, useContext, useEffect } from 'react';
import { ProfessionsPanel } from './ProfessionsPanel';
import { AbilitiesPanel } from './AbilitiesPanel';
import { PerkPanel } from './PerkPanel';
import { useLearnedSkills } from 'hooks/useLearnedSkills';
import { AbilitiesListDisplay } from 'components/shared/AbilitiesListDisplay';
import { StatsPanel } from './StatsPanel';
import { Player, Mercenary, Combatant } from 'types';
import { useAbilities } from 'hooks/useAbilities';
import { usePlayer } from 'hooks/usePlayer';

type Tab = 'All' | 'Stats' | 'Professions' | 'Skills' | 'Spells' | 'Perks';

const AllTab: React.FC<{ character: Player | Mercenary | Combatant }> = ({ character }) => {
  const { toggleFavoriteAbility, favoriteAbilities } = useAbilities();
  const isPlayer = 'professions' in character;
  const stats = character.totalStats;

  return (
    <div className="character-tab-content">
      <StatsPanel stats={stats} />
      {isPlayer && (
        <>
          <hr className="stat-divider" />
          <ProfessionsPanel />
        </>
      )}
      <hr className="stat-divider" />
      <AbilitiesPanel character={character} onFavoriteToggle={isPlayer ? toggleFavoriteAbility : undefined} favoriteAbilities={isPlayer ? favoriteAbilities : undefined} />
      {isPlayer && (
        <>
          <hr className="stat-divider" />
          <PerkPanel />
        </>
      )}
    </div>
  );
};

const SkillsTab: React.FC<{ character: Player | Mercenary | Combatant }> = ({ character }) => {
  const { toggleFavoriteAbility, favoriteAbilities } = useAbilities();
  const learnedSkills = useLearnedSkills(character, 'Skill');
  const isPlayer = 'professions' in character;

  if (!character) return null;

  return (
    <div className="character-tab-content">
      <h3>Skills</h3>
      {learnedSkills.length === 0 ? (
        <p>No skills learned.</p>
      ) : (
        <AbilitiesListDisplay
          character={character}
          abilityIds={learnedSkills}
          onFavoriteToggle={isPlayer ? toggleFavoriteAbility : undefined}
          favoriteAbilities={isPlayer ? favoriteAbilities : undefined}
        />
      )}
    </div>
  );
};

const SpellsTab: React.FC<{ character: Player | Mercenary | Combatant }> = ({ character }) => {
  const { toggleFavoriteAbility, favoriteAbilities } = useAbilities();
  const learnedSpells = useLearnedSkills(character, 'Spell');
  const isPlayer = 'professions' in character;

  if (!character) return null;

  return (
    <div className="character-tab-content">
      <h3>Spells</h3>
      {learnedSpells.length === 0 ? (
        <p>No spells learned.</p>
      ) : (
        <AbilitiesListDisplay
          character={character}
          abilityIds={learnedSpells}
          onFavoriteToggle={isPlayer ? toggleFavoriteAbility : undefined}
          favoriteAbilities={isPlayer ? favoriteAbilities : undefined}
        />
      )}
    </div>
  );
};

interface CharacterTabsProps {
  character?: Player | Mercenary | Combatant;
}

export const CharacterTabs: React.FC<CharacterTabsProps> = ({ character: characterProp }) => {
  const player = usePlayer();
  const character = characterProp || player;

  const isPlayer = character ? 'professions' in character : false;
  const availableTabs: Tab[] = isPlayer ? ['All', 'Stats', 'Professions', 'Skills', 'Spells', 'Perks'] : ['All', 'Stats', 'Skills', 'Spells'];

  const getInitialTab = () => {
    return availableTabs[0];
  };

  const [activeTab, setActiveTab] = useState<Tab>(getInitialTab);

  useEffect(() => {
    if (!availableTabs.includes(activeTab)) {
      setActiveTab(availableTabs[0]);
    }
  }, [availableTabs, activeTab]);

  if (!character) {
    return null;
  }

  const renderTabContent = () => {
    if (!character) return null;
    const stats = character.totalStats;

    switch (activeTab) {
      case 'All':
        return <AllTab character={character} />;
      case 'Stats':
        return (
          <div className="character-tab-content">
            <StatsPanel stats={stats} />
          </div>
        );
      case 'Professions':
        return isPlayer ? (
          <div className="character-tab-content">
            <ProfessionsPanel />
          </div>
        ) : null;
      case 'Skills':
        return <SkillsTab character={character} />;
      case 'Spells':
        return <SpellsTab character={character} />;
      case 'Perks':
        return isPlayer ? (
          <div className="character-tab-content">
            <PerkPanel />
          </div>
        ) : null;
      default:
        return null;
    }
  };

  return (
    <div className="character-tabs-container">
      <div className="tabs">
        {availableTabs.map((tab) => (
          <button key={tab} className={`tab-btn ${activeTab === tab ? 'active' : ''}`} onClick={() => setActiveTab(tab)}>
            {tab}
          </button>
        ))}
      </div>
      <div className="tab-content">{renderTabContent()}</div>
    </div>
  );
};