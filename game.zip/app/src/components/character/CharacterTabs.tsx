import { AbilitiesListDisplay } from 'components/shared/AbilitiesListDisplay';
import { useAbilities } from 'hooks/useAbilities';
import { useLearnedSkills } from 'hooks/useLearnedSkills';
import { usePlayer } from 'hooks/usePlayer';
import React, { useEffect, useState } from 'react';
import { Combatant, Mercenary, Player, TotalPlayerStats } from 'types';
import { AbilitiesPanel } from './AbilitiesPanel';
import { PerkPanel } from './PerkPanel';
import { ProfessionsPanel } from './ProfessionsPanel';
import { StatsPanel } from './StatsPanel';

type Tab = 'All' | 'Stats' | 'Professions' | 'Skills' | 'Spells' | 'Perks';

const AllTab: React.FC<{ character: Player | Mercenary | Combatant }> = ({ character }) => {
  const { toggleFavoriteAbility, favoriteAbilities } = useAbilities();
  const isPlayer = 'professions' in character;
  const stats = character.totalStats;

  return (
    <div className="character-tab-content">
      <StatsPanel stats={stats} />
      {isPlayer && (
        <>
          <hr className="stat-divider" />
          <ProfessionsPanel />
        </>
      )}
      <hr className="stat-divider" />
      <AbilitiesPanel character={character} onFavoriteToggle={isPlayer ? toggleFavoriteAbility : undefined} favoriteAbilities={isPlayer ? favoriteAbilities : undefined} />
      {isPlayer && (
        <>
          <hr className="stat-divider" />
          <PerkPanel />
        </>
      )}
    </div>
  );
};

const StatsTab: React.FC<{ stats: TotalPlayerStats }> = ({ stats }) => (
  <div className="character-tab-content">
    <StatsPanel stats={stats} />
  </div>
);

const ProfessionsTab: React.FC = () => (
  <div className="character-tab-content">
    <ProfessionsPanel />
  </div>
);

const PerksTab: React.FC = () => (
  <div className="character-tab-content">
    <PerkPanel />
  </div>
);

const AbilityListTab: React.FC<{
  character: Player | Mercenary | Combatant;
  abilityType: 'Skill' | 'Spell';
}> = ({ character, abilityType }) => {
  const { toggleFavoriteAbility, favoriteAbilities } = useAbilities();
  const learnedAbilities = useLearnedSkills(character, abilityType);
  const isPlayer = 'professions' in character;

  if (!character) return null;

  return (
    <div className="character-tab-content">
      <h3>{abilityType}s</h3>
      {learnedAbilities.length === 0 ? (
        <p>No {abilityType.toLowerCase()}s learned.</p>
      ) : (
        <AbilitiesListDisplay
          character={character}
          abilityIds={learnedAbilities}
          onFavoriteToggle={isPlayer ? toggleFavoriteAbility : undefined}
          favoriteAbilities={isPlayer ? favoriteAbilities : undefined}
        />
      )}
    </div>
  );
};

interface CharacterTabsProps {
  character?: Player | Mercenary | Combatant;
}

export const CharacterTabs: React.FC<CharacterTabsProps> = ({ character: characterProp }) => {
  const player = usePlayer();
  const character = characterProp || player;

  const isPlayer = character ? 'professions' in character : false;
  const availableTabs: Tab[] = isPlayer ? ['All', 'Stats', 'Professions', 'Skills', 'Spells', 'Perks'] : ['All', 'Stats', 'Skills', 'Spells'];

  const getInitialTab = () => {
    return availableTabs[0];
  };

  const [activeTab, setActiveTab] = useState<Tab>(getInitialTab);

  useEffect(() => {
    if (!availableTabs.includes(activeTab)) {
      setActiveTab(availableTabs[0]);
    }
  }, [availableTabs, activeTab]);

  if (!character) {
    return null;
  }

  const renderTabContent = () => {
    if (!character) return null;

    switch (activeTab) {
      case 'All':
        return <AllTab character={character} />;
      case 'Stats':
        return <StatsTab stats={character.totalStats} />;
      case 'Professions':
        return isPlayer ? <ProfessionsTab /> : null;
      case 'Skills':
        return <AbilityListTab character={character} abilityType="Skill" />;
      case 'Spells':
        return <AbilityListTab character={character} abilityType="Spell" />;
      case 'Perks':
        return isPlayer ? <PerksTab /> : null;
      default:
        return null;
    }
  };

  return (
    <div className="character-tabs-container">
      <div className="tabs">
        {availableTabs.map((tab) => (
          <button key={tab} className={`tab-btn ${activeTab === tab ? 'active' : ''}`} onClick={() => setActiveTab(tab)}>
            {tab}
          </button>
        ))}
      </div>
      <div className="tab-content">{renderTabContent()}</div>
    </div>
  );
};
