import { ProfessionState } from 'types';
import React from 'react';
import { usePlayer } from 'hooks/usePlayer';

export const ProfessionsPanel: React.FC = () => {
  const player = usePlayer();
  if (!player) return null;

  return (
    <div className="professions-panel">
      <h3>Professions</h3>
      <div className="professions-grid">
        {Object.entries(player.professions).map(([id, state]: [string, ProfessionState]) => {
          const percentage = state.xpToNextLevel > 0 ? (state.xp / state.xpToNextLevel) * 100 : 100;
          const capitalizedId = id.charAt(0).toUpperCase() + id.slice(1);
          return (
            <div key={id} className="profession-grid-item" title={capitalizedId}>
              <h3>{capitalizedId}</h3>
              <p className="profession-level">Lvl {state.level}</p>
              <p className="profession-xp">
                {state.xp} / {state.xpToNextLevel} ({percentage.toFixed(0)}%)
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};
