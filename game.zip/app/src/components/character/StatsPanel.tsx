import React from 'react';
import { TotalPlayerStats } from 'types';

interface StatsPanelProps {
  stats: TotalPlayerStats;
}

const STAT_DISPLAY_ORDER = {
  Offense: ['attackPower', 'spellPower', 'critChance', 'attackSpeed', 'accuracy'],
  Defense: ['armor', 'evasion'],
  Utility: ['goldFind', 'xpGain', 'luck', 'worldHpRegen', 'worldMpRegen', 'worldSpRegen'],
};

const STAT_NAMES: Record<string, string> = {
  attackPower: 'Attack Power',
  spellPower: 'Spell Power',
  critChance: 'Critical Chance',
  attackSpeed: 'Attack Speed',
  accuracy: 'Accuracy',
  armor: 'Armor',
  evasion: 'Evasion',
  worldHpRegen: 'HP Regen/hr',
  goldFind: 'Gold Find',
  xpGain: 'XP Gain',
  worldMpRegen: 'MP Regen/hr',
  worldSpRegen: 'SP Regen/hr',
  luck: 'Luck',
};

export const StatsPanel: React.FC<StatsPanelProps> = ({ stats }) => {
  const formatStatValue = (statKey: string, value: number) => {
    if (['critChance', 'goldFind', 'xpGain'].includes(statKey)) {
      return `${value.toFixed(2)}%`;
    }
    if (statKey === 'attackSpeed') {
      return `${(value * 100).toFixed(0)}%`;
    }
    if (['worldHpRegen', 'worldMpRegen', 'worldSpRegen'].includes(statKey)) {
      return `${(value * 60).toFixed(2)}/hr`;
    }
    return Math.round(value);
  };

  return (
    <div className="stats-panel-categorized">
      {Object.entries(STAT_DISPLAY_ORDER).map(([category, statKeys]) => (
        <div key={category} className="stat-category">
          <h4>{category}</h4>
          {statKeys.map((statKey) => (
            <div key={statKey} className="stat-box">
              {STAT_NAMES[statKey]}
              <span>{formatStatValue(statKey, (stats as any)[statKey] || 0)}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};
