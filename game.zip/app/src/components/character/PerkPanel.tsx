import { useAbilities } from 'hooks/useAbilities';
import { usePlayer } from 'hooks/usePlayer';
import React from 'react';
import { AbilitiesListDisplay } from '../shared/AbilitiesListDisplay';

export const PerkPanel: React.FC = () => {
  const player = usePlayer();
  const { learnedPerks } = useAbilities();

  if (!player) {
    return null;
  }

  return (
    <div className="perks-panel">
      <h3>Perks</h3>
      {learnedPerks.length === 0 ? <p>No perks learned. Visit the Perks window to learn some.</p> : <AbilitiesListDisplay character={player} abilityIds={learnedPerks} />}
    </div>
  );
};
