import React from 'react';
import { AbilitiesListDisplay } from '../shared/AbilitiesListDisplay';
import { useLearnedSkills } from '../../hooks/useLearnedSkills';
import { AbilityId, Combatant, Mercenary, Player } from 'types';

interface AbilitiesPanelProps {
  character: Player | Mercenary | Combatant;
  onFavoriteToggle?: (abilityId: AbilityId) => void;
  favoriteAbilities?: AbilityId[];
}

export const AbilitiesPanel: React.FC<AbilitiesPanelProps> = ({ character, onFavoriteToggle, favoriteAbilities }) => {
  const learnedSkills = useLearnedSkills(character, 'Skill');
  const learnedSpells = useLearnedSkills(character, 'Spell');

  if (!character) {
    return null;
  }

  return (
    <div className="abilities-panel">
      <h3>Skills</h3>
      {learnedSkills.length === 0 ? (
        <p>No skills learned. Learn them from Skill Scrolls.</p>
      ) : (
        <AbilitiesListDisplay character={character} abilityIds={learnedSkills} onFavoriteToggle={onFavoriteToggle} favoriteAbilities={favoriteAbilities} />
      )}

      <hr className="stat-divider" />

      <h3>Spells</h3>
      {learnedSpells.length === 0 ? (
        <p>No spells learned. Learn them from Spell Tomes.</p>
      ) : (
        <AbilitiesListDisplay character={character} abilityIds={learnedSpells} onFavoriteToggle={onFavoriteToggle} favoriteAbilities={favoriteAbilities} />
      )}
    </div>
  );
};
