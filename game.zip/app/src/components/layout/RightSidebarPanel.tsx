import React, { useContext } from "react";

import { InventoryPanel } from "../character/InventoryPanel";
import { LogContext } from "context/LogContext";
import { LogDisplay } from "../shared/LogDisplay";

export const RightSidebarPanel: React.FC = () => {
  const { logs } = useContext(LogContext)!;

  return (
    <div id="right-sidebar-panel">
      <div className="sidebar-inventory-wrapper panel">
        <InventoryPanel />
      </div>
      <div className="sidebar-log-wrapper panel">{logs && <LogDisplay logs={logs} />}</div>
    </div>
  );
};
