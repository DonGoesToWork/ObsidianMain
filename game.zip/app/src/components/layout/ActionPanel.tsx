import React, { useContext } from 'react';

import { CombatActionPanel } from './CombatActionPanel';
import { WorldActionPanel } from './WorldActionPanel';
import { CombatContext } from 'context/CombatContext';

export const ActionPanel: React.FC = () => {
  const { currentCombat } = useContext(CombatContext)!;

  if (currentCombat?.isActive) {
    return <CombatActionPanel />;
  }

  return <WorldActionPanel />;
};
