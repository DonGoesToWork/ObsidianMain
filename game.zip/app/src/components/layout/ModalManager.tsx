import React, { useContext, Suspense, LazyExoticComponent } from 'react';
import { UIContext } from 'context/UIContext';

// Lazy load all modals for code-splitting and performance
const CharacterPageModal = React.lazy(() =>
  import('../modals/CharacterPageModal').then((m) => ({
    default: m.CharacterPageModal,
  }))
);
const ShopModal = React.lazy(() => import('../modals/ShopModal').then((m) => ({ default: m.ShopModal })));
const QuestLogModal = React.lazy(() => import('../modals/QuestLogModal').then((m) => ({ default: m.QuestLogModal })));
const BankModal = React.lazy(() => import('../modals/BankModal').then((m) => ({ default: m.BankModal })));
const PerksModal = React.lazy(() => import('../modals/PerksModal').then((m) => ({ default: m.PerksModal })));
const QuestGiverModal = React.lazy(() =>
  import('../modals/QuestGiverModal').then((m) => ({
    default: m.QuestGiverModal,
  }))
);
const CraftingModal = React.lazy(() => import('../modals/CraftingModal').then((m) => ({ default: m.CraftingModal })));
const NotImplementedModal = React.lazy(() =>
  import('../modals/NotImplementedModal').then((m) => ({
    default: m.NotImplementedModal,
  }))
);
const SettingsModal = React.lazy(() => import('../modals/SettingsModal').then((m) => ({ default: m.SettingsModal })));
const DebugModal = React.lazy(() => import('../modals/DebugModal').then((m) => ({ default: m.DebugModal })));
const ClinicModal = React.lazy(() => import('../modals/ClinicModal').then((m) => ({ default: m.ClinicModal })));
const InnModal = React.lazy(() => import('../modals/InnModal').then((m) => ({ default: m.InnModal })));
const RestModal = React.lazy(() => import('../modals/RestModal').then((m) => ({ default: m.RestModal })));
const InspectModal = React.lazy(() => import('../modals/InspectModal').then((m) => ({ default: m.InspectModal })));
const MercenaryGuildModal = React.lazy(() =>
  import('../party/MercenaryGuildModal').then((m) => ({
    default: m.MercenaryGuildModal,
  }))
);
const PartyModal = React.lazy(() => import('../party/PartyModal').then((m) => ({ default: m.PartyModal })));
const DebugShopModal = React.lazy(() =>
  import('../modals/DebugShopModal').then((m) => ({
    default: m.DebugShopModal,
  }))
);
const AppraiserModal = React.lazy(() =>
  import('../modals/AppraiserModal').then((m) => ({
    default: m.AppraiserModal,
  }))
);
const DeathModal = React.lazy(() => import('../modals/DeathModal').then((m) => ({ default: m.DeathModal })));
const ItemContainerModal = React.lazy(() =>
  import('../modals/ItemContainerModal').then((m) => ({
    default: m.ItemContainerModal,
  }))
);
const ConfirmationModal = React.lazy(() =>
  import('../modals/ConfirmationModal').then((m) => ({
    default: m.ConfirmationModal,
  }))
);

const MODAL_MAP: Record<string, LazyExoticComponent<React.FC<any>>> = {
  character: CharacterPageModal,
  'shop-modal': ShopModal,
  'quest-log': QuestLogModal,
  'bank-modal': BankModal,
  'perks-modal': PerksModal,
  'quest-modal': QuestGiverModal,
  'crafting-modal': CraftingModal,
  'not-implemented': NotImplementedModal,
  'settings-modal': SettingsModal,
  'debug-modal': DebugModal,
  'clinic-modal': ClinicModal,
  'inn-modal': InnModal,
  'rest-modal': RestModal,
  'inspect-modal': InspectModal,
  'mercenary-guild-modal': MercenaryGuildModal,
  'party-modal': PartyModal,
  'debug-shop-modal': DebugShopModal,
  'appraiser-modal': AppraiserModal,
  'death-modal': DeathModal,
  'item-container-modal': ItemContainerModal,
  'confirmation-modal': ConfirmationModal,
};

const ModalFallback: React.FC = () => (
  <div className="modal-content modal-small">
    <div className="modal-header">
      <h2>Loading...</h2>
    </div>
    <div className="modal-body">
      <p>Please wait...</p>
    </div>
  </div>
);

export const ModalManager: React.FC = () => {
  const { modalStack, setActiveModal } = useContext(UIContext)!;

  if (modalStack.length === 0) {
    return null;
  }

  return (
    <>
      {modalStack.map((modalState, index) => {
        const ModalComponent = MODAL_MAP[modalState.id];
        if (!ModalComponent) {
          console.warn(`No modal component found for key: ${modalState.id}`);
          return null;
        }

        const isTopModal = index === modalStack.length - 1;

        const handleBackdropClick = () => {
          if (isTopModal) {
            setActiveModal(null);
          }
        };

        return (
          <div className="modal-backdrop" style={{ zIndex: 1000 + index }} onClick={handleBackdropClick} key={`${modalState.id}-${index}`}>
            <div style={{ pointerEvents: isTopModal ? 'auto' : 'none' }}>
              <Suspense fallback={<ModalFallback />}>
                <ModalComponent {...modalState.options} />
              </Suspense>
            </div>
          </div>
        );
      })}
    </>
  );
};
