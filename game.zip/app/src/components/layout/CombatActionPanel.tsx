import React, { useContext } from 'react';

import { AbilityButtons } from 'components/shared/AbilityButtons';
import { AbilityId } from 'types';
import { COMBAT_ACTIONS } from '../../config/uiConfig';
import { CombatContext } from 'context/CombatContext';
import { GameDataContext } from 'context/GameDataContext';
import { HotkeyContext } from '../../context/HotkeyContext';
import { getHotkeyDisplay } from '../../config/hotkeys';
import { isCombatantDefeated } from 'utils/combatUtils';
import { useAbilities } from 'hooks/useAbilities';
import { usePlayer } from 'hooks/usePlayer';

export const CombatActionPanel: React.FC = () => {
  const player = usePlayer();
  const { learnedSkills, learnedSpells, favoriteAbilities } = useAbilities();
  const combatContext = useContext(CombatContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const { getHotkeyFor } = useContext(HotkeyContext)!;
  const { currentCombat, setSelectedAction, selectedAction, playerUseSkill } = combatContext;

  if (!player || !currentCombat) return null;

  const handleAbilityClick = (abilityId: AbilityId) => {
    const abilityData = GAME_DATA.SKILLS[abilityId];
    if (abilityData.targetRule === 'Self' || abilityData.targetRule === 'Field' || abilityData.targetRule === 'AllEnemies') {
      playerUseSkill(abilityId, 'player', null, false);
    } else {
      setSelectedAction({ type: 'skill', skillId: abilityId });
    }
  };

  const playerCombatant = currentCombat.combatants['player'];
  const isPlayerDead = isCombatantDefeated(playerCombatant);

  const favoritedIds = favoriteAbilities || [];
  const allLearnedAbilities = [...learnedSkills, ...learnedSpells];

  const currentFavoriteAbilities = favoritedIds.filter((id) => allLearnedAbilities.includes(id));
  const otherAbilities = allLearnedAbilities.filter((id) => !favoritedIds.includes(id));

  return (
    <fieldset disabled={isPlayerDead} style={{ border: 'none' }}>
      <div className="action-panel-grid">
        {COMBAT_ACTIONS.map((action) => (
          <button
            key={action.id}
            className={`btn combat-btn ${selectedAction?.type === action.id ? 'selected' : ''}`}
            onClick={() => {
              if (action.onClick) action.onClick(combatContext as any);
              else if (action.action) setSelectedAction(action.action);
            }}
            disabled={action.disabled ? action.disabled(combatContext as any) : false}
          >
            {action.label} ({getHotkeyDisplay(getHotkeyFor(action.actionName))})
          </button>
        ))}
      </div>

      {currentFavoriteAbilities.length > 0 && (
        <>
          <hr className="stat-divider" />
          <h3 className="action-panel-section-header">Favorite Abilities</h3>
          <AbilityButtons
            type="combat"
            abilityIds={currentFavoriteAbilities}
            character={playerCombatant}
            getHotkeyFor={getHotkeyFor}
            onAbilityClick={handleAbilityClick}
            isFavoriteList={true}
            selectedSkillId={selectedAction?.skillId}
          />
        </>
      )}

      {otherAbilities.length > 0 && (
        <>
          <hr className="stat-divider" />
          <h3 className="action-panel-section-header">Other Abilities</h3>
          <AbilityButtons
            type="combat"
            abilityIds={otherAbilities}
            character={playerCombatant}
            getHotkeyFor={getHotkeyFor}
            onAbilityClick={handleAbilityClick}
            selectedSkillId={selectedAction?.skillId}
          />
        </>
      )}

      {isPlayerDead && <p style={{ color: '#ff6b6b', textAlign: 'center', marginTop: '1em' }}>You are defeated. Combat will resolve automatically.</p>}
    </fieldset>
  );
};
