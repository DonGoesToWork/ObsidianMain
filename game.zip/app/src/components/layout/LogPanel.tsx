import React from 'react';
import { LogEntry } from 'types';
import { LogDisplay } from '../shared/LogDisplay';

interface LogPanelProps {
  logs: LogEntry[];
}

export const LogPanel: React.FC<LogPanelProps> = ({ logs }) => {
  return (
    <div id="log-panel" className="panel">
      <div id="log-container">
        <LogDisplay logs={logs} />
      </div>
    </div>
  );
};
