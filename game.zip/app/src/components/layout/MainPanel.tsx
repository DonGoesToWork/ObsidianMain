import React, { useContext } from "react";

import { ActionPanel } from "./ActionPanel";
import { CombatSimulatorScreen } from "../screens/CombatSimulatorScreen";
import CombatUI from "../CombatUI";
import DungeonScreen from "../screens/DungeonScreen";
import { GroundLootPanel } from "./GroundLootPanel";
import { HotkeyContext } from "../../context/HotkeyContext";
import { MAIN_PANEL_TABS } from "../../config/uiConfig";
import TownScreen from "../screens/TownScreen";
import WildsScreen from "../screens/WildsScreen";
import WorldMapScreen from "../screens/WorldMapScreen";
import { getHotkeyDisplay } from "../../config/hotkeys";
import { UIContext } from "context/UIContext";
import { WorldContext } from "context/WorldContext";
import { CombatContext } from "context/CombatContext";

export const MainPanel: React.FC = () => {
  const { setActiveModal } = useContext(UIContext)!;
  const { gameState } = useContext(WorldContext)!;
  const { currentCombat } = useContext(CombatContext)!;
  const { getHotkeyFor } = useContext(HotkeyContext)!;

  const renderScreen = () => {
    if (currentCombat?.isActive) return <CombatUI />;

    switch (gameState) {
      case "town":
        return <TownScreen />;
      case "wilds":
        return <WildsScreen />;
      case "world-map":
        return <WorldMapScreen />;
      case "dungeon":
        return <DungeonScreen />;
      case "combat-sim":
        return <CombatSimulatorScreen />;
      default:
        return <TownScreen />;
    }
  };

  return (
    <div id="main-panel" className="panel">
      <div className="main-panel-content-wrapper">
        <div className="main-panel-tabs">
          {MAIN_PANEL_TABS.map((tab) => {
            const hotkey = getHotkeyFor(tab.action);
            const hotkeyDisplay = hotkey ? ` (${getHotkeyDisplay(hotkey)})` : "";
            return (
              <button key={tab.label} className="btn" onClick={() => setActiveModal(tab.modal, tab.props)}>
                {tab.label}
                {hotkeyDisplay}
              </button>
            );
          })}
        </div>
        <div className="main-content-area">{renderScreen()}</div>
        <div className="main-content-bottom-area">
          <div className="party-hud-wrapper-panel">{/* <PartyHud /> */}</div>
          <div className="ground-loot-wrapper panel">
            <GroundLootPanel />
          </div>
        </div>
      </div>
      <div className="action-panel-sidebar">
        <ActionPanel />
      </div>
    </div>
  );
};