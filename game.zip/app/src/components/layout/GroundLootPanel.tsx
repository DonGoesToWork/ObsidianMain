import React, { useContext, useMemo } from "react";
import { UnifiedInventoryDisplay, ColumnDef } from "components/shared/UnifiedInventoryDisplay";
import { ItemInstance, ViewMode } from "types";
import { getItemName, getItemWeight } from "utils/itemUtils";
import { useContextMenu, ContextMenuOption } from "context/ContextMenuContext";
import { WorldContext } from "context/WorldContext";
import { UIContext } from "context/UIContext";
import { GameDataContext } from "context/GameDataContext";

const getGroundLootColumns = (GAME_DATA: any): ColumnDef[] => [
  {
    key: "name",
    label: "Name",
    render: (item, group) => `${getItemName(item)}${group.count > 1 ? ` (${group.count})` : ""}`,
    className: "inventory-row-name",
    isSortable: true,
  },
  {
    key: "weight",
    label: "Weight",
    render: (item) => getItemWeight(item, GAME_DATA).toFixed(1),
    className: "inventory-row-weight",
    isSortable: true,
  },
];

export const GroundLootPanel: React.FC = () => {
  const { currentLocation, grabItemsFromGround, identifyGroundItem } = useContext(WorldContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const GROUND_LOOT_COLUMNS = useMemo(() => getGroundLootColumns(GAME_DATA), [GAME_DATA]);
  const { modalUiSettings, setModalUiSettings } = useContext(UIContext)!;
  const { showContextMenu } = useContextMenu();

  const modalId = "groundLoot";
  const panelId = "main";

  const viewMode = (modalUiSettings[modalId]?.[panelId]?.viewMode as ViewMode) ?? "simple";
  const transferAmount = (modalUiSettings[modalId]?.[panelId]?.transferAmount as number) ?? 1;

  const updateSetting = (setting: "viewMode" | "transferAmount", value: any) => {
    setModalUiSettings((prev) => ({
      ...prev,
      [modalId]: {
        ...prev[modalId],
        [panelId]: {
          ...(prev[modalId]?.[panelId] ?? {}),
          [setting]: value,
        },
      },
    }));
  };

  const handleTransfer = (_item: ItemInstance, quantity: number, originalIndices: number[]) => {
    grabItemsFromGround(originalIndices.slice(0, quantity));
  };

  const handleItemClick = (item: ItemInstance, originalIndices: number[]) => {
    if (item.isUnidentified) {
      identifyGroundItem(originalIndices[0]);
    } else {
      handleTransfer(item, 1, originalIndices);
    }
  };

  const groundLoot = currentLocation?.groundLoot || [];

  const handleContextMenu = (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => {
    e.preventDefault();
    e.stopPropagation();

    const options: ContextMenuOption[] = [];
    const itemIndex = originalIndices[0];

    if (item.isUnidentified) {
      options.push({
        label: "Identify",
        onClick: () => identifyGroundItem(itemIndex),
      });
    }

    options.push({
      label: `Grab x${transferAmount}`,
      onClick: () => handleTransfer(item, transferAmount, originalIndices),
    });

    if (options.length > 0) {
      showContextMenu(e.clientX, e.clientY, options);
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ flexGrow: 1, minHeight: 0 }}>
        <UnifiedInventoryDisplay
          title="Ground Loot"
          items={groundLoot}
          onItemClick={handleItemClick}
          onTransfer={handleTransfer}
          onItemContextMenu={handleContextMenu}
          transferButtonText="Grab"
          columns={GROUND_LOOT_COLUMNS}
          showSortButtons={true}
          showViewToggle={true}
          showFilterBar={true}
          showTransferControls={true}
          viewMode={viewMode}
          onViewModeChange={(mode) => updateSetting("viewMode", mode)}
          transferAmount={transferAmount}
          onTransferAmountChange={(amount) => updateSetting("transferAmount", amount)}
        />
      </div>
      {groundLoot.length > 0 && (
        <div
          style={{
            display: "flex",
            justifyContent: "flex-end",
            marginTop: "10px",
            flexShrink: 0,
          }}
        >
          <button className="btn" onClick={() => grabItemsFromGround(groundLoot.map((_, i) => i))}>
            Loot All
          </button>
        </div>
      )}
    </div>
  );
};