import { ColumnDef, UnifiedInventoryDisplay } from 'components/shared/UnifiedInventoryDisplay';
import { ContextMenuOption, useContextMenu } from 'context/ContextMenuContext';
import { GameDataContext } from 'context/GameDataContext';
import { WorldContext } from 'context/WorldContext';
import { useModalState } from 'hooks/useModalState';
import React, { useContext, useMemo } from 'react';
import { ItemInstance, SortKey, ViewMode } from 'types';
import { getItemName, getItemWeight } from 'utils/itemUtils';

const getGroundLootColumns = (GAME_DATA: any): ColumnDef[] => [
  {
    key: 'name',
    label: 'Name',
    render: (item, group) => `${getItemName(item, GAME_DATA)}${group.count > 1 ? ` (${group.count})` : ''}`,
    className: 'inventory-row-name',
    isSortable: true,
  },
  {
    key: 'weight',
    label: 'Weight',
    render: (item) => getItemWeight(item, GAME_DATA).toFixed(1),
    className: 'inventory-row-weight',
    isSortable: true,
  },
];

export const GroundLootPanel: React.FC = () => {
  const { currentLocation, grabItemsFromGround, abandonAllLoot } = useContext(WorldContext)!;
  const GAME_DATA = useContext(GameDataContext)!;
  const GROUND_LOOT_COLUMNS = useMemo(() => getGroundLootColumns(GAME_DATA), [GAME_DATA]);
  const { showContextMenu } = useContextMenu();

  const groundLootState = useModalState('groundLoot', 'main');
  const defaultSortConfig = useMemo(() => ({ key: 'name' as SortKey, direction: 'asc' as const }), []);
  const sortConfig = groundLootState.sortConfig === undefined ? defaultSortConfig : groundLootState.sortConfig;

  const handleTransfer = (item: ItemInstance, quantity: number, originalIndices: number[]) => {
    const isStackable = GAME_DATA.ITEMS[item.id].stackable;

    if (isStackable) {
      grabItemsFromGround([{ representativeUniqueId: item.unique_id, quantity }]);
    } else {
      const groundLoot = currentLocation?.groundLoot || [];
      const itemsToGrab = originalIndices
        .slice(0, quantity)
        .map((index) => groundLoot[index])
        .filter((i): i is ItemInstance => !!i)
        .map((itemToGrab) => ({ representativeUniqueId: itemToGrab.unique_id, quantity: 1 }));

      if (itemsToGrab.length > 0) {
        grabItemsFromGround(itemsToGrab);
      }
    }
  };

  const handleItemClick = (_e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => {
    handleTransfer(item, 1, originalIndices);
  };

  const groundLoot = currentLocation?.groundLoot || [];

  const handleContextMenu = (e: React.MouseEvent, item: ItemInstance, originalIndices: number[]) => {
    e.preventDefault();
    e.stopPropagation();

    const options: ContextMenuOption[] = [];

    options.push({
      label: `Grab x${groundLootState.transferAmount}`,
      onClick: () => handleTransfer(item, groundLootState.transferAmount, originalIndices),
    });

    if (options.length > 0) {
      showContextMenu(e.clientX, e.clientY, options);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div style={{ flexGrow: 1, minHeight: 0 }}>
        <UnifiedInventoryDisplay
          title="Ground Loot"
          items={groundLoot}
          onItemClick={handleItemClick}
          onTransfer={handleTransfer}
          onItemContextMenu={handleContextMenu}
          transferButtonText="Grab"
          columns={GROUND_LOOT_COLUMNS}
          showSortButtons={true}
          showViewToggle={true}
          showFilterSearchBar={true}
          showFilterButtonBar={true}
          dynamicFilters={true}
          showTransferControls={true}
          viewMode={groundLootState.viewMode}
          onViewModeChange={groundLootState.setViewMode}
          transferAmount={groundLootState.transferAmount}
          onTransferAmountChange={groundLootState.setTransferAmount}
          sortConfig={sortConfig}
          onSortChange={groundLootState.setSortConfig}
          disablePrimaryItemActions={true}
        />
      </div>
      {groundLoot.length > 0 && (
        <div
          style={{
            display: 'flex',
            justifyContent: 'flex-end',
            gap: '10px',
            marginTop: '10px',
            flexShrink: 0,
          }}
        >
          <button className="btn btn-danger" onClick={() => abandonAllLoot?.()}>
            Abandon All
          </button>
          <button className="btn" onClick={() => grabItemsFromGround(groundLoot.map((item) => ({ representativeUniqueId: item.unique_id, quantity: item.quantity })))}>
            Loot All
          </button>
        </div>
      )}
    </div>
  );
};