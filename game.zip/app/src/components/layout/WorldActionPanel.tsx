import React, { useContext } from 'react';

import { AbilityButtons } from 'components/shared/AbilityButtons';
import { LogContext } from 'context/LogContext';
import { UIContext } from 'context/UIContext';
import { WorldContext } from 'context/WorldContext';
import { useAbilities } from 'hooks/useAbilities';
import { usePlayer } from 'hooks/usePlayer';
import { getHotkeyDisplay } from '../../config/hotkeys';
import { HotkeyContext } from '../../context/HotkeyContext';

export const WorldActionPanel: React.FC = () => {
  const player = usePlayer();
  const { favoriteAbilities, toggleFavoriteAbility, learnedSpells, learnedSkills } = useAbilities();
  const { gameState, changeGameState, currentLocation, travelTo, castAbilityOutOfCombat } = useContext(WorldContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  const { logMessage } = useContext(LogContext)!;
  const { getHotkeyFor } = useContext(HotkeyContext)!;

  if (!player || !favoriteAbilities) return null;

  const isExploring = gameState === 'world-map';
  const isEncumbered = player.currentWeight >= player.maxCarryWeight;
  const exploreButtonText = isExploring ? 'Return to Area' : 'Explore World';

  const handleExploreClick = () => {
    if (isEncumbered) {
      logMessage(
        {
          floatingText: 'Encumbered!',
          detailedText: 'You are too encumbered to travel.',
        },
        'error'
      );
      return;
    }
    if (isExploring) {
      if (currentLocation) {
        travelTo(currentLocation.id);
      }
    } else {
      changeGameState('world-map');
    }
  };

  const favoritedIds = favoriteAbilities || [];
  const allLearnedAbilities = [...learnedSkills, ...learnedSpells];

  const currentFavoriteAbilities = favoritedIds.filter((id) => allLearnedAbilities.includes(id));
  const otherAbilities = allLearnedAbilities.filter((id) => !favoritedIds.includes(id));

  return (
    <>
      <div className="action-panel-grid">
        <button className="btn" onClick={handleExploreClick} disabled={isEncumbered}>
          {exploreButtonText}
          {getHotkeyDisplay(getHotkeyFor('WORLD_EXPLORE'))}
        </button>
        <button className="btn" onClick={() => setActiveModal('wait-modal')}>
          Wait{getHotkeyDisplay(getHotkeyFor('WORLD_WAIT'))}
        </button>
        <button className="btn" onClick={() => setActiveModal('crafting-modal')}>
          Craft{getHotkeyDisplay(getHotkeyFor('WORLD_CRAFT'))}
        </button>
      </div>
      <hr className="stat-divider" />
      {currentFavoriteAbilities.length > 0 && (
        <>
          <h3 className="action-panel-section-header">Favorite Abilities</h3>
          <AbilityButtons
            type="world"
            abilityIds={currentFavoriteAbilities}
            character={player}
            getHotkeyFor={getHotkeyFor}
            onAbilityClick={(id, e) => e && castAbilityOutOfCombat(id, e)}
            onFavoriteToggle={toggleFavoriteAbility}
            isFavoriteList={true}
          />
        </>
      )}

      {otherAbilities.length > 0 && (
        <>
          <h3 className="action-panel-section-header">Other Abilities</h3>
          <AbilityButtons
            type="world"
            abilityIds={otherAbilities}
            character={player}
            getHotkeyFor={getHotkeyFor}
            onAbilityClick={(id, e) => e && castAbilityOutOfCombat(id, e)}
            onFavoriteToggle={toggleFavoriteAbility}
            isFavoriteList={false}
          />
        </>
      )}
    </>
  );
};