import React, { useContext } from 'react';
import { HotkeyContext } from '../../context/HotkeyContext';
import { getHotkeyDisplay } from '../../config/hotkeys';
import { usePlayer } from 'hooks/usePlayer';
import { useAbilities } from 'hooks/useAbilities';
import { WorldContext } from 'context/WorldContext';
import { UIContext } from 'context/UIContext';
import { LogContext } from 'context/LogContext';
import { AbilityButtons } from 'components/shared/AbilityButtons';

export const WorldActionPanel: React.FC = () => {
  const player = usePlayer();
  const { favoriteAbilities, toggleFavoriteAbility, learnedSpells, learnedSkills } = useAbilities();
  const { gameState, changeGameState, currentLocation, travelTo, castAbilityOutOfCombat } = useContext(WorldContext)!;
  const { setActiveModal } = useContext(UIContext)!;
  const { logMessage } = useContext(LogContext)!;
  const { getHotkeyFor } = useContext(HotkeyContext)!;

  if (!player || !favoriteAbilities) return null;

  const isExploring = gameState === 'world-map';
  const isEncumbered = player.currentWeight >= player.maxCarryWeight;
  const exploreButtonText = isExploring
    ? `Return to Area (${getHotkeyDisplay(getHotkeyFor('WORLD_EXPLORE'))})`
    : `Explore World (${getHotkeyDisplay(getHotkeyFor('WORLD_EXPLORE'))})`;

  const handleExploreClick = () => {
    if (isEncumbered) {
      logMessage(
        {
          floatingText: 'Encumbered!',
          detailedText: 'You are too encumbered to travel.',
        },
        'error'
      );
      return;
    }
    if (isExploring) {
      if (currentLocation) {
        travelTo(currentLocation.id);
      }
    } else {
      changeGameState('world-map');
    }
  };

  const favoritedIds = favoriteAbilities || [];
  const allLearnedAbilities = [...learnedSkills, ...learnedSpells];

  const currentFavoriteAbilities = favoritedIds.filter((id) => allLearnedAbilities.includes(id));
  const otherAbilities = allLearnedAbilities.filter((id) => !favoritedIds.includes(id));

  return (
    <>
      <div className="action-panel-grid">
        <button className="btn" onClick={handleExploreClick} disabled={isEncumbered}>
          {exploreButtonText}
        </button>
        <button className="btn" onClick={() => setActiveModal('rest-modal')}>
          Rest ({getHotkeyDisplay(getHotkeyFor('WORLD_REST'))})
        </button>
        <button className="btn" onClick={() => setActiveModal('crafting-modal')}>
          Craft ({getHotkeyDisplay(getHotkeyFor('WORLD_CRAFT'))})
        </button>
      </div>
      <hr className="stat-divider" />
      {currentFavoriteAbilities.length > 0 && (
        <>
          <h4 className="action-panel-section-header">Favorite Abilities</h4>
          <AbilityButtons
            type="world"
            abilityIds={currentFavoriteAbilities}
            character={player}
            getHotkeyFor={getHotkeyFor}
            onAbilityClick={(id, e) => e && castAbilityOutOfCombat(id, e)}
            onFavoriteToggle={toggleFavoriteAbility}
            isFavoriteList={true}
          />
        </>
      )}

      {otherAbilities.length > 0 && (
        <>
          <h4 className="action-panel-section-header">Other Abilities</h4>
          <AbilityButtons
            type="world"
            abilityIds={otherAbilities}
            character={player}
            getHotkeyFor={getHotkeyFor}
            onAbilityClick={(id, e) => e && castAbilityOutOfCombat(id, e)}
            onFavoriteToggle={toggleFavoriteAbility}
            isFavoriteList={false}
          />
        </>
      )}
    </>
  );
};
