import React, { useContext } from 'react';
import { Combatant, Limb, StatusEffectInstance } from 'types';

import { CombatContext } from 'context/CombatContext';
import { GameDataContext } from 'context/GameDataContext';
import { calculateHitChance } from 'utils/combatUtils';
import { getWeaponDisplayStat } from 'utils/itemUtils';
import { ResourceBar } from '../shared/ResourceBar';
import { StatusEffectIcon } from '../shared/StatusEffectIcon';

const LimbBar: React.FC<{
  limb: Limb;
  combatant: Combatant;
  selectedLimbId: string | null;
  isTargetable: boolean;
  onLimbSelect: (limbId: string) => void;
  accuracyText: string;
}> = ({ limb, combatant, selectedLimbId, isTargetable, onLimbSelect, accuracyText }) => {
  const GAME_DATA = useContext(GameDataContext)!;
  const percentage = limb.maxHp > 0 ? (limb.currentHp / limb.maxHp) * 100 : 0;

  const isWeaponHand = limb.equipmentSlots.includes('weapon');
  let weaponStatText = '';
  if (isWeaponHand && combatant.equipment.weapon) {
    const weaponStat = getWeaponDisplayStat(combatant.equipment.weapon, GAME_DATA);
    if (weaponStat) {
      weaponStatText = weaponStat.text;
    }
  }

  const text = `${limb.displayName}: ${limb.currentHp.toFixed(0)}/${limb.maxHp} (${percentage.toFixed(0)}%), 🛡️: ${limb.armorValue.toFixed(0)}${weaponStatText}`;
  const title = `${limb.displayName}: HP ${limb.currentHp.toFixed(0)} / ${limb.maxHp.toFixed(0)}, Armor: ${limb.armorValue.toFixed(0)}. ${accuracyText}`;

  return (
    <div
      className={`limb-bar-wrapper ${selectedLimbId === limb.id ? 'limb-selected' : ''} ${isTargetable ? 'limb-targetable' : ''}`}
      onClick={(e) => {
        e.stopPropagation();
        if (isTargetable) onLimbSelect(limb.id);
      }}
      title={title}
    >
      <div className="stat-bar-container limb-bar">
        <div className="stat-bar">
          <div
            className="bar-fill"
            style={{
              width: `${percentage}%`,
              backgroundColor: limb.state === 'Injured' ? '#c88f2d' : limb.state === 'Destroyed' ? '#666' : '#a02c2c',
            }}
          ></div>
        </div>
        <div className="bar-text">{text}</div>
      </div>
    </div>
  );
};

interface CombatantDisplayProps {
  combatant: Combatant;
  isSelected: boolean;
  onSelect: () => void;
  onLimbSelect: (limbId: string) => void;
  selectedLimbId: string | null;
  isTargetable: boolean;
  isDefeated: boolean;
}

export const CombatantDisplay: React.FC<CombatantDisplayProps> = ({ combatant, isSelected, onSelect, onLimbSelect, selectedLimbId, isTargetable, isDefeated }) => {
  const { currentCombat, selectedAction } = useContext(CombatContext)!;
  const GAME_DATA = useContext(GameDataContext)!;

  const getAccuracyTextForLimb = (limb: Limb): string => {
    const playerCombatant = currentCombat?.combatants.player;
    if (!playerCombatant || !selectedAction || !isTargetable || selectedAction.type === 'inspect' || combatant.team === 'player') {
      return '';
    }
    const hitChance = calculateHitChance(playerCombatant, combatant, limb, selectedAction, GAME_DATA);
    return hitChance >= 0 ? `(${hitChance.toFixed(0)}%)` : '';
  };

  const limbIsTargetable = (limb: Limb) => isTargetable && limb.state !== 'Destroyed';
  const combatantTitle = `${combatant.name} Lvl ${combatant.level} (${combatant.type})`;
  const canBeClicked = !isDefeated || isTargetable;
  const wrapperClass = `combatant-display ${combatant.team === 'player' ? 'player-team' : 'enemy-team'} ${isSelected ? 'selected' : ''} ${
    isTargetable && isSelected ? 'targetable-glow' : ''
  } ${isDefeated ? 'defeated' : ''}`;

  const allEffects = [
    ...combatant.statusEffects.map((instance) => ({
      instance,
      limbName: 'Body',
    })),
    ...Object.values(combatant.body).flatMap((limb) =>
      limb.statusEffects.map((instance) => ({
        instance,
        limbName: limb.displayName,
      }))
    ),
  ];

  const groupedEffects = allEffects.reduce((acc, { instance, limbName }) => {
    const key = `${instance.id}-${instance.currentStage}-${instance.turnsRemaining}-${instance.durationInMinutes}-${instance.isClosed}`;
    if (!acc[key]) {
      acc[key] = {
        representative: instance,
        limbs: [],
      };
    }
    acc[key].limbs.push(limbName);
    return acc;
  }, {} as Record<string, { representative: StatusEffectInstance; limbs: string[] }>);

  return (
    <div className={wrapperClass} onClick={canBeClicked ? onSelect : undefined} title={combatantTitle}>
      <h3>
        {combatant.name} <small>Lvl {combatant.level}</small>
      </h3>

      <div className="limb-display">
        {Object.values(combatant.body).map((limb: Limb) => (
          <LimbBar
            key={limb.id}
            limb={limb}
            combatant={combatant}
            selectedLimbId={selectedLimbId}
            isTargetable={limbIsTargetable(limb)}
            onLimbSelect={onLimbSelect}
            accuracyText={getAccuracyTextForLimb(limb)}
          />
        ))}
      </div>

      <div className="resource-bars-combat">
        <ResourceBar current={combatant.mp} max={combatant.maxMp} label="MP" color="#2c5da0" className="resource-bar" />
        <ResourceBar current={combatant.sp} max={combatant.maxSp} label="SP" color="#2ca055" className="resource-bar" />
      </div>

      <div className="status-effect-display-combat">
        {Object.values(groupedEffects).map(({ representative, limbs }, i) => (
          <StatusEffectIcon
            key={`${representative.instanceId}-${i}`}
            statusEffectInstance={representative}
            affectedLimbs={limbs}
            count={limbs.length > 1 ? limbs.length : undefined}
            character={combatant}
          />
        ))}
      </div>
    </div>
  );
};
