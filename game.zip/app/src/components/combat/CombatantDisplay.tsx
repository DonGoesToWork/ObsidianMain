import { Combatant, Limb, StatusEffectInstance } from 'types';
import React, { useContext } from 'react';

import { CombatContext } from 'context/CombatContext';
import { GameDataContext } from 'context/GameDataContext';
import { StatusEffectIcon } from '../shared/StatusEffectIcon';
import { calculateHitChance } from 'utils/combatUtils';

const LimbBar: React.FC<{
  limb: Limb;
  combatant: Combatant;
  selectedLimbId: string | null;
  isTargetable: boolean;
  onLimbSelect: (limbId: string) => void;
  accuracyText: string;
}> = ({ limb, combatant, selectedLimbId, isTargetable, onLimbSelect, accuracyText }) => {
  const GAME_DATA = useContext(GameDataContext)!;
  const percentage = limb.maxHp > 0 ? (limb.currentHp / limb.maxHp) * 100 : 0;

  const isWeaponHand = limb.equipmentSlots.includes('weapon');
  let weaponStatText = '';
  if (isWeaponHand && combatant.equipment.weapon) {
    const weapon = combatant.equipment.weapon;
    const weaponData = GAME_DATA.ITEMS[weapon.id];
    let displayValue = 0;
    let baseValue = 0;
    let icon = '⚔️';

    if (weaponData?.stats?.attackPower) {
      baseValue = weaponData.stats.attackPower;
      icon = '⚔️';
    } else if (weaponData?.stats?.spellPower) {
      baseValue = weaponData.stats.spellPower;
      icon = '🥍';
    }

    if (baseValue > 0) {
      displayValue = baseValue;
      const plusValue = weapon.plus_value || 0;
      if (plusValue > 0) {
        displayValue += Math.ceil(baseValue * plusValue * 0.1);
      }
      if (displayValue > 0) {
        weaponStatText = `, ${icon}:${displayValue}`;
      }
    }
  }

  const text = `${limb.displayName}: ${limb.currentHp.toFixed(0)}/${limb.maxHp} (${percentage.toFixed(0)}%), 🛡️: ${limb.armorValue.toFixed(0)}${weaponStatText}`;
  const title = `${limb.displayName}: HP ${limb.currentHp.toFixed(0)} / ${limb.maxHp.toFixed(0)}, Armor: ${limb.armorValue.toFixed(0)}. ${accuracyText}`;

  return (
    <div
      className={`limb-bar-wrapper ${selectedLimbId === limb.id ? 'limb-selected' : ''} ${isTargetable ? 'limb-targetable' : ''}`}
      onClick={(e) => {
        e.stopPropagation();
        if (isTargetable) onLimbSelect(limb.id);
      }}
      title={title}
    >
      <div className="stat-bar-container limb-bar">
        <div className="stat-bar">
          <div
            className="bar-fill"
            style={{
              width: `${percentage}%`,
              backgroundColor: limb.state === 'Injured' ? '#c88f2d' : limb.state === 'Destroyed' ? '#666' : '#a02c2c',
            }}
          ></div>
        </div>
        <div className="bar-text">{text}</div>
      </div>
    </div>
  );
};

interface CombatantDisplayProps {
  combatant: Combatant;
  isSelected: boolean;
  onSelect: () => void;
  onLimbSelect: (limbId: string) => void;
  selectedLimbId: string | null;
  isTargetable: boolean;
  isDefeated: boolean;
}

export const CombatantDisplay: React.FC<CombatantDisplayProps> = ({ combatant, isSelected, onSelect, onLimbSelect, selectedLimbId, isTargetable, isDefeated }) => {
  const { currentCombat, selectedAction } = useContext(CombatContext)!;
  const GAME_DATA = useContext(GameDataContext)!;

  const getAccuracyTextForLimb = (limb: Limb): string => {
    const playerCombatant = currentCombat?.combatants.player;
    if (!playerCombatant || !selectedAction || !isTargetable || selectedAction.type === 'inspect' || combatant.team === 'player') {
      return '';
    }
    const hitChance = calculateHitChance(playerCombatant, combatant, limb, selectedAction, GAME_DATA);
    return hitChance >= 0 ? `(${hitChance.toFixed(0)}%)` : '';
  };

  const limbIsTargetable = (limb: Limb) => isTargetable && limb.state !== 'Destroyed';
  const combatantTitle = `${combatant.name} Lvl ${combatant.level} (${combatant.type})`;
  const canBeClicked = !isDefeated || isTargetable;
  const wrapperClass = `combatant-display ${combatant.team === 'player' ? 'player-team' : 'enemy-team'} ${isSelected ? 'selected' : ''} ${
    isTargetable && isSelected ? 'targetable-glow' : ''
  } ${isDefeated ? 'defeated' : ''}`;

  const allEffects = [
    ...combatant.statusEffects.map((instance) => ({
      instance,
      limbName: 'Body',
    })),
    ...Object.values(combatant.body).flatMap((limb) =>
      limb.statusEffects.map((instance) => ({
        instance,
        limbName: limb.displayName,
      }))
    ),
  ];

  const groupedEffects = allEffects.reduce((acc, { instance, limbName }) => {
    const key = `${instance.id}-${instance.currentStage}-${instance.turnsRemaining}-${instance.durationInMinutes}-${instance.isClosed}`;
    if (!acc[key]) {
      acc[key] = {
        representative: instance,
        limbs: [],
      };
    }
    acc[key].limbs.push(limbName);
    return acc;
  }, {} as Record<string, { representative: StatusEffectInstance; limbs: string[] }>);

  return (
    <div className={wrapperClass} onClick={canBeClicked ? onSelect : undefined} title={combatantTitle}>
      <h3>
        {combatant.name} <small>Lvl {combatant.level}</small>
      </h3>

      <div className="limb-display">
        {Object.values(combatant.body).map((limb: Limb) => (
          <LimbBar
            key={limb.id}
            limb={limb}
            combatant={combatant}
            selectedLimbId={selectedLimbId}
            isTargetable={limbIsTargetable(limb)}
            onLimbSelect={onLimbSelect}
            accuracyText={getAccuracyTextForLimb(limb)}
          />
        ))}
      </div>

      <div className="resource-bars-combat">
        <div className="stat-bar-container resource-bar" title={`Mana: ${combatant.mp.toFixed(0)}/${combatant.maxMp}`}>
          <div id="mp-bar" className="stat-bar">
            <div
              className="bar-fill"
              style={{
                width: `${combatant.maxMp > 0 ? (combatant.mp / combatant.maxMp) * 100 : 0}%`,
              }}
            />
          </div>
          <div className="bar-text">{`MP: ${combatant.mp.toFixed(0)}/${combatant.maxMp} (${
            combatant.maxMp > 0 ? ((combatant.mp / combatant.maxMp) * 100).toFixed(0) : 0
          }%)`}</div>
        </div>
        <div className="stat-bar-container resource-bar" title={`Stamina: ${combatant.sp.toFixed(0)}/${combatant.maxSp}`}>
          <div id="sp-bar" className="stat-bar">
            <div
              className="bar-fill"
              style={{
                width: `${combatant.maxSp > 0 ? (combatant.sp / combatant.maxSp) * 100 : 0}%`,
              }}
            />
          </div>
          <div className="bar-text">{`SP: ${combatant.sp.toFixed(0)}/${combatant.maxSp} (${
            combatant.maxSp > 0 ? ((combatant.sp / combatant.maxSp) * 100).toFixed(0) : 0
          }%)`}</div>
        </div>
      </div>

      <div className="status-effect-display-combat">
        {Object.values(groupedEffects).map(({ representative, limbs }, i) => (
          <StatusEffectIcon
            key={`${representative.instanceId}-${i}`}
            statusEffectInstance={representative}
            affectedLimbs={limbs}
            count={limbs.length > 1 ? limbs.length : undefined}
            character={combatant}
          />
        ))}
      </div>
    </div>
  );
};