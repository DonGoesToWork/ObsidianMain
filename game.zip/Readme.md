cd /mnt/c/Users/donalda/Desktop/game_html
/mnt/c/Users/donalda/Desktop/game_html

**Python Scripts:**

python /mnt/c/Users/donalda/Desktop/game_html/prompts/1_input/3_prompt_gen.py
python /mnt/c/Users/donalda/Desktop/game_html/prompts/3_response/2_apply_response.py

cd /mnt/c/Users/donalda/Desktop/game_html/app ; npm start dev

cd C:\Users\Donald\Desktop\game_html\ ; git status
cd C:\Users\Donald\Desktop\game_html\app ; npm start dev
python C:\Users\Donald\Desktop\game_html\prompts\1_input\3_prompt_gen.py
python C:\Users\Donald\Desktop\game_html\prompts\3_response\2_apply_response.py

npx https://github.com/google-gemini/gemini-cli

# Add changes

git add . ; git commit -m "updates"

# Zipping project:

git archive --format=zip --output game.zip master
