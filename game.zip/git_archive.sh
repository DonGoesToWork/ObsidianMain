git archive --format=zip --output game.zip master
