git diff --word-diff --ignore-all-space
