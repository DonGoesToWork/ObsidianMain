git add . ; git commit -m "updates"
