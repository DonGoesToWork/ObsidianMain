1:

We are working on Chronicles of Aura, a brutal, procedurally generated turn-based RPG web game experience. And, there is a critical, fundamental flaw with the game architecture that I want to brainstorm a solution for with you.

Essentially, the web game is coded in such a way that if object properties change, we do not necessarily trigger recalculations of data or re-reneders of modals based on them, resulting in weird, strange, buggy and incorrect behaviors constantly.

For instance, right now, in the game, if I rest for 24 hours several times, it will cause my party members to die from thirst. This works fine and exactly as expected. But, what isn't fine, is that the code for converting a party member into a corpse on death isn't being run.

I could create add a specific, targetted fix that causes corpse creation logic to be generated on rest when a party member dies. However, that's just a band-aid to the more fundamental issue: my party member isn't creating a corpse when they die outside of combat. If I implement the band-aid, there is no garuntee some other condition won't crop up in the future that fails to address the fundamental issue. And, that's exactly what is happening right now in the first place.

Another example of this is, say, in the Debug Menu, I can change my thirst to 0. However, again, like with the party member, I do not die. This is because the game does not automatically check to see if I am alive or dead after each action. And yes, I could make it so that hitting the debug button triggers a check, but again that's unreasonable and kind of stupid - rather than add millions of conditional checks or even any sort of manual code to handle all of these various game conditions and results, I would ideally like to have a solution that always ensure core concerns are addressed, for instance, in this case: character's die when their thirst hits 0.

the reason it is important is to get a fundamental architectural change is because I already know that if thirst is fixed, it won't fix hunger, so hunger will need fixed next, and when curses get add that can be lethal, we'll need to add fixes for that.... and on and on in a nearly endless cycle u ntil the game is literally complete.

Is there a way that we can rewrite the game logic to ensure that, regardless of the source, core data state changes, like a change to player thirst, cascades to update all relevant modals, checks for party member survivability, etc. without needing ot write a bunch of event-specific checks?

What do you think? Am I wrong and maybe the 'one-off' changes are the best? Maybe we should do a full refactor of state management? Maybe there are npm packages that can help? Be creative, open-minded and think with an enterprise hat on what the best solution would be to handle this situation.

------------------------

2:

The theory behind what you said is sound, however, there are some clear side effects that worry me. Right now, when I drop and pick up items, the items disappear completely. They don't to the 'other inventory' as they are supposed to. I feel like there are going to be more of these side effects too, no? Re-evaluate your solution and really consider everything... we must be sure that if we use a solution, it doesn't break any existing functionality.
