Loot Quest is brutal scenario-driven power fantasy. Start as a literal slave and work your way up to whatever heights you aspire to achieve. Do you solely aspire for freedom? Or perhaps you seek to become something greater?
---

Description:

Loot Quest is my vision for what a truly brutal choice-driven game should be.
It's about playing as a character that has challenging encounters and must make meaningful decisions across hundreds of unique scenarios.
You will be put into unconfortable sitautions. You will need to make tough choices. There will be lasting consequences to your actions.
In the face of these completely unreasonable odds, will you merely survive?
Or will you escape your circumstances to thrive and conquer?

Features:

- Classic RPG Leveling - Lvls 1 to 100
- 30 Professions To Train to 100 - Smithing, Enchanting, Woodcutting, etc.
- 100s of Character Perks to Obtain
- 10+ Races with Powerful Racial Abilities
- 100s of Skills and Spells
- 15 Item Slots to Gear Up
- Overly Realistic Limb System
- Overly Realistic Debuff System
- 100s of Scenarios to Experience
- Many fully-fleshed out quest lines.
- Infinite dynamically generated content - World Tiles, Quests, Enemies, Dungeons, etc.
- A fully complete game with hundreds of hours of content.

DLC:

Think the game is great? Consider buying a supporter pack. Thanks! Tt's a great way to show support. And, you even get an extra chunk of post-game content.

AI Notice:

The story's verbal components - narratives, item names, descriptions, etc. - are all hand-written. Practically everything else was coded with the assistance of AI.
