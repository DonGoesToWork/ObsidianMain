I am working on a web game and need you to rework our item storage mechanisms greatly.

# Background

The idea behind the game is to have a balanced experience where you start weak and become extremely strong later on.
This is a level 1 to 100 type of game.
Level 1 tools are wooden, while level 100 tool are 'divine'. That's the kind of power scaling we're going for.

# Task - materials.ts rework

For the materials.ts file, we need to flesh it out more.
We want to start off by making sure that there is at least 1 item per 'tier'. A tier is level 1-9, 10-19, etc.
So, T1 materials are basic wooden, T2 is stone, T3 is tin/copper, T3.5 = bronze, etc.

What I want you to do is rebalance and flesh out the materials so that there are at least 11 materials in each category.
Also, move some of the objects around in a way that makes sense. For instance, I'd expect you to move 'mat_equip_copper' to 'mat_equip_copper_ore'.
Make sure that we are also keeping a reasonable balance in mind. Don't put Divinite in T1 and don't put Wood in T10.
If a list already has 11 items, don't add any more.

# Task items.ts rework

Currently, we are creating most of the crated items in items.ts manually by hand.
This is the wrong approach.
For crafted items, like a 'dagger', 'chestplate' or 'boots', we should be creating them dynamically using a generator function.

The idea is to make it so that we aren't creating hundreds of records using logic that can easily be baked into generator functions.
Make it so that there is no 'Wooden Dagger' that is listed in items.ts.
Instead, we should have a 'Dagger' base type with generator-related base information 'attack, attack speed, value, etc.'.
Then, we will generate 'Wooden Dagger' record by using a generator function during program start that iterates over our 'Equipment Materials' to create a Wooden Dagger in memory.
This will massively reduce the number of entries in items.ts while also automatically generating thousands of items for us.

For instance, this whole section should be reworked:

"    // Weapons (Base/Unique/Loot)
    'w001': { name: "Sword", type: ["equipment"], slot: "weapon", material: 'mat_equip_wood', itemLevel: 1, weight: 5, stats: { attackPower: 3 }, value: 20 },
    'w002': { name: "War-Axe", type: ["equipment"], slot: "weapon", material: 'mat_ingot_iron', itemLevel: 5, weight: 8, stats: { attackPower: 8, strength: 2 }, value: 150 },
    'w003': { name: "Staff", type: ["equipment"], slot: "weapon", material: 'mat_equip_wood', itemLevel: 1, weight: 4, stats: { spellPower: 5, intelligence: 1 }, value: 25, charges: 10, maxCharges: 10, chargeUnit: 'charge' },
    'w004': { name: "Dagger", type: ["equipment"], slot: "weapon", material: 'mat_ingot_iron', itemLevel: 1, weight: 2, stats: { attackPower: 2, dexterity: 2 }, value: 25 },
    'w005': { name: "Mace", type: ["equipment"], slot: "weapon", material: 'mat_equip_wood', itemLevel: 2, weight: 7, stats: { spellPower: 4, strength: 1 }, value: 30 },
    'w_bow01': { name: "Hunting Bow", type: ["equipment"], slot: "weapon", material: 'mat_equip_wood', twoHanded: true, itemLevel: 2, weight: 4, stats: { attackPower: 4, dexterity: 1 }, value: 35 },
    'w_bow02': { name: "Longbow", type: ["equipment"], slot: "weapon", material: 'mat_equip_wood', twoHanded: true, itemLevel: 8, weight: 5, stats: { attackPower: 9, dexterity: 3 }, value: 200 },
"

The goal for this is to also enable us to dynamically generate items via crafting recipes more easily too.
For instance, if a user has a smithing recipe for the 'Dagger' item, it should require number of ingots, a dagger mold and a known Dagger recipe to be crafted.

Uniquely named items with special properties and set items, for instance, won't be randomly generated though.

# Overall Conclusion

The goal of these changes is to add more base materials to the game that are balanced, while also dynamically generating items and content based on these materials.
We should look through the code to take this approach of dynamic generation when possible so that we can keep or code clean, lean and also easily expandable in the future.
