Focus on fleshing out game mechanics. Continue to develop our brand new skills feature.

The skills feature has certain aspects already implemented, like a 'Professions Tab' in the character view.
However, we still fundamentally lack many critical skill-related elements in the game.
- No way to mine.
- No way to smith.
- No way to enchant.
etc. etc. etc.

We urgently need to add a button 'Enchant Item' to our 'Action Bar' at the bottom (where it says 'Explore the World') to access the enchanting feature.
Make the 'Cursed Mine' into a 'mine' type area with the 'Mine Ore' action available.
In town, there should be a 'Smith Item' option there to smith items.

In the Whispering Forest, get rid of 'Skin Beast' option and 'Forage for Anything' buttons. We only need 'Forage', 'Cut Logs', 'Search for Tracks'.
Here is a recap of the skill expansion's goals that need fully implemented:

# Skills Feature Expansion:

Let's formally add a 'Skills' feature to the game.

- 'Skills tab' on character page showing exp / level of skills
- Skill should be categorized as 'Weapon Skills', 'Armor Skills', 'Crafting Skills', 'Gathering Skills', 'Utility Skills', etc.
- The level of your skill primarily influences the amount of benefit that the skill provides to the character RELATIVE to the level of the area you're in. So, take mining for instance: at 10 mining, you'll often get lots of goodies frequently while mining in a level 1 zone. But, in a level 20 zone, you will often times click 'Mine' and find nothing useful at all and will take longer per attempt.
- Items should be unidentified to start and require 'Appraisal' to be identified.
- Add new right-click option to identify items to unid'd items.
- Game's overall scaling is meant to be from level 1 to 100. So, balance skills effects and potency around that. 10 skills level below a given activity's difficulty level should be considered 'the lowest' in terms of being unskilled and you'd expect nearly a 0% success rate, while 10 skills above would be 'overleveled' and enjoy maximum benefits.
- We should also formally coin the term 'difficulty levels' for various activities formally based on area level, etc.
- Player may require skill-relevant equipment to perform skills. Low level tools should usually be available for purchase in shops. Actually good ones should need to be found as loot in the wilds.

## Add new skills:

Add 5 new skills to the game to start.

1: 'Mining' - Level effects mining speed & quality of ores, gems, magic stones, etc. found. Tool is pickaxe, which isn't required, but provides major bonus mining levels. Pickaxes are heavy, items should have weight modifiers. Character should have encumbrance based on strength. If not using a pickaxe, character strength should be used. Without sufficient strength, character should immediately fail mining attempts. Mining can only be done in mine areas via a 'Mine Stone' button.

2: 'Foraging' - Forage speed & quality of misc. resources found. Idea is that foraging lets you find things potentially left behind. For instance: empty potion bottle, stick, leaf, discarded potion, broken armor, potion with 1 dose left of something, unidentified herb, etc. Main appeals of foraging is ability to get crafting ingredients for certain skills, like herbs for potion brewing, and you can also rarely find items that are very useful relative to the area level, but have a downside, like a 'better-than-normal' armor, but it needs repaired or has a curse modifier. No tool requirement.

3: 'Appraisal' - Effects item identification speed and success rate. Tool is 'magnifying lens', which isn't required, but provides bonus levels. This skill is necessary for identifying loot yourself. Add a perk for Appraisal to attempt to auto-id items.

4: 'Enchanting' - Effects enchanting speed, success rate and quality of enchantments. Tools are consumable resource: magic crystal. Can enchant anywhere at any time as long as you have enough magic crystals.

Item's should also be able to roll 'enchantments'.
Enchantments don't use prefix/suffix systems like most ARPGs. Items should just have 'modifiers' that have an effect on the item or the user of the item.
Example modifiers might be, 'Swift', which increases an items attack speed by 10%. A suffix might be 'Healthy', which grants +1 Constitution.

Enchantments are an integral part of items and should fundamentally effect how tiems are presented to the user.
Depending on how many enchants an item has, the border of the item should change, along with the prefix before the item name.
The follower are the prefixes, text color and border colors items should have based on their enchanted value:

1 enchantment = Enchanted (light blue text)
2 enchantments = Rare (dark-blue)
3 enchantments = Very Rare (green)
4 enchantments = Epic (orange)
5 enchantments = Legendary (red)
6 enchantments = Artifact (purple)
7 enchantments = Divine (gold)

Note: Tools should have 'implicit modifiers' that are considered seperately from these 'external modifiers'.

Players should need to collect 'magic crystals' to perform enchantments. Adding modifiers to items requirements more magic crystals for higher grade enchantments. Failing with enchantments should have a random consequence based on enchanting skill level and luck: resources wasted (not too bad), item loses an enchantment (bad), item gains a curse (very bad), item is destroyed (worst). There should also be different tiers of magic crystal: T1 Magic Crystal, T2 Magic Crystal, ..., etc. Higher tier magic crystals should naturally be rarer to obtain, more valuable and be mandatory for higher level enchantments.

5: 'Smithing' - Effects smithing speed, success rate and quality of items. Dedicated tool is a hammer. Can only be done in town areas.

Item's should have 'Craftsmanship' quality modifier that get displayed as a line under the items name in its description: poor (grey text), average (white text), good (green text), great (blue text), exceptional (orange text), masterwork (purple text), one-of-a-kind (red text). Higher smithing increases your chances of getting higher quality modifiers. Quality modifiers should effect the implicit stats of items. 'Craftsmanship' should not effect the border color of the item.

6: 'Woodcutting' - Effects chopping speed, sucess rate and quality of logs. Dedicated tool is axe. Can only be done in forest areas.

# Recap

Identify elements of these skills that haven't been implemented and then implement them so that these features are Feature Complete in the game.

# Game Paths

Main Game Src Path: /mnt/c/Users/donalda/Desktop/game_html/app/src/
App.tsx path: /mnt/c/Users/donalda/Desktop/game_html/app/src/App.tsx
Components path: /mnt/c/Users/donalda/Desktop/game_html/app/src/components
.gitignore path: /mnt/c/Users/donalda/Desktop/game_html/app/src/.gitignore
