for my web game, I'd like to start to make sweeping changes to transition it more into a brutally difficult procedurally generated roguelike.
The goal is for playthroughs to be unique and for content scaling in the game to be truly infinite.
Let's get started by making these changes:

# Infinite Items

Fundamentally, item scaling should 'be infinite'. I'm going to say that a lot.

- All items should be made from a base material that has an item level associated with it. Each material should associate with items in a broad range of item levels (lowest material = 1-9, 2nd material = 10-19, 3rd material = 20-29, etc.)
- To start, for each item type, we want to generate a data object with at least 11 base materials for each type that starts with very common materials types and scales up to fantasy types. The idea is that the 'equipment' item type (weapons/swords/etc.) can initially be made with common wood and then eventually fantasy materials.
- In the future, we may have more than 11 base materials for a given item type, like equipment, so make sure to support specifying the exact item level of materials and allowing more than one material at a particular item level. For instance, at level 5, we may want to allow 'Stone' as a base material, 'Aga Wood' as a second one and 'Muscle Crab Spines' as a third one. The different materials may grant different innate modifiers to items, hence the need for support.

Crafting Materials (equipment/tools, etc.): Wood (1-9), Stone (10-19), Copper (20-29), Tin (20-29), Bronze (30-39), Iron (40-49), Steel (50-59), Mithril (60-69), Adamant (70-79), Crystal (80-89), Dragon Bone (90-99), Divinite (100).
Herbs: Aloe Herb, Fiery Herb, Frosty Herb, Shocking Herb, Magi's Boon Herb, Devil's Tongue Herb, Misty Herb, Spiritual Herb, Moondrop Herb, Starlit Herb, Divine Herb
Magic Crystals (for enchanting): T1 through T20 magic crystals.

Continue this trend for other item types as necessary.

# Infinite Exploration Regions

On game start, we should be garunteed to generate 1 town and 1 level forest right outside of the town that is level 1. Then, after that, we should generate a random area every 3 levels past that.

These areas should be forests, mines, towns and dungeons, as per our curent declaration rules.

As we go to higher level places, the quality of items that can be found increases (shops stock better goods for instance), but the challenges of everything increase constantly.

We should associate our new infinite items rules with the quality of loot found in regions.

# Misc. Infinity

Identify areas of the code where infinite scaling rules haven't been applied and apply infinite scaling to them.
