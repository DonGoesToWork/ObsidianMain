We are going to add touchups and polish to the web game now:

- The 'right-click menu' on items should go away when I click anywhere that is not on the menu itself or if I move my mouse a reasonable distance away from it. Currently, it doesn't go away until I actually click on the menu, which doesn't give me a chance to 'change my mind'.
- Put "Explore the World" button to the left of any other buttons in the action bar. (Should alwasy be left-most button).
Remove "Crafting Station / Enchanter" from town view. We have action buttons for these now.
- Remove "Jeweler Tiffany" from town view.
- Remove "Skinner Fiona" from town view.
- Remove "Faction Emissary' from town view - we're going to use only guilds.
- Add magic crystals T1 to the town shop.
- Use '🍖' meat on bone emoji for 'beast taming treat'.
- Use hammer icon for tools: 🔨
- Use 💎 for magic crystals, gems, etc.
- The shop should group items by type and have tabs at the top of the "For Sale" column to select 'All' or a specific type to narrow searches down now that they show lots of items.
- Greatly expand debug options menu to let us add +1, +5, +10, +100 levels, +10, 100, 1000, 10,000 gold, etc. etc. etc.
- Currently, all actions that get clicked in the 'Whispering Forest' are executed twice. Fix that.
- Make the 'exp gain messages' for skills give a better message like: '+1 Foraging Exp - 1% to next level - 1/100' for instance
- Perk text should be very descriptive and precise with what the perk does. For example, I'd improve Power Strike to say:

"Power Strike (Rank 1)
A powerful blow that deals 50% [+50% per rank] bonus weapon damage."

At rank 2, the text should be:

"Power Strike (Rank 1)
A powerful blow that deals 100% [+50% per rank] bonus weapon damage."

Shield Bash should be:

Shield Bash
Bash the enemy, dealing 25% [+5% per rank] base weapon damage. Has a 3% [+3% per rank] chance of stunning your foe, capped at 75%.

You see? More focused information that is more useful to the reader immediately. Do a full polish pass on all perks, active and passive.

- Skill bars for professions are not all the same width. They are based on the text above, causing some to be short and others to be long.
- Text for attribute points are not aligned in character page.
- Show "Difficulty: [num]" on the 'Forage', 'Cut Logs', etc. buttons. Should also put this on the Enchant Menu and other places as applicable.

# Recap

Identify elements of these skills that haven't been implemented and then implement them so that these features are Feature Complete in the game.

# Game Paths

Main Game Src Path: /mnt/c/Users/donalda/Desktop/game_html/app/src/
App.tsx path: /mnt/c/Users/donalda/Desktop/game_html/app/src/App.tsx
Components path: /mnt/c/Users/donalda/Desktop/game_html/app/src/components
.gitignore path: /mnt/c/Users/donalda/Desktop/game_html/app/src/.gitignore
