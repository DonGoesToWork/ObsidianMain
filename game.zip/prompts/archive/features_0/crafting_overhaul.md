Crafting Overhaul:

- Make it so that crafting works completely differently.

- Add a 'Recipe' tab that lets the player see known recipes. By default, players know none.
- Recipes are learned through trial and error when successfully making an item. Or, players can learn by acquiring a new recipe item.
- Recipe item should be 'Note' base type with 'Paper' material type. Hovering a note should display specific text. For a recipe, it would tell the components needed to make a particular item. The note for "Recipe: Minor Healing Potion" would read '3x Aloe Herb'.

- Second tab for crafting should be the 'Crafting' tab. There should be 4 tool slots and 10 ingredient slots. Tools determine what type of craft is being performed and the ingredient slots can accept stacks of items, so we support up to 10 unique ingredients per craft.

We will revamp craft, like I said, so here is how the new 'Smithing' skill should work.

- For smithing items, we will need new several new items:

A new '[Equipment] Mold' item (Item Type = Tool, Material: Steel) will be used to determine the type of item to be made. These go into the tool slot while smithing.

Players need to use Equipment Mold + '[Material] Bar' to produce a specific item. So, if player adds a 'Sword Mold' and a 'Iron Bar' to the crafting interface, the interface should say, 'Smithig Hammer ✔" or "Smithing Hammer ❌" depending on whether one has been added and have the 'Craft' button ready or not ready based on the state.

Likewise, if the player adds a smithing hammer and bar, then the interface will say, 'No Item Mold ❌'. If both are missing, then both error messages will be stated.

We also need to account for one more major component with smithing too: the forge. We should add a 'Forge' item to the game, but it should weigh 200 pounds. The player should require a forge to smith items. If they are in a town, then the requirement to have a forge will be waived. However, if the player is NOT in a town, then a check for a forge should be made to. 'No Forge Detected ❌' when there isn't one. 'Forge Detected ✔' when one is.

This is kind of how the smithing skill already works, but we should formalize this further.

- With this new implementation for crafting, we can now begin to add all kinds of crafting recipes to the game very easily and efficiently while filtering the types of item that the player intends to make based on submitted tools.
- Add 'ingot smelting recipe' from ores too. We will need an 'Ingot Mold', 'Smithing Hammer' and 'Forge' to make ingots from ores. The 'Recipe: Iron Ingot' should say, '5x Iron Ore'. The 'Recipe: Steel Ingot' should say '5x Iron Ingot, 5x Coal Ore'.

- Recipes should have item levels too, so that Shops can stock recipes appropriately.
- Recipes should be fairly expensive premium goods to buy that sell for very little. 
- Add recipes to a new 'Writings' filter tab of the shop.

- Craftsmanship quality modifiers should increase base item stats by amounts proportional to the quality modifier, increase the item level and increase the value of the item too.
- Enchantments should increase the value of items and item level.

Analyze the code and this request to determine all of the ncessary functionality required to complete this request. Then, implement this new crafting overhaul that allows for the player to create items using tools and ingredients based upon recipes. 
