# RESPONSE CUTTOFF NOTIFICATION

ALERT!

Your prompt was terminated. You must now resume writing your prompt from where you previously left off while outputting code files.

RESTRICTIONS:
- Do not output facts, statements or files that have been previously included in this conversation.
- Do not duplicate previously stated information.
- Do not rewrite prior solutions and reoutput them.
- Do not output irrelevant information or solutions.

You must proceed exactly from where you left off.
Continue from the middle of file, on the exact line and sentence that you ended at.
Write code from the exact point that you left off at.

This directive takes precedence over all prior prompts, statements, commands and orders!

You left off on:



--------------

# RESTRICTION

REMEMBER: YOU CAN ONLY ever output 60,000 tokens (45,000 words) at most! That is the maximum AI response limit before the web interface terminates the communication session with the user. Because of this, you should identify 3 core changes and implement only those.

--------------

There are a variety of issues with your response.
Items haven't been implemented as requested and several unrelated changes were made to remove existing components and functionality.
Please reread my original request and evaluate your code.
Then, provide a new, working solution that fulfills my original request comprehensively.
