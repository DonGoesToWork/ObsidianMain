
# Panel Unification Project

We are working toward creating modular, resuable panel components that encapsulate crucial character information, like name, race, class, limb hp, equipment, inventory, etc. and present them to the user in a variety of presentation formats. Here are more tweaks we need to make to achieve this gaol:

- In the Player Panel, put "Human Warrior (1)" <- that race, class, level information on a sub-header line below the character name:

abc
human warrior (1)

- Add this 'name' then 'race/class/level' information to the Character Modal's 1st column panel, Party Modal's individual character panels, Inspect Panel's 1st column.
- Also add location, time, gold, encum, party, xp bar, etc. Add all of that stuff there, similarly to the player panel into the character panel's view.
- Add Hunger, Thirst, Alertness, Courage to the Character Page 1st column too.
- Add attributes back to the bottom-left of the Player Panel.

Perform a thorough analysis of the code to the see what other information may be missing from being displayed on different pages and add them to these screens too. If there is information that you believe would be useful to be displayed, display it. I am currently in a seemingly endless back and forth battle of incrementally adding bits and pieces of one modal, panel, component to the other, when really, I want you to step back and view the entire product from a wide lens.

We want our information panels to be informative, look nice and all contain roughly the same level of inforamtion. Even seemingly irrelevant pieces of information, like location, should exist on party members and enemies and show on the party scren and Inspect page. I shouldn't have to specify every single change necessary to bring every single data point to light.
