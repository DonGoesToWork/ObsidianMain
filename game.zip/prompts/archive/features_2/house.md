
# Background

We want to add a house system to the game where you can progressively buy houses that give better and better features


- Add new button into town, "City Hall"
- In the City Hall, list properties that can be purchased: "Buy [Shack / House / Mansion / Castle ]"
- Property available to purchase should vary based on town level.

Town Levels 1 - 50 all offer the ability to buy the following: Shack, Small House, House, Large House, Mansion, 
Town levels 

Manner (6th), Castle (7th), Palace (8th), Floating Island (9th), Pocket Dimension (10th)



House, Mansion

- Add divider between current existing town screen and new 'properties' section.
- Buying any property should add new buttons to the main town screen that references the property that has been purchased.



Th
- Add new button to game window, "Buy Shack"
- Can click shack button and have options to purchase various items and upgrades depending on the level of the town.


- The different sizes of property effect 



 "Buy House, Buy Mansion, Buy Castle"


, "Buy [Property]"
- Property types that are available 

In towns, add a new option, "Buy House". Depend 
