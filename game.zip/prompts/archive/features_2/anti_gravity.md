
We want to make some additions/changes to the enchantment system. Specifically, we want all types of items to be enchantable, with restrictions, so that we can have even seemingly normal items become extremely potent with the right enchantments. To do this, implement the following:

- If this isn't already the case, modify the code to be able to enchant literally any type of item with enchantments.
- Make it so that enchantments have a type restriction property that allows for any number of types to be specified on them in regards to the items that they can be enchanted on.
- To test these changes fully, add a new 'T11' enchantment -> 'Anti-Gravity':
- Anti-=Gravity can e applied to any item type, from equipment, to writings, to potions, to containers.
- When Anti-Gravity is applied to a container, it should cause the chest weight to be equal to the inverse of its content's weight -> Math.abs([total content's weight]). This will cause it to negate the weight of its contents and truly be, as the name implies, 'Anti-Gravity'.
- 'Anti-Gravity' should be a T11 enchantment that requires the highest tier enchanting resources to create.

--------------

- Had to fix tooltips to show enchantments on chests
- Had to fix weight manually (was doing -math.abs)

