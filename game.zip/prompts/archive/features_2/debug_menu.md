# Pt. 1:

We want to make the debug feature much more comprehensive with its functionality. As such, we will rework its layout and add a variety of new controls aimed at making it more powerful.

1. Add tabs to the Debug Menu titled, "Player, Party, Enemy, All, General":

- Player: Player only changes, plus attribute points to spend, plus perk points, etc.
- Party: Restore and remove hunger or thirst, add gold, modify health/mp/sp, change limb states, etc.
- Enemy: Similar to party, but more limited and enemy-exclusive - no hunger/thirst/gold mods, but can still add stats, modify hp/mp/sp, change limb states, etc.
- All: Changes that apply to all - modify stats, modify hp/mp/sp, change limb states, etc.
- General: Add currrent non-character related debug options like 'Open Combat Sim' from 'Max Debug' to here, etc.

In the "Party" and "Enemy" tabs, the left-most column of the modal should let us radio boxes to select: "Player / [Party Member 1 Name] / [Party Member 2 Name] / [Party Member 3 Name]" or "[Enemy 1 Name] ... rest of enemies" respectively with buttons to select 'All' or 'None' quickly too.

The recommended design is to add a targetting infrastructure for the debug menu that changes targets based on the tab the user clicks.
Then, whenever a button is pressed, the function assigned to the button is called on every target specified by the tab.

This also means that we should be able repeat buttons across tabs in a modular way with no code duplication, indicating a need for our architecture to decentralize target selection logic and buttno operation logic from the primary debug modal view, so that we can mix and match targets and button operaitons flexibly.

Create this new architecture and then assign our existing buttons to the new tabs so that we can call a plethora of operations upon in-game characters to test a variety of game conditions dynamically.

# Pt. 2

We are working on improving the debug menu. To achieve this, we have added tabs and buttons that perform operations based on targets specified by tabs.

Now, we want to improve the features of the debug menu while circling back to the core game logic to ensure that any logic that we wish to execute in the debug menu is natively supported within the core game code.

Make the following changes in the debug menu and ensure that the specific (target + operation) combos possible by all new created (tab + button) combinations are supported by the game code:

- Add "Learn All Skills" and "Learn All Spells" button to the "Party", "Enemy" and "All" tabs -> all characters must be capable of learning any skill or spell
- Move "Open Debug Shop" to "General" tab.
- Split "Currency & Items" into 2 sections: "Currency" / "Items"
- Add new "Currency" section to Party tab -> make sure that party members can have their current amounts increased and decreased
- Add new "Items" section to Party, Enemy and All tabs. -> should be able to arbitrarily give/remove items to people/enemies at will
- Add "Experience and Levels" to Party, Enemy and All tabs -> again, should be able to arbitrarily increase/decrease exp, levels, etc.
