**Design Goal:** A core element of the game is to NOT kill the player immediately. We want to wear the player down and have them die from laziness, poor planning, or rarely excessive bad luck.

To achive this, we want our status effect system to reflect this. We MUST do a complete overhaul of the status effect system, gutting out and completely refactoring anything that doesn't fit this vision.

A few major aspects of our status effect system that make it unique are:
- status effects are linked to limbs and each other: an open wound can link to a bleed, so when the wound is healed, the bleed is healed. If a limb is bleeding and gets chopped off, the limb will get the 'bleeding out' state. An infection in one limb can travel from one limb to another. The same for other issues like overheating and freezing.
- status effects have 'stages', a progression tier that influences what debuff is currently active and its effects

**Status Effect Logic:**

As stated before, status effects should all be logically based on damage, situation and even other status effects, tending to start simple and progress from one thing to another while considering a variety of logical factors.

The following are some examples of how status effects should work in accordance with my vision. The debuff should state the generic name for the title of the actual debuff, then below that, the description should be given of the more exact debuff in effect.

1. Cut:

Max Stages = 5
Cuts are injuries to the player that are applied by slashing and piercing damage.
Cuts can be 'open' or 'patched'.
Cuts default to 'open' when applied.
A 'cut' may be patched with an appropriately tired restorative, making it 'Patched', causing its associated bleed to be removed and for the risk of infection to decrease to 0%.
An unpatched 'cut' has a chance to become 'infected' and applies 'external bleed' debuffs at stage 2 and up.
The severity of applied cuts to the body should depend on how much damage is dealt to a given limb.
Limbs can have multiple cuts at different stages and multiple bleeds.

- Cut I:

Description = "Scratch".
Inflicted when taking 10-20% limb hp damage.
0.001% chance to gain 'Infection 1' debuff every 6 seconds when unpatched.
This debuff automatically heals after 30 minutes of game time has passed.

- Cut II:

Description = "Cut"
Inflicted when taking 20-30% limb hp damage.
0.01% chance to gain 'Infection 1' every 6 seconds when unpatched.
Automatically applies the 'External Bleed I' debuff to limb.
This debuff 'heals' (really transfers) into a Cut I after 24 hours of game time. Patch state transfers when 'healing'.

- Cut III:

Description = "Slash"
Inflicted when taking 30-40% limb hp damage.
0.1% chance of infection every 6 seconds when unpatched.
Applies 'External Bleed II' debuff to imb.
This debuff changes into a Cut II after 24 hours of game time. Patch state transfers when 'healing'.

- Cut IV:

Description = "Gash"
Inflicted when taking 40-99% limb hp damage.
1% chance of infection every 6 seconds when unpatched.
Applies 'External Bleed III' debuff to limb.
This debuff 'heals' into a Cut III after 24 hours of game time. Patch state transfers when 'healing'.

- Cut V:

Description = "Severed"
Inflicted when taking 100% limb hp damage.
1% chance of infection every 6 seconds on limb when unpatched.
Applies 'External Bleed IV' to the limb.
All other debuffs are removed from the limb.
This debuff does NOT heal after any amount of game time.

2. External Bleed

External Bleeds are created by 'cut' debuffs and logically bound to them. If a 'cut' decreases in stage from 3 to 2 (III to II), then the bleed should be reduced too. The reverse is not true, however. If we stop the bleeding of a 'cut', this doesn't necessarily mean that the 'cut' itself will decrease stages. The logic behind this is that you can put a bandage on the 'cut' to stop the bleeding, but that doesn't necessarily heal the 'cut'.

When a limb has a damage dealing debuff (like bleed), is severed (Cut V, for instance), and would take damage from bleed, the damage should be inflicted upon the torso in place of the severed limb.

External Bleeds deal physical damage over time to the holder exclusively.

External Bleed I:
Description = "Small Bleed"
-0.1% hp per game turn

External Bleed II:
Description = "Bleeding"
-1% hp per game turn

External Bleed III:
Description = "Major Bleed"
-5% hp per game turn

External Bleed IV:
Description = "Gushing Bleed"
-10% hp per game turn

External Bleed V:
Description = "Draining Blood"
-25% hp per game turn

## Other Status Effect Errors

The tooltip should say:

[status effect] [stage]
[status effect stage name]
[literal effect]
[description]
[remaining duration]

ex:

External Bleed I
Small Bleed
-1 hp/s
Losing a small amount of health.
1h remaining

## Restoratives:

Cut I is closed with "Bandage" - An ordinary bandage suitable for patching wounds.
Cut II is closed with "Large Bandage" - A large bandage suitable for patching large wounds.
Cut III is closed with "Advanced Bandage" - An advanced bandage layered with creams and ointments capable of closing the toughest wounds. 
Cut IV is closed with "Supreme Bandage" - A bandage using advanced technology to clot blood and prevent wounds from bleeding any further.
Cut V is closed with "Magic Bandage" - A magic bandage that can mystically close any wound.

When a cut is 'patched' (aka closed) by the appropriate treatment, its associated bleed should be cured and removed.
A patched cut will still require its stated time to heal. And, cuts heal in stages, meaning, Cut II requires 24 hours to heal and becomes a Cut I. Then, after 30 minutes, the Cut I vanishes and you are fully healed.
If a wound is attacked again while patched, it should be liable to open back up and have a small chance (20%) to become worse than before.
The message in this situation would be "Your patch breaks and your wound bursts open."
Bandages should have right-click 'apply' message that has sub-menu to click bleeding limb to apply bandage to.

# Problem Solving Strategy

Analyze my request, the code and all supplamental data to determine requirements, then create a comprehensive solution to implement all requested functionality.
Finally, implemenet the solution in the requested format.

# Game Paths

Main Game Src Path: /mnt/c/Users/donalda/Desktop/game_html/app/src/
App.tsx path: /mnt/c/Users/donalda/Desktop/game_html/app/src/App.tsx
Components path: /mnt/c/Users/donalda/Desktop/game_html/app/src/components
.gitignore path: /mnt/c/Users/donalda/Desktop/game_html/app/src/.gitignore
