

We are working on adding Item Container Support to the game:

- create a new 'Item Container' class that represents a container capable of holding items.
- We should be able to have a 'chest' item be an instance of it with customizations. We will have other types of containers in the future (corpse, anti-gravity box, etc.), so make sure that Item Container properties are customizable.
- Container items should have a right-click "loot" option to open up a new "Item Container" modal that shows my player inventory and the container that I can use to transfer items between the two.
- The total weight of a container should be equal to the base weight of a container, plus the items held inside.
- Dynamically generate chest items from all base material types similarly to how we generate equipment.
- Dynamically generate recipes for all chest types from base materials, ala "Recipe: [material] Chest // [material] x20". Sell these recipes in shops.
- Add new 'Chest Mold' as the tool for smithing chests.
- Give chests a weight limit, rather than an item count limit. I like weight limit more, because it better accounts for varying item sizes.



- Container tooltips should show how many items they contain.
- Hovering container should show a mini-preview of contents too.
- If a party member dies in combat, keep them dead in combat in the UI as normal.
- However, once combat ends, we should remove the party member from the party and add a 'corpse' item onto the 'Ground Loot'.
- Corpses should be a new class that contains an "Item Container" that holds the corpses items, but it should also hold a reference to the now-dead Party Member object instance. (Technically, I'm not sure what the best architectural approach is, so evaluate and analyze what would be the best way to handle this data interaction).
- The weight of the corpse should be the weight of the party member meaning we need to add add a 'base weight' property to all creature types (players, party member, mercs, monsters, etc.). For now, to keep things simple, make weight based on race. Humans will all weigh 150 pounds by default. Goblins and wolves would naturally weigh less.
- Like with all containers, the player should be able to right-click "Loot" on corpses to look at items they have an potentially exchange items between it and their inventory.


