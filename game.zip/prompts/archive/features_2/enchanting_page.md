Let's modify the appearance and functionality of the enchanting panel. It was a good first try, but now, let's make it better. We should display enchants in this format:

[Enchantment Name] - [Enchantment Category ()]
[Enchantment Name] ([Tier]) <- Name of enchant and current tier (if there is one already).
[Strength Buttons] <- Buttons to click to specify enchantment power level. Clicking these will dynamically update the resource costs, difficulty rating of enchantment, etc. in following fields:
[Enchantment ]
[Primary Resource Cost] <- magic crystal cost.
[Secondary Resource Cost] <- secondary resource cost (if any).
[Difficulty Rating] ([Success Rate %]) <- difficulty rating of enchantment.

ex, if I click the [III] strength button for strength:

Strength
T1 - Giant
[I] [II] [III] [IV] [V] [VI] 
[VII] [VIII] [IX] [X] [XI]
5x Greater Magic Crystal
500 gold coins
DR: 5 (33%)

^ In this case, the [I] and [II] options would be greyed out and unselectable.

