Let's make improvements to the Debug Menu.

Task 1: Convert sections of the Debug Menu to use the 'DebugSetter' component. It is a very compact, flexible and convenient way to perform debug operations, so we want to convert more areas of the debug menu to use it. We can change:

- 'Give 5x random item', 'Give 5x RU Items', 'Give Damaged Item', etc.
- The set xp and level fields.
- The stat points and perk points.
- Make it so that the 'Limb State' section let's us actually set the hp of selected limbs of selected targets. We should be able to use radio boxes to select limbs. And, Our 'quick' buttons should be 'set 100%' or 'set 0%'.

Do a full evaluation of all buttons to see what buttons can be converted into the DebugSetter format and remove any buttons that are made redundant because of these new, improved controls.
Make sure tha twe preserve the functionality of the menu though - we only want to add features, not remove - so if we remove a button, make sure that a DebugSetting exists that can perform its minimum set of functionality.

------------------------

Change 1: Modify the debug menu to give items via oak chests enchanted with the anti-gravity mod. This will be a very quick and convenient way to provide me items conveniently without effecting my gameplay too much.

this means, when I click 'Duplicate Items', I should get a chest that contains duplicates of all of my items.
When I click use the 'Give Random Items -> 1x' button, I should get a chest that contains 1 random item.

Do a pass on the crafting menu to ensure all items given from various sections are given via anti-gravity chests.
