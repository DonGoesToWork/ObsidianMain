
Add support for multiple types of infections.

When infections are applied from most sources, they start at Stage 1 and progress over time to higher stages.
Generally, the first stage of an infection is the longest and the best time to cure the disease before it spread.
After it spreads even once to the 2nd stage of further, it can become a huge pain to deal with a disease without professional treatment.
Generally, infections literally 'spread' throughout the body over time, becoming more potent by virtue of effecting more limbs.
Then, in the final stages, the intensity increases until fatal circumstances are reached.

## Stage 1

Infections start out in one limb in an 'incubating' state.

In this state, the person with the disease won't know what the disease is. This means there will not be a visible debuff icon.

Instead, there should be clues depending on the disease - periodically, our character should get a debuff based on the symptons of the disease (cough, chills, etc.) on infected limbs.

While the disease is in this stage, it should gradually spread to different body parts depending on how fast the disease progresses.

Once all body parts are effected by the 'incubating' disease, the disease should immediately progress to stage 2.

## Stage 2

After reaching stage 2, the disease will become active and begin to actively apply debuffs to the character.
Side effects like chills, etc., become permanent and tick while the disease is active.
If the disease is fully healed, the associated side effect is fully healed. This logic is similar to how if a 'Cut' is healed, the 'Bleed' goes away.
However, differently, if a disease is 'treated', the side effects do NOT go away.

## Stage 3

The most active stage of the disease and basically the last chance for the player to address the disease.
Side effects become more severe "Chills becomes Chills II".

## Stage 4

The final and most dangerous stage of diseases. At this point, you become a 'host' to the disease and suffer severely.

# Treatment

- Add a 'Test Kit' item that can be used to detect whether a disease is active.
- Add a '[Disease] Medicine' that can be used to apply 'treated' to diseases:

Applying the associated medicine for a disease to any body part applies 'Treated' to the disease on every infected limb.
Treated diseases still have their full debuff intensity, but they can no longer spread (when stage 1) and their stage will reduce over time (1 stage every 24 hours) rather than increase.

# Infection Types:

Weakness
Stages: I - IV

Stage 1 = Hidden / Warning Sign = Chills. Lasts for 30 seconds. Appears randomly every 10 minutes to 2 hours. Increases 'fear' by 1 per turn (6 seconds).
Stage 2 = Visible / Name = 'Bonerot II' / Debuff = Weakness = 33% reduced strength.
Stage 3 = Bonrote III = Weakness at 66% reduced strength
Stage 4 = Bonerot IV = Weakness at 100% reduced strength. 100% reduced strength = paralyzed = in combat, turns are skipped, in wilds, time passes automatically in 1 hour increments

# Other Features

- Debuffs should interrupt rest. Do not have it interrupt travel at the moment (future feature).
