
- Add a new 'ground loot' panel to the main panel view at the bottom-right that uses our UnifiedInventoryDisplay component.
- The ground loot will be the 'loot on the ground' that we find in an area as we do things in an area. So, for instance, we can 'cut logs' and, rather than have the logs go striaght into our inventory, the log will go into the 'ground loot'. If we 'Forage', the foraged items will go into the ground loot. When we kill monsters, put monster loot there, etc.
- Enable the filter, sort options, etc. for it.
- Make the click action on Ground loot rows be 'Grab' -> which sends the item to the player's inventory.
- Add right-click 'drop' option to items in the player inventory (make it the bottom-most entry) -> Because the Inventory is pretty complex and we probably don't want to drop items often (we'll sell instead), let's only add drop here.
