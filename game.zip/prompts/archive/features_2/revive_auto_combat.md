We are working on Chronicles of Aura, a brutal, procedurally generated RPG web game experience. We are implementing features:

We are aggressively working to get the combat loop to work how I want and expect it to behave. I am actively using the combat simulator to help speed up testing and notice a variety of issues with combat that need urgently resolved.

- Add a 'Revive' spell to the game. This should be a level 70 spell that revives a party member, restoring all of their limbs to 10% hp.
- Add a 'Pheonix Feather' item to the game. The pheonix feature should be a lvl 60 item that revives a party member when used on them, restoring all of their limbs to 10% hp.
- Make sure to add both 'Revive Spell Tome' and 'Pheonix Feather' to the store.
- When I die in combat, my character is able to continue acting as if alive when I have a party member. This is wrong. If I die in combat, I shouldn't be able to act. Instead, combat should proceed between my party members and the enemies automatically taking turns until combat fully resolves.
- After combat ends, if I'm dead, my companion attempt to use items and spells to revive me if they have a happiness value of 50 or higher and have a spell or item to revive me with.

# RESTRICTION

REMEMBER: YOU CAN ONLY ever output 60,000 tokens (45,000 words) at most! That is the maximum AI response limit before the web interface terminates the communication session with the user. Because of this, you should identify 3 core changes and implement only those.

# Problem Solving Strategy 

Analyze my request, the code and all supplamental data to determine requirements, then create a comprehensive solution to implement all requested functionality.
Finally, implemenet the solution in the requested format.

# Game Paths

Main Game Src Path: /mnt/c/Users/donalda/Desktop/game_html/app/src/
App.tsx path: /mnt/c/Users/donalda/Desktop/game_html/app/src/App.tsx
Components path: /mnt/c/Users/donalda/Desktop/game_html/app/src/components
.gitignore path: /mnt/c/Users/donalda/Desktop/game_html/app/src/.gitignore
