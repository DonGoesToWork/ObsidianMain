
There is some weird behavior happening when I unequip items.

Basically, my character was wearing some pants and I took them out, and what happens is that my character recieved a war axe insstead of pants. This war axe is an item from my inventory, so I feel like there are some item id reference shenanigans happening that are causing issues.

This was happening in other areas of the code, like containers, and the problem was that item indexes were changing due to splice operatins, resulting in a variety of item reference issues that caused a variety of glitches to occur.

The solution at that time was to add unique ids to items, so that the interface can never lose track of the accurate positions of items. And, this fixed the problem instantly.

I feel like this is another situation that is behaving similarly.

Do a full pass on the equip/unequip logic to bring the code up to these new standards. Make sure that equipping and unequipping items references items by their unique id, not necessarily their inventory indexes, this way we can ensure that the correct items are being moved around properly.