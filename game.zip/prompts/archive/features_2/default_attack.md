
We want to improve the way held items are treated in the game. I want the game to work as follows:

# Default Attacks:

A creature's default attack option should be based specifically off of the weapon or weapons that the creature is using.
For example, A sword should deal 'Slashing' damage for the default attack option, a mace should deal 'Blunt' damage, a torch should deal 50% blunt and 50% fire. There are tags on abilities. Let's make sure that tags are present on all crafted weapons too and visible on their tooltips.
Modify the code so that weapons state what the default attack damage type is.

# Unarmed Weapon:

- In the character panel, rename the 'Weapon' and 'Shield' slots to 'Hand 1' and 'Hand 2'.
- If no weapon is held in Hand 1 or Hand 2, set Hand 1 to a 'Fist' weapon for human characters.
- The 'fist' weapon should not be interactable by the player. All it should say is the title "Fist", "Punch (Blunt)" and a bit of flavor text, "It's a fist. What did you expect?"
- Different creature types should have different unarmed weapons. For instance, a 'Wolf' type of creature should have 'Claws' for their unarmed attack.
- For 'Claws', the damage type should be 'Slashing'.
- Make sure all creatures have appropriate weapons.

# UI Chnages:

Make sure to modify UIs to show all of these changes too. If I check a party member, I want to see a Fist if they are unarmed. If I use Inspect on a Wolf in combat with no equipment in hand 1, I want to be able see 'Claws' stating that they deal slashing damage.
