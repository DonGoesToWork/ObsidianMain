
Drag and Drop:

- CHANGE: Disable auto-sort option, don't stack by default, stacking should be a sort behavior.
- ADD/CHANGE: Add ability to 'drag and drop' items when the UnifiedInventoryDisplay is in Grid/List view. If the inventory has a sort mode selected, then it should just immediately resort the item on 'drop'.

Details:
We want to make a few changes to our UnifiedInventoryDisplay component.

- CHANGE: Add option to disable auto-sort. Have auto-sort disabled by default.
- CHANGE: Modify item stacking to not auto-stack items IF item sorting is disabled.
- CHANGE: Make 'pick up' the default action for clicking all items.
- ADD/CHANGE: Add ability to 'drag and drop' items when the UnifiedInventoryDisplay is in Grid/List view. If the inventory has a sort mode selected, then it should just immediately resort the item on 'drop'.
- ADD/CHANGE: Make drag and drop scroll inventory lists nicely when items are 'held' near and above the inventory's physical web component, with increasing scroll acceleration the further the item is dragged away from the top/bottom of the inventory list, for a nice, user-friendly scroll experience to drag and drop items.

Make sure to consider all of the impacts to items from these changes.
