


# Enemy AI

**5.4 Ability & Item Tagging
*   Add internal-only tags to abilities that NPCs can use to assess what the ability can do. These should be generic and be used mostly for AI enhancements.
* 	There should be very few tags in general and should only be, for now: "Single Target Consistent Damage", "Multi-Target Consistent Damage", "Execute", "Buff", "Debuff", "Recover Health", "Recovery Mana", "Recovery Stamina", "Field Effect".
*   Implement very preliminary AI for NPCs:

Tag NPCs as "Warrior, Mage, Rogue". Depending on the type, it should have slightly different behaviors.


Priority 1: If a target has low hp, prioritze abilities with "Execute". Use one at random.
Priority 2: If caster has low hp, prioritize healing hp.
Priority 3: Depending on class, 


If there are multiple targets, prioritize

https://aistudio.google.com/prompts/1YeMTag4AdTPzzSqDdMyvfsXtwZjiBxbi

------------------
# Combat Overhauls

Combat needs some tweaks. Right now, it is implemented so that if your torso takes enough damage, you die. We need to change the system in a variety of ways.

- First, make all limbs have 100/100 health. The physical width of all fatal human body parts (neck, arm, legs, etc.) are all relatively the same, so just make them all the same hp-wise. We will use armor as the main factor for determining how much damage a body part takes instead.
- Show limb hp on each limb. For example, "Torso" current becomes "Torso 12/12". Get rid of the 'top bar' on each enemy panel that shows torso hp and the tooltip that pulls up on hover. We should only have the 6 main limb hp bars visible for each entity in combat, not a 'big hp bar' above all the limbs.
- Implement accuracy into combat. Whenever we choose an ability to use, further modify the limb hp bar text to state the accuracy percent of the ability on a given limb. For example, "Torso: 12/12" becomes "Torse: 12/12 (58%)"
- Add limb-specific accuracy modifiers. Each limb should have a specific modifier to accuracy. The chest should have a 100% accuracy modifier. The head should impose a 25% accuracy modifier (equal to 75% lower accuracy because 100 * 0.25 = 25%). Arms should impose a 50% modifier. Legs should impose a 75% modifier.
- Make it so that when the head reaches 0 health, your character dies. Head health is balanced by accuracy, with it being hard to target and hit effectively.
- Show player, party member, enemy mana and stamina bars in combat below the limb hp bars. (can go left/right in a 4th resource bar row). Show cur/max of the two resources.
- Readd Defend (D) to the combat interface.
- Defend should add a buff that reduces damage taken by 50% for 1 turn when used and also increase limb accuracy by 50%.


------------------

- On the character panels, put after each location the area level in parenthesis. So, for instance, if in Westhaven, put "Westhaven (1)".
- Make it so that the level of items sold in a town are based on the town level with some slight RNG:

min item level = town level - 5 +- 20% (minimum of 1).
max item level = town level + 5 +- 20%

- Add debug menu button to open 'Debug Shop' that sells all items in the game for 0 gold.
- Add "Appraiser" button to town with associated modal. Appraiser should offer to identify all items for a certain amount of gold. For instance, he'd say, "You have 25 unidentified items. I can identify them all for 4000 gold pieces." and then there would be a button saying, "1st line: Identify 25 items / 2nd line: 5000 gold" that can be clicked to identify all items.

------------------


- On the character panels, put after each location the area level in parenthesis. So, for instance, if in Westhaven, put "Westhaven (1)".
- Make it so that the level of items sold in a town are based on the town level with some slight RNG:

min item level = town level - 5 +- 20% (minimum of 1).
max item level = town level + 5 +- 20%

- Add debug menu button to open 'Debug Shop' that sells all items in the game for 0 gold.
- Add "Appraiser" button to town with associated modal. Appraiser should offer to identify all items for a certain amount of gold. For instance, he'd say, "You have 25 unidentified items. I
- The crafting menu currently has some issues to fix in the 'Create' menu - The logic for determining whether you can create an item is incomplete:

1. If I only have a "Bronze Ingot", then I can click the "Bronze Dagger" known recipe. This is wrong. I should need a smithing hammer, dagger mold and forge for this recipe to become active. (Do not check smithing level for this particular operation). Fix the 'add recipe items' feature to require all components (tools, molds, etc.) for any given crafting operation. Make sure you fix this for alchemy, jewelcrafting, leatherworking, tailoring too. The "Bronze Dagger" recipe shouldn't even be considered 'active to use' in the known recipes view unless I have all necessary tools, etc.

2. Clicking the 'add recipe items' buttons causes the entire 'tools' and 'ingredients' sections of the create screen to shift up unnaturally, causing them to be 'underneath' the inventory section. They shouldn't move when I hit 'add recipe items' at all.



------------------

# Dynamic Generation

Implement more dynamic, procedural generation.

## Zones

Currently, we have several hardcoded zones in zones.ts...
This is NOT how I want the game to work.
We should be generating zones dynamically on game start so that there are at least 3 zones per level.
