---------------

- When I get an "External Bleed I", the duration text says infinity <- this is correct. The duration should be infinite until the wound is patched. What is wrong is that, if I rest for 6 seconds, the infinite icon goes away. The bleed remains infinitely as expected, but the ifinity text needs to stay even if I rest 6s.
- If a limb is 'Severed' and I rest '6' seconds, the 'Severed' status effect icon goes away. This has been a reoccuring issue with status effects and had even occured with the External Bleed debuff before. Do a full root analysis of this issue to ensure that this status effect and any other infinite status effects do not vanish after a 6s rest. They should be truly infinite until their treatment condition is met.
- The bleed 'damage per second' status description is correct, but the actual damage taken is wrong by my character is wrong. If I have an External Bleed III that is meant to deal 6 damage per tick, what really happens is I take 36 damage per tick. Evaluate and fix the code so that bleeds are doing correct damage to limbs as expected.

---------------

Fix the following errors:

- When I get a 'Cut' debuff of any stage, it should say in the status effect tooltip, 'Open' to indicate that it hasn't been patched. I would recommend putting it right before the stage description on the second line, so that the 2nd line says for 'Cut I' -> 'Open Scratch' vs. 'Patched Scratch'.
- When I get an "External Bleed I", the duration text says infinity <- this is correct. The duration should be infinite until the wound is patched. What is wrong is that, if I rest for 6 seconds, the bleed will go away. The bleed should have an infinite duration and not go away until an appropriately tiered bandage for the bleed stage is applied to the limb.
- If a limb is 'Severed', the icon should have an infinite icon. It looks like right now it has some cut off 'Infinity' text string.
- The bleed 'damage per second' status description is correct, but the actual damage taken is wrong by my character is wrong. If I have an External Bleed III that is meant to deal 6 damage per tick, what really happens is I take 36 damage per tick. It looks like the code in StatusEffectIcon.tsx is correct:

    const totalMaxHp = Object.values(character.body).reduce((sum: number, l: any) => sum + l.maxHp, 0);
    const damagePerTurn = totalMaxHp * ((onTurnEffect as any).percent / 100);
    const damagePerSecond = damagePerTurn / 6;
    literalEffectText = `-${damagePerSecond.toFixed(1)} HP / sec`;

while the code in timeActions.ts is incomplete/wrong:

 if (bleedStageData.effects?.onTurn?.type === 'damage_percent_max_hp') {
              const percent = (bleedStageData.effects.onTurn as any).percent;
              const damage = totalMaxHp * (percent / 100);
              bleedDamageAmount += damage;
              ...

Evaluate and fix the code so that bleeds are doing correct limb damage.
