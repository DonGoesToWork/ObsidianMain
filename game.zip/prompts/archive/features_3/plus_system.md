
Let's change the way that craftsmanship works and is presented to the user.

Rather than saying "Craftsmanship: [value]" on the item tooltip, let's switch to an old RPG classic: plus or minus some number, ex: [+1].
How this will look is that an item will have it's enchantment prefix, item name, then plus value after.
So a magic item might have the final tooltip name: Magic Adamantite Chestplate [+5].

Rework 'craftsmanship' to be a 'plus_value' system internally within the code and how it is presented to the user based on the stated rules.
This will entail also modifying the Crafting -> Upgrade tab to support increasing the plus value of an item.
We should make Crafting -> Upgrade behave like Crafting -> Enchant, we can only increase the plus value of an item up to the tier of the item, and each increase in plus value makes the next plus value roll harder (increase DR by 1).
In general, we want Tier 1 to be a DR of 5, Tier 2 to be a DR of 15, T3 = 25, etc. up to T11 at DR 105.
Plus values must be increased incremently, one after the other, unlike enchanting that lets us jump straight to our desired enchantment tier in one go.

Plus values should be able to go negative too, so ensure that there support for that.
There won't be a way for items to have negative plus value yet, but, we will add those later.

-------------------

