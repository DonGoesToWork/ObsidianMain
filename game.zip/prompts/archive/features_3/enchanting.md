- Every enchantment on an item should make the next enchantment have a lower success rate. So, if I have 100 enchanting vs. a DR 100 enchant, it would a be 50% chance of success on the first one. However, after that first enchantment, the DR should go to 101, lowering the success chance to 45%. Basically, the DR for enchanting should equal 
- We should limit the max enchantment tier that can be put on an item based on the item level. In accordance with the tier rules stated below, a Tier 1 (lvl 1-9) item would be eligible for Tier 1 enchants. A Tier 2 (lvl 10-19) item would be eligible for Tier 1 and Tier 2 enchants. And so on and so forth.
- Add a hard limit on the number of enchantments that can be placed on an item to number of 'ITEM_RARITY_TIERS'.

-------------

We want to add an 'Enchantment Recipes' system to the game.
Currently, the player has all enchants unlocked.
But, I'd rather hide some of the higher tier ones, like Anti-Gravity, and soon to be developed ones, from early game view.

Make it so that the player has no enchants unlocked by default and must collect new "Memory Globes: 🔮" to learn enchantments.
A Memory Globe may say:

Memory: [name - roman numerals tier]
Unlocks the [name - roman numerals tier] Enchantment
[Enchant Description]

ex:

Memory: Strength II
Unlocks the Strength II Enchantment
Gain +2 Strength
Value: 'x'

# Implementation Details

- Dynamically generate new memory globe items for each enchantment and tier.
- Implement the locked / unlocking system via learning recipes through memory globes.
- Update the Enchanting Interface to not show enchantments that aren't learned yet.
- Add memory globes to the store.
- Add debug menu options to the 'Unlocks' section to unlock recipes and make 'Unlock All' unlock all enchantment recipes.
- Flesh out any other details necessary to make the feature complete similar to the other skill/spell recipe learning systems.
