

- There is some kind of entangling between enchanted items and their non-enchanted counterparts in certain menus, like the store.

Basically, when I enchant an item and then click to move it, it will cause other items that were previously in the same stack to move with it.

For instance, if I have 5 stone and enchant two of those stone to 'Magic' rarity, then moving 1 of any stone (enchanted or not) will move 1 of each stone type (the two enchanted stones and one of the unenchanted stones).

This 'entangling' needs to be analyzed and fixed. Investigate and resolve this problem.

It doesn't happen between the inventory and ground loot, bank, and a few other spots. But, it does happen in the store and Crafting -> Create Modal, Crafting -> Repair for the ingredient slot. The tool slot in Crafting -> Repair visually only moves over 1 item to the Tool section and gets rid of whatever was left in the Inventory.

Fix these bugs.