

1:


We want to change how item identification works entirely.

The design vision for the item identification system is that if you find an item, you'll see it and know that it is an item of some kind, but you won't necessarily know how good the item is at first glance.

For instance, if you find a stone dagger, you may have some expectations for how good it is in terms of attack speed, weight, attack damage, etc. and you may even guess its value based on the properties of it that you can see. However, you won't necessarily know how good it is or how strong the enchantments on it are until you use it for a while.

How this will look in the game is that you will find items and see all of their properties except for enchantments. Over time, your character will automatically perform appraisal checks on his items for a chance to reveal the modifiers on the item, possibly fully revealing them eventually given enough time and skill.

Rewrite the enchantment system from the ground up to follow these new rules:

- Found items are no longer 'unidentified' or have a '?' icon. Instead, the player will always be able to see the name, attack damage, attack speed, weight, etc. of the item.
- Instead, make it so that items that have unidentified enchantments have an extra lore line, 'Contained Unknown Magic.' This will indicate to the user that the item has enchantments that aren't identified.
- Add a new hourly check that the player makes to Appraise the items in their inventory. A successful roll will have a chance at revealing an enchantment on the item. If an enchantment is revealed, another roll should be made. These rolls should continue until a failure occurs. This will allow for Appraisal to have the ability to fully reveal items in a single hour given a high enough degree of skill relative to the item level.
- Remove all other remants of the old item identification system; get rid of right-click identify, left-click identify, etc. All items should be identified by default now other than their enchantment information which will be unknown until revealed.
- Add a new debug option: "Give 5x RU Items" to the Debug Modal -> Player Tab -> Items section to give 5 random unenchanted items to the player.

-----------------

- Add a new 'Fame' stat to the character. Fame can be positive or negative.
- If I or a party member is bleeding and I attempt to travel, display a confirmation message saying, "[name] is bleeding. Are you sure you would like to travel? Yes/No".
- If the user then decides to press Yes, kill off the character that is bleeding. This is because it is not possible to survive travel while actively bleeding.
- If the player is the one that dies, this should bring up the death modal.
- If it is a party member, kill the party member, and notably do not leave a corpse and reduce the player's fame by 100.
- Completing a quest should increase fame by 1.



-----------------

- Bleed is not ticking on enemies in combat. Do a full code pass to ensure status effects are applying to enemies and 
- The External Bleed debuff in the party window is exhibiting old issues. If my party member has a bleed and gets another one, the its possible for the newly applied one to not display with an infinite icon.


-----------------

TODO:

- Add 'Clear Equipment' debug menu button under "Items". It should clear out all equipment worn by selected characters.
- In the Debug Menu, clicking any button clears selected targets in the "Targets" section. Make target selection persist even after button presses.
- The Save Button is currently doing nothing.


- Get rid of settimeout from combat



-----------------
Fix the following things:

- In combat, I should be able to choose myself and party members as valid attack options.
- All abilities that target limbs should be able to target myself and party members as valid attack options.
- Abilities should have an 'isBeneficial' flag added to them, similarly to status effects.
- Whenever an ally is hit by a non-beneficial spell in any way (friendly fire, direct target, etc.), the ally should lose 5 happiness.

- Status effects aren't ticking on enemies in combat. (check if that is the same for allies)




-----------------


Rework the game in whatever capacity 

We want to add loot persistence to various places in the game so that we don't have to worry about items being lost when certain operations are performed. Specifically, I have several instances where we want loot persistence implemented. To start:

- Corpse equipment handling is currently incomplete. When a party member dies and a corpse is generated, the corpse has the party member's equipment in the corpses inventory. This is fine. What isn't fine, however, is that reviving the corpse causes a brand new 


------------------------

Analyze and improve the following prompt that I have created to improve combat:


List of observations:


- Limit inventory size to 20 items by default. Show size usage in Character Panel Modal as "Inventory: [cur items]/20"
- Limit stack size for items to 5.

- Bandage says Quaff...

- Make hunger, thirst, alertness and courage do things, get managed properly as expected.
- Debuffs still need work...

----------------------

# Save Improvements

- Add better save support. Save when the user moves to a new area. Save when the user ends combat. Save when we craft a piece of equipment. We should also be able to save mid-combat, reload the game and resume.


----------------------

- Debuffs Continue To Ensure Works (Bug Fixes)

- NPC Ai - Combat
- Party AI - Out of combat

- Infection System
- New World Map - hex grid.

- Travel Interruptions
- House System
- Guild System
- Forge and tool rental.
- Dungeons
- Quests

- Content Additions


------------

We are aggressively working to get the combat loop to work how I want and expect it to behave. I am actively using the combat simulator to help speed up testing and notice a variety of issues with combat that need urgently resolved.

# Issue 1: Merging Debuffs

Currently, we have debuffs merging together in the combat view when they are exactly the same. This behavior should also happen in the Player Panel. Create some kind of modular, unified buff display logic that the Player Panel can share with the combat interface.

------------


Combat Improvements Prompt:

# Inspect
- Add a new 'Inspect (I)' feature to the combat action bar. Pressing I lets you select a creature. This then opens up a modal that shows detailed information about the target. It should effectively show everything visible in the current 'Party' menu, except for only targetting the individual selected creature. Enemy creatures should have the same stats and attributes as players, so this inferfact should work for monsters, party members, and even the player without any issues or comptability problems.

# Fix Selection
- The combat interface needs some improvements. When a creature is dead, it will still glow as a valid target. And, we can even still 'select' the dead creature, causing the to 'glitch up' for a sec before reselecting a an actually target. Modify the interface so that dead creatures do not glow as valid targets and can't be selected at all.

# Combat Overhauls

Combat needs some tweaks. Right now, it is implemented so that if your torso takes enough damage, you die. We need to change the system in a variety of ways.

- First, make all limbs have 100/100 health. The width of all fatal parts, neck, arm, legs, etc. are all relatively the same, so just make htem all the same hp-wise. We will use armor as the main factor for determining how much damage a body part takes instead.
- Show limb hp on each limb. For example, "Torso" current becomes "Torso 12/12". Get rid of the 'top bar' on each enemy panel that shows torso hp. We should only have limb hp bars visible, not a 'big hp bar' above the limbs.
- Implement accuracy into combat. Whenever we choose an ability to use, further modify the limb hp bar text to state the accuracy percent of the ability on a given limb. For example, "Torso: 12/12" becomes "Torse: 12/12 (58%)"
- Add limb-specific accuracy modifiers. Each limb should have a specific modifier to accuracy. The chest should have no accuracy modifier. The head should reduce accuracy by 75%. Arms should reduce accuracy by 50%. Legs should reduce by 25%.
- Make it so that when the head reaches 0 health, your character dies. Head health is balanced by accuracy, with it being hard to target and hit effectively.
- Show player, party member, enemy mana and stamina bars in combat below the limb hp bars. (can go left/right in a 4th resource bar row). Show cur/max of the two resources.
- Readd Defend (D) to the combat interface.
- Defend should add a buff that reduces damage taken by 50% for 1 turn when used.



Need to display:

equipment

---------------------

# Party Member Behaviors:

- We need internal and external faction tags that can be used to mark affiliations of the player and npc.
- External factions would be "[ Guild Name ]"

- Internal factions would be: "Player" for player, "Wolf" for wolf
, "Wolf", 
- Implement factions into the game, an internal tag on NPCs to mark their group affiliation.
- Sample factions are 'Player', 'Wilderness Encounter', 'Wolf', 'Cultists', 'Dungeon Boss', etc.
- NPCs can have more than one faction.
- Give our 

- Add support for multi-party conflicts: Can have 4 parties of 4 in a combat.

'Group Tags' into the game. The player will be in the "Player" group. A wolf would be int he "W

- Add party members as valid targets in combat. If you attack a party member, then it should lower the party members 'happiness' by 20. If happiness is less than 50, then the party member should leave your side.

 to the enemy team.


