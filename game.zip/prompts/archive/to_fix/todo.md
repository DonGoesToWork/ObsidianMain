Misc:
- Neck equipment slot.
- Neck Guard for it.
- Item Stack Optimization.

Attributes:
- Attributes revamp (str, dex, vit, magus, arcana, int, wis, luk)
- item stat requirements


Combat:
- Improvised weapon system.
- show ground loot in combat
- chained limb breakage and event actions: breaking arm = breaking hand = drop weawpon

Debuffs:
- Debuffs Continue To Ensure Works (Bug Fixes)
- Infection Debuff System.

Items:
- Curses
- Plus Values for All Item Types - Create -> Upgrade has tabs like Create for different skills.
- Materials can grant properties to crafted item types. For instance, steel might reduce electriicty resistance, while wood might increase it.
- More efficient item storage for stacked items
- Hard Inventory Item Limit of 1,000 items.
- Enchantment Recipes

AI:
- NPC AI - Combat
- Party AI - Out of combat

Map:
- New World Map - hex grid.
- Travel Interruptions & Encounter system

Towns:
- House System
- Guild System
- Forge and tool rental.

Exploration:
- Dungeons
- Quests

Content Additions: 
- Skills
- Items
- Perks
- Enchantments
- Resistances (Player Stats)
- Materials
- Spells
- Unique Materials
- Quests
- Encounters
- Monster Types


AI really allowed me to supercharge my development speed. While some games can be in Early Access for years, struggling to push out even 3 or 4 significant game update per year, I was able to create major game expansions within the timeframe of a day.
