Misc:
+ Optimization Pass
x Neck equipment slot. (removed neck)
x Neck Guard for it. (removed neck)
+ Item Stack Implementation for Optimization.
    + Item Stack Bug Fixes.
+ Upgrade System Improvements (Cap at 11).
+ Stack 'ALL' item types, even equipment.
+ Enchantment Recipes
    + Enchantment Recipes Bug Fixes.

Items:
- Hard Inventory Item Limit of 1,000 unique items.
- Drag + Drop Currency Items to use on Items:
    - Enchanting Orb - Can apply a specific enchantment to an item.
    - Plus Stone - Can increase the plus value of an item.
    - 

Attributes:
- Attributes revamp (str, dex, vit, magus, arcana, int, wis, luk)
- item stat requirements

Combat:
- More debuff controls in Debug Menu (apply cut/bleed)
- More limb damage/destruction control in Debug Menu.
- rework display - ground loot where logs is, scenario text + controls in bottom-middle of screen
- show ground loot in combat
- chained limb breakage and event actions: breaking arm = breaking hand = drop weawpon

    Debuffs:
    - Infection Debuff System.
    - Debuffs Continue To Ensure Works (Bug Fixes)

    AI:
    - NPC AI - Combat
    - Party AI - Out of combat

Map:
- New World Map - hex grid:
    - Earth, fire, wind, water, frost, metal, light, dark, lightning, time, space, soul
        - Plains / Forest / Deep Woods / Ancient Jungle / Primeval Jungle - earth, wind water
        - Tropics / Desert / Obsidian Fields / Volcano / Lava Sea - earth, fire
        - Windswept Plains / Gusty Plains / Eye of the Storm (Hurricane) / Tornado Island / Air Cage - earth, air
        - Beach / Ocean / Underwater Temple / Whirlpool Ruins / The Abyss (large crack in the ocean that constantly pulls down)
        - Mine / Bleak Mine / Crystal Forest / Ancient Lair / Divinite Crack
        - Elemental Plain of Light
        - Elemental Plain of Dark
        - Lightning Plains / Thunder Peak / Cloud 


        
    


- Travel Interruptions & Encounter system
- Dungeons - (Multi-creature, dungeon modifiers, flee system, world influence)

Towns:
- House System
- Guild System
- Forge and tool rental.
- Quests

Content Additions: 
- Skills
- Spells
- Items
- Perks
- Enchantments
- Resistances (Player Stats)
- Materials
- Unique Materials
- Quests
- Encounters
- Monster Types


AI really allowed me to supercharge my development speed. While some games can be in Early Access for years, struggling to push out even 3 or 4 significant game update per year, I was able to create major game expansions within the timeframe of a day.

Stretch Goals:

    Enchants:
    - Curses

    Items:
    - Plus Values for All Item Types - Create -> Upgrade has tabs like Create for different skills.
    - Materials can grant properties to crafted item types. For instance, steel might reduce electriicty resistance, while wood might increase it.

    Combat:
    - Improvised weapon system. 

Bugs:
- Buying out store insta-restocks?

QOL:
- Warning when buying expensive items from store (> 10% of wealth)
