Misc:
+ Optimization Pass
x Neck equipment slot. (removed neck)
x Neck Guard for it. (removed neck)
+ Item Stack Implementation for Optimization.
    + Item Stack Bug Fixes.
+ Upgrade System Improvements (Cap at 11).
+ Stack 'ALL' item types, even equipment.
+ Enchantment Recipes
    + Enchantment Recipes Bug Fixes.

Items:
+ Hard Inventory Item Limit of 1,000 unique items.
+ Added GLOBAL_QUICK_DEV_CONFIGURATION.ts and integrations
+ Drag + Drop Currency Items to use on Items:
    + Plus Stone - Can increase the plus value of an item.
    + Enchanting Orb - Adds enchantment of a tier to an item.

Misc II:

+ BUG: Containers that contain different items should not stack.
+ BUG: Picking up items should say which items are picked up, not generic 'Item(s)'. Find other places in code where this happens, if any, and fix this issue there too.
+ ADD: Abandon Loot button to clear ground loot.
+ Change town's to sell items within their tier. Replace the existing '*0.85% - 5', etc. logic with this.
+ Add a random number of lower level items to shops when they restock. This will be to keep town inventory's interesting.
+ ADD: 'Unmodifiable' flag on items to prevent modification.
x CHANGE: Add option to disable auto-sort - keep auto-sort enabled by default - item stacking should only occur when sorting is enabled. (denied, doesn't really make sense for game, maybe revisit later?)
- Add Full Drag and Drop support

Attributes:
- Attributes revamp (str, dex, vit, magus, arcana, int, wis, luk)
- item stat requirements

Combat:
- More debuff controls in Debug Menu (apply cut/bleed)
- More limb damage/destruction control in Debug Menu.
- rework display - ground loot where logs is, scenario text + controls in bottom-middle of screen
- show ground loot in combat
- chained limb breakage and event actions: breaking arm = breaking hand = drop weawpon

    Debuffs:
    - Infection Debuff System.
    - Debuffs Continue To Ensure Works (Bug Fixes)

    AI:
    - NPC AI - Combat
    - Party AI - Out of combat

Map:
- New World Map - hex grid:
    - Earth, fire, wind, water, frost, metal, light, dark, lightning, time, space, soul
        - Plains / Forest / Deep Woods / Ancient Jungle / Primeval Jungle - earth, wind water
        - Tropics / Desert / Obsidian Fields / Volcano / Lava Sea - earth, fire
        - Windswept Plains / Gusty Plains / Eye of the Storm (Hurricane) / Tornado Island / Air Cage - earth, air
        - Beach / Ocean / Underwater Temple / Whirlpool Ruins / The Abyss (large crack in the ocean that constantly pulls down)
        - Mine / Bleak Mine / Crystal Forest / Ancient Lair / Divinite Crack
        - Elemental Plain of Light
        - Elemental Plain of Dark
        - Lightning Plains / Thunder Peak / Cloud 


        
    


- Travel Interruptions & Encounter system
- Dungeons - (Multi-creature, dungeon modifiers, flee system, world influence)

Towns:
- House System
- Guild System
- Forge and tool rental.
- Quests

Content Additions: 
- Skills
- Spells
- Items:
    * Equipment Repair Kits at various tiers, etc.
- Perks
- Enchantments
- Resistances (Player Stats)
- Materials
- Unique Materials
- Quests
- Encounters
- Monster Types

Stretch Goals:

    Enchants:
    - Curses

    Items:
    - Plus Values for All Item Types - Create -> Upgrade has tabs like Create for different skills.
    - Materials can grant properties to crafted item types. For instance, steel might reduce electriicty resistance, while wood might increase it.

    Combat:
    - Improvised weapon system. 

Bugs:
+ Buying out store insta-restocks?
- Need better quality leathers for chestplates.

QOL:
- Warning when buying expensive items from store (> 10% of wealth)
