



Rework the game in whatever capacity 

We want to add loot persistence to various places in the game so that we don't have to worry about items being lost when certain operations are performed. Specifically, I have several instances where we want loot persistence implemented. To start:

- Corpse equipment handling is currently incomplete. When a party member dies and a corpse is generated, the corpse has the party member's equipment in the corpses inventory. This is fine. What isn't fine, however, is that reviving the corpse causes a brand new 


------------------------

Analyze and improve the following prompt that I have created to improve combat:


List of observations:


- Limit inventory size to 20 items by default. Show size usage in Character Panel Modal as "Inventory: [cur items]/20"
- Limit stack size for items to 5.

- Bandage says Quaff...

- Make hunger, thirst, alertness and courage do things, get managed properly as expected.
- Debuffs still need work...

----------------------

# Save Improvements

- Add better save support. Save when the user moves to a new area. Save when the user ends combat. Save when we craft a piece of equipment. We should also be able to save mid-combat, reload the game and resume.


----------------------

- Debuffs Continue To Ensure Works (Bug Fixes)

- NPC Ai - Combat
- Party AI - Out of combat

- Infection System
- New World Map - hex grid.

- Travel Interruptions
- House System
- Forge and tool rental.
- Dungeons
- Quests

------------

We are aggressively working to get the combat loop to work how I want and expect it to behave. I am actively using the combat simulator to help speed up testing and notice a variety of issues with combat that need urgently resolved.

# Issue 1: Merging Debuffs

Currently, we have debuffs merging together in the combat view when they are exactly the same. This behavior should also happen in the Player Panel. Create some kind of modular, unified buff display logic that the Player Panel can share with the combat interface.

------------


Combat Improvements Prompt:

# Inspect
- Add a new 'Inspect (I)' feature to the combat action bar. Pressing I lets you select a creature. This then opens up a modal that shows detailed information about the target. It should effectively show everything visible in the current 'Party' menu, except for only targetting the individual selected creature. Enemy creatures should have the same stats and attributes as players, so this inferfact should work for monsters, party members, and even the player without any issues or comptability problems.

# Fix Selection
- The combat interface needs some improvements. When a creature is dead, it will still glow as a valid target. And, we can even still 'select' the dead creature, causing the to 'glitch up' for a sec before reselecting a an actually target. Modify the interface so that dead creatures do not glow as valid targets and can't be selected at all.

# Combat Overhauls

Combat needs some tweaks. Right now, it is implemented so that if your torso takes enough damage, you die. We need to change the system in a variety of ways.

- First, make all limbs have 100/100 health. The width of all fatal parts, neck, arm, legs, etc. are all relatively the same, so just make htem all the same hp-wise. We will use armor as the main factor for determining how much damage a body part takes instead.
- Show limb hp on each limb. For example, "Torso" current becomes "Torso 12/12". Get rid of the 'top bar' on each enemy panel that shows torso hp. We should only have limb hp bars visible, not a 'big hp bar' above the limbs.
- Implement accuracy into combat. Whenever we choose an ability to use, further modify the limb hp bar text to state the accuracy percent of the ability on a given limb. For example, "Torso: 12/12" becomes "Torse: 12/12 (58%)"
- Add limb-specific accuracy modifiers. Each limb should have a specific modifier to accuracy. The chest should have no accuracy modifier. The head should reduce accuracy by 75%. Arms should reduce accuracy by 50%. Legs should reduce by 25%.
- Make it so that when the head reaches 0 health, your character dies. Head health is balanced by accuracy, with it being hard to target and hit effectively.
- Show player, party member, enemy mana and stamina bars in combat below the limb hp bars. (can go left/right in a 4th resource bar row). Show cur/max of the two resources.
- Readd Defend (D) to the combat interface.
- Defend should add a buff that reduces damage taken by 50% for 1 turn when used.



Need to display:

equipment

---------------------

# Party Member Behaviors:

- We need internal and external faction tags that can be used to mark affiliations of the player and npc.
- External factions would be "[ Guild Name ]"

- Internal factions would be: "Player" for player, "Wolf" for wolf
, "Wolf", 
- Implement factions into the game, an internal tag on NPCs to mark their group affiliation.
- Sample factions are 'Player', 'Wilderness Encounter', 'Wolf', 'Cultists', 'Dungeon Boss', etc.
- NPCs can have more than one faction.
- Give our 

- Add support for multi-party conflicts: Can have 4 parties of 4 in a combat.

'Group Tags' into the game. The player will be in the "Player" group. A wolf would be int he "W

- Add party members as valid targets in combat. If you attack a party member, then it should lower the party members 'happiness' by 20. If happiness is less than 50, then the party member should leave your side.

 to the enemy team.


