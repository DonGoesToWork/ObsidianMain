import pathlib
import sys
import re

VERSION = "WSL"

if VERSION == "WSL":
    PATCH_FILE_PATH = r"/mnt/c/Users/donalda/Desktop/game_html/prompts/3_response/1_response.md"
else:
    PATCH_FILE_PATH = r"C:\Users\Donald\Desktop\game_html\prompts\3_response\1_response.md"

def parse_transformations(
    content: str,
) -> list[tuple[pathlib.Path, str]]:
    """
    Parses the new patch file format into a list of (path, code) tuples.

    Args:
        content: The string content of the patch file.

    Returns:
        A list of tuples, where each tuple contains a pathlib.Path object
        for the target file and a string with its new content.
    """
    transformations = []
    
    # 1. Pre-process: remove markdown fences and surrounding whitespace.
    # Handles optional language identifiers like ```python
    content = re.sub(r'^\s*```[^\n]*\n', '', content)
    content = re.sub(r'\n```\s*$', '', content)
    content = content.strip()

    if not content:
        return []
        
    # 2. Split content into file blocks. The separator is a hyphen on its own line.
    blocks = content.split('\n-\n')

    for i, block in enumerate(blocks, 1):
        block = block.strip()
        if not block:
            continue

        # 3. Separate the path line from the code block.
        try:
            path_line, code_part = block.split('\n', 1)
        except ValueError:
            # This occurs if a block has a path line but no code, which is valid.
            path_line = block
            code_part = ""

        path_line = path_line.strip()
        
        # 4. Validate and extract file path.
        if not (path_line.startswith('[ ') and path_line.endswith(' ]')):
            print(
                f"Error: Malformed path in block #{i}. Expected format '[ /path/to/file ]'. "
                f"Found: '{path_line}'",
                file=sys.stderr
            )
            continue
            
        target_path_str = path_line[2:-2]
        if not target_path_str:
            print(f"Error: Empty file path found in block #{i}.", file=sys.stderr)
            continue

        transformations.append((pathlib.Path(target_path_str), code_part))

    return transformations


def apply_transformations(
    transformations: list[tuple[pathlib.Path, str]]
) -> None:
    """
    Displays the planned changes and applies them to the filesystem after user
    confirmation.

    Args:
        transformations: A list of (path, code) tuples to apply.
    """
    print("The following file transformations are proposed:")
    for path, _ in transformations:
        status = " (overwrite)" if path.exists() else " (create)"
        print(f"  - {path}{status}")
    print("-" * 20)

    try:
        confirm = input(f"Apply these {len(transformations)} change(s)? (y/N): ").lower().strip()
    except KeyboardInterrupt:
        print("\nOperation aborted by user.")
        sys.exit(1)

    if confirm != 'y':
        print("Operation cancelled.")
        return

    print("\nApplying transformations...")
    applied_count = 0
    for path, code in transformations:
        try:
            print(f"Writing {len(code.encode('utf-8'))} bytes to {path}...")
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(code, encoding='utf-8', newline='\n')
            applied_count += 1
        except (IOError, OSError) as e:
            print(f"Error: Failed to write to file {path}. Reason: {e}", file=sys.stderr)
            print("Aborting remaining transformations.", file=sys.stderr)
            sys.exit(1)

    print(f"\nSuccessfully applied {applied_count} transformation(s).")


def main() -> None:
    """
    Main execution function: locates, reads, parses, and applies transformations.
    """
    script_dir = pathlib.Path(__file__).parent.resolve()
    patch_file = script_dir / PATCH_FILE_PATH

    if not patch_file.is_file():
        print(
            f"Error: Patch file not found at the expected path: '{patch_file}'",
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        print(f"Reading patch file: {patch_file}")
        content = patch_file.read_text(encoding='utf-8')
    except (IOError, OSError, UnicodeDecodeError) as e:
        print(f"Error: Could not read patch file. Reason: {e}", file=sys.stderr)
        sys.exit(1)

    transformations = parse_transformations(content)

    if not transformations:
        print("No valid transformations were found in the patch file.")
        sys.exit(0)

    apply_transformations(transformations)


if __name__ == "__main__":
    main()