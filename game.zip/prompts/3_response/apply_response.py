import pathlib
import sys
import re
from collections import namedtuple
from functools import lru_cache
from typing import List, Tuple, Optional, Dict

# --- Automatic OS Detection ---
# Detect the OS and set path configurations automatically.
IS_WINDOWS = sys.platform.startswith('win32')

# Adjust this path to the root of your project source
if IS_WINDOWS:
    # This attempts to find the user's desktop, with a fallback.
    try:
        from ctypes import windll, create_unicode_buffer
        buf = create_unicode_buffer(260)
        windll.kernel32.GetEnvironmentVariableW('USERPROFILE', buf, 260)
        user_profile = buf.value
        PROJECT_ROOT = pathlib.Path(user_profile).joinpath("Desktop/game_html/app")
        PATCH_FILE_PATH = pathlib.Path(user_profile).joinpath("Desktop/game_html/prompts/3_response/1_response.md")
    except Exception:
        PROJECT_ROOT = pathlib.Path("C:/Users/User/Desktop/game_html/app") # Fallback
        PATCH_FILE_PATH = pathlib.Path("C:/Users/User/Desktop/game_html/prompts/3_response/1_response.md")
else: # WSL or Linux/macOS
    PROJECT_ROOT = pathlib.Path("/mnt/c/Users/donalda/Desktop/game_html/app")
    PATCH_FILE_PATH = pathlib.Path("/mnt/c/Users/donalda/Desktop/game_html/prompts/3_response/1_response.md")


# --- Colorized Output ---
class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

# --- Data Structures ---
Message = namedtuple('Message', ['level', 'text'])
TRANSFORM_LEVELS = {'INFO': 1, 'SUCCESS': 2, 'WARNING': 3, 'ERROR': 4}
# Type hint for transformations, now supporting deletion (code=None)
Transformation = Tuple[str, Optional[str]]

# --- OS-Agnostic Path Checking Helper ---
def is_path_absolute_for_any_os(path_str: str) -> bool:
    """Checks if a path string is absolute for Windows or POSIX."""
    if not isinstance(path_str, str): return False
    if path_str.startswith('/'): return True
    if len(path_str) > 2 and path_str[1] == ':' and path_str[2] in ('\\', '/'): return True
    return False

# --- Helper Functions ---
@lru_cache(maxsize=128)
def _find_files_with_same_name(filename: str, root: pathlib.Path) -> list[pathlib.Path]:
    """Finds all files with a given name, efficiently skipping specified directories."""
    matches = []
    exclude_dirs = {'node_modules', '.git', '__pycache__', 'dist', 'build'}
    directories_to_search = [root]
    while directories_to_search:
        current_dir = directories_to_search.pop()
        try:
            for path in current_dir.iterdir():
                if path.is_dir():
                    if path.name not in exclude_dirs:
                        directories_to_search.append(path)
                elif path.name == filename:
                    matches.append(path)
        except (IOError, OSError): continue
    return matches

def _repair_path(malformed_path_str: str, messages: list) -> str:
    """Attempts to repair a relative path string, returning an absolute path string on success."""
    filename = pathlib.Path(malformed_path_str).name
    messages.append(Message('WARNING', f"Path '{malformed_path_str}' is malformed. Attempting to repair."))
    potential_matches = _find_files_with_same_name(filename, PROJECT_ROOT)
    if len(potential_matches) == 1:
        repaired_path = potential_matches[0]
        messages.append(Message('SUCCESS', f"Path auto-repaired to '{repaired_path}'."))
        return str(repaired_path)
    elif len(potential_matches) > 1:
        messages.append(Message('ERROR', f"Found multiple possible matches for '{filename}'. Cannot auto-repair. Matches: {[str(p) for p in potential_matches]}"))
    else:
        messages.append(Message('ERROR', f"Could not find any file named '{filename}' in the project to repair path."))
    return malformed_path_str # Return original string on failure

def _is_likely_a_path(path_str: str) -> bool:
    """Uses heuristics to determine if a string is a file path marker vs. a piece of code."""
    path_str = path_str.strip()
    
    # Rule 1: Always accept if it contains a path separator.
    if '/' in path_str or '\\' in path_str:
        return True
    
    # Rule 2: Reject common code patterns like [OBJECT.PROPERTY] or [Enum.MEMBER].
    parts = path_str.split('.')
    if len(parts) == 2:
        # Reject [ALL_CAPS.ALL_CAPS]
        if parts[0].isupper() and parts[1].isupper():
            return False
        # Reject [PascalCase.PascalCase] for Enums/Classes
        if parts[0] and parts[0][0].isupper() and not parts[0].isupper() and parts[1] and parts[1][0].isupper():
            return False

    # Rule 3: Accept if it has a plausible file extension.
    if '.' in path_str:
        base, ext = path_str.rsplit('.', 1)
        # Extension must be 2-5 chars, alpha, and lowercase. Base must not contain invalid chars.
        if base and 2 <= len(ext) <= 5 and ext.isalpha() and ext.islower():
            if not any(c in base for c in "[]() '\""):
                return True

    # Rule 4: Reject all others.
    return False

# --- Core Logic ---
def parse_transformations(content: str) -> tuple[List[Transformation], List[Message]]:
    """Parses patch content into (path_string, code_string | None) tuples."""
    messages = []
    
    # Use a generic regex to find all bracketed lines, then validate with our heuristic function.
    potential_marker_regex = r'^\s*\[([^\]\n]+)\]\s*$'
    all_potential_markers = list(re.finditer(potential_marker_regex, content, re.MULTILINE))
    markers = [m for m in all_potential_markers if _is_likely_a_path(m.group(1))]

    if not markers:
        if re.search(r'```', content):
            messages.append(Message('WARNING', "Content found, but no file path markers like '[ /path/to/file ]' were detected."))
        else:
            messages.append(Message('ERROR', "No valid patch markers ('[ /path/to/file ]') found in the input."))
        return [], messages

    first_marker_start = markers[0].start()
    if first_marker_start > 0:
        preamble = content[:first_marker_start].strip()
        if preamble:
            messages.append(Message('INFO', f"Ignoring {len(preamble)} characters of initial explanation text."))

    raw_patches = []
    for i, marker in enumerate(markers):
        path_str = marker.group(1).strip()
        code_start = marker.end()
        code_end = markers[i + 1].start() if i + 1 < len(markers) else len(content)
        code = content[code_start:code_end]
        code = re.sub(r'\s*-\s*$', '', code, flags=re.MULTILINE).strip()
        raw_patches.append({'path': path_str, 'code': code})

    processed_patches: Dict[str, Optional[str]] = {}
    for patch in raw_patches:
        path_str, new_code = patch['path'], patch['code']
        if path_str in processed_patches:
            messages.append(Message('WARNING', f"Duplicate file patch for '{path_str}'. The last entry will be used."))
        
        new_code = re.sub(r'^\s*```[^\n]*\n', '', new_code, count=1)
        new_code = re.sub(r'\n```\s*$', '', new_code)
        
        processed_patches[path_str] = None if not new_code.strip() else new_code.strip()

    final_transformations: Dict[str, Optional[str]] = {}
    for path_str, code in processed_patches.items():
        final_path_str = path_str if is_path_absolute_for_any_os(path_str) else _repair_path(path_str, messages)
        final_transformations[final_path_str] = code
         
    return list(final_transformations.items()), messages

def apply_transformations(transformations: List[Transformation], messages: List[Message]) -> None:
    """Displays proposed changes and prompts the user to apply them."""
    if not transformations and not messages:
        print(f"{bcolors.OKGREEN}No changes or issues to report.{bcolors.ENDC}"); return

    print(f"{bcolors.HEADER}{bcolors.BOLD}--- Proposed File Changes ---{bcolors.ENDC}")
    if transformations:
        for path_str, code in transformations:
            check_path = pathlib.Path(path_str) if is_path_absolute_for_any_os(path_str) else PROJECT_ROOT / path_str
            if code is None: status = f"{bcolors.WARNING}(file delete){bcolors.ENDC}"
            elif check_path.exists(): status = f"{bcolors.OKCYAN}(overwrite){bcolors.ENDC}"
            else: status = f"{bcolors.OKGREEN}(create new file){bcolors.ENDC}"
            if not check_path.exists() and code is not None:
                existing = _find_files_with_same_name(check_path.name, PROJECT_ROOT)
                if existing and str(existing[0]) != str(check_path): status += f" {bcolors.WARNING}(Warning: A file named '{check_path.name}' already exists at {existing[0]}){bcolors.ENDC}"
            print(f"  - {check_path} {status}")
    else: print("No files will be changed.")
    print("-" * 25)

    print(f"{bcolors.HEADER}{bcolors.BOLD}--- Parsing & Analysis Report ---{bcolors.ENDC}")
    messages.sort(key=lambda m: TRANSFORM_LEVELS.get(m.level, 0))
    if not messages: print(f"{bcolors.OKGREEN}No formatting issues detected.{bcolors.ENDC}")
    else:
        for msg in messages:
            color = {'INFO': bcolors.OKBLUE, 'SUCCESS': bcolors.OKGREEN, 'WARNING': bcolors.WARNING, 'ERROR': bcolors.FAIL}.get(msg.level, bcolors.ENDC)
            print(f"{color}[{msg.level.ljust(7)}] {bcolors.BOLD if msg.level in ['WARNING', 'ERROR'] else ''}{msg.text}{bcolors.ENDC}")
    print("-" * 25)

    if not transformations: return
    try:
        if input(f"Apply these {len(transformations)} change(s)? (y/N): ").lower().strip() != 'y':
            print("Operation cancelled."); return
    except KeyboardInterrupt: print(f"\n{bcolors.FAIL}Operation aborted by user.{bcolors.ENDC}"); sys.exit(1)

    print(f"\n{bcolors.BOLD}Applying transformations...{bcolors.ENDC}")
    applied_count = 0
    for path_str, code in transformations:
        final_path = pathlib.Path(path_str) if is_path_absolute_for_any_os(path_str) else PROJECT_ROOT / path_str
        try:
            if code is None:
                if final_path.exists(): print(f"Deleting file {final_path}..."); final_path.unlink(); applied_count += 1
                else: print(f"Skipping deletion of non-existent file {final_path}...")
            else:
                print(f"Writing {len(code.encode('utf-8'))} bytes to {final_path}..."); final_path.parent.mkdir(parents=True, exist_ok=True); final_path.write_text(code, encoding='utf-8', newline='\n'); applied_count +=1
        except (IOError, OSError) as e: print(f"{bcolors.FAIL}Error applying change to {final_path}: {e}{bcolors.ENDC}", file=sys.stderr); sys.exit(1)
    print(f"\n{bcolors.OKGREEN}{bcolors.BOLD}Successfully applied {applied_count} transformation(s).{bcolors.ENDC}")

def main() -> None:
    """Main execution function to read and apply a patch file."""
    if not PATCH_FILE_PATH.is_file():
        print(f"{bcolors.FAIL}Error: Patch file not found at '{PATCH_FILE_PATH}'{bcolors.ENDC}", file=sys.stderr)
        sys.exit(1)
    try:
        print(f"Reading patch file: {PATCH_FILE_PATH}")
        content = PATCH_FILE_PATH.read_text(encoding='utf-8')
        _find_files_with_same_name.cache_clear()
        transformations, messages = parse_transformations(content)
        apply_transformations(transformations, messages)
    except Exception as e:
        print(f"{bcolors.FAIL}An unexpected error occurred: {e}{bcolors.ENDC}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()