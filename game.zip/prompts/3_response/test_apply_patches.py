import unittest
import tempfile
import pathlib
import textwrap
import os
import sys

# Ensure the current directory is in the path to find apply_response
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
import apply_response

class TestPatchParser(unittest.TestCase):
    def setUp(self):
        """Set up a temporary directory to act as a mock project root for each test."""
        self.temp_dir = tempfile.TemporaryDirectory()
        self.mock_project_root = pathlib.Path(self.temp_dir.name)
        
        # Override the PROJECT_ROOT in the imported module for the duration of the test
        apply_response.PROJECT_ROOT = self.mock_project_root
        
        # Create a mock file structure
        self.app_dir = self.mock_project_root / "app"
        actions_dir = self.app_dir / "src/context/actions"
        actions_dir.mkdir(parents=True, exist_ok=True)
        (actions_dir / "combatActions.ts").touch()

        components_dir = self.app_dir / "src/components"
        components_dir.mkdir(exist_ok=True)
        (components_dir / "rogue.ts").touch() 
        (components_dir / "file_to_delete.ts").touch()

        lib_dir = self.app_dir / "lib"
        lib_dir.mkdir(exist_ok=True)
        (lib_dir / "rogue.ts").touch()

    def tearDown(self):
        """Clean up the temporary directory and clear caches after each test."""
        self.temp_dir.cleanup()
        apply_response._find_files_with_same_name.cache_clear()

    def test_ignores_react_dependency_array(self):
        """Tests that the parser correctly ignores a React dependency array on its own line."""
        content = textwrap.dedent('''
            [ /app/src/file.ts ]
            const getZoneData = useCallback(
                (zoneId: string): Zone | undefined => {
                // ... function body
                },
                [GAME_DATA.ZONES]
            );
        ''')
        transformations, messages = apply_response.parse_transformations(content)
        self.assertEqual(len(transformations), 1)
        self.assertEqual(transformations[0][0], '/app/src/file.ts')
        self.assertIn("[GAME_DATA.ZONES]", transformations[0][1])
        self.assertFalse(any("malformed" in msg.text.lower() for msg in messages))

    def test_ignores_code_enum_access(self):
        """Tests that the parser correctly ignores another common code pattern (PascalCase Enum)."""
        content = textwrap.dedent('''
            [ /app/src/file.ts ]
            const x = MyEnum.Value;
            switch(y) {
                case [MyEnum.AnotherValue]:
                    break;
            }
        ''')
        transformations, messages = apply_response.parse_transformations(content)
        self.assertEqual(len(transformations), 1)
        self.assertEqual(transformations[0][0], '/app/src/file.ts')
        self.assertIn("[MyEnum.AnotherValue]", transformations[0][1])
        self.assertFalse(any("malformed" in msg.text.lower() for msg in messages))

    def test_deletion_of_file_with_empty_block(self):
        """Tests that a file patch with no content is correctly parsed as a deletion command."""
        file_to_delete_path = str(self.app_dir / "src/components/file_to_delete.ts")
        content = textwrap.dedent(f"[ {file_to_delete_path} ]\n\n[ /app/src/another_file.ts ]\nconst x = 1;")
        transformations, _ = apply_response.parse_transformations(content)
        self.assertEqual(len(transformations), 2)
        trans_map = {t[0]: t[1] for t in transformations}
        self.assertIn(file_to_delete_path, trans_map)
        self.assertIsNone(trans_map[file_to_delete_path])
        self.assertEqual(trans_map['/app/src/another_file.ts'], 'const x = 1;')

    def test_path_repair_success_unique_file(self):
        """Tests the path repair mechanism for a uniquely named file (no path)."""
        content = "[ combatActions.ts ]\nconst x = 1;"
        transformations, messages = apply_response.parse_transformations(content)
        repaired_path_str = str(self.mock_project_root / "app/src/context/actions/combatActions.ts")
        self.assertEqual(len(transformations), 1)
        self.assertEqual(transformations[0][0], repaired_path_str)
        self.assertTrue(any("Path auto-repaired" in msg.text for msg in messages))

    def test_path_repair_failure_multiple_matches(self):
        """Tests path repair failure when multiple ambiguous matches are found."""
        content = "[ rogue.ts ]\nlet a = 1;"
        transformations, messages = apply_response.parse_transformations(content)
        self.assertEqual(len(transformations), 1)
        self.assertEqual(transformations[0][0], "rogue.ts") # Returns original on failure
        self.assertTrue(any("Found multiple possible matches" in msg.text for msg in messages))

if __name__ == '__main__':
    unittest.main(verbosity=2)