# PROBLEM SOLVING STRATEGY
Analyze my request, perform a full end-to-end analysis of the code and review all supplemental data to determine requirements. Then, create a comprehensive solution plan before implementing.

### Mandatory Planning Process
Before writing code, detail your plan by analyzing the request through the lens of our event-driven architecture:
*   **1. User Interaction Analysis:** Describe the sequence of user actions that trigger the new functionality.
*   **2. Component & UI Impact:** List all components to be modified/created and the specific UI changes.
*   **3. State & Logic Flow (CQRS):** Detail the end-to-end data flow.
    *   **Action:** Which command function is called from the UI?
    *   **State Update:** What minimal, direct state change does the reducer/setter make?
    *   **Consequences (Observer Effect):** What downstream effects are triggered by observers watching the state change?
*   **4. Edge Cases & Safeguards:** Identify potential edge cases and how the solution handles them.

### Final Checks
*   Do not make any changes beyond the scope of my requested changes.
*   Preserve all existing functionality.
*   When fixing bugs, add `console.log`, `console.warn`, and in-game log statements to make program flow and variable states transparent for debugging.
*   You must perform a full end-to-end analysis to make the solution work. Think deeply and analyze thoroughly; do not use a quick or easy workaround.

# PROJECT CODE & FILE PATHS

### Game Paths:
*   Main Game Src Path: `/mnt/c/Users/donalda/Desktop/game_html/app/src/`
*   App.tsx path: `/mnt/c/Users/donalda/Desktop/game_html/app/src/App.tsx`
*   Components path: `/mnt/c/Users/donalda/Desktop/game_html/app/src/components`
*   .gitignore path: `/mnt/c/Users/donalda/Desktop/game_html/app/src/.gitignore`

# Project Code: