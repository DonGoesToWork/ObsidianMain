#!/usr/bin/env python3

import os
import sys
from pathlib import Path

VERSION = "WIN"

if VERSION == "WSL":
    SOURCE_FOLDER = Path("/mnt/c/Users/donalda/Desktop/game_html/app")
    OUTPUT_FILE = Path("/mnt/c/Users/donalda/Desktop/game_html/prompts/2_generated_prompt/2_output.md")

    INDIVIDUAL_FILES_TO_INCLUDE = [
        "/mnt/c/Users/donalda/Desktop/game_html/prompts/1_input/1_prompt.md",
        "/mnt/c/Users/donalda/Desktop/game_html/prompts/1_input/2_error.log"
    ]
else:
    SOURCE_FOLDER = Path(r"C:\Users\Donald\Desktop\game_html\app")
    OUTPUT_FILE = Path(r"C:\Users\Donald\Desktop\game_html\prompts\2_generated_prompt\2_output.md")
    INDIVIDUAL_FILES_TO_INCLUDE = [
        r"C:\Users\Donald\Desktop\game_html\prompts\1_input\1_prompt.md"
    ]

EXCLUDED_FILES = {
    ".DS_Store",
    "package-lock.json",
    "poetry.lock",
    "pnpm-lock.yaml",
}

EXCLUDED_FOLDERS = {
    ".git",
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
    "env",
    ".env",
    "dist",
    "build",
    ".idea",
    ".vscode",
}

def add_individual_files():
    try:
        individual_files = [Path(p).resolve(strict=False) for p in INDIVIDUAL_FILES_TO_INCLUDE]
        output_file = OUTPUT_FILE.resolve(strict=False)
    except Exception as e:
        print(f"Error resolving configuration paths: {e}", file=sys.stderr)
        sys.exit(1)

    EXCLUDED_FILES.add(output_file.name)
    EXCLUDED_FILES.add(Path(__file__).name)

    files_to_combine = []

    # 1. Add individually specified files
    for file_path in individual_files:
        if file_path.is_file():
            files_to_combine.append(file_path)
        else:
            print(f"Warning: Individual file not found, skipping: {file_path}", file=sys.stderr)

    if not files_to_combine:
        print("No files found to combine. Exiting.", file=sys.stderr)
        return

    print(f"Combining {len(files_to_combine)} files into {output_file}...")

    try:
        with open(output_file, "w", encoding="utf-8") as f_out:
            for file_path in files_to_combine:
                print(f"  -> Adding {file_path}")

                header = f"--- FILE: {file_path} ---"
                f_out.write(header + "\n")

                try:
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as f_in:
                        content = f_in.read()
                        f_out.write(content)
                        # Ensure the file content ends with a newline before the next separator
                        if content and not content.endswith('\n'):
                            f_out.write("\n")
                        f_out.write("\n")
                except Exception as e:
                    error_msg = f"Error reading file {file_path}: {e}"
                    print(error_msg, file=sys.stderr)
                    f_out.write(f"!!! {error_msg} !!!\n\n")
    except IOError as e:
        print(f"Error: Could not write to output file {output_file}: {e}", file=sys.stderr)
        sys.exit(1)

    print("\nCombination complete.")
    print(f"Output file created at: {output_file}")

def add_folders():
    try:
        source_folder = SOURCE_FOLDER.resolve(strict=False)
        output_file = OUTPUT_FILE.resolve(strict=False)
    except Exception as e:
        print(f"Error resolving configuration paths: {e}", file=sys.stderr)
        sys.exit(1)

    # Add the intended output file and this script to the exclusion list
    # to prevent them from being included in the output.
    EXCLUDED_FILES.add(output_file.name)
    EXCLUDED_FILES.add(Path(__file__).name)

    files_to_combine = set()

    # 2. Walk the source folder and gather files
    if source_folder.is_dir():
        for root, dirs, files in os.walk(source_folder, topdown=True):
            # Prune traversal by modifying dirs in-place. This is efficient.
            dirs[:] = [d for d in dirs if d not in EXCLUDED_FOLDERS]

            current_root = Path(root)
            for filename in files:
                if filename not in EXCLUDED_FILES:
                    files_to_combine.add(current_root / filename)
    elif str(SOURCE_FOLDER) != ".": # Don't warn if SOURCE_FOLDER is intentionally blank
        print(f"Warning: Source folder not found, skipping search: {source_folder}", file=sys.stderr)

    if not files_to_combine:
        print("No files found to combine. Exiting.", file=sys.stderr)
        return

    # Create the output directory if it doesn't exist
    try:
        output_file.parent.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        print(f"Error: Could not create output directory {output_file.parent}: {e}", file=sys.stderr)
        sys.exit(1)

    # Sort files by path for a deterministic and logical order
    sorted_files = files_to_combine

    print(f"Combining {len(sorted_files)} files into {output_file}...")

    try:
        with open(output_file, "a", encoding="utf-8") as f_out:
            for file_path in sorted_files:
                print(f"  -> Adding {file_path}")

                header = f"--- FILE: {file_path} ---"
                f_out.write(header + "\n")

                try:
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as f_in:
                        content = f_in.read()
                        f_out.write(content)
                        # Ensure the file content ends with a newline before the next separator
                        if content and not content.endswith('\n'):
                            f_out.write("\n")
                        f_out.write("\n")
                except Exception as e:
                    error_msg = f"Error reading file {file_path}: {e}"
                    print(error_msg, file=sys.stderr)
                    f_out.write(f"!!! {error_msg} !!!\n\n")
    except IOError as e:
        print(f"Error: Could not write to output file {output_file}: {e}", file=sys.stderr)
        sys.exit(1)

    print("\nCombination complete.")
    print(f"Output file created at: {output_file}")

def main():
    try:
        os.remove(OUTPUT_FILE)
    except FileNotFoundError:
        print("cool")

    add_individual_files()
    add_folders()

if __name__ == "__main__":
    main()