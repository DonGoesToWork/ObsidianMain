#!/usr/bin/env python3

import os
import sys
import shutil
import re
from pathlib import Path

# --- Configuration ---

SOURCE_FOLDER = Path("/mnt/c/Users/donalda/Desktop/game_html/app")
OUTPUT_FILE = Path("/mnt/c/Users/donalda/Desktop/game_html/prompts/2_generated_prompt/2_output.md")

INDIVIDUAL_FILES_TO_INCLUDE = [
    {"path": "/mnt/c/Users/donalda/Desktop/game_html/prompts/1_input/0_prompt_base_a.md", "append_header": False},
    {"path": "/mnt/c/Users/donalda/Desktop/game_html/prompts/1_input/1_prompt_task.md", "append_header": False},
    {"path": "/mnt/c/Users/donalda/Desktop/game_html/prompts/1_input/0_prompt_base_b.md", "append_header": False},
    {"path": "/mnt/c/Users/donalda/Desktop/game_html/prompts/1_input/2_error.log", "append_header": False}
]

# --- Environment Detection ---
IS_WINDOWS = sys.platform == "win32"

def convert_wsl_to_windows_path_str(wsl_path):
    """Converts a single WSL path string to a Windows path string."""
    if wsl_path.startswith('/mnt/'):
        path_no_mnt = wsl_path[5:]
        drive_letter = path_no_mnt[0].upper()
        rest_of_path = path_no_mnt[1:]
        return f"{drive_letter}:{rest_of_path.replace('/', os.path.sep)}"
    return wsl_path.replace('/', os.path.sep)

def adjust_paths_for_environment():
    """Dynamically adjusts the global path configurations based on the OS."""
    global SOURCE_FOLDER, OUTPUT_FILE, INDIVIDUAL_FILES_TO_INCLUDE
    if IS_WINDOWS:
        SOURCE_FOLDER = Path(convert_wsl_to_windows_path_str(str(SOURCE_FOLDER)))
        OUTPUT_FILE = Path(convert_wsl_to_windows_path_str(str(OUTPUT_FILE)))
        INDIVIDUAL_FILES_TO_INCLUDE = [
            {"path": Path(convert_wsl_to_windows_path_str(p["path"])), "append_header": p["append_header"]}
            for p in INDIVIDUAL_FILES_TO_INCLUDE
        ]
    else:
        # For WSL or other Unix-like systems, just ensure they are Path objects
        SOURCE_FOLDER = Path(SOURCE_FOLDER)
        OUTPUT_FILE = Path(OUTPUT_FILE)
        INDIVIDUAL_FILES_TO_INCLUDE = [
            {"path": Path(p["path"]), "append_header": p["append_header"]}
            for p in INDIVIDUAL_FILES_TO_INCLUDE
        ]


def convert_wsl_path_to_windows(input_file_path, output_file_path):
    """
    Copies a file and, if in a Windows environment, converts any WSL-style
    paths within the file's content to Windows-style paths.
    """
    try:
        # Ensure the output directory exists
        Path(output_file_path).parent.mkdir(parents=True, exist_ok=True)
        # First, copy the file
        shutil.copy(input_file_path, output_file_path)

        if IS_WINDOWS:
            # If on Windows, read the copied file and replace paths
            with open(output_file_path, 'r', encoding='utf-8', errors='ignore') as file:
                content = file.read()

            # Use regex to find and replace all instances of /mnt/c/... style paths
            replacement_lambda = lambda m: m.group(1).upper() + ":\\" + m.group(2).replace('/', '\\')
            content = re.sub(r'/mnt/([a-zA-Z])(/[^ \n\r]*)', replacement_lambda, content)

            with open(output_file_path, 'w', encoding='utf-8') as file:
                file.write(content)
        
        print(f"Processed and copied {input_file_path} to {output_file_path}")

    except Exception as e:
        print(f"Error processing file {input_file_path}: {e}", file=sys.stderr)


def preprocess_files_for_path_conversion():
    """
    Iterates through a predefined list of files and processes them for
    path conversion based on the environment.
    """
    # This list defines which files should have their content paths converted.
    # The paths are in WSL format and will be auto-converted for the environment.
    check_replacement_files = [
        [
            "/mnt/c/Users/donalda/Desktop/game_html/prompts/1_input/0_prompt_base_a.md",
            "/mnt/c/Users/donalda/Desktop/game_html/prompts/2_generated_prompt/0_prompt_base_a_processed.md",
        ]
    ]

    # Adjust paths in check_replacement_files for the current environment
    if IS_WINDOWS:
        processed_check_files = [
            [convert_wsl_to_windows_path_str(p[0]), convert_wsl_to_windows_path_str(p[1])]
            for p in check_replacement_files
        ]
    else:
        processed_check_files = check_replacement_files
    
    print("\n--- Pre-processing files for path conversion ---")
    for input_path, output_path in processed_check_files:
        convert_wsl_path_to_windows(input_path, output_path)
    print("--- Pre-processing complete ---\n")

EXCLUDED_FILES = {
    ".DS_Store",
    "package-lock.json",
    "poetry.lock",
    "pnpm-lock.yaml",
}

EXCLUDED_FOLDERS = {
    ".git",
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
    "env",
    ".env",
    "dist",
    "build",
    ".idea",
    ".vscode",
}

def add_individual_files():
    """Adds individually specified files to the output."""
    output_file = OUTPUT_FILE
    EXCLUDED_FILES.add(output_file.name)
    EXCLUDED_FILES.add(Path(__file__).name)

    files_to_combine = []

    # 1. Add individually specified files
    for file_info in INDIVIDUAL_FILES_TO_INCLUDE:
        file_path = file_info["path"]
        if file_path.is_file():
            files_to_combine.append(file_info)
        else:
            print(f"Warning: Individual file not found, skipping: {file_path}", file=sys.stderr)

    if not files_to_combine:
        print("No individually specified files found to combine.", file=sys.stderr)
        return

    print(f"Combining {len(files_to_combine)} individual files into {output_file}...")

    try:
        with open(output_file, "w", encoding="utf-8") as f_out:
            for file_info in files_to_combine:
                file_path = file_info["path"]
                append_header = file_info["append_header"]
                
                print(f"  -> Adding {file_path}")
                if append_header:
                    header = f"[ {file_path} ]"
                    f_out.write(header + "\n")
                
                try:
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as f_in:
                        content = f_in.read()
                        f_out.write(content)
                        if content and not content.endswith('\n'):
                            f_out.write("\n")
                        f_out.write("\n")
                except Exception as e:
                    error_msg = f"Error reading file {file_path}: {e}"
                    print(error_msg, file=sys.stderr)
                    f_out.write(f"!!! {error_msg} !!!\n\n")
    except IOError as e:
        print(f"Error: Could not write to output file {output_file}: {e}", file=sys.stderr)
        sys.exit(1)

    print("\nIndividual file combination complete.")

def add_folders():
    """Walks the source folder and appends files to the output."""
    source_folder = SOURCE_FOLDER.resolve(strict=False)
    output_file = OUTPUT_FILE.resolve(strict=False)

    EXCLUDED_FILES.add(output_file.name)
    EXCLUDED_FILES.add(Path(__file__).name)

    files_to_combine = set()

    if source_folder.is_dir():
        for root, dirs, files in os.walk(source_folder, topdown=True):
            dirs[:] = [d for d in dirs if d not in EXCLUDED_FOLDERS]
            current_root = Path(root)
            for filename in files:
                if filename not in EXCLUDED_FILES:
                    files_to_combine.add(current_root / filename)
    elif str(SOURCE_FOLDER) != ".":
        print(f"Warning: Source folder not found, skipping search: {source_folder}", file=sys.stderr)

    if not files_to_combine:
        print("No folder files found to combine.", file=sys.stderr)
        return

    sorted_files = sorted(list(files_to_combine))

    print(f"\nCombining {len(sorted_files)} files from folders into {output_file}...")

    try:
        # Use append mode 'a' since add_individual_files runs first
        with open(output_file, "a", encoding="utf-8") as f_out:
            for file_path in sorted_files:
                print(f"  -> Adding {file_path}")
                header = f"[ {file_path} ]"
                f_out.write(header + "\n")
                try:
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as f_in:
                        content = f_in.read()
                        f_out.write(content)
                        if content and not content.endswith('\n'):
                            f_out.write("\n")
                        f_out.write("\n")
                except Exception as e:
                    error_msg = f"Error reading file {file_path}: {e}"
                    print(error_msg, file=sys.stderr)
                    f_out.write(f"!!! {error_msg} !!!\n\n")
    except IOError as e:
        print(f"Error: Could not write to output file {output_file}: {e}", file=sys.stderr)
        sys.exit(1)

    print("\nFolder file combination complete.")
    print(f"Output file created at: {output_file}")


def main():
    """Main execution function."""
    # Adjust all paths at the start
    adjust_paths_for_environment()
    
    # Run the new pre-processing step
    preprocess_files_for_path_conversion()

    # Clear the output file before writing
    try:
        if OUTPUT_FILE.exists():
            os.remove(OUTPUT_FILE)
    except OSError as e:
        print(f"Error removing existing output file: {e}", file=sys.stderr)
        sys.exit(1)

    add_individual_files()
    add_folders()

if __name__ == "__main__":
    main()