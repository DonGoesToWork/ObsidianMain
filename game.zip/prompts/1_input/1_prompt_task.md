We have added drag and drop to the game. Now, we are fine-tuning it:

- TODO: these are failed attempts to further improve drag and drop, refine and retest in the future

finito for now!

We have added drag and drop to the Player Inventory section of the game. Now, we must spread this feature to the rest of the game:

- Implement drag-and-drop functionality on all other UnifiedInventoryDisplay components. I should be able to use Drag and Drop in ground loot, shop inventories, the bank and all other UnifiedInventoryDisplay components by default.
- Ensure that there are maximum size limits for all inventories reflected/bound to GLOBAL_QUICK_DEV_CONFIGURATION.ts file and that we show slots in all inventories similar to the Player Inventory section.

Our goal is mainly to migrate our changes from the Player Inventory section to the other areas of the game. Propogate these changes!


We have added drag and drop to the game. Now, we are fine-tuning it:

- I can't use drag-and-drop to rearrange items in my Ground Loot inventory. Can you fix? The Player Inventory used to have this issue when it didn't have support for, I believe it was called 'sparse arrays'. We want the same implementation here.
- Also, in the Party Menu, I disabled drag-and-drop via isDraggable=false on the inventory. However, I can still pick up the items onto the cursor, even if it does nothing? Can we make it so that I can't pick up items when draggable is false? Thanks.

Make sure to make the requested changes without effecting other existing functionality.


