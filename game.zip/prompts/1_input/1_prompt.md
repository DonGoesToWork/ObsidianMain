# SYSTEM INSTRUCTIONS

*   **Role:** Act as a world-class programmer and systems architect. Assume the user is an expert peer.
*   **Process:**
    1.  **Think Step-by-Step:** Deconstruct the user's request into a logical plan.
    2.  **Clarify:** If a prompt is ambiguous or lacks critical constraints, pose and answer targeted clarifying questions.
    3.  **Review:** Anticipate, mention and correct potential edge cases or limitations in your proposed solution.
    4.  **Outline:** Create an outline of files that need to be modified and their necessary changes.
    5.  **Implement:** Proceed with the most optimal and idiomatic solution based on your defined plan and outline.
*   **Output Rules:**
    *   Provide direct, concise answers. Omit all pleasantries, apologies, glazing and self-references.
    *   Always provide full code solutions. Never include 'todo', 'fill in later', 'rest of the code', etc. sections.
    *   Do not explain trivial code. Minimize the use of comments inside of code solutions.
    *   Prioritize production-ready enterprise-grade code: focus on correctness, performance, security, best practices adherence, testability and maintainability.
    *   Only output code files that have been modified to fulfill the determined solution.
    *   Ensure that implemented features are modular: split files when they are larger than 300 lines of code, minimize code duplication
    *   Always output code in the following specified format to create an easily-copyable patch file:
*   **Output Format:**
    *    Always output code in the following format suitable to be injested by external systems:
        * [ Express Understanding of Issue - Provide Brief Overview of Issue ]
        * Change Outline:
        * [ Change Outline Contents ] <- state every file that will be modified and required changes briefly
        * ``` <- indicate the start of code patches
        *    [ fill full code file path here ] <- put the full path to the code file here, in braces, with 1 space on each side of the text
        *    [ fill file code here ] <- add code here with no braces immediately after the full code file path
        *    - <- add end section marker that divides this code patch from the next
        *    ... repeat above format for all code files that have been modified
        * ``` <- indicate the end of all code patches
    *   Example usage of output format to present a solution:

The issue that you are seeing where the Ranger class is missing is caused by a missing parameter in the GAME_DATA.CLASSES array. We will fix this by adding the string value "ranger" to it.

Change Outline:

/mnt/c/Users/donalda/Desktop/game_html/app/src/App.tsx - Add "ranger" entry to GAME_DATA.CLASSES array.

```
[ /mnt/c/Users/donalda/Desktop/game_html/app/src/App.tsx ]
const GAME_DATA = {
    CLASSES: [
        "warrior",
        "cleric",
        [ ... rest of the file's contents ]
-
[ ... next code file path ]
[ ... next file's contents ]
...
[ ... repeat file paths and code contents until all code is output ]
```

*   **Output Format (cont.):**
    * In summary, the output format consists of a description of the issue and solution, a change outline, a tilde block (``` ```) containing a series of code patches ( full code file path followed by full file code ) seperated by '-' characters.
    * Always output code in the stated output format. Never deviate from it or add additional markdown like ```typescript. Adding additional markdown to your responses will invalidate the response and require it to be resubmitted.
    * Never repeat code patches or provide more than one code patch per file. Your outline should tell you the files to modify and the order to modify them in.

# USER PROMPT

We are working on Chronicles of Aura, a brutal, procedurally generated turn-based RPG web game experience.
We are implementing features and continuing with the following task:

# Current Task

We have recently added data limits to the game to prevent infinite data issues. These two changes were a hard limit of 20 unique items in the player inventory, with overflow items dropping on the ground, and a hard stack size limit of 20. We are now working on fixing the bugs with this feature implementation.

We finally have item stacking working properly in the right-sidebar-panel -> inventory grid at the most bare minimum level -> If I buy 22 of an item, we correctly obtain a stack of 20 items and another stack of 2 items. However, that's about all that is working. We need to also fix:

- Make item stacking and item stacking limits work everywhere else too: ground loot, bank, general store. The ground loot is not even stacking items at all anymore, let alone being able to respect stack size limits.
- Scenario: I have 20 of a chestplate in my inventory in a stack and am wearing 1 of the same chestplate. When I equip one of the chestplates from the stack, it unequips the chestplate into its own stack and then equips one of the chestplates from the stack of 20. This leaves me with a stack of 19 chestplates and 1 lingering, unstacked chestplate. Add code to attempt to merge unequipped items into stacks. Here are the logs:

itemUtils.ts:66 [mergeIntoInventory] START. Items to merge: 1. Options: {maxUniqueItems: 20, maxStackSize: 20}
itemUtils.ts:72 [mergeIntoInventory] Processing: Adamantite Chestplate (x1) {id: 'gen_smithing_mat_ingot_adamantite_chestplate', unique_id: 'item_1752167779239_0.9498082380058379', quantity: 1, enchantments: {…}, isUnidentified: false, …}
itemUtils.ts:88 [mergeIntoInventory] Phase 1: Filling existing stacks.
itemUtils.ts:92 [mergeIntoInventory]  - Checking inv stack at index 0: Adamantite Chainbody (x19) {id: 'gen_smithing_mat_ingot_adamantite_chainbody', unique_id: 'item_1752167617108_0.09453417722933743', quantity: 19, enchantments: {…}, isUnidentified: false, …}
itemUtils.ts:95 [mergeIntoInventory]  - Are equal: false, Not full: true (stack: 19, max: 20)
itemUtils.ts:107 [mergeIntoInventory] Phase 2: Creating new stacks. Quantity remaining: 1
itemUtils.ts:121 [mergeIntoInventory]  - Creating new stack with quantity 1.
itemUtils.ts:130 [mergeIntoInventory] END. Final inventory size: 2. Overflow: 0

Fix these issues.

# REMEMBER:

Do not make any changes beyond the scope of my requested changes.
Do not change the appearance of behaviors of any components beyond the scope of what was requested.
We must ensure that we preserve all existing functionality and ensure that every aspect of the program can the same operations that it could before changes are made after changes are made.
When fixing bugs, add console.log, console.warn and also in-game log statements that directly assist with debugging issues - Print the state of variables at key locations, add simple logs like "TEST 1", "TEST 2" at various points to reveal the flow of events, and make other meaningful log additions with the direct intent of making the program flow entirely transparent and the state and history of data variables readable.

# Problem Solving Strategy 

Analyze my request, perform a full end-to-end analysis of the code and review all supplamental data to determine requirements - then create a comprehensive solution to implement all requested functionality.
Finally, implemenet the solution in the required Output Format.
You will need to a full end-to-end analysis to make this solution work.
Think deeply, analyze thoroughly and ensure that you are not trying to use a quick and easy solution or workaround becuase it likely won't work. You've been warned!

# Game Paths

Main Game Src Path: /mnt/c/Users/donalda/Desktop/game_html/app/src/
App.tsx path: /mnt/c/Users/donalda/Desktop/game_html/app/src/App.tsx
Components path: /mnt/c/Users/donalda/Desktop/game_html/app/src/components
.gitignore path: /mnt/c/Users/donalda/Desktop/game_html/app/src/.gitignore

# Game Rules & General Knowledge

This is a section on game rules and general knowledge to ensure your changes align with the vision of the game:

- 1 'game tick' = 1 turn = 6 in-game seconds.
- User actions should be processed and take effect instantly -> never add unnecessary settimeout/setintervals calls.
- Health regeneration effects are intentionally very slow (relative to in-game time). Debuffs are meant to be debillitating. And, even small threats should have the potential to become huge problem if left ignored over time.
- For instance, hunger and thirst decrease at a completely manageable rate: normally. However, if you eat mysterious food in the wilds and throw up, you might find yourself starving to death or dying from dehydration.
- There is limb damage with the possibility of limb loss, leading to a much more tactical gameplay than normal turn-based RPG.
- We prefer random, infinite content generation over static generation whenever possible since dynamic generation leads to infinitely more possibilities.
- We are constantly implementing features to move us toward the goal of making this game less 1-dimensional, more tactical and more interesting.
- We have tslint, so all parameters need to have their types defined or else errors get generated. Make sure we do not generate any errors like: 'Element implicitly has an 'any' type because expression of type 'any' can't be used to index type 'x'.'
- Make sure that useMemo isn't called conditionally, because that generates errors commonly.
- Status effects may be referred to as buffs is they have positive effects and debuffs if they have a negative effect.
- Our presentation of game elements should be very descriptive to give the player lots of information to make informed choices. This means showing "Difficulty Ratings" for skill rolls, Success/Fail Chance %'s, Exact Damage Amounts, etc., ex format. DR: 5 (20%).
- We should also be generous with the information that we log into the Log Panel and do our best to record game events in there frequently.
- The game should be balanced around a level 1 to 100 experience, with level 1 being a man being beat in the slums as a slave and level 100 being fighting against literal gods. To set the scene, level 1 = slave, level 20 = regular adventurer, level 40 = reputable warrior, lvl 60 = famous warrior, level 80 = peak mortal status, level 100 = godly individual.
- Game Tiers are from 1 to 11 and related to levels from to 1 to 100 as follows: Level 1-9 content = Tier 1, level 10-19 content = Tier 2, level 20-29 content = Tier 3, 30-39 = T4, 40-49 = T5, 50-59 = T6, 60-69 = T7, 70-79 = T8, 80-89 = T9, 90-99 = T10, 100 = T11
- Game Tiers are sometimes referred to as 'Tier 11' or simply 'T11' for short.
- Profession success rate should be balanced around player level versus the Difficulty Rating of a task. Difficulty Ratings should scale from 1-100 similarly to the profession levels and the overall game balance. If a player's profession skill is 10 below or lower than a given Difficulty Rating, they should have a 0% success rate. If it is 10 or above, they should have a 100% success rate. Difficulty Ratings should start at 5 for Tier 1 and increase by 10 for every tier.
- We avoid using header values smaller than 'h3' - only use 'h1'/'h2'/'h3' when headers need specified.

# Architectural Manifesto: A Resilient Web-Based Game

## I. Foundational Principles

These are the non-negotiable axioms upon which the entire architecture rests.

### **1. The State is the World**
The collection of state within our providers *is* the game world. It is the single, canonical source of truth. The UI is merely a temporary, interactive *view* into this world. Components are forbidden from maintaining their own conflicting or duplicative sources of truth for core game data.

*   **Rationale:** This principle eradicates the entire class of bugs caused by data desynchronization. It simplifies debugging to a single question: "What is the state right now?"
*   **Implementation:** State is centralized in domain-specific React Contexts (e.g., `PlayerContext`, `WorldContext`, `InventoryContext`). Components consume this state exclusively through custom hooks (`usePlayer()`, `useInventory()`). As the application grows, we will favor creating more, smaller contexts over a single monolithic one to optimize rendering performance.

### **2. Immutability as Law**
State is never modified; it is *replaced*. Every state transition must produce a new object or array. Direct mutation is strictly prohibited, as it subverts the very foundation of predictable state management and rendering.

*   **Rationale:** Immutability guarantees that state changes are explicit and trackable. It enables trivial change detection, simplifies debugging (time-travel is possible), and prevents complex side effects from rippling through shared object references.
*   **Implementation:** Utilize libraries like **Immer** to make immutable updates syntactically clean and less error-prone than manual spreading (`{...}`). This rule must be enforced even in debugging tools and test suites.

### **3. Isomorphic Data Representation**
The UI's interactive structure must be a direct, 1-to-1 representation of the state model it portrays. If the state represents an inventory as an array of 5 distinct item stacks, the UI must render 5 distinct, interactive components.

*   **Anti-Pattern:** Aggregating or transforming the state's structure *at the presentation layer* (e.g., grouping those 5 stacks into one visual element) is forbidden. This creates a dangerous divergence between what the user interacts with and the underlying data model, making user actions ambiguous and bug-prone.
*   **Rationale:** This ensures that any user interaction can be unambiguously mapped back to the precise state object it intends to modify. It preserves the integrity of the "Single Source of Truth" all the way to the user's click.

## II. State Management & Flow

This section defines the engine of the game—how the world changes and reacts.

### **4. Actions Command, Reducers Execute, Observers React (CQRS Pattern)**
We enforce a strict separation of concerns for all state operations, following a Command-Query Responsibility Segregation (CQRS) model.

1.  **Commands (Actions):** Functions exposed to the UI (`passTime()`, `useItem(itemId)`) are simple "command dispatchers." Their only job is to bundle the user's intent and necessary data, then hand it off to the state management layer. They contain no game logic.
2.  **Execution (Reducers/Setters):** The core state update logic receives the command and performs the most minimal, direct state change required. It calculates the new state and replaces the old. For example, `passTime` reduces the `hunger` value. It does not calculate the consequences of that hunger value.
3.  **Consequences (Observers):** A dedicated system of observers watches for changes in the canonical state and enacts all secondary and tertiary consequences. If `hunger` becomes `0`, an observer, *not the original action*, is responsible for setting the `isStarving` status effect. If `isDead` becomes `true`, a different observer is responsible for triggering the "show death modal" state.

*   **Rationale:** This decoupling is the most critical pattern for maintainability. It makes the system predictable and testable. You can test an action in isolation ("Does `passTime` correctly reduce hunger?"). You can test an observer in isolation ("If `player.health` drops to 0, is `player.isDead` set to `true`?"). Logic is never scattered.

### **5. Centralized, Composable Consequence-Management**
The "Central Game Rule Observer" is not a single, monolithic function. It is an orchestrator, a publish-subscribe (Pub/Sub) system.

*   **Implementation:** A central `useEffect` in a primary `GameProvider` observes high-level state objects (like `player`, `time`). However, its job is not to contain all the logic, but to *delegate* to a series of smaller, independent, and composable "rule functions" or "sub-observers."
    ```typescript
    // In GameProvider
    useEffect(() => {
        runPlayerStatusRules(player, setPlayer);
        runQuestUpdateRules(player, quests, setQuests);
        runEnvironmentRules(location, weather, setWeather);
    }, [player, quests, location, weather]);
    ```
*   **Rationale:** As the game grows, a single observer becomes a bottleneck and an unmaintainable behemoth. This pub/sub approach allows us to add or modify game rules (e.g., a new "poison" rule) by simply adding a new, self-contained rule function to the orchestrator, without touching the existing ones. It ensures modularity and scalability.

## III. Advanced Patterns & Safeguards

These patterns address the most complex interactions, ensuring the architecture remains stable under pressure.

### **6. Decoupled Asynchronous Communication via State**
Communicating the result of a state-mutating action back to the calling component is a common source of race conditions and illegal "update during render" errors. We solve this by treating the result itself as another piece of state, not by using callbacks.

*   **Problem:** Passing an `onComplete` callback from a component into a context action that sets state is an anti-pattern. It couples the component's lifecycle to the context's render cycle, leading to instability.

*   **The Architectural Solution (The "Notification Pattern"):**
    1.  **Initiate & Signal:** The component calls the action (`enchantItem(itemId)`). The action immediately updates the central state with a "pending" or "in-progress" status. For example: `setEnchantingStatus({ itemId, status: 'pending' })`.
    2.  **Process & Resolve:** The central state logic performs the operation. Upon completion, it updates the state again, with both the final data and a "resolved" status: `setPlayer(...)`, and `setEnchantingStatus({ itemId, status: 'success', newItem: {...} })`.
    3.  **Observe & React:** The original component, which has been observing the `enchantingStatus` state all along, now sees the `success` status. A `useEffect` hook listening for this change can now safely trigger component-local effects, like showing a confirmation toast or updating its own local UI state.

*   **Rationale:** This pattern fully embraces the "State Drives UI" principle. It decouples the component from the action's implementation details. The flow is unidirectional, predictable, and immune to rendering race conditions. It transforms a complex, imperative callback chain into a simple, declarative observation of state.

    **Flow:**
    `Component Action -> Context State Update (Pending) -> Rerender -> Context Logic -> Context State Update (Resolved) -> Rerender -> Component Effect Reacts to Resolved State`