We are working on Chronicles of Aura, a brutal, procedurally generated turn-based RPG web game experience.
We are implementing features and continuing with the following task:

# Current Task

Fix the following bug: Damage dealt to party members doesn't instantly reflect in the Party Modal. Fix the modal to reflect the real, active stats of the player, updating as they change. Make sure that your implementation causes player state changes to persist after combat and for other modals, like the Inspect modal, to work properly too.

# Problem Solving Strategy 

Analyze my request, the code and all supplamental data to determine requirements, then create a comprehensive solution to implement all requested functionality.
Finally, implemenet the solution in the requested format.

You will need to a full end-to-end analysis to make this solution work, think deeply, analyze thoroughly and ensure that you are not trying to use a quick and easy method, becuase it likely won't work. You've been warned!

# Game Paths

Main Game Src Path: /mnt/c/Users/donalda/Desktop/game_html/app/src/
App.tsx path: /mnt/c/Users/donalda/Desktop/game_html/app/src/App.tsx
Components path: /mnt/c/Users/donalda/Desktop/game_html/app/src/components
.gitignore path: /mnt/c/Users/donalda/Desktop/game_html/app/src/.gitignore

# Game Rules & General Knowledge

This is a section on game rules and general knowledge to ensure your changes align with the vision of the game:

- 1 'game tick' = 1 turn = 6 in-game seconds.
- User actions should be processed and take effect instantly -> never add unnecessary settimeout/setintervals calls.
- Health regeneration effects are intentionally very slow (relative to in-game time). Debuffs are meant to be debillitating. And, even small threats should have the potential to become huge problem if left ignored over time.
- For instance, hunger and thirst decrease at a completely manageable rate: normally. However, if you eat mysterious food in the wilds and throw up, you might find yourself starving to death or dying from dehydration.
- There is limb damage with the possibility of limb loss, leading to a much more tactical gameplay than normal turn-based RPG.
- We prefer random, infinite content generation over static generation whenever possible since dynamic generation leads to infinitely more possibilities.
- We are constantly implementing features to move us toward the goal of making this game less 1-dimensional, more tactical and more interesting.
- We have tslint, so all parameters need to have their types defined or else errors get generated.
- Make sure that useMemo isn't called conditionally, because that generates errors commonly.
- Status effects may be referred to as buffs is they have positive effects and debuffs if they have a negative effect.
