We are working on Chronicles of Aura, a brutal, procedurally generated turn-based RPG web game experience. In this game:

- 1 'game tick' = 1 turn = 6 in-game seconds.
- Health regeneration effects are intentionally very slow (relative to in-game time). Debuffs are meant to be debillitating. And, even small threats should have the potential to become huge problem if left ignored over time.
- For instance, hunger and thirst decrease at a completely manageable rate: normally. However, if you eat mysterious food in the wilds and throw up, you might find yourself starving to death or dying from dehydration.
- There is limb damage with the possibility of limb loss, leading to a much more tactical gameplay than normal turn-based RPG.
- We prefer random, infinite content generation over static generation whenever possible since dynamic generation leads to infinitely more possibilities.
- We are constantly implementing features to move us toward the goal of making this game less 1-dimensional, more tactical and more interesting.
- We have tslint, so all parameters need to have their types defined or else errors get generated.
- Make sure that useMemo isn't called conditionally, because that generates errors commonly.

We are implementing features and continuing with the following task.

# Current Task

The game has gotten quite large. As wuch, we need to do a quality pass on it. Identify 3 core changes to make that will improve the codebase in alignment with the following principles and then implement all of them.

Optimize this code with a focus on high-level software engineering principles. Apply modularity, loose coupling, high cohesion, and single responsibility. Ensure DRY (Don't Repeat Yourself), KISS (Keep It Simple, Stupid), and YAGNI (You Aren’t Gonna Need It) principles. Refactor for reusability, testability, and readability without sacrificing performance. Minimize code footprint, memory usage, and runtime overhead. Break large files/functions into small, self-contained components. Favor pure functions, immutability, and stateless design where possible. Use efficient data structures, eliminate dead code, and avoid premature optimization. Follow clean architecture, use clear separation of concerns, and apply SOLID principles throughout. Output should be lean, maintainable, and scalable.

Remember: We intend to feed our entire codebase into AI, and the AI will also return our full code files, so lower token count and smaller file sizes = ideal. Don't minimize names or split up files to the point of meaninglessness. But, do reduce name length, function sizes, etc. whenever reasonable and whenever such changes do not impact the operational efficiency of the program in a negative way. As a rule of thumb, we should begin to consider breaking a file up once it has 10,000 character, while a file with 15,000 characters or more absolutely must be split up into pieces, even if it leads to a file_[1].ts, file_[2].ts type structure. This is because we must organize the code in such a way that files can be selectively chosen to be fed to AI to handle specific, focused tasks, easily.

# Problem Solving Strategy 

Analyze my request, the code and all supplamental data to determine requirements, then create a comprehensive solution to implement all requested functionality.
Finally, implemenet the solution in the requested format.

# Game Paths

Main Game Src Path: C:\Users\Donald\Desktop\game_html\app\src
App.tsx path: C:\Users\Donald\Desktop\game_html\app\src\App.tsx
Components path: C:\Users\Donald\Desktop\game_html\app\src\components
.gitignore path: C:\Users\Donald\Desktop\game_html\.gitignore
