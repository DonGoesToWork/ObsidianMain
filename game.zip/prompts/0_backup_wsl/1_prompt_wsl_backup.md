We are working on Chronicles of Aura, a brutal, procedurally generated turn-based RPG web game experience.
We are implementing features and continuing with the following task:

# Current Task

[ FILL ]

# REMEMBER:

Do not make any changes beyond the scope of my requested changes.
Do not change the appearance of behaviors of any components beyond the scope of what was requested.
We must ensure that we preserve all existing functionality and ensure that every aspect of the program can the same operations that it could before changes are made after changes are made.

# Problem Solving Strategy 

Analyze my request, perform a full end-to-end analysis of the code and review all supplamental data to determine requirements - then create a comprehensive solution to implement all requested functionality.
Finally, implemenet the solution in the required Output Format.
You will need to a full end-to-end analysis to make this solution work.
Think deeply, analyze thoroughly and ensure that you are not trying to use a quick and easy solution or workaround becuase it likely won't work. You've been warned!

# Game Paths

Main Game Src Path: /mnt/c/Users/donalda/Desktop/game_html/app/src/
App.tsx path: /mnt/c/Users/donalda/Desktop/game_html/app/src/App.tsx
Components path: /mnt/c/Users/donalda/Desktop/game_html/app/src/components
.gitignore path: /mnt/c/Users/donalda/Desktop/game_html/app/src/.gitignore

# Game Rules & General Knowledge

This is a section on game rules and general knowledge to ensure your changes align with the vision of the game:

- 1 'game tick' = 1 turn = 6 in-game seconds.
- User actions should be processed and take effect instantly -> never add unnecessary settimeout/setintervals calls.
- Health regeneration effects are intentionally very slow (relative to in-game time). Debuffs are meant to be debillitating. And, even small threats should have the potential to become huge problem if left ignored over time.
- For instance, hunger and thirst decrease at a completely manageable rate: normally. However, if you eat mysterious food in the wilds and throw up, you might find yourself starving to death or dying from dehydration.
- There is limb damage with the possibility of limb loss, leading to a much more tactical gameplay than normal turn-based RPG.
- We prefer random, infinite content generation over static generation whenever possible since dynamic generation leads to infinitely more possibilities.
- We are constantly implementing features to move us toward the goal of making this game less 1-dimensional, more tactical and more interesting.
- We have tslint, so all parameters need to have their types defined or else errors get generated. Make sure we do not generate any errors like: 'Element implicitly has an 'any' type because expression of type 'any' can't be used to index type 'x'.'
- Make sure that useMemo isn't called conditionally, because that generates errors commonly.
- Status effects may be referred to as buffs is they have positive effects and debuffs if they have a negative effect.
- Our presentation of game elements should be very descriptive to give the player lots of information to make informed choices. This means showing "Difficulty Ratings" for skill rolls, Success/Fail Chance %'s, Exact Damage Amounts, etc., ex format. DR: 5 (20%).
- We should also be generous with the information that we log into the Log Panel and do our best to record game events in there frequently.
- The game should be balanced around a level 1 to 100 experience, with level 1 being a man being beat in the slums as a slave and level 100 being fighting against literal gods. To set the scene, level 1 = slave, level 20 = regular adventurer, level 40 = reputable warrior, lvl 60 = famous warrior, level 80 = peak mortal status, level 100 = godly individual.
- Game Tiers are from 1 to 11 and related to levels from to 1 to 100 as follows: Level 1-9 content = Tier 1, level 10-19 content = Tier 2, level 20-29 content = Tier 3, 30-39 = T4, 40-49 = T5, 50-59 = T6, 60-69 = T7, 70-79 = T8, 80-89 = T9, 90-99 = T10, 100 = T11
- Game Tiers are sometimes referred to as 'Tier 11' or simply 'T11' for short.
- Profession success rate should be balanced around player level versus the Difficulty Rating of a task. Difficulty Ratings should scale from 1-100 similarly to the profession levels and the overall game balance. If a player's profession skill is 10 below or lower than a given Difficulty Rating, they should have a 0% success rate. If it is 10 or above, they should have a 100% success rate.
- We avoid using header values smaller than 'h3' - only use 'h1'/'h2'/'h3' when headers need specified.

# Game Architecture: Core Rules & Intentions

- Central Observer Pattern: All core game state logic must be reactive. A central "Game Rule Observer" (implemented as a useEffect hook in GameProvider) is the single point of authority for enforcing the consequences of state changes. Any change to a core state object (like player) must trigger this observer. This prevents game logic from being scattered and ensures rules are applied globally.

- State Drives UI, Not Actions: UI changes (like showing a modal) are a consequence of a state change, not a direct result of an action. An action changes the state (e.g., setThirst(0)), and the central observer reacts to the new state (e.g., isDead is now true) to trigger the appropriate UI update (e.g., showDeathModal()).

- Immutability is Non-Negotiable: All state updates (setPlayer, setCurrentLocation, etc.) must be performed with new objects and arrays. Directly mutating state will break React's change detection and the observer pattern. This rule applies to all contexts, especially debug functions which are common sources of mutation bugs.

- Single Source of Truth: The state held within GameProvider is the absolute source of truth. All components must derive their data from this central state, preferably through custom hooks (usePlayer, useInventory). Components should never maintain their own local, duplicate copies of game state, as they will become stale.

- Actions Cause, Observers React: Separate the "what happened" from the "what to do about it." Functions that implement user actions or game events (like passTime or useItem) should focus only on making the initial state change. The central observer is then responsible for calculating and applying all cascading consequences (e.g., death, status effects, quest updates, UI changes). This enforces a clean separation of concerns.
